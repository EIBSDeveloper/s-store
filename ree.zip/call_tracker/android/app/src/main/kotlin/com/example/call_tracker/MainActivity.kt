package com.example.call_tracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
