package com.example.call_tracker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import android.util.Log
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.dart.DartExecutor
import io.flutter.embedding.engine.FlutterEngineCache
import io.flutter.plugin.common.MethodChannel

class CallReceiver : BroadcastReceiver() {

    private var callStartTime: Long = 0
    private var lastNumber: String? = null

    override fun onReceive(context: Context, intent: Intent) {
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        if (state == null) return

        when (state) {
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                // Call started
                callStartTime = System.currentTimeMillis()
                lastNumber = number ?: "Unknown"
            }

            TelephonyManager.EXTRA_STATE_IDLE -> {
                // Call ended
                if (callStartTime != 0L) {
                    val durationSec = (System.currentTimeMillis() - callStartTime) / 1000
                    showFlutterOverlay(context, lastNumber ?: "Unknown", durationSec)
                    callStartTime = 0
                }
            }
        }
    }

    private fun showFlutterOverlay(context: Context, number: String, duration: Long) {
        try {
            Log.d("CallReceiver", "Triggering Flutter overlay for number: $number")

            // Create background Flutter engine
            val engine = FlutterEngine(context.applicationContext)
            engine.dartExecutor.executeDartEntrypoint(
                DartExecutor.DartEntrypoint.createDefault()
            )

            val channel = MethodChannel(engine.dartExecutor.binaryMessenger, "call_channel")

            channel.invokeMethod("showOverlay", mapOf(
                "number" to number,
                "duration" to duration
            ))

            FlutterEngineCache.getInstance().put("call_engine", engine)
        } catch (e: Exception) {
            Log.e("CallReceiver", "Error launching Flutter overlay: ${e.message}")
        }
    }
}
