import 'package:call_log/call_log.dart';
import 'package:call_tracker/src/core/app_style.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'src/app/utils/routes/app_pages.dart';
import 'src/core/app_colors.dart';

// import 'package:flutter/material.dart';
// import 'package:lucide_icons/lucide_icons.dart';

// VoiceMessageCard(),
// FeedbackMessageCard(
//   title: "To check client’s feedback",
//   dateTime: "20/10/2025 - 12:00 am",
//   message:
//       "I wanted to follow up to see if you had a chance to review our proposal and share your thoughts...",
// ),

class VoiceMessageCard extends StatelessWidget {
  const VoiceMessageCard({super.key});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.symmetric(vertical: 3, horizontal: 10),
    decoration: AppStyle.decoration,
    child: Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          // Left section: date & message
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    AppColors.getCallTypeIcon(CallType.incoming),
                    Text(
                      "21/02/2025 10:32 am",
                      style: Get.theme.textTheme.bodySmall?.copyWith(
                        color: Get.theme.primaryColor,
                      ),
                    ),

                    Container(
                      decoration: AppStyle.decoration.copyWith(
                        color: Colors.red.withAlpha(50),
                        boxShadow: [],
                      ),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 4,
                        vertical: 2,
                      ),
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      child: const Row(
                        children: [
                          Icon(Icons.circle, color: Colors.red, size: 8),
                          Text(
                            "RCE",
                            style: TextStyle(color: Colors.black, fontSize: 9),
                          ),
                        ],
                      ),
                    ),

                    // LocalAudioPlayer(audioPath: audioPath!),
                  ],
                ),

              const SizedBox(height:5,),
                Text(
                  "Just wanted to confirm if you received my previous email regarding ...",
                  style: Get.theme.textTheme.bodySmall,
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),

          // Right section: play icon and red rec dot
          Column(
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  // Play button circle
                  Container(
                    decoration:  BoxDecoration(
                      color:Get.theme.primaryColor.withAlpha(30),
                      shape: BoxShape.circle,
                    ),
                    padding: const EdgeInsets.all(5),
                    child:  Icon(
                      Icons.play_arrow,
                      color: Get.theme.primaryColor,
                      size: AppStyle.iconSize,
                    ),
                  ),

                  // Red dot positioned bottom right
                  Positioned(
                    bottom: 2,
                    right: 2,
                    child: Container(
                      width: 5,
                      height: 5,
                      decoration: const BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 8),
              Text("10:00", style: Get.theme.textTheme.bodySmall),
            ],
          ),
        ],
      ),
    ),
  );
}

class FeedbackMessageCard extends StatelessWidget {
  final String title;
  final String dateTime;
  final String message;

  const FeedbackMessageCard({
    super.key,
    required this.title,
    required this.dateTime,
    required this.message,
  });

  @override
  Widget build(BuildContext context) => Container(
    decoration: AppStyle.decoration,
    padding: const EdgeInsets.all(10),
    margin: const EdgeInsets.only(bottom: 10),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Vertical black bar
        Container(
          width: 6,
          height: 60,
          decoration: BoxDecoration(
            color: Colors.black87,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        const SizedBox(width: 12),

        // Text content
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Title
              Text(
                title,
                style: Get.theme.textTheme.bodyMedium?.copyWith(
                  color: Get.theme.primaryColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 5),
              // Date and time
              Text(
                dateTime,
                style: Get.theme.textTheme.bodySmall?.copyWith(
                  color: Colors.grey[700],
                ),
              ),
              const SizedBox(height: 5),
              // Message text
              Text(message, style: Get.theme.textTheme.bodySmall),
            ],
          ),
        ),
      ],
    ),
  );
}

// =====

/*class CustomAppDrawer extends StatelessWidget {
  final String selectedItem;

  const CustomAppDrawer({super.key, required this.selectedItem});

  @override
  Widget build(BuildContext context) => Drawer(
    backgroundColor: const Color.fromARGB(
      255,
      255,
      255,
      255,
    ), // Dark blue background
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.only(
        topRight: Radius.circular(24),
        bottomRight: Radius.circular(24),
      ),
    ),
    child: SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // User info section
            const SizedBox(height: 12),
            Row(
              children: [
                CircleAvatar(
                  radius: 24,
                  backgroundColor: Get.theme.primaryColor,
                  child: const Icon(Icons.person, color: Colors.white),
                ),
                const SizedBox(width: 12),
                 Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "User",
                      style: TextStyle(
                        color: Get.theme.primaryColor ,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const Text(
                      "ID: B5002",
                      style: TextStyle(color: Colors.black45, fontSize: 13),
                    ),
                  ],
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.black),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Browse section
             Text(
              "Main menu",
              style: TextStyle(
                color: Get.theme.primaryColor ,
                fontSize: 12,
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 8),

            _buildMenuItem(
              icon: Icons.home,
              title: 'Whatsapp Message',
              selected: selectedItem == "whatsapp",
              onTap: () {
                  Get.toNamed(AppPages.whatsAppMessage);
                },
            ),
            _buildMenuItem(
              icon: Icons.person,
              title: 'Assing to me',
              selected: selectedItem == "Assing",
            ),
            // _buildMenuItem(
            //   icon: Icons.star,
            //   title: "Favorites",
            //   selected: selectedItem == "Favorites",
            // ),
            // _buildMenuItem(
            //   icon: Icons.message,
            //   title: "Help",
            //   selected: selectedItem == "Help",
            // ),

            // const SizedBox(height: 10),
            // const Divider(thickness: 1),
            // const SizedBox(height: 10),

            // History section
             Text(
              "Settings",
              style: TextStyle(
                color:Get.theme.primaryColor ,
                fontSize: 12,
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 8),

            // _buildMenuItem(
            //   icon: Icons.timelapse_sharp,
            //   title: "History",
            //   selected: selectedItem == "History",
            // ),
            _buildMenuItem(
              icon: Icons.notifications,
              title: "Notification",
              selected: selectedItem == "Notification",
            ),

            const Spacer(),

            // Dark Mode toggle
            // Row(
            //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //   children: [
            //      Row(
            //       children: [
            //         Icon(Icons.light_mode, color: Colors.blue.withAlpha(200)),
            //         SizedBox(width: 10),
            //         Text(
            //           "Dark Mode",
            //           style: TextStyle(color: Colors.blue),
            //         ),
            //       ],
            //     ),
            //     Switch(
            //       value: false,
            //       onChanged: (val) {},
            //       activeColor: Colors.blueAccent,
            //     ),
            //   ],
            // ),
          ],
        ),
      ),
    ),
  );

  // Drawer menu item widget
  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    bool selected = false,
    void Function()? onTap,
  }) => Container(
    margin: const EdgeInsets.symmetric(vertical: 4),
    decoration: BoxDecoration(
      color: selected ? Colors.blueAccent.withOpacity(0.2) : Colors.transparent,
      borderRadius: BorderRadius.circular(12),
    ),
    child: ListTile(
      leading: Icon(icon, color: selected ? Colors.blueAccent :Get.theme.primaryColor ),
      title: Text(
        title,
        style: TextStyle(
          color: selected ? Get.theme.primaryColor : Colors.black,
          fontWeight: selected ? FontWeight.bold : FontWeight.normal,
        ),
      ),
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 8),
    ),
  );
}*/

class CustomAppDrawer extends StatelessWidget {
  final String selectedItem;

  const CustomAppDrawer({super.key, required this.selectedItem});

  @override
  Widget build(BuildContext context) {
    final double drawerWidth =
        MediaQuery.of(context).size.width *
        0.72; // ✅ slightly smaller for elegance

    return SizedBox(
      width: drawerWidth,
      child: Drawer(
        backgroundColor: Colors.white,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topRight: Radius.circular(24),
            bottomRight: Radius.circular(24),
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 🔹 Profile Header Card
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Get.theme.primaryColor,
                        Get.theme.primaryColor.withOpacity(0.85),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.15),
                        blurRadius: 8,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.white,
                        child: Icon(
                          Icons.person,
                          color: Get.theme.primaryColor,
                          size: AppStyle.iconSize,
                        ),
                      ),
                      const SizedBox(width: 14),

                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Vetri Vijayan",
                              style: Get.theme.textTheme.bodyMedium?.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              "ID: B5002",
                              style: Get.theme.textTheme.bodySmall?.copyWith(
                                color: Colors.white70,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                      /*IconButton(
                        icon: const Icon(Icons.close, color: Colors.white),
                        onPressed: () => Navigator.pop(context),
                      ),*/
                    ],
                  ),
                ),

                const SizedBox(height: 8),

                // 🔹 Section: Main Menu
                _sectionTitle("Main Menu"),
                _buildMenuItem(
                  icon: Icons.home,
                  title: 'Whatsapp Message',
                  selected: selectedItem == "whatsapp",
                  onTap: () => Get.toNamed(AppPages.whatsAppMessage),
                ),
                _buildMenuItem(
                  icon: Icons.assignment_ind,
                  title: 'Assigned to Me',
                  selected: selectedItem == "Assigned",
                ),
                const SizedBox(height: 8),

                // 🔹 Section: Settings
                _sectionTitle("Settings"),
                _buildMenuItem(
                  icon: Icons.notifications_active,
                  title: "Notifications",
                  selected: selectedItem == "Notification",
                ),

                const Spacer(),

                // 🔹 Footer
                Center(
                  child: Column(
                    children: [
                      const Divider(thickness: 0.5),
                      const SizedBox(height: 10),
                      Text(
                        "App Version 1.0.0",
                        style: TextStyle(
                          color: Colors.grey.shade500,
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height: 10),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// 🔹 Reusable section title widget
  Widget _sectionTitle(String title) => Padding(
    padding: const EdgeInsets.only(left: 8, bottom: 8),
    child: Text(
      title.toUpperCase(),
      style: TextStyle(
        color: Get.theme.primaryColor,
        fontSize: 12,
        fontWeight: FontWeight.w600,
        letterSpacing: 1,
      ),
    ),
  );

  /// 🔹 Reusable drawer menu item
  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    bool selected = false,
    void Function()? onTap,
  }) => Container(
    margin: const EdgeInsets.symmetric(vertical: 4),
    decoration: BoxDecoration(
      color:
          selected
              ? Get.theme.primaryColor.withOpacity(0.1)
              : Get.theme.colorScheme.primaryContainer,
      borderRadius: BorderRadius.circular(12),
    ),
    child: ListTile(
      leading: Icon(
        icon,
        size: AppStyle.iconSize,
        color:
            selected
                ? Get.theme.primaryColor
                : Get.theme.colorScheme.onPrimaryContainer,
      ),
      title: Text(
        title,
        style: Get.theme.textTheme.bodyMedium?.copyWith(
          color: selected ? Get.theme.primaryColor : Colors.black,
          fontWeight: selected ? FontWeight.w600 : FontWeight.normal,
        ),
      ),
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 8),
    ),
  );
}
