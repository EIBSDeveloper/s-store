import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';

class Utils {
  static Future<void> requestContactPermission() async {
    var status = await Permission.contacts.status;
    if (!status.isGranted) {
      await Permission.contacts.request();
    }
  }

  static String formatDuration(int totalSeconds) {
    final minutes = (totalSeconds ~/ 60).toString().padLeft(2, '0');
    final seconds = (totalSeconds % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  static String capitalizeFirstLetter(String input) {
    if (input.isEmpty) return input;
    return '${input[0].toUpperCase()}${input.substring(1)}';
  }
}

String capitalizeFirstLetter(final String input) =>
    input.isEmpty ? input : input[0].toUpperCase() + input.substring(1);

/// Open WhatsApp chat with a specific phone number
Future<void> openWhatsApp(String phoneNumber, {String message = ''}) async {
  final whatsappUrl = Uri.parse(
    "https://wa.me/$phoneNumber?text=${Uri.encodeComponent(message)}",
  );

  if (await canLaunchUrl(whatsappUrl)) {
    await launchUrl(whatsappUrl, mode: LaunchMode.externalApplication);
  } else {
    throw 'Could not launch WhatsApp';
  }
}

/// Open SMS app with a message
Future<void> openSMS(String phoneNumber, {String message = ''}) async {
  final smsUrl = Uri(
    scheme: 'sms',
    path: phoneNumber,
    queryParameters: <String, String>{'body': message},
  );

  if (await canLaunchUrl(smsUrl)) {
    await launchUrl(smsUrl);
  } else {
    throw 'Could not launch SMS';
  }
}


  Color getLabelColor(String label) {
    switch (label.toLowerCase()) {
      case 'food':
        return Colors.green;
      case 'projects':
        return Colors.blue;
      case 'goals':
        return Colors.orange;
      case 'personal':
        return Colors.purple;
      case 'reminders':
        return Colors.red;
      case 'voices':
        return Colors.teal;
      default:
        return Get.theme.colorScheme.primary;
    }
  }
