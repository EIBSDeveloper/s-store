// app_pages.dart

import 'package:call_tracker/src/app/modules/auth/views/screens/login_page.dart';
import 'package:call_tracker/src/app/modules/auth/views/screens/otp_page.dart';
import 'package:call_tracker/src/app/modules/auth/views/screens/splash.dart';
import 'package:call_tracker/src/app/modules/bottombar/views/screens/home.dart';
import 'package:call_tracker/src/app/modules/calls/views/screens/dial_pad.dart';
import 'package:call_tracker/src/app/modules/followups/views/screens/add_followup_page.dart';
import 'package:call_tracker/src/app/modules/followups/views/screens/followups_page.dart';
import 'package:call_tracker/src/app/modules/followups/views/screens/today_followups_page.dart';
import 'package:call_tracker/src/app/modules/leads/views/screens/add_lead_page.dart';
import 'package:call_tracker/src/app/modules/leads/views/screens/leads_page.dart';
import 'package:call_tracker/src/app/modules/notification/views/screens/notifications.dart';
import 'package:call_tracker/src/app/modules/profile/binding/profile_binding.dart';
import 'package:call_tracker/src/app/modules/profile/view/screens/profilescreen.dart';
import 'package:call_tracker/src/app/utils/routes/app_pages.dart';
import 'package:get/get.dart';

import '../../modules/bot/view/screen/smart_farm_binding.dart';
import '../../modules/bot/view/screen/smart_farm_view.dart';
import '../../modules/calls/binding/client_binding.dart';
import '../../modules/calls/views/screens/call_record.dart';
import '../../modules/calls/views/screens/client_details_screen.dart';
import '../../modules/whatsapp/bindings/notes_binding.dart';
import '../../modules/whatsapp/view/screens/note_detail_screen.dart';
import '../../modules/whatsapp/view/screens/notes_screen.dart';
import '../../modules/whatsapp_message/bindings/note_bindings.dart';
import '../../modules/whatsapp_message/view/my_notes_screen.dart';

class Routes {
  static final pages = [
    GetPage(name: AppPages.splash, page: () => const SplashScreen()),
    GetPage(name: AppPages.login, page: () => LoginPage()),
    GetPage(name: AppPages.otp, page: () => OtpPage()),
    GetPage(name: AppPages.home, page: () => const Home()),
    GetPage(name: AppPages.leads, page: () => const LeadsPage()),
    GetPage(name: AppPages.addLead, page: () => const AddLeadPage()),

    GetPage(name: AppPages.dialPad, page: () => const DialPad()),

    GetPage(
      name: AppPages.todayFollowups,
      page: () => const TodayFollowUpsPage(),
    ),
    GetPage(name: AppPages.followups, page: () => const FollowUpsPage()),
    GetPage(name: AppPages.notification, page: () => const Notifications()),
    GetPage(name: AppPages.addFollowup, page: () => const AddFollowUpPage()),
    GetPage(name: AppPages.callRecord, page: () => CallRecordingScreen()),
    // GetPage(name: Routes.test, page: () => const DetailPage()),
    GetPage(
      name: AppPages.logDetails,
      page: () => const ClientDetailsScreen(),
      binding: ClientBinding(),
    ),

    GetPage(
      name: AppPages.whatsAppMessage,
      page: () => const NotesScreen(),
      binding: NotesBinding(),
    ),
    GetPage(
      name: '/add-note',
      page: () => const NoteDetailScreen(),
      binding: NoteDetailBinding(),
    ),
    GetPage(
      name: '/note-detail',
      page: () => const NoteDetailScreen(),
      binding: NoteDetailBinding(),
    ),
    GetPage(
      name: AppPages.bot,
      page: () => const SmartFarmView(),
      binding: SmartFarmBinding(),
    ),
    GetPage(
      name: AppPages.notes,
      page: () => const MyNotesScreen(),
      binding: MessageBinding(),
    ),
    GetPage(
      name: AppPages.notesDetails,
      page: () => const NoteDetailScreen(),
      binding: BindingsBuilder(() {
        MessageDetailBinding().dependencies();
      }),
    ),

    GetPage(
      name: AppPages.profile,
      page: () => const Profilescreen(),
      binding: ProfileBinding(),
    ),
  ];
}
