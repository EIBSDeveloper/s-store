import 'package:hive_flutter/hive_flutter.dart';

import '../../modules/followups/model/followup_model.dart';

class FollowUpRepository {
  final Box<FollowUpModel> _followUpBox = Hive.box<FollowUpModel>('followups');

  List<FollowUpModel> getAllFollowUps() => _followUpBox.values.toList();

  List<FollowUpModel> getFollowUpsByLeadId(String leadId) =>
      _followUpBox.values.where((f) => f.leadId == leadId).toList();

  List<FollowUpModel> getTodayFollowUps() {
    final today = DateTime.now();
    return _followUpBox.values
        .where(
          (f) =>
              f.followUpDate.year == today.year &&
              f.followUpDate.month == today.month &&
              f.followUpDate.day == today.day,
        )
        .toList();
  }

  List<FollowUpModel> filterFollowUpsByStatus(String status) {
    var list = _followUpBox.values.where((f) => f.status == status).toList();
    return list;
  }

  List<FollowUpModel> filterTodayFollowUpsByStatus(String status) {
    final today = DateTime.now();
    var list =
        _followUpBox.values
            .where(
              (f) =>
                  f.status == status &&
                  f.followUpDate.year == today.year &&
                  f.followUpDate.month == today.month &&
                  f.followUpDate.day == today.day,
            )
            .toList();
    return list;
  }

  List<FollowUpModel> filterFollowUpsByLeadId(String id) {
    var list = _followUpBox.values.where((f) => f.status == id).toList();
    return list;
  }

  List<FollowUpModel> searchFollowUps(String query) =>
      _followUpBox.values
          .where((f) => f.reason.toLowerCase().contains(query.toLowerCase()))
          .toList();

  // Asynchronous methods (for operations that might need waiting)
  Future<void> addFollowUp(FollowUpModel followUp) async =>
      await _followUpBox.put(followUp.id, followUp);

  Future<void> updateFollowUp(FollowUpModel followUp) async =>
      await _followUpBox.put(followUp.id, followUp);

  Future<void> deleteFollowUp(String followUpId) async =>
      await _followUpBox.delete(followUpId);

  Future<FollowUpModel?> getFollowUpById(String id) async =>
      _followUpBox.get(id);

  Future<List<FollowUpModel>> getUpcomingFollowUps() async {
    final now = DateTime.now();
    final endOfWeek = now.add(const Duration(days: 7));
    return _followUpBox.values
        .where(
          (f) =>
              f.followUpDate.isAfter(now) && f.followUpDate.isBefore(endOfWeek),
        )
        .toList();
  }
}
