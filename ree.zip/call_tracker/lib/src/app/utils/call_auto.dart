import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

class CallRecordingManager {
  static const platform = MethodChannel('com.yourapp/call_tracker');

  static Future<void> requestPermissions() async {
    await [
      Permission.microphone,
      Permission.phone,
      Permission.storage,
    ].request();
    // startRecording() ;
  }

// static  Future<void> startRecording() async {
//     try {
//       await platform.invokeMethod('startRecording');
//         Future.delayed(
//      Duration(seconds: 10), () => stopRecording());
//     } catch(e) {

//     }
//   }

//  static Future<void> stopRecording() async {
//     try {
//       await platform.invokeMethod('stopRecording');
//     } on PlatformException {
//     }
//   }
}
