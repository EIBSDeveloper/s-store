import 'package:flutter/material.dart';

class Background extends StatelessWidget {
  final Widget? child;
  const Background({super.key, this.child});

  @override
  Widget build(BuildContext context) => Container(
      color: Colors.white,
      child: Container(
        decoration: BoxDecoration(
          // gradient: LinearGradient(
          //   colors: [
          //     const Color.fromARGB(255, 217, 152, 228).withAlpha(30),
          //     const Color.fromARGB(255, 96, 171, 194).withAlpha(30),
          //     const Color.fromARGB(255, 149, 207, 255).withAlpha(30),
          //   ],
          //   begin: Alignment.topLeft,
          //   end: Alignment.bottomRight,
          // ),
        ),
        child: child,
      ),
    );
}
