// import 'package:flutter/material.dart';

// class LeadTile extends StatelessWidget {
//   final Map<String, String> lead;

//   const LeadTile({super.key, required this.lead});

//   @override
//   Widget build(BuildContext context) {
//     return Container(
      
//       decoration: BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.all(Radius.circular(10)),
//         boxShadow:  AppStyle.boxShadow
//       ),
//       margin: const EdgeInsets.symmetric(vertical: 6,horizontal: 5),
//       child: ListTile(
       
//         title: Text(lead['name'] ?? ''),
//         subtitle: Text('${lead['status']} • ${lead['time']}'),
//         trailing: const Icon(Icons.arrow_forward_ios, size: 16),
//       ),
//     );
//   }
// }
