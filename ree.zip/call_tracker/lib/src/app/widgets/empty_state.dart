import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/app_icons.dart';
import '../../core/app_style.dart';
import '../modules/main/view/widgets/action_button.dart';

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) => Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
         ImageView(AppIcons.search,width: AppStyle.iconSize,height: AppStyle.iconSize,),
          const SizedBox(height: 16),
          Text(
            title,
            style:Get.theme.textTheme.titleLarge?.copyWith(
                  color: Colors.grey[600],
                ),
          ),
          const SizedBox(height: 8),
          Text(
            subtitle,
            style:Get.theme.textTheme.bodyMedium?.copyWith(
                  color: Colors.grey[500],
                ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
}