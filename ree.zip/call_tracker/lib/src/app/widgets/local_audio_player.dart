import 'dart:async';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

class LocalAudioPlayer extends StatefulWidget {
  final String audioPath;

  const LocalAudioPlayer({super.key, required this.audioPath});

  @override
  // ignore: library_private_types_in_public_api
  _LocalAudioPlayerState createState() => _LocalAudioPlayerState();
}

class _LocalAudioPlayerState extends State<LocalAudioPlayer> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  PlayerState _playerState = PlayerState.stopped;
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;

  StreamSubscription? _durationSubscription;
  StreamSubscription? _positionSubscription;
  StreamSubscription? _playerCompleteSubscription;
  StreamSubscription? _playerStateChangeSubscription;

  @override
  void initState() {
    super.initState();
    _initAudioPlayer();
  }

  @override
  void dispose() {
    _durationSubscription?.cancel();
    _positionSubscription?.cancel();
    _playerCompleteSubscription?.cancel();
    _playerStateChangeSubscription?.cancel();
    _audioPlayer.dispose();
    super.dispose();
  }

  void _initAudioPlayer() {
    _durationSubscription = _audioPlayer.onDurationChanged.listen((duration) {
      setState(() {
        _duration = duration;
      });
    });

    _positionSubscription = _audioPlayer.onPositionChanged.listen((position) {
      setState(() {
        _position = position;
      });
    });

    _playerCompleteSubscription = _audioPlayer.onPlayerComplete.listen((event) {
      debugPrint('Audio playback complete');
      setState(() {
        _playerState = PlayerState.stopped;
        _position = Duration.zero;
      });
    });

    _playerStateChangeSubscription = _audioPlayer.onPlayerStateChanged.listen((state) {
      debugPrint('Player state changed: $state');
      setState(() {
        _playerState = state;
      });
    });
  }

  Future<void> _play() async {
    if (_playerState == PlayerState.playing) {
      debugPrint('Already playing, ignoring _play call');
      return;
    }
    debugPrint('Starting playback');
    await _audioPlayer.play(DeviceFileSource(widget.audioPath));
    // No need to set _playerState here, listener will do it.
  }

  Future<void> _pause() async {
    debugPrint('Pausing playback');
    await _audioPlayer.pause();
  }
  

  Future<void> _stop() async {
    debugPrint('Stopping playback');
    await _audioPlayer.stop();
    setState(() {
      _position = Duration.zero;
      _playerState = PlayerState.stopped;
    });
  }

  Future<void> _seek(Duration position) async {
    debugPrint('Seeking to ${position.inMilliseconds} ms');
    await _audioPlayer.seek(position);
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final hours = twoDigits(duration.inHours);
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));
    return [if (duration.inHours > 0) hours, minutes, seconds].join(':');
  }

  @override
  Widget build(BuildContext context) {
    final maxSliderValue = _duration.inMilliseconds.toDouble();
    var currentSliderValue = _position.inMilliseconds.toDouble();

    // Safety: prevent slider value overflow (e.g. when position > duration)
    if (currentSliderValue > maxSliderValue) {
      currentSliderValue = maxSliderValue;
    }

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Expanded(
        //   child: Column(
        //     children: [
        //       Slider(
        //         min: 0.0,
        //         max: maxSliderValue > 0 ? maxSliderValue : 1.0,
        //         value: maxSliderValue > 0 ? currentSliderValue : 0.0,
        //         onChanged: (value) => _seek(Duration(milliseconds: value.round())),
        //       ),
        //       if (_playerState == PlayerState.playing || _playerState == PlayerState.paused)
        //         Padding(
        //           padding: const EdgeInsets.symmetric(horizontal: 16.0),
        //           child: Row(
        //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //             children: [
        //               Text(_formatDuration(_position)),
        //               Text(_formatDuration(_duration - _position)),
        //             ],
        //           ),
        //         ),
        //     ],
        //   ),
        // ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // IconButton(
            //   icon: const Icon(Icons.stop),
            //   onPressed: _playerState != PlayerState.stopped ? _stop : null,
            // ),
            IconButton(
              icon: Icon(
                _playerState == PlayerState.playing ? Icons.pause : Icons.mic,
              ),
              onPressed: () async {
                if (_playerState == PlayerState.playing) {
                  await _pause();
                } else {
                  await _play();
                }
              },
            ),
          ],
        ),
      ],
    );
  }
}
