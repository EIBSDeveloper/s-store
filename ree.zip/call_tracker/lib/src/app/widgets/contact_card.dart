// // import 'package:call_log/call_log.dart';

// import 'package:flutter/material.dart';

// class ContactCard extends StatelessWidget {
//   const ContactCard({
//     super.key,
//     required this.name,
//     required this.number,
//     this.image,
//     this.id,
//   });

//   final String name;
//   final String number;
//   final String? image;
//   final String? id;

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: EdgeInsets.all(5),
//       decoration: BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.all(Radius.circular(10)),
//         boxShadow:  AppStyle.boxShadow
//       ),
//       child: Row(
//         children: [
//           CircleAvatar(
//             backgroundColor: const Color.fromARGB(255, 224, 223, 223),
//           ),
//           SizedBox(width: 10),
//           Expanded(
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Text(name, style: TextStyle(fontWeight: FontWeight.bold)),
//                 Padding(
//                   padding: const EdgeInsets.symmetric(vertical: 3),
//                   child: Row(
//                     children: [
//                       Icon(Icons.phone, color: Colors.greenAccent),
//                       Text(" $number"),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
