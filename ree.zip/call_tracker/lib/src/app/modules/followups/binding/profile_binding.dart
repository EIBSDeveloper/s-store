import 'package:call_tracker/src/app/modules/profile/repository/profile_repository.dart';
import 'package:get/get.dart';

import '../contoller/followup_add_controller.dart';

class ProfileBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ProfileRepository>(() => ProfileRepository());
    Get.lazyPut<FollowUpAddController>(() => FollowUpAddController());
  }
}
