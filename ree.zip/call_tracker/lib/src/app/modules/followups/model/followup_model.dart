

import 'package:hive_flutter/hive_flutter.dart';

part 'followup_model.g.dart';

@HiveType(typeId: 1)
class FollowUpModel {
  @HiveField(0)
  final String id;
  
  @HiveField(1)
  final String leadId;
  
  @HiveField(2)
  final DateTime followUpDate;
  
  @HiveField(3)
  final String reason;
  
  @HiveField(4)
  final String status; // Scheduled, Completed, Cancelled, Postponed
  
  @HiveField(5)
  final String notes;
  
  @HiveField(6)
  final DateTime createdAt;

  FollowUpModel({
    required this.id,
    required this.leadId,
    required this.followUpDate,
    required this.reason,
    required this.status,
    required this.notes,
    required this.createdAt,
  });FollowUpModel copyWith({
    String? id,
    String? leadId,
    DateTime? followUpDate,
    String? reason,
    String? status,
    String? notes,
    DateTime? createdAt,
  }) => FollowUpModel(
      id: id ?? this.id,
      leadId: leadId ?? this.leadId,
      followUpDate: followUpDate ?? this.followUpDate,
      reason: reason ?? this.reason,
      status: status ?? this.status,
      notes: notes ?? this.notes,
      createdAt: createdAt ?? this.createdAt,
    );

}