import 'package:flutter/material.dart';

class FollowUp {
  final String? id;
  final DateTime date;
  final TimeOfDay time;
  final String reason;
  final String? notes;
  final DateTime? createdAt;

  FollowUp({
    this.id,
    required this.date,
    required this.time,
    required this.reason,
    this.notes,
    this.createdAt,
  });

  // Add the missing fromJson factory constructor
  factory FollowUp.fromJson(Map<String, dynamic> json) => FollowUp(
      id: json['id'],
      date: DateTime.parse(json['date']),
      time: _parseTimeFromString(json['time']),
      reason: json['reason'] ?? '',
      notes: json['notes'],
      createdAt: json['created_at'] != null ? DateTime.parse(json['created_at']) : null,
    );

  static TimeOfDay _parseTimeFromString(String timeString) {
    try {
      final parts = timeString.split(':');
      final hour = int.parse(parts[0]);
      final minute = int.parse(parts[1]);
      return TimeOfDay(hour: hour, minute: minute);
    } catch (e) {
      return TimeOfDay.now();
    }
  }

  Map<String, dynamic> toJson() => {
      if (id != null) 'id': id,
      'date': _formatDate(date),
      'time': _formatTime(time),
      'reason': reason,
      if (notes != null) 'notes': notes,
      if (createdAt != null) 'created_at': createdAt!.toIso8601String(),
    };

  String _formatDate(DateTime date) => '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';

  String _formatTime(TimeOfDay time) => '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';

  DateTime get combinedDateTime => DateTime(
      date.year,
      date.month,
      date.day,
      time.hour,
      time.minute,
    );

  // Helper method to create a copy with updated values
  FollowUp copyWith({
    String? id,
    DateTime? date,
    TimeOfDay? time,
    String? reason,
    String? notes,
    DateTime? createdAt,
  }) => FollowUp(
      id: id ?? this.id,
      date: date ?? this.date,
      time: time ?? this.time,
      reason: reason ?? this.reason,
      notes: notes ?? this.notes,
      createdAt: createdAt ?? this.createdAt,
    );

  @override
  String toString() => 'FollowUpModel(id: $id, date: $date, time: $time, reason: $reason, notes: $notes)';

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is FollowUp &&
        other.id == id &&
        other.date == date &&
        other.time == time &&
        other.reason == reason &&
        other.notes == notes;
  }

  @override
  int get hashCode => Object.hash(id, date, time, reason, notes);
}

class FollowUpResponse {
  final bool status;
  final String message;
  final FollowUp? data;

  FollowUpResponse({
    required this.status,
    required this.message,
    this.data,
  });

  factory FollowUpResponse.fromJson(Map<String, dynamic> json) => FollowUpResponse(
      status: json['status'] ?? false,
      message: json['message'] ?? '',
      data: json['data'] != null ? FollowUp.fromJson(json['data']) : null,
    );

  Map<String, dynamic> toJson() => {
      'status': status,
      'message': message,
      'data': data?.toJson(),
    };
}