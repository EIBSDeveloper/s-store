import 'package:flutter/material.dart';
import 'package:get/get.dart';

class DetailItem extends StatelessWidget {
  final String label;
  final String value;
  const DetailItem({super.key, required this.label, required this.value});

  @override
  Widget build(BuildContext context) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.only(right: 8),
              child: Text(
                label,
                style: Get.theme.textTheme.bodyMedium?.copyWith(
                  color: Colors.black,
                ),
              ),
            ),
          ),

          Expanded(
            flex: 4,
            child: Text(value, style: Get.theme.textTheme.bodyMedium),
          ),
        ],
      ),
    );
}
