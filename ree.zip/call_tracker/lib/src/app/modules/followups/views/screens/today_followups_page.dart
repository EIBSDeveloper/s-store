import 'package:call_tracker/src/app/widgets/input_card_style.dart';
import 'package:call_tracker/src/core/app_data.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../core/app_colors.dart';
import '../../contoller/followup_controller.dart';
import '../../../../widgets/empty_state.dart';
import '../widgets/followup_card.dart';
import 'followup_detail_page.dart';

class TodayFollowUpsPage extends GetView<FollowUpController> {
  const TodayFollowUpsPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold( backgroundColor: Colors.white,
      appBar: AppBar( backgroundColor: Colors.white,
        title: Text(
          "Today's Followups",
          style: Get.theme.textTheme.titleMedium!,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            Column(
              children: [
                // AppTextField(
                //   hintText: 'Search followups...',
                //   prefixIcon: Icons.search,
                //   onChanged: controller.searchFollowUps,
                // ),
                Obx(
                  () => InputCardStyle(
                 
                    padding:  const EdgeInsets.symmetric(horizontal: 8),
                    child: DropdownButtonFormField<String>(
                      initialValue: controller.todayListFillter.value,
                      items:
                          ['All', ...AppData.followupStatus].map((status) => DropdownMenuItem<String>(
                              value: status,
                              child: Text(
                                status,
                                style: TextStyle(
                                  color: AppColors.getFolloupsStatusColor(
                                    status,
                                  ),
                                ),
                              ),
                            )).toList(),
                      onChanged: (value) => controller.filterTodayFolloUpByStatus(value!),
                      decoration: const InputDecoration(
                        // labelText: 'Filter by status',
                        border: InputBorder.none,
                      ),
                      icon: Icon(
                        Icons.keyboard_arrow_down_outlined,
                        color: Get.theme.primaryColor,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ),
            Expanded(
              child: Obx(() {
                if (controller.todayFollowUps.isEmpty) {
                  return const EmptyState(
                    icon: Icons.calendar_today,
                    title: 'No Followups Today',
                    subtitle: 'All caught up! No followups scheduled for today',
                  );
                }
                return RefreshIndicator(
                  onRefresh: () async => controller.loadTodayFollowUps(),
                  child: ListView.builder(
                    padding: const EdgeInsets.only(bottom: 16),
                    itemCount: controller.todayFollowUps.length,
                    itemBuilder: (context, index) {
                      final followUp = controller.todayFollowUps[index];
                      return FollowUpCard(
                        followUp: followUp,
                        onTap:
                            () => Get.to(
                              () => FollowUpDetailPage(followUp: followUp),
                            ),
                      );
                    },
                  ),
                );
              }),
            ),
          ],
        ),
      ),
    );
}
