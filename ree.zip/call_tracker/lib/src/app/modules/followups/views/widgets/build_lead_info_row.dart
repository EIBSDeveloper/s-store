import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../core/app_style.dart';
import '../../../main/view/widgets/action_button.dart';

class BuildLeadInfoRow extends StatelessWidget {
final String icon; final String text;
  const BuildLeadInfoRow({super.key,required this.icon, required this.text});

  @override
  Widget build(BuildContext context) => Row(
      children: [
        ImageView(icon,width: AppStyle.iconSize2,height: AppStyle.iconSize2,),
        const SizedBox(width: 12),
        Text(text, style: Get.theme.textTheme.bodyMedium),
      ],
    );
}
