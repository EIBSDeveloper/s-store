
import 'package:call_tracker/src/app/modules/followups/contoller/followup_add_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

class AddFollowUpBottomSheet extends GetView<FollowUpAddController> {
  const AddFollowUpBottomSheet({super.key});

  @override
  Widget build(BuildContext context) => Material(
      color: Colors.white,
      borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      clipBehavior: Clip.antiAlias,
      child: SafeArea(
        top: false,
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.5, // Start at 70% height
          minChildSize: 0.5, // Minimum 50%
          maxChildSize: 1.0, // Can expand to full height
          builder: (context, scrollController) => Stack(
              children: [
                // Main scrollable content
                Obx(
                  () => SingleChildScrollView(
                    controller: scrollController,
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 10),
                        _buildHeader(),
                        const SizedBox(height: 8),
                        _buildTabs(),
                        const SizedBox(height: 8),

                        if (controller.selectedTab.value == 'Add Notes')
                          _buildAddNotesSection()
                        else ...[
                          _buildWhenSection(),
                          const SizedBox(height: 8),
                          if (controller.selectedWhenOption.value ==
                              'Custom') ...[
                            _buildDateSection(context),
                            const SizedBox(height: 8),
                            _buildTimeSection(context),
                          ],
                          const SizedBox(height: 8),
                          _buildActionButtons(),
                          const SizedBox(height: 16),
                          _buildPreviousReminders(),
                        ],
                        const SizedBox(height: 30),
                      ],
                    ),
                  ),
                ),

                // Close button
                Positioned(
                  top: 0,
                  right: 0,
                  child: IconButton(
                    icon: Icon(
                      Icons.highlight_remove,
                      color: Get.theme.colorScheme.primary,
                    ),
                    iconSize: 40,
                    onPressed: () => Get.back(),
                  ),
                ),
              ],
            ),
        ),
      ),
    );

  // HEADER
  Widget _buildHeader() => Center(
    child: Container(
      width: 60,
      height: 4,
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.grey[300],
        borderRadius: BorderRadius.circular(4),
      ),
    ),
  );

  // TABS
  Widget _buildTabs() => Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: [
      _buildTab(Icons.note_add, 'Add Notes'),
      _buildTab(Icons.alarm, 'Reminder'),
    ],
  );

  Widget _buildTab(IconData icon, String label) => GestureDetector(
    onTap: () => controller.selectedTab.value = label,
    child: Obx(() {
      final isSelected = controller.selectedTab.value == label;
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 20,
                color: isSelected ? Get.theme.colorScheme.primary : Colors.grey,
              ),
              const SizedBox(width: 6),
              Text(
                label,
                style: Get.theme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color:
                      isSelected ? Get.theme.colorScheme.primary : Colors.grey,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Container(
            height: 2,
            width: 80,
            color:
                isSelected ? Get.theme.colorScheme.primary : Colors.transparent,
          ),
        ],
      );
    }),
  );

  // ADD NOTES
  Widget _buildAddNotesSection() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        'Add your note below:',
        style: TextStyle(fontWeight: FontWeight.w600, color: Colors.grey[700]),
      ),
      const SizedBox(height: 7),
      TextField(
        maxLines: 5,
        onChanged: (val) => controller.noteDescription.value = val,
        decoration: InputDecoration(
          hintText: 'Type your note here...',
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Get.theme.colorScheme.primary,
              width: 1.5,
            ),
          ),
        ),
      ),
      const SizedBox(height: 24),
      SizedBox(
        width: double.infinity,
        child: ElevatedButton(
          onPressed: () {},
          style: ElevatedButton.styleFrom(
            backgroundColor: Get.theme.primaryColor,
            padding: const EdgeInsets.symmetric(vertical: 8),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: Text(
            'SAVE',
            style: Get.theme.textTheme.bodyMedium?.copyWith(
              color: Colors.white,
            ),
          ),
        ),
      ),
    ],
  );

  // WHEN / DATE / TIME / OPTIONS
  Widget _buildWhenSection() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        children: [
          Icon(Icons.timelapse, color: Get.theme.colorScheme.primary),
          const SizedBox(width: 6),
          Text('WHEN?', style: sectionTitleStyle),
        ],
      ),
      const SizedBox(height: 12),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          _buildOption('15 min', controller.selectedWhenOption),
          _buildOption('30 min', controller.selectedWhenOption),
          _buildOption('1 hour', controller.selectedWhenOption),
          _buildOption('2 hours', controller.selectedWhenOption),
          _buildCustomOption('Custom', controller.selectedWhenOption),
        ],
      ),
      const SizedBox(height: 8),
    ],
  );

  Widget _buildDateSection(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        children: [
          Icon(Icons.calendar_today, color: Get.theme.colorScheme.primary),
          const SizedBox(width: 6),
          Text('DATE', style: sectionTitleStyle),
        ],
      ),
      const SizedBox(height: 12),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          _buildOption('Today', controller.selectedDateOption),
          _buildOption('Tomorrow', controller.selectedDateOption),
          _buildOption('In 7 days', controller.selectedDateOption),
          GestureDetector(
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: DateTime.now(),
                firstDate: DateTime(2020),
                lastDate: DateTime(2100),
              );
              if (picked != null) {
                controller.selectedCustomDate.value = DateFormat(
                  'MMM dd, yyyy',
                ).format(picked);
              }
            },
            child: Obx(() {
              final hasDate = controller.selectedCustomDate.isNotEmpty;
              return Container(
                padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(
                    color:
                        hasDate
                            ? Get.theme.colorScheme.primary
                            : Colors.black87,
                  ),
                ),
                child: Text(
                  hasDate ? controller.selectedCustomDate.value : 'Select date',
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    color:
                        hasDate ? Get.theme.colorScheme.primary : Colors.black,
                  ),
                ),
              );
            }),
          ),
        ],
      ),
      const SizedBox(height: 8),
    ],
  );

  Widget _buildTimeSection(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        children: [
          Icon(Icons.access_time, color: Get.theme.colorScheme.primary),
          const SizedBox(width: 6),
          Text('TIME', style: sectionTitleStyle),
        ],
      ),
      const SizedBox(height: 12),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          _buildOption('Morning 5 am', controller.selectedTimeOption),
          _buildOption('Afternoon 1 pm', controller.selectedTimeOption),
          _buildOption('Evening 5 pm', controller.selectedTimeOption),
          _buildOption('Night 8 pm', controller.selectedTimeOption),
          GestureDetector(
            onTap: () async {
              final picked = await showTimePicker(
                context: context,
                initialTime: TimeOfDay.now(),
              );
              if (picked != null) {
                controller.selectedCustomTime.value = picked.format(context);
              }
            },
            child: Obx(() {
              final hasTime = controller.selectedCustomTime.isNotEmpty;
              return Container(
                padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(
                    color:
                        hasTime
                            ? Get.theme.colorScheme.primary
                            : Colors.black87,
                  ),
                ),
                child: Text(
                  hasTime ? controller.selectedCustomTime.value : 'Select time',
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    color:
                        hasTime ? Get.theme.colorScheme.primary : Colors.black,
                  ),
                ),
              );
            }),
          ),
        ],
      ),
      const SizedBox(height: 8),
    ],
  );

  Widget _buildOption(String text, RxString selected) => Obx(() {
    final isSelected = selected.value == text;
    return GestureDetector(
      onTap: () => selected.value = text,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        decoration: BoxDecoration(
          color:
              isSelected ? Get.theme.colorScheme.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: isSelected ? Get.theme.colorScheme.primary : Colors.black87,
          ),
        ),
        child: Text(
          text,
          style: Get.theme.textTheme.bodyMedium?.copyWith(
            color: isSelected ? Colors.white : Colors.black,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  });

  Widget _buildCustomOption(String text, RxString selected) => Obx(() {
    final isSelected = selected.value == text;
    return GestureDetector(
      onTap: () => selected.value = text,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: isSelected ? Get.theme.colorScheme.primary : Colors.black87,
          ),
        ),
        child: Text(
          text,
          style: Get.theme.textTheme.bodyMedium?.copyWith(
            color: isSelected ? Get.theme.colorScheme.primary : Colors.black,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  });

  Widget _buildActionButtons() => Row(
    children: [
      Expanded(
        child: OutlinedButton(
          onPressed: Get.back,
          style: OutlinedButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: 6),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: Text('CANCEL', style: Get.theme.textTheme.bodyMedium),
        ),
      ),
      const SizedBox(width: 12),
      Expanded(
        child: ElevatedButton(
          onPressed: controller.submitFollowUp,
          style: ElevatedButton.styleFrom(
            backgroundColor: Get.theme.primaryColor,
            padding: const EdgeInsets.symmetric(vertical: 6),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: Text(
            'SAVE',
            style: Get.theme.textTheme.bodyMedium?.copyWith(
              color: Colors.white,
            ),
          ),
        ),
      ),
    ],
  );

  Widget _buildPreviousReminders() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Previous reminders',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Get.theme.colorScheme.primary,
            ),
          ),
          GestureDetector(
            onTap: () {},
            child: Text(
              'VIEW ALL',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Get.theme.colorScheme.primary,
              ),
            ),
          ),
        ],
      ),
      const SizedBox(height: 16),
      _buildReminderItem(
        'Reminder to explore Superfone trial',
        'Nov 09, 2025, 09:45 am',
      ),
      const SizedBox(height: 16),
      _buildReminderItem('Remind me!', 'Nov 08, 2025, 09:50 am'),
    ],
  );

  Widget _buildReminderItem(String title, String date) => Container(
    padding: const EdgeInsets.all(16),
    width: double.infinity,
    decoration: BoxDecoration(
      color: Colors.grey[50],
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Colors.grey[200]!),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14),
        ),
        const SizedBox(height: 4),
        Text(date, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
      ],
    ),
  );

  TextStyle get sectionTitleStyle =>
      TextStyle(fontWeight: FontWeight.w600, color: Colors.grey[700]);
}

Future<void> openAddFollowUpBottomSheet() async {
  Get.lazyPut(() => FollowUpAddController());
  await Get.bottomSheet(
    const AddFollowUpBottomSheet(),
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
  );
}
