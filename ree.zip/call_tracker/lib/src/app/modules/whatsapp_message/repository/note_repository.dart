import 'package:get/get.dart';


import '../../../utils/http/http_service.dart';
import '../model/note_model.dart';

class NoteRepository {
   HttpService httpService = Get.find();

  NoteRepository();

  Future<NotesResponse> getNotes({String? search, String? category}) async {
    try {
      final queryParams = <String, dynamic>{};
      if (search != null && search.isNotEmpty) {
        queryParams['search'] = search;
      }
      if (category != null && category != 'All') {
        queryParams['category'] = category;
      }

      // final response = await httpService.get(
      //   '/notes',
      //   queryParams: queryParams,
      // );

      // // Hot code response simulation
      // if (response is Map<String, dynamic>) {
      //   return NotesResponse.fromJson(response);
      // }

      // Fallback hot response for development
      return NotesResponse.fromJson({
        "status": true,
        "message": "Success",
        "data": [
          {
            "id": "1",
            "title": "Meeting Notes",
            "content": "Discussed project timeline and deliverables for Q1 2024.",
            "category": "Work",
            "created_at": "2024-01-15T10:30:00Z",
            "updated_at": "2024-01-15T10:30:00Z",
            "is_bookmarked": true,
            "tags": ["work", "meeting"],
            "bullets": [
              {
                "id": "1",
                "text": "Finalize design mockups",
                "is_checked": true
              },
              {
                "id": "2", 
                "text": "Schedule client review",
                "is_checked": false
              }
            ],
            "attachments": []
          },
          {
            "id": "2",
            "title": "Grocery List",
            "content": "Weekly grocery shopping items for the family.",
            "category": "Family", 
            "created_at": "2024-01-14T16:45:00Z",
            "updated_at": "2024-01-14T16:45:00Z",
            "is_bookmarked": false,
            "tags": ["family", "shopping"],
            "bullets": [
              {
                "id": "1",
                "text": "Milk and eggs",
                "is_checked": false
              },
              {
                "id": "2",
                "text": "Fresh vegetables",
                "is_checked": false
              }
            ],
            "attachments": []
          },
          {
            "id": "3",
            "title": "Personal Goals",
            "content": "Things I want to achieve this year for personal growth.",
            "category": "Personal",
            "created_at": "2024-01-10T09:15:00Z",
            "updated_at": "2024-01-12T14:20:00Z",
            "is_bookmarked": true,
            "tags": ["personal", "goals"],
            "bullets": [],
            "attachments": []
          }
        ]
      });
    } catch (e) {
      throw Exception('Failed to load notes: $e');
    }
  }

  Future<Note> getNoteDetail(String noteId) async {
    try {
      // final response = await httpService.get('/notes/$noteId');

      // // Hot code response
      // if (response is Map<String, dynamic>) {
      //   return Note.fromJson(response['data'] ?? {});
      // }

      // Fallback for development
      return Note.fromJson({
        "id": noteId,
        "title": "Meeting Notes",
        "content": "Discussed project timeline and deliverables for Q1 2024. Need to follow up with the design team about the mockups.",
        "category": "Work",
        "created_at": "2024-01-15T10:30:00Z",
        "updated_at": "2024-01-15T10:30:00Z",
        "is_bookmarked": true,
        "tags": ["work", "meeting", "important"],
        "bullets": [
          {
            "id": "1",
            "text": "Finalize design mockups by Friday",
            "is_checked": true
          },
          {
            "id": "2",
            "text": "Schedule client review meeting",
            "is_checked": false
          },
          {
            "id": "3",
            "text": "Prepare presentation slides",
            "is_checked": false
          }
        ],
        "attachments": []
      });
    } catch (e) {
      throw Exception('Failed to load note details: $e');
    }
  }

  Future<bool> createNote(Note note) async {
    try {
      // final response = await httpService.post('/notes',  note.toJson());
      // return response['status'] ?? true;
      return true;
    } catch (e) {
      // For development, simulate success
      await Future.delayed(const Duration(milliseconds: 500));
      return true;
    }
  }

  Future<bool> updateNote(Note note) async {
    try {
      // final response = await httpService.put('/notes/${note.id}',  note.toJson());
      // return response['status'] ?? true;
      return  true;
    } catch (e) {
      // For development, simulate success
      await Future.delayed(const Duration(milliseconds: 500));
      return true;
    }
  }

  Future<bool> deleteNote(String noteId) async {
    try {
      // final response = await httpService.delete('/notes/$noteId');
      // return response['status'] ?? true;
      return true;
    } catch (e) {
      // For development, simulate success
      await Future.delayed(const Duration(milliseconds: 500));
      return true;
    }
  }

  Future<bool> toggleBookmark(String noteId, bool isBookmarked) async {
    try {
      // final response = await httpService.put(
      //   '/notes/$noteId/bookmark',
      //   {'is_bookmarked': !isBookmarked},
      // );
      // return response['status'] ?? true;
      return  true;
    } catch (e) {
      // For development, simulate success
      await Future.delayed(const Duration(milliseconds: 500));
      return true;
    }
  }
}