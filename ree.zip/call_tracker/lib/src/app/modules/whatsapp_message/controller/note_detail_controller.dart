import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import '../model/note_model.dart';
import '../repository/note_repository.dart';

class NoteDetailController extends GetxController {
  final NoteRepository repository = Get.find();
  final String noteId="0";

  NoteDetailController();

  final Rx<Note?> note = Rx<Note?>(null);
  final RxBool isLoading = false.obs;
  final RxString error = ''.obs;
  final RxBool isEditing = false.obs;
  final RxBool isBookmarked = false.obs;

  final TextEditingController titleController = TextEditingController();
  final TextEditingController contentController = TextEditingController();
  final RxString selectedCategory = 'Personal'.obs;

  final List<String> categories = ['Personal', 'Work', 'Family'];

  @override
  void onInit() {
    super.onInit();
    loadNoteDetail();
  }

  Future<void> loadNoteDetail() async {
    try {
      isLoading.value = true;
      error.value = '';

      final noteData = await repository.getNoteDetail(noteId);
      note.value = noteData;
      isBookmarked.value = noteData.isBookmarked;
      
      // Initialize controllers with note data
      titleController.text = noteData.title;
      contentController.text = noteData.content;
      selectedCategory.value = noteData.category;
    } catch (e) {
      error.value = e.toString();
      _showToast('Failed to load note details', isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  void toggleEditing() {
    isEditing.value = !isEditing.value;
  }

  Future<void> toggleBookmark() async {
    try {
      final currentNote = note.value;
      if (currentNote != null) {
        final success = await repository.toggleBookmark(
          currentNote.id,
          currentNote.isBookmarked,
        );
        
        if (success) {
          isBookmarked.value = !isBookmarked.value;
          note.value = currentNote.copyWith(isBookmarked: isBookmarked.value);
          _showToast(
            isBookmarked.value ? 'Note bookmarked' : 'Note unbookmarked',
          );
        } else {
          _showToast('Failed to update bookmark', isError: true);
        }
      }
    } catch (e) {
      _showToast('Failed to update bookmark', isError: true);
    }
  }

  Future<void> saveNote() async {
    try {
      final currentNote = note.value;
      if (currentNote != null) {
        final updatedNote = currentNote.copyWith(
          title: titleController.text.trim(),
          content: contentController.text.trim(),
          category: selectedCategory.value,
          updatedAt: DateTime.now(),
        );

        final success = await repository.updateNote(updatedNote);
        
        if (success) {
          note.value = updatedNote;
          isEditing.value = false;
          _showToast('Note updated successfully');
        } else {
          _showToast('Failed to update note', isError: true);
        }
      }
    } catch (e) {
      _showToast('Failed to update note', isError: true);
    }
  }

  void updateCategory(String category) {
    selectedCategory.value = category;
  }

  void addBulletPoint() {
    final currentNote = note.value;
    if (currentNote != null) {
      final newBullet = NoteBullet(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        text: '',
      );
      final updatedBullets = List<NoteBullet>.from(currentNote.bullets)..add(newBullet);
      note.value = currentNote.copyWith(bullets: updatedBullets);
    }
  }

  void updateBulletText(int index, String text) {
    final currentNote = note.value;
    if (currentNote != null && index < currentNote.bullets.length) {
      final updatedBullets = List<NoteBullet>.from(currentNote.bullets);
      updatedBullets[index] = updatedBullets[index].copyWith(text: text);
      note.value = currentNote.copyWith(bullets: updatedBullets);
    }
  }

  void toggleBulletCheck(int index) {
    final currentNote = note.value;
    if (currentNote != null && index < currentNote.bullets.length) {
      final updatedBullets = List<NoteBullet>.from(currentNote.bullets);
      updatedBullets[index] = updatedBullets[index].copyWith(
        isChecked: !updatedBullets[index].isChecked,
      );
      note.value = currentNote.copyWith(bullets: updatedBullets);
    }
  }

  void deleteBullet(int index) {
    final currentNote = note.value;
    if (currentNote != null && index < currentNote.bullets.length) {
      final updatedBullets = List<NoteBullet>.from(currentNote.bullets)..removeAt(index);
      note.value = currentNote.copyWith(bullets: updatedBullets);
    }
  }

  void _showToast(String message, {bool isError = false}) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: isError ? Colors.red : Colors.green,
      textColor: Colors.white,
    );
  }

  @override
  void onClose() {
    titleController.dispose();
    contentController.dispose();
    super.onClose();
  }
}