import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import '../model/note_model.dart';
import '../repository/note_repository.dart';

class MyNotesController extends GetxController {
   NoteRepository repository = Get.find();

  MyNotesController();

  final RxList<Note> notes = <Note>[].obs;
  final RxList<Note> filteredNotes = <Note>[].obs;
  final RxBool isLoading = false.obs;
  final RxString error = ''.obs;
  final RxString searchQuery = ''.obs;
  final RxString selectedCategory = 'All'.obs;

  final List<String> categories = ['All', 'Personal', 'Work', 'Family'];

  @override
  void onInit() {
    super.onInit();
    loadNotes();
  }

  Future<void> loadNotes() async {
    try {
      isLoading.value = true;
      error.value = '';

      final response = await repository.getNotes(
        search: searchQuery.value.isEmpty ? null : searchQuery.value,
        category: selectedCategory.value == 'All' ? null : selectedCategory.value,
      );

      if (response.status) {
        notes.value = response.data;
        _filterNotes();
      } else {
        error.value = response.message;
        _showToast(response.message, isError: true);
      }
    } catch (e) {
      error.value = e.toString();
      _showToast('Failed to load notes', isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  void _filterNotes() {
    if (searchQuery.value.isEmpty && selectedCategory.value == 'All') {
      filteredNotes.value = notes;
    } else {
      filteredNotes.value = notes.where((note) {
        final matchesSearch = searchQuery.value.isEmpty ||
            note.title.toLowerCase().contains(searchQuery.value.toLowerCase()) ||
            note.content.toLowerCase().contains(searchQuery.value.toLowerCase());
        
        final matchesCategory = selectedCategory.value == 'All' ||
            note.category == selectedCategory.value;
        
        return matchesSearch && matchesCategory;
      }).toList();
    }
  }

  void onSearchChanged(String query) {
    searchQuery.value = query;
    _filterNotes();
  }

  void onCategoryChanged(String category) {
    selectedCategory.value = category;
    _filterNotes();
  }

  void navigateToNoteDetail(Note note) {
    Get.toNamed('/note-detail', arguments: {'noteId': note.id});
  }

  void navigateToNoteEditor({Note? note}) {
    if (note != null) {
      Get.toNamed('/note-editor', arguments: {'note': note});
    } else {
      Get.toNamed('/note-editor');
    }
  }

  Future<void> deleteNote(String noteId) async {
    try {
      final success = await repository.deleteNote(noteId);
      if (success) {
        notes.removeWhere((note) => note.id == noteId);
        _filterNotes();
        _showToast('Note deleted successfully');
      } else {
        _showToast('Failed to delete note', isError: true);
      }
    } catch (e) {
      _showToast('Failed to delete note', isError: true);
    }
  }

  void _showToast(String message, {bool isError = false}) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: isError ? Colors.red : Colors.green,
      textColor: Colors.white,
    );
  }
}