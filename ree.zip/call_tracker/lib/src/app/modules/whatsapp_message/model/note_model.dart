class Note {
  final String id;
  final String title;
  final String content;
  final String category;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isBookmarked;
  final List<String> tags;
  final List<NoteBullet> bullets;
  final List<NoteAttachment> attachments;

  Note({
    required this.id,
    required this.title,
    required this.content,
    required this.category,
    required this.createdAt,
    required this.updatedAt,
    this.isBookmarked = false,
    this.tags = const [],
    this.bullets = const [],
    this.attachments = const [],
  });

  factory Note.fromJson(Map<String, dynamic> json) => Note(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      content: json['content'] ?? '',
      category: json['category'] ?? 'Personal',
      createdAt: DateTime.parse(json['created_at'] ?? DateTime.now().toString()),
      updatedAt: DateTime.parse(json['updated_at'] ?? DateTime.now().toString()),
      isBookmarked: json['is_bookmarked'] ?? false,
      tags: List<String>.from(json['tags'] ?? []),
      bullets: List<NoteBullet>.from(
          (json['bullets'] ?? []).map((x) => NoteBullet.fromJson(x))),
      attachments: List<NoteAttachment>.from(
          (json['attachments'] ?? []).map((x) => NoteAttachment.fromJson(x))),
    );

  Map<String, dynamic> toJson() => {
      'id': id,
      'title': title,
      'content': content,
      'category': category,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
      'is_bookmarked': isBookmarked,
      'tags': tags,
      'bullets': bullets.map((x) => x.toJson()).toList(),
      'attachments': attachments.map((x) => x.toJson()).toList(),
    };

  Note copyWith({
    String? id,
    String? title,
    String? content,
    String? category,
    DateTime? createdAt,
    DateTime? updatedAt,
    bool? isBookmarked,
    List<String>? tags,
    List<NoteBullet>? bullets,
    List<NoteAttachment>? attachments,
  }) => Note(
      id: id ?? this.id,
      title: title ?? this.title,
      content: content ?? this.content,
      category: category ?? this.category,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      isBookmarked: isBookmarked ?? this.isBookmarked,
      tags: tags ?? this.tags,
      bullets: bullets ?? this.bullets,
      attachments: attachments ?? this.attachments,
    );
}

class NoteBullet {
  final String id;
  final String text;
  final bool isChecked;

  NoteBullet({
    required this.id,
    required this.text,
    this.isChecked = false,
  });

  factory NoteBullet.fromJson(Map<String, dynamic> json) => NoteBullet(
      id: json['id'] ?? '',
      text: json['text'] ?? '',
      isChecked: json['is_checked'] ?? false,
    );

  Map<String, dynamic> toJson() => {
      'id': id,
      'text': text,
      'is_checked': isChecked,
    };

  NoteBullet copyWith({
    String? id,
    String? text,
    bool? isChecked,
  }) => NoteBullet(
      id: id ?? this.id,
      text: text ?? this.text,
      isChecked: isChecked ?? this.isChecked,
    );
}

class NoteAttachment {
  final String id;
  final String type; // image, gif, file
  final String url;
  final String name;

  NoteAttachment({
    required this.id,
    required this.type,
    required this.url,
    required this.name,
  });

  factory NoteAttachment.fromJson(Map<String, dynamic> json) => NoteAttachment(
      id: json['id'] ?? '',
      type: json['type'] ?? '',
      url: json['url'] ?? '',
      name: json['name'] ?? '',
    );

  Map<String, dynamic> toJson() => {
      'id': id,
      'type': type,
      'url': url,
      'name': name,
    };
}

class NotesResponse {
  final bool status;
  final String message;
  final List<Note> data;

  NotesResponse({
    required this.status,
    required this.message,
    required this.data,
  });

  factory NotesResponse.fromJson(Map<String, dynamic> json) => NotesResponse(
      status: json['status'] ?? false,
      message: json['message'] ?? '',
      data: List<Note>.from((json['data'] ?? []).map((x) => Note.fromJson(x))),
    );
}