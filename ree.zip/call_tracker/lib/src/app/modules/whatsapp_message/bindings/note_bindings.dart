import 'package:get/get.dart';

import '../controller/my_notes_controller.dart';
import '../controller/note_detail_controller.dart';
import '../repository/note_repository.dart';

class MessageBinding extends Bindings {
  @override
  void dependencies() {
     Get.lazyPut<NoteRepository>(
      () => NoteRepository( ),
    );
    
    Get.lazyPut<MyNotesController>(
      () => MyNotesController(),
    );
  }
}

class MessageDetailBinding extends Bindings {
  

  MessageDetailBinding();

  @override
  void dependencies() {
     Get.lazyPut<NoteRepository>(
      () => NoteRepository( ),
    );
    Get.lazyPut<NoteDetailController>(
      () => NoteDetailController( ),
    ); 
   
  }
}