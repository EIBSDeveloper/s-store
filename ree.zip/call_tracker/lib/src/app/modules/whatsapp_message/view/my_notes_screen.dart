import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../controller/my_notes_controller.dart';
import '../model/note_model.dart';

class MyNotesScreen extends GetView<MyNotesController> {
  const MyNotesScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(
        title: Text('notes_title'.tr),
        actions: [
          IconButton(
            icon: CircleAvatar(
              radius: 16,
              backgroundColor: Get.theme.primaryColor,
              child: const Text(
                'U',
                style: TextStyle(color: Colors.white, fontSize: 12),
              ),
            ),
            onPressed: () {
              // Navigate to profile
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            _buildSearchSection(),
            _buildCategoryFilter(),
            _buildNotesList(),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => controller.navigateToNoteEditor(),
        backgroundColor: Get.theme.primaryColor,
        child: const Icon(Icons.add),
      ),
    );

  Widget _buildSearchSection() => Padding(
      padding: const EdgeInsets.all(16),
      child: TextField(
        onChanged: controller.onSearchChanged,
        decoration: InputDecoration(
          hintText: 'search_hint'.tr,
          prefixIcon: const Icon(Icons.search),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        ),
      ),
    );

  Widget _buildCategoryFilter() => Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: controller.categories.map((category) {
            final isSelected = controller.selectedCategory.value == category;
            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: FilterChip(
                label: Text(category),
                selected: isSelected,
                onSelected: (_) => controller.onCategoryChanged(category),
                selectedColor: Get.theme.primaryColor.withOpacity(0.2),
                checkmarkColor: Get.theme.primaryColor,
                backgroundColor: Colors.grey[100],
                labelStyle: TextStyle(
                  color: isSelected ? Get.theme.primaryColor : Colors.grey[700],
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );

  Widget _buildNotesList() => Expanded(
      child: Obx(() {
        if (controller.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }

        if (controller.error.value.isNotEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(controller.error.value),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: controller.loadNotes,
                  child: Text('retry'.tr),
                ),
              ],
            ),
          );
        }

        if (controller.filteredNotes.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.note_add, size: 64, color: Colors.grey[400]),
                const SizedBox(height: 16),
                Text(
                  'no_notes'.tr,
                  style: Get.theme.textTheme.bodyMedium,
                ),
              ],
            ),
          );
        }

        return Padding(
          padding: const EdgeInsets.all(16),
          child: ListView.builder(
            itemCount: controller.filteredNotes.length,
            itemBuilder: (context, index) {
              final note = controller.filteredNotes[index];
              return _buildNoteCard(note);
            },
          ),
        );
      }),
    );

  Widget _buildNoteCard(Note note) => Card(
      elevation: 2,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: Icon(
          _getCategoryIcon(note.category),
          color: _getCategoryColor(note.category),
          size: 32,
        ),
        title: Text(
          note.title,
          style: Get.theme.textTheme.titleMedium!.copyWith(
            fontWeight: FontWeight.w600,
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text(
              note.content,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: Get.theme.textTheme.bodyMedium,
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _getCategoryColor(note.category).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    note.category,
                    style: TextStyle(
                      color: _getCategoryColor(note.category),
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                const Spacer(),
                if (note.isBookmarked)
                  const Icon(Icons.bookmark, color: Colors.amber, size: 16),
                const SizedBox(width: 4),
                Text(
                  _formatDate(note.updatedAt),
                  style: Get.theme.textTheme.bodySmall,
                ),
              ],
            ),
          ],
        ),
        onTap: () => controller.navigateToNoteDetail(note),
        onLongPress: () {
          _showDeleteDialog(note);
        },
      ),
    );

  void _showDeleteDialog(Note note) {
    Get.dialog(
      AlertDialog(
        title: const Text('Delete Note'),
        content: Text('Are you sure you want to delete "${note.title}"?'),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Get.back();
              controller.deleteNote(note.id);
            },
            child: const Text(
              'Delete',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }

  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Work':
        return Icons.work;
      case 'Personal':
        return Icons.person;
      case 'Family':
        return Icons.family_restroom;
      default:
        return Icons.note;
    }
  }

  Color _getCategoryColor(String category) {
    switch (category) {
      case 'Work':
        return Colors.blue;
      case 'Personal':
        return Colors.green;
      case 'Family':
        return Colors.orange;
      default:
        return Get.theme.primaryColor;
    }
  }

  String _formatDate(DateTime date) => DateFormat('MMM dd, yyyy').format(date);
}