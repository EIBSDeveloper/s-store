import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../controller/note_detail_controller.dart';
import '../model/note_model.dart';

class NoteDetailScreen extends GetView<NoteDetailController> {
  

  const NoteDetailScreen({super.key,});

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        title: Text('notes_title'.tr),
        actions: [
          Obx(() => IconButton(
            icon: Icon(
              controller.isBookmarked.value 
                  ? Icons.bookmark 
                  : Icons.bookmark_border,
              color: controller.isBookmarked.value ? Colors.amber : null,
            ),
            onPressed: controller.toggleBookmark,
          )),
          Obx(() => IconButton(
            icon: Icon(controller.isEditing.value ? Icons.save : Icons.edit),
            onPressed: () {
              if (controller.isEditing.value) {
                controller.saveNote();
              } else {
                controller.toggleEditing();
              }
            },
          )),
        ],
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }

        if (controller.error.value.isNotEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(controller.error.value),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: controller.loadNoteDetail,
                  child: Text('retry'.tr),
                ),
              ],
            ),
          );
        }

        final note = controller.note.value;
        if (note == null) {
          return Center(child: Text('no_data'.tr));
        }

        return _buildContent(note);
      }),
      bottomNavigationBar: Obx(() => controller.isEditing.value 
          ? _buildFormattingToolbar() 
          : const SizedBox(),
      ),
    );

  Widget _buildContent(Note note) => SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildTimestamp(note),
          const SizedBox(height: 16),
          _buildTitleSection(),
          const SizedBox(height: 16),
          _buildCategorySection(),
          const SizedBox(height: 16),
          _buildContentSection(),
          const SizedBox(height: 16),
          _buildBulletsSection(),
          const SizedBox(height: 16),
          _buildTagsSection(note),
        ],
      ),
    );

  Widget _buildTimestamp(Note note) => Row(
      children: [
        const Icon(Icons.access_time, size: 16, color: Colors.grey),
        const SizedBox(width: 4),
        Text(
          'Created ${_formatDateTime(note.createdAt)}',
          style: Get.theme.textTheme.bodySmall,
        ),
        const SizedBox(width: 16),
        Text(
          'Updated ${_formatDateTime(note.updatedAt)}',
          style: Get.theme.textTheme.bodySmall,
        ),
      ],
    );

  Widget _buildTitleSection() => Obx(() {
      if (controller.isEditing.value) {
        return TextField(
          controller: controller.titleController,
          decoration: InputDecoration(
            hintText: 'title_hint'.tr,
            border: InputBorder.none,
            contentPadding: EdgeInsets.zero,
          ),
          style: Get.theme.textTheme.headlineSmall!.copyWith(
            fontWeight: FontWeight.bold,
          ),
          maxLines: null,
        );
      } else {
        return Text(
          controller.titleController.text,
          style: Get.theme.textTheme.headlineSmall!.copyWith(
            fontWeight: FontWeight.bold,
          ),
        );
      }
    });

  Widget _buildCategorySection() => Obx(() {
      if (controller.isEditing.value) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Category',
              style: Get.theme.textTheme.titleSmall,
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: controller.categories.map((category) {
                final isSelected = controller.selectedCategory.value == category;
                return ChoiceChip(
                  label: Text(category),
                  selected: isSelected,
                  onSelected: (_) => controller.updateCategory(category),
                  selectedColor: _getCategoryColor(category).withOpacity(0.2),
                  labelStyle: TextStyle(
                    color: isSelected ? _getCategoryColor(category) : Colors.grey[700],
                  ),
                );
              }).toList(),
            ),
          ],
        );
      } else {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: _getCategoryColor(controller.selectedCategory.value).withOpacity(0.1),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Text(
            controller.selectedCategory.value,
            style: TextStyle(
              color: _getCategoryColor(controller.selectedCategory.value),
              fontWeight: FontWeight.w500,
            ),
          ),
        );
      }
    });

  Widget _buildContentSection() => Obx(() {
      if (controller.isEditing.value) {
        return TextField(
          controller: controller.contentController,
          decoration: InputDecoration(
            hintText: 'content_hint'.tr,
            border: InputBorder.none,
            contentPadding: EdgeInsets.zero,
          ),
          style: Get.theme.textTheme.bodyLarge,
          maxLines: null,
          keyboardType: TextInputType.multiline,
        );
      } else {
        return Text(
          controller.contentController.text,
          style: Get.theme.textTheme.bodyLarge,
        );
      }
    });

  Widget _buildBulletsSection() => Obx(() {
      final bullets = controller.note.value?.bullets ?? [];
      
      if (bullets.isEmpty && !controller.isEditing.value) {
        return const SizedBox();
      }

      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (controller.isEditing.value || bullets.isNotEmpty) ...[
            Text(
              'Bullet Points',
              style: Get.theme.textTheme.titleSmall,
            ),
            const SizedBox(height: 8),
          ],
          ...bullets.asMap().entries.map((entry) {
            final index = entry.key;
            final bullet = entry.value;
            return _buildBulletItem(bullet, index);
          }),
          if (controller.isEditing.value) ...[
            const SizedBox(height: 8),
            ElevatedButton.icon(
              onPressed: controller.addBulletPoint,
              icon: const Icon(Icons.add),
              label: const Text('Add Bullet Point'),
              style: ElevatedButton.styleFrom(
                // primary: Colors.transparent,
                // onPrimary: Get.theme.primaryColor,
                elevation: 0,
              ),
            ),
          ],
        ],
      );
    });

  Widget _buildBulletItem(NoteBullet bullet, int index) => Obx(() {
      if (controller.isEditing.value) {
        return Row(
          children: [
            Checkbox(
              value: bullet.isChecked,
              onChanged: null, // Disable during editing
            ),
            Expanded(
              child: TextField(
                controller: TextEditingController(text: bullet.text),
                onChanged: (text) => controller.updateBulletText(index, text),
                decoration: const InputDecoration(
                  hintText: 'Enter bullet point...',
                  border: InputBorder.none,
                ),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () => controller.deleteBullet(index),
            ),
          ],
        );
      } else {
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Checkbox(
              value: bullet.isChecked,
              onChanged: (_) => controller.toggleBulletCheck(index),
            ),
            Expanded(
              child: Text(
                bullet.text,
                style: Get.theme.textTheme.bodyLarge!.copyWith(
                  decoration: bullet.isChecked ? TextDecoration.lineThrough : null,
                ),
              ),
            ),
          ],
        );
      }
    });

  Widget _buildTagsSection(Note note) {
    if (note.tags.isEmpty) return const SizedBox();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Tags',
          style: Get.theme.textTheme.titleSmall,
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: note.tags.map((tag) => Chip(
              label: Text(
                tag,
                style: const TextStyle(fontSize: 12),
              ),
              backgroundColor: Colors.grey[100],
              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
            )).toList(),
        ),
      ],
    );
  }

  Widget _buildFormattingToolbar() => Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Colors.grey[300]!)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildToolbarButton(Icons.format_bold, 'Bold'),
          _buildToolbarButton(Icons.format_italic, 'Italic'),
          _buildToolbarButton(Icons.format_underlined, 'Underline'),
          _buildToolbarButton(Icons.format_list_bulleted, 'Bullet List'),
          _buildToolbarButton(Icons.format_align_left, 'Align Left'),
          _buildToolbarButton(Icons.format_align_center, 'Align Center'),
          _buildToolbarButton(Icons.format_align_right, 'Align Right'),
        ],
      ),
    );

  Widget _buildToolbarButton(IconData icon, String tooltip) => IconButton(
      icon: Icon(icon, size: 20),
      onPressed: () {
        // Implement formatting logic
        // controller._showToast('$tooltip formatting applied');
      },
      tooltip: tooltip,
    );

  Color _getCategoryColor(String category) {
    switch (category) {
      case 'Work':
        return Colors.blue;
      case 'Personal':
        return Colors.green;
      case 'Family':
        return Colors.orange;
      default:
        return Get.theme.primaryColor;
    }
  }

  String _formatDateTime(DateTime date) => DateFormat('MMM dd, yyyy - HH:mm').format(date);
}