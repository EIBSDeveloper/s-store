// lead_controller.dart
import 'package:get/get.dart';

import '../../../utils/repository/lead_repository.dart';
import '../../whatsapp/modules/note_model.dart';
import '../model/lead_model.dart';

class LeadController extends GetxController {
  final LeadRepository _leadRepository = Get.find();
  final RxList<LeadModel> leads = <LeadModel>[].obs;
  final RxString searchQuery = ''.obs;
  final RxString selectedType = 'All'.obs;
  final RxString selectedLabel = 'All'.obs;
  final RxList<NoteFilter> labels =
      <NoteFilter>[
        NoteFilter(label: "All", isSelected: false),
        NoteFilter(label: "CRM", isSelected: false),
        NoteFilter(label: "Assigned by me", isSelected: false),
        NoteFilter(label: "Assigned to me", isSelected: false),
        NoteFilter(label: "Others", isSelected: false),
      ].obs;
  @override
  void onInit() {
    addTestLeads();
    loadLeads();
    super.onInit();
  }

  void loadLeads() {
    leads.value = _leadRepository.getAllLeads();
    // if (labels.isEmpty) {

    // }
  }

  // Add this method to your controller or wherever your leads list is defined
  Future<void> addTestLeads() async {
    if (leads.isNotEmpty) {
      return;
    }
    final testLeads = [
      LeadModel(
        id: '100',
        name: 'John Doe',
        phone: '+1234567890',
        city: 'New York',
        state: 'NY',
        type: 'Hot',
        notes: 'Interested in our premium service',
        createdAt: DateTime.now().subtract(const Duration(days: 1)),
        isActive: true,
      ),
      LeadModel(
        id: '102',
        name: 'Jane Smith',
        phone: '+1987654321',
        city: 'Los Angeles',
        state: 'CA',
        type: 'Warm',
        notes: 'Requested a callback',
        createdAt: DateTime.now().subtract(const Duration(days: 3)),
        isActive: true,
      ),
      LeadModel(
        id: '103',
        name: 'Mike Johnson',
        phone: '+1122334455',
        city: 'Chicago',
        state: 'IL',
        type: 'Cold',
        notes: 'Needs follow-up in 2 weeks',
        createdAt: DateTime.now().subtract(const Duration(days: 7)),
        isActive: true,
      ),
      LeadModel(
        id: '104',
        name: 'Sarah Wilson',
        phone: '+1567890123',
        city: 'Miami',
        state: 'FL',
        type: 'Hot',
        notes: 'Ready to purchase',
        createdAt: DateTime.now().subtract(const Duration(days: 2)),
        isActive: true,
      ),
      LeadModel(
        id: '105',
        name: 'David Brown',
        phone: '+1345678901',
        city: 'Seattle',
        state: 'WA',
        type: 'Warm',
        notes: 'Comparing with competitors',
        createdAt: DateTime.now().subtract(const Duration(days: 5)),
        isActive: true,
      ),
    ];

    for (final lead in testLeads) {
      await _leadRepository.addLead(lead);
    }
  }

  // Call this method to add the test data
  // addTestLeads();
  void filterByLabel(String label) {
    selectedLabel(label);
    // loadNotes();
  }

  LeadModel? getLeadById(String leadId) =>
      leads.firstWhereOrNull((lead) => lead.id == leadId);

  void searchLeads(String query) {
    searchQuery.value = query;
    if (query.isEmpty && selectedType.value == 'All') {
      loadLeads();
    } else if (query.isEmpty) {
      leads.value = _leadRepository.filterLeadsByType(selectedType.value);
    } else if (selectedType.value == 'All') {
      leads.value = _leadRepository.searchLeads(query);
    } else {
      leads.value =
          _leadRepository
              .filterLeadsByType(selectedType.value)
              .where(
                (lead) => lead.name.toLowerCase().contains(query.toLowerCase()),
              )
              .toList();
    }
  }

  void filterByType(String type) {
    selectedType.value = type;
    if (type == 'All') {
      loadLeads();
    } else {
      leads.value = _leadRepository.filterLeadsByType(type);
    }
  }

  Future<void> addLead(LeadModel lead) async {
    await _leadRepository.addLead(lead);
    loadLeads();
  }

  Future<void> updateLead(LeadModel lead) async {
    await _leadRepository.updateLead(lead);
    loadLeads();
  }

  Future<void> updateLeadStatus(String leadId, String newStatus) async {
    try {
      final lead = _leadRepository.getLeadById(leadId);
      if (lead != null) {
        final updatedLead = lead.copyWith(type: newStatus);
        await _leadRepository.updateLead(updatedLead);
        loadLeads();
      }
    } catch (e) {
      Get.snackbar('Warning', 'Failed to update lead status: ${e.toString()}');
    }
  }

  List<LeadModel> searchLeadsForFollowUp(String query) =>
      _leadRepository.searchLeads(query);

  Future<void> deleteLead(String leadId) async {
    await _leadRepository.deleteLead(leadId);
    loadLeads();
  }
}
