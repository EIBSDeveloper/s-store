import 'package:call_log/call_log.dart';
import 'package:call_tracker/src/app/modules/calls/contoller/call_log_contoller.dart';
import 'package:call_tracker/src/app/modules/followups/contoller/followup_controller.dart';
import 'package:call_tracker/src/app/modules/leads/views/widgets/detail_row.dart';
import 'package:call_tracker/src/app/widgets/background.dart';
import 'package:call_tracker/src/core/app_data.dart';
import 'package:flutter/material.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../../../core/app_colors.dart';
import '../../../../../core/app_icons.dart';
import '../../../../../core/app_style.dart';
import '../../../../utils/utils.dart';
import '../../../../widgets/toggle_bar.dart';
import '../../../calls/views/widgets/call_log_card.dart';
import '../../../followups/model/followup_model.dart';
import '../../../followups/views/screens/followup_detail_page.dart';
import '../../../followups/views/widgets/followup_card.dart';
import '../../../main/view/widgets/action_button.dart';
import '../../contoller/lead_controller.dart';
import '../../model/lead_model.dart';

class LeadDetailPage extends StatefulWidget {
  final LeadModel lead;
  const LeadDetailPage({super.key, required this.lead});

  @override
  // ignore: library_private_types_in_public_api
  _LeadDetailPageState createState() => _LeadDetailPageState();
}

class _LeadDetailPageState extends State<LeadDetailPage> {
  LeadController controller = Get.put(LeadController());
  FollowUpController folloUpController = Get.put(FollowUpController());
  CallLogController callLogController = Get.put(CallLogController());
  String? _selectedType;
  List<FollowUpModel> followUps = [];
  List<CallLogEntry> callLogs = [];
  int tab = 0;
  @override
  void initState() {
    super.initState();
    _selectedType = widget.lead.type;
    update();
  }

  Future<void> update() async {
    setState(() {
      followUps = folloUpController.getFollowUpsByLeadId(widget.lead.id);
      callLogController.fetchCallLogsByNumber(widget.lead.phone);
    });
  }

  @override
  Widget build(BuildContext context) {
    LeadModel lead = widget.lead;

    return Background(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: Text(
            'Lead Details',
            style: Get.theme.textTheme.titleLarge!.copyWith(
              color: Get.theme.primaryColor,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        body: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Name Row
                  DetailRow(
                    icon: AppIcons.user3,
                    text: Utils.capitalizeFirstLetter(lead.name),
                  ),

                  // Phone Row
                  DetailRow(
                    icon: AppIcons.call,
                    text: lead.phone,
                    isPhone: true,
                  ),

                  // Location Row
                  DetailRow(
                    icon: AppIcons.location,
                    text: '${lead.city}, ${lead.state}',
                  ),

                  // Lead Type Dropdown
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Row(
                      children: [
                        ImageView(
                          AppIcons.edit,
                          width: AppStyle.iconSize2,
                          height: AppStyle.iconSize2,
                        ),

                        const SizedBox(width: 16),
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: Colors.grey.shade300,
                                width: 1,
                              ),
                              boxShadow: AppStyle.boxShadow,
                            ),
                            child: DropdownButton<String>(
                              value: _selectedType,
                              underline: const SizedBox(),
                              isExpanded: true,
                              icon: Icon(
                                Icons.keyboard_arrow_down,
                                color: Get.theme.primaryColor,
                              ),
                              items:
                                  AppData.leadTypes
                                      .map(
                                        (type) => DropdownMenuItem<String>(
                                          value: type,
                                          child: Text(
                                            type,
                                            style: TextStyle(
                                              color: AppColors.getLeadTypeColor(
                                                type,
                                              ),
                                              fontSize: 16,
                                            ),
                                          ),
                                        ),
                                      )
                                      .toList(),
                              onChanged:
                                  (value) => setState(() {
                                    _selectedType = value!;
                                    controller.updateLeadStatus(lead.id, value);
                                  }),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Notes Section (if available)
                  if (lead.notes.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(
                      'Info',
                      style: Get.theme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: Get.theme.primaryColor,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Get.theme.colorScheme.secondaryContainer,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        lead.notes,
                        style: Get.theme.textTheme.bodyMedium,
                      ),
                    ),
                  ],
                ],
              ),
            ),

            Expanded(
              child: Stack(
                children: [
                  Container(
                    decoration: const BoxDecoration(
                      color: Color.fromARGB(158, 255, 255, 255),
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(50),
                        topRight: Radius.circular(50),
                      ),
                      // boxShadow: AppStyle.boxShadow,
                    ),
                    margin: const EdgeInsets.only(top: 15),
                    padding: const EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        const SizedBox(height: 10),
                        ToggleBar(
                          onTap: (index) {
                            setState(() {
                              tab = index;
                            });
                          },
                          activePageIndex: tab,
                          buttonsList: ['Follows', "Call logs"],
                        ),
                        const SizedBox(height: 10),
                        if (tab == 0)
                          Expanded(
                            child: ListView.builder(
                              padding: const EdgeInsets.only(
                                bottom: 16,
                                right: 10,
                                left: 10,
                              ),
                              itemCount: followUps.length,
                              itemBuilder: (context, index) {
                                final followUp = followUps[index];
                                return FollowUpCard(
                                  followUp: followUp,
                                  noCall: false,
                                  onTap:
                                      () => Get.to(
                                        () => FollowUpDetailPage(
                                          followUp: followUp,
                                        ),
                                      ),
                                );
                              },
                            ),
                          ),
                        if (tab == 1) _buildCallLogList(),
                      ],
                    ),
                  ),
                  Positioned(
                    top: 0,
                    right: 10,
                    child: InkWell(
                      onTap: () {
                        FlutterPhoneDirectCaller.callNumber(lead.phone);
                      },
                      child: Container(
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.all(Radius.circular(50)),

                          boxShadow: AppStyle.boxShadow,
                        ),
                        padding: const EdgeInsets.all(13),
                        child: ImageView(
                          AppIcons.call,
                          width: AppStyle.iconSize,
                          height: AppStyle.iconSize,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCallLogList() => Expanded(
    child: Obx(() {
      if (callLogController.isLoadNumberCallsLog.value) {
        return const Center(child: CircularProgressIndicator());
      }

      final grouped = callLogController.numberCallLogs;
      if (grouped.isEmpty) {
        return const Center(child: Text("No call logs found."));
      }

      return RefreshIndicator(
        onRefresh:
            () => callLogController.fetchCallLogsByNumber(widget.lead.phone),
        child: ListView.separated(
          physics: const AlwaysScrollableScrollPhysics(),
          itemCount: grouped.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, index) {
            final date = grouped.keys.elementAt(index);
            final entries = grouped[date]!;

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(10),
                  child: Text(
                    date,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                ...entries.map(
                  (entry) => CallLogCard(
                    name:
                        entry.name?.isNotEmpty == true
                            ? entry.name!
                            : entry.number.toString(),
                    duration: entry.duration.toString(),
                    number: entry.number.toString(),

                    startTime: DateFormat('hh:mm a').format(
                      DateTime.fromMillisecondsSinceEpoch(entry.timestamp ?? 0),
                    ),
                    endTime: entry.timestamp.toString(),
                    callType: entry.callType!,
                  ),
                ),
              ],
            );
          },
        ),
      );
    }),
  );
}
