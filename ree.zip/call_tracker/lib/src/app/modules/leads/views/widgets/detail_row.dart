import 'package:flutter/material.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:get/get.dart';

import '../../../../../core/app_style.dart';
import '../../../main/view/widgets/action_button.dart';

class DetailRow extends StatelessWidget {
  final String icon;
  final String text;
  final bool isPhone;
  const DetailRow({
    super.key,
    required this.icon,
    required this.text,
    this.isPhone = false,
  });

  @override
  Widget build(BuildContext context) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          // Icon(icon, color: Get.theme.primaryColor, size: 24),
         ImageView(icon,width: AppStyle.iconSize2,height: AppStyle.iconSize2,),
          const SizedBox(width: 16),
          if (isPhone)
            InkWell(
              onTap: () => FlutterPhoneDirectCaller.callNumber(text),
              child: Text(
                text,
                style: TextStyle(
                  color: Get.theme.primaryColor,
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            )
          else
            Text(
              text,
              style: TextStyle(
                color: Get.theme.primaryColor,
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
        ],
      ),
    );
}
