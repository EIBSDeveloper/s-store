import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:get/get.dart';

import '../../../../../core/app_colors.dart';
import '../../../../../core/app_icons.dart';
import '../../../../../core/app_style.dart';
import '../../../../utils/routes/app_pages.dart';
import '../../../../utils/utils.dart';
import '../../../main/view/widgets/action_button.dart';
import '../../model/lead_model.dart';

class LeadCard extends StatelessWidget {
  final LeadModel lead;
  final VoidCallback onTap;

  const LeadCard({super.key, required this.lead, required this.onTap});

  @override
  Widget build(BuildContext context) => Column(
    children: [
      Container(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 5),
          margin: const EdgeInsets.symmetric(vertical: 4),
          decoration:AppStyle.decoration.copyWith(
            //   border: Border(
            //   left: BorderSide(
            //     color: AppColors.getLeadTypeColor(lead.type),
            //     width:10,
            //   ),
            // ),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: (){
                  Get.toNamed(AppPages.logDetails);
            },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                      
                   
                    InkWell(
                      onTap: () {
                        Get.toNamed(AppPages.logDetails);
                      },
                      child: Stack(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(5),
                            child: CircleAvatar(  backgroundColor: Color.fromARGB(
                                  50,
                                  Random().nextInt(256),
                                  Random().nextInt(256),
                                  Random().nextInt(256),
                                ), 
                                // backgroundColor: Get.theme.primaryColor.withAlpha(20),
                                child:Text(lead.name[0].toUpperCase()),
                            ),
                          ),
                          // Positioned(bottom: 0, right: 0, child: Text("😊")),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            Utils.capitalizeFirstLetter(lead.name),
                            style: Get.theme.textTheme.bodyMedium!.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),    const SizedBox(height:5,),
                          Text(
                            '${lead.city}, ${lead.state}',
                            style: Get.theme.textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                    CircleAvatar( backgroundColor: Get.theme.primaryColor.withAlpha(20),
                      child: IconButton(
                        padding: const EdgeInsets.all(0),
                        onPressed: () {
                          FlutterPhoneDirectCaller.callNumber(lead.phone);
                        },
                        icon: ImageView(
                          AppIcons.call,
                          width: AppStyle.iconSize,
                          height: AppStyle.iconSize,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
     Divider(height: 6,color: Get.theme.primaryColor.withAlpha(10),), ],
  );
}
