import 'package:call_tracker/src/app/widgets/input_card_style.dart';
import 'package:call_tracker/src/core/app_data.dart';
import 'package:contacts_service_plus/contacts_service_plus.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../core/app_colors.dart';
import '../../../../../core/app_style.dart';
import '../../../../utils/utils.dart';
import '../../../calls/contoller/call_log_contoller.dart';
import '../../contoller/lead_controller.dart';
import '../../model/lead_model.dart';
import '../../../../widgets/app_button.dart';
import '../../../../widgets/app_text_field.dart';

class AddLeadPage extends StatefulWidget {
  const AddLeadPage({super.key});

  @override
  State<AddLeadPage> createState() => _AddLeadPageState();
}

class _AddLeadPageState extends State<AddLeadPage> {
  final LeadController _controller = Get.find();
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _notesController = TextEditingController();
  String _selectedType = AppData.leadTypes[0];
  String _selectedCity = '';
  String _selectedState = '';
  String _selectedCountries = 'India';

  final List<String> _cities = ['Madurai', 'Chennai', 'Mumbai', 'Delhi'];

  final List<String> _states = [
    'Tamil Nadu',
    'Kerala',
    'Maharashtra',
    'Karnataka',
  ];
  final List<String> _countries = [
    'India',
    'United States',
    'China ',
    'Brazil ',
  ];

  @override
  void initState() {
    final data = Get.arguments;
    if (data != null) {
      _phoneController.text = data;
    }
    super.initState();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _submitForm() async {
    await Utils.requestContactPermission();
    if (_formKey.currentState!.validate()) {
      Contact newContact = Contact(
        prefix: _nameController.text,
        phones: [Item(label: "mobile", value: _phoneController.text)],
      );
      await await ContactsService.addContact(newContact);
      final newLead = LeadModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: _nameController.text,
        phone: _phoneController.text,
        city: _selectedCity,
        state: _selectedState,
        type: _selectedType,
        notes: _notesController.text,
        createdAt: DateTime.now(),
      );

      await _controller.addLead(newLead);
      final controller = Get.put(CallLogController());
      await controller.fetchUnsavedCallLogs();
      Get.back();
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(
        title: Text('Add New Lead', style: Get.theme.textTheme.titleMedium!),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              AppTextField(
                controller: _nameController,
                labelText: 'Lead Name',
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter lead name';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 10),
              AppTextField(
                controller: _phoneController,
                labelText: 'Phone Number',
                keyboardType: TextInputType.phone,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter phone number';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 10),
              InputCardStyle(  padding: const EdgeInsets.symmetric(horizontal: 8),
                child: DropdownButtonFormField<String>(
                  initialValue: _countries.isNotEmpty ? _selectedCountries : null,
                  items:
                      _countries.map((countries) => DropdownMenuItem<String>(
                          value: countries,
                          child: Text(countries),
                        )).toList(),
                  onChanged:
                      (value) => setState(() => _selectedCountries = value!),
                  decoration: const InputDecoration(
                    labelText: 'Countries',
                    border: InputBorder.none,
                  ),
                  icon: Icon(
                    Icons.keyboard_arrow_down_outlined,
                    color: Get.theme.primaryColor,
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please select a city';
                    }
                    return null;
                  },
                ),
              ),
              const SizedBox(height: 10),
              InputCardStyle(  padding: const EdgeInsets.symmetric(horizontal: 8),
            child: DropdownButtonFormField<String>(
                  initialValue: _selectedState.isNotEmpty ? _selectedState : null,
                  items:
                      _states.map((state) => DropdownMenuItem<String>(
                          value: state,
                          child: Text(state),
                        )).toList(),
                  onChanged: (value) => setState(() => _selectedState = value!),
                  decoration: const InputDecoration(
                    labelText: 'State',
                    border: InputBorder.none,
                  ),
                  icon: Icon(
                    Icons.keyboard_arrow_down_outlined,
                    color: Get.theme.primaryColor,
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please select a state';
                    }
                    return null;
                  },
                ),
              ),

              const SizedBox(height: 10),
              InputCardStyle(  padding: const EdgeInsets.symmetric(horizontal: 8),
                child: DropdownButtonFormField<String>(
                  initialValue: _selectedCity.isNotEmpty ? _selectedCity : null,
                  items:
                      _cities.map((city) => DropdownMenuItem<String>(
                          value: city,
                          child: Text(city),
                        )).toList(),
                  onChanged: (value) => setState(() => _selectedCity = value!),
                  decoration: const InputDecoration(
                    labelText: 'City',
                    border: InputBorder.none,
                  ),
                  icon: Icon(
                    Icons.keyboard_arrow_down_outlined,
                    color: Get.theme.primaryColor,
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please select a city';
                    }
                    return null;
                  },
                ),
              ),

              const SizedBox(height: 10),
              InputCardStyle(  padding: const EdgeInsets.symmetric(horizontal: 8),
               child: DropdownButtonFormField<String>(
                  initialValue: _selectedType,
                  items:
                      AppData.leadTypes.map((type) => DropdownMenuItem<String>(
                          value: type,
                          child: Text(
                            type,
                            style: TextStyle(
                              color: AppColors.getLeadTypeColor(type),
                            ),
                          ),
                        )).toList(),
                  onChanged: (value) => setState(() => _selectedType = value!),
                  decoration: const InputDecoration(
                    labelText: 'Lead Type',
                    border: InputBorder.none,
                  ),
                  icon: Icon(
                    Icons.keyboard_arrow_down_outlined,
                    color: Get.theme.primaryColor,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              AppTextField(
                controller: _notesController,
                labelText: 'Info',
                maxLines: 3,
              ),
              const SizedBox(height: 24),
              AppButton(text: 'Save Lead', onPressed: _submitForm),
            ],
          ),
        ),
      ),
    );
}
