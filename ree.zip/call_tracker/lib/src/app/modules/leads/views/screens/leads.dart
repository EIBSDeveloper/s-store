import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../core/app_colors.dart';
import '../../../../../core/app_data.dart';
import '../../../../../core/app_icons.dart';
import '../../../../../core/app_style.dart';
import '../../../../widgets/app_text_field.dart';
import '../../../../widgets/empty_state.dart';
import '../../../../widgets/input_card_style.dart';
import '../../../main/view/widgets/action_button.dart';
import '../../contoller/lead_controller.dart';
import '../../model/lead_model.dart';
import '../widgets/lead_card.dart';
import 'lead_detail_page.dart';

class Leads extends GetView<LeadController> {
  const Leads({super.key});

  @override
  Widget build(BuildContext context) => Column(
    children: [
      // Search and Filter Section
      _buildSearchFilterSection(context),

      // Leads List Section
      Expanded(
        child: Obx(() {
          final leads = controller.leads;
          if (leads.isEmpty) {
            return _buildEmptyState();
          }
          return _buildLeadsList(leads);
        }),
      ),
    ],
  );

  Widget _buildSearchFilterSection(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 20),
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            Expanded(
              child: AppTextField(
                hintText: 'Search leads...',
                prefixIcon: ImageView(
                  AppIcons.search,
                  width: AppStyle.iconSize3,
                  height: AppStyle.iconSize3,
                ),

                onChanged: controller.searchLeads,
              ),
            ),
            const SizedBox(width: 10),
            InputCardStyle(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: IconButton(
                onPressed: () {
                  Get.bottomSheet(const LeadStatusFilter());
                },
                icon: const Icon(Icons.filter_alt_sharp),
              ),
            ),
          ],
        ),
        // const SizedBox(height: 10),
        // _buildTypeFilterDropdown(),
        _buildLabelsFilter(),
        // const SizedBox(height: 10),
      ],
    ),
  );

  Widget _buildLabelsFilter() => Obx(() {
    if (controller.labels.isEmpty) {
      return const SizedBox();
    }

    return Container(
      height: 45,
      // padding: const EdgeInsets.symmetric(vertical: 8),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: controller.labels.length,
        itemBuilder: (context, index) {
          final filter = controller.labels[index];
          return Padding(
            key: ValueKey(index.toString()),
            padding: const EdgeInsets.only(right: 8),
            child: FilterChip(
              label: Text(filter.label),
              labelStyle: Get.theme.textTheme.bodySmall,
              selected: controller.selectedLabel.value == filter.label,
              onSelected: (selected) {
                controller.filterByLabel(filter.label);
              },
            ),
          );
        },
      ),
    );
  });

  Widget _buildTypeFilterDropdown() => Obx(
    () => Container(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.all(Radius.circular(10)),
        boxShadow: AppStyle.boxShadow,
      ),
      child: DropdownButton<String>(
        value: controller.selectedType.value,
        items:
            ['All', ...AppData.leadTypes]
                .map(
                  (type) => DropdownMenuItem<String>(
                    value: type,
                    child: Text(
                      type,
                      style: TextStyle(color: AppColors.getLeadTypeColor(type)),
                    ),
                  ),
                )
                .toList(),
        onChanged: (value) => controller.filterByType(value!),
        underline: const SizedBox(),
        isExpanded: true,
        icon: Icon(
          Icons.keyboard_arrow_down_outlined,
          color: Get.theme.primaryColor,
        ),
      ),
    ),
  );

  Widget _buildEmptyState() => const EmptyState(
    icon: Icons.people_alt_outlined,
    title: 'No Leads Found',
    subtitle: 'Add your first lead to get started',
  );

  Widget _buildLeadsList(List<LeadModel> leads) => RefreshIndicator(
    onRefresh: () async => controller.loadLeads(),
    child: Container(
      // decoration: BoxDecoration(
      //   borderRadius: const BorderRadius.only(
      //     topLeft: Radius.circular(20),
      //     topRight: Radius.circular(20),
      //   ),
      //   color: Colors.white,
      //   boxShadow: AppStyle.boxShadow,
      // ),
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: ListView.custom(
        padding: const EdgeInsets.only(bottom: 16),
        childrenDelegate: SliverChildBuilderDelegate(
          (context, index) {
            final lead = leads[index];
            return LeadCard(
              lead: lead,
              onTap: () => Get.to(() => LeadDetailPage(lead: lead)),
            );
          },
          childCount: leads.length,
          // Better estimation for dynamic item heights
          findChildIndexCallback: (Key key) {
            final ValueKey valueKey = key as ValueKey;
            final int index = int.parse(valueKey.value);
            return index;
          },
        ),
      ),
    ),
  );
}

class LeadStatusFilter extends GetView<LeadController> {
  const LeadStatusFilter({super.key});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: const BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
    ),
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const ButtomSheetScrollButton(),
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text('Lead Filter', style: TextStyle(color: Colors.black)),
        ),
        const SizedBox(height: 16),

        /// 🔹 Dropdown for Lead Type
        Row(
          children: [
            const Expanded(
              child: Text("Lead Status", style: TextStyle(color: Colors.black)),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: InputCardStyle(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                child: Obx(
                  () => DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: controller.selectedType.value,
                      alignment: AlignmentDirectional.center,
                      icon: const Icon(Icons.keyboard_arrow_down),
                      isExpanded: true,
                      items:
                          ['All', 'Hot', 'Warm', 'Cold']
                              .map(
                                (type) => DropdownMenuItem(
                                  value: type,
                                  child: Text(type.tr),
                                ),
                              )
                              .toList(),
                      onChanged: (value) {
                        if (value != null) {
                          controller.filterByType(value);
                        }
                      },
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),

        const SizedBox(height: 20),

        /// 🔹 Close Button
        ElevatedButton(
          onPressed: () => Get.back(),
          style: ElevatedButton.styleFrom(
            backgroundColor: Get.theme.colorScheme.primary,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 10),
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                'Close'.tr,
                style: const TextStyle(color: Colors.white, fontSize: 14),
              ),
            ),
          ),
        ),

        const SizedBox(height: 60),
      ],
    ),
  );
}

class ButtomSheetScrollButton extends StatelessWidget {
  const ButtomSheetScrollButton({super.key});

  @override
  Widget build(BuildContext context) => Column(
    children: [
      Center(
        child: Container(
          width: 40,
          height: 4,
          decoration: BoxDecoration(
            color: Colors.grey[300],
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ),
      const SizedBox(height: 16),
    ],
  );
}
