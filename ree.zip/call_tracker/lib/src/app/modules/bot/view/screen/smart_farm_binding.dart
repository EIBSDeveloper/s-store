
import 'package:get/get.dart';

import '../../controller/chat_repository.dart';
import 'smart_farm_controller.dart';

class SmartFarmBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ChatRepository>(() => ChatRepository());

    Get.lazyPut<SmartFarmController>(
      () => SmartFarmController(repository: Get.find<ChatRepository>()),
    );
  }
}
