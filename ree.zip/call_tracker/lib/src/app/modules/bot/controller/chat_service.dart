import 'dart:convert';
import 'package:http/http.dart' as http;

class GeminiApiService {
  // ⚠️ Replace with your actual Gemini API key securely (e.g., via .env or secure storage)
  final String _apiKey = 'AIzaSyAr235rJSHqiFNob0Kr90gIvJ5I0tkC96o';
  final String _geminiApiUrl =
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';

  /// Sends a user query to the Gemini model and returns a smart response
  /// specifically tuned for a Sales Call Tracker app.
  Future<String> getResponse(String query, {String? contextData}) async {
    try {
      String prompt = query;

      // Customize prompt for Sales Call Tracker support
      if (contextData != null && contextData.isNotEmpty) {
        prompt = '''
You are a helpful assistant for a Sales Call Tracker app. 
You help users with:
- Logging sales calls
- Tracking follow-ups and customer interactions
- Summarizing call notes
- Generating call scripts and reminders
- Providing sales insights or tips

Based on this context data:
$contextData

User query: $query

Provide a clear, helpful, and professional response related to sales call tracking or CRM tasks.
''';
      } else {
        prompt = '''
You are a helpful assistant for a Sales Call Tracker app.
User query: $query
Provide a clear and practical response about tracking calls, CRM tasks, or sales productivity.
''';
      }

      final Map<String, dynamic> requestBody = {
        'contents': [
          {
            'parts': [
              {'text': prompt},
            ],
          },
        ],
        'generationConfig': {
          'temperature': 0.4,
          'topK': 32,
          'topP': 0.9,
          'maxOutputTokens': 1024,
        },
      };

      final response = await http.post(
        Uri.parse('$_geminiApiUrl?key=$_apiKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(requestBody),
      );

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        return responseData['candidates'][0]['content']['parts'][0]['text'] ??
            'Sorry, I could not generate a meaningful response.';
      } else {
        throw Exception('Failed to get response: ${response.body}');
      }
    } catch (e) {
      return 'Sorry, an error occurred while processing your request: $e';
    }
  }
}
