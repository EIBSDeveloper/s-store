import 'package:get/get.dart';
import '../../../utils/routes/app_pages.dart';

class AuthController extends GetxController {
  var phoneNumber = ''.obs;
  var otpCode = ''.obs;
  var isLoading = false.obs;

  void sendOtp(String number) {
    phoneNumber.value = number;
    isLoading.value = true;
    Future.delayed(const Duration(seconds: 2), () {
      isLoading.value = false;
      Get.toNamed(AppPages.otp);
    });
  }

  void verifyOtp(String code) {
    otpCode.value = code;
    isLoading.value = true;
    Future.delayed(const Duration(seconds: 2), () {
      isLoading.value = false;
      Get.snackbar("Success", "OTP Verified",backgroundColor: Get.theme.colorScheme.secondaryContainer);
       Get.offAllNamed(AppPages.home,);
    });
  }
}
