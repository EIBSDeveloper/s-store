// import 'package:get/get.dart';

// import '../../../utils/http/http_service.dart';
// import '../model/login_request.dart';
// import '../model/login_response.dart';


// class LoginRepository extends GetxService {
//   Future<LoginResponse> login(LoginRequest request) async {
//     try {
//       final response = await Get.find<HttpService>().post(
//         '/auth/login',
//          request.toJson(),
//       );
      
//       return LoginResponse.fromJson(response.body);
//     } catch (e) {
//       rethrow;
//     }
//   }
// }