class LoginRequest {
  final String userId;
  final String password;
  final bool rememberMe;

  LoginRequest({
    required this.userId,
    required this.password,
    required this.rememberMe,
  });

  Map<String, dynamic> toJson() {
    return {
      'user_id': userId,
      'password': password,
      'remember_me': rememberMe,
    };
  }
}