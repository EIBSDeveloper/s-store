import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../controller/auth_controller.dart';

class LoginPage extends StatelessWidget {
  final authController = Get.put(AuthController());
  final TextEditingController phoneController = TextEditingController();

  LoginPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
      body: Obx(
        () => Stack(
          children: [
            AnimatedOpacity(
              opacity: authController.isLoading.value ? 0.5 : 1,
              duration: const Duration(milliseconds: 500),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 18),
                      Container(
                        width: 200,
                        height: 200,
                        decoration: BoxDecoration(
                          color:Get.theme.hoverColor,
                          shape: BoxShape.circle,
                        ),
                        // child: ImageView('assets/images/illustration-2.png'),
                      ),
                      const SizedBox(height: 24),
                      const Text(
                        'Registration',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        "Add your phone number. we'll send you a verification code so we know you're real",
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.black38,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 28),
                      const SizedBox(height: 20),
                      TextField(
                        controller: phoneController,
                        keyboardType: TextInputType.phone,
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: const BorderSide(color: Colors.black12),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: const BorderSide(color: Colors.black12),
                            borderRadius: BorderRadius.circular(10),
                          ),

                          // border: OutlineInputBorder(),
                          prefixText: '+91 ',
                          labelText: "Mobile Number",
                        ),
                      ),
                      const SizedBox(height: 20),
                     
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () {
                          if (phoneController.text.length == 10) {
                            authController.sendOtp(phoneController.text);
                            
                          } else {
                            Get.snackbar(
                              "Error",
                              "Enter a valid 10-digit number",
                            );
                          }
                          },
                          style: ButtonStyle(
                            foregroundColor: WidgetStateProperty.all<Color>(
                             Get.theme.hintColor
                            ),
                            backgroundColor: WidgetStateProperty.all<Color>(
                             Get.theme.primaryColor,
                            ),
                            shape:
                                WidgetStateProperty.all<RoundedRectangleBorder>(
                                  RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(24.0),
                                  ),
                                ),
                          ),
                          child: const Padding(
                            padding: EdgeInsets.all(14.0),
                            child: Text('Send', style: TextStyle(fontSize: 16)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            if (authController.isLoading.value)
              const Center(child: CircularProgressIndicator()),
          ],
        ),
      ),
    );
}
