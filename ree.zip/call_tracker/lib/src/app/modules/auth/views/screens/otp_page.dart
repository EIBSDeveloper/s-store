import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sms_autofill/sms_autofill.dart';

import '../../controller/auth_controller.dart';

class OtpPage extends StatelessWidget {
  final authController = Get.find<AuthController>();

   OtpPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
      body: Obx(
        () => Stack(
          children: [
            AnimatedOpacity(
              opacity: authController.isLoading.value ? 0.5 : 1,
              duration: const Duration(milliseconds: 500),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 18),
                      Container(
                        width: 200,
                        height: 200,
                        decoration: BoxDecoration(
                          color:Get.theme.hoverColor,
                          shape: BoxShape.circle,
                        ),
                        // child: ImageView('assets/images/illustration-3.png'),
                      ),
                      const SizedBox(height: 24),
                      const Text(
                        'Verification',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        "Enter your OTP code number",
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.black38,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 28),
                      PinFieldAutoFill(
                        codeLength: 6,
                        decoration: UnderlineDecoration(
                          textStyle: const TextStyle(
                            fontSize: 20,
                            color: Colors.black,
                          ),
                          colorBuilder: const FixedColorBuilder(Colors.grey),
                        ),
                        onCodeSubmitted: (code) {
                          authController.verifyOtp(code);
                        },
                        onCodeChanged: (code) {
                          if (code!.length == 6) {
                            authController.verifyOtp(code);
                          }
                        },
                      ),
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () {
                            authController.verifyOtp(
                              authController.otpCode.value,
                            );
                          },
                          style: ButtonStyle(
                            foregroundColor: WidgetStateProperty.all<Color>(
                             Get.theme.hintColor
                            ),
                            backgroundColor: WidgetStateProperty.all<Color>(
                             Get.theme.primaryColor,
                            ),
                            shape:
                                WidgetStateProperty.all<RoundedRectangleBorder>(
                                  RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(24.0),
                                  ),
                                ),
                          ),
                          child: const Padding(
                            padding: EdgeInsets.all(14.0),
                            child: Text(
                              'Verify',
                              style: TextStyle(fontSize: 16),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            if (authController.isLoading.value)
              const Center(child: CircularProgressIndicator()),
          ],
        ),
      ),
    );
}
