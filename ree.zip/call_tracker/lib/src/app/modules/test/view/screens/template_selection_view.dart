import 'package:call_tracker/src/app/modules/main/view/widgets/action_button.dart';
import 'package:call_tracker/src/app/widgets/bottom_sheet_syle.dart';
import 'package:call_tracker/src/app/widgets/input_card_style.dart';
import 'package:call_tracker/src/core/app_icons.dart';
import 'package:call_tracker/src/core/app_style.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../controller/template_controller.dart';
import '../../model/template_model.dart';

class TemplateBottomSheet extends GetView<TemplateController> {
  const TemplateBottomSheet({super.key});

  @override
  Widget build(BuildContext context) => BottomSheetStyle(
      child: Expanded(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  const SizedBox(width: 8),
                  Text(
                    'selection'.tr,
                    style: Get.theme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),

            // Search field
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16,),
              child: InputCardStyle(
                child: TextFormField(
                  decoration: InputDecoration(
                    hintText: 'search_hint'.tr,
                    hintStyle:  Get.theme.textTheme.bodySmall,
                    prefixIcon: Icon(
                      Icons.search,
                      color: Get.theme.colorScheme.onSurface.withOpacity(0.6),
                    ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                  ),
                  onChanged: controller.searchTemplates,
                  textInputAction: TextInputAction.search,
                ),
              ),
            ),

            // Template list
            Expanded(child: _buildTemplateList()),
          ],
        ),
      ),
    );

  Widget _buildTemplateList() => Obx(() {
      if (controller.isLoading && controller.templates.isEmpty) {
        return const Center(child: CircularProgressIndicator());
      }

      if (controller.filteredTemplates.isEmpty) {
        return Center(
          child: Text(
            controller.isSearching ? 'no_results'.tr : 'no_templates'.tr,
            style: Get.theme.textTheme.bodyMedium?.copyWith(
              color: Get.theme.colorScheme.onSurface.withOpacity(0.6),
            ),
          ),
        );
      }

      return ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: controller.filteredTemplates.length,
        itemBuilder: (context, index) {
          final template = controller.filteredTemplates[index];
          return _buildTemplateCard(template);
        },
      );
    });

  Widget _buildTemplateCard(TemplateModel template) => InkWell(
    borderRadius: BorderRadius.circular(12),
    onTap: () => controller.selectTemplate(template),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  template.title,
                  style: Get.theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Get.theme.colorScheme.primary,
                  ),
                ),
              ),
              _buildActionIcons(template),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            template.message,
            style: Get.theme.textTheme.bodySmall?.copyWith(
              color: Get.theme.colorScheme.onSurface.withOpacity(0.8),
            ),
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    ),
  );

  Widget _buildActionIcons(TemplateModel template) => Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const SizedBox(width: 10),
        // if (template.hasChat)
          ImageView(
            AppIcons.sms,
            width: AppStyle.iconSize,
            height: AppStyle.iconSize,
          ),
        const SizedBox(width: 20),
        // if (template.hasCall)
        ImageView(
          AppIcons.whatsapp,
          width: AppStyle.iconSize,
          height: AppStyle.iconSize,
        ),
      ],
    );
}
