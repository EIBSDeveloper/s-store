import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../controller/template_controller.dart';
import '../../model/template_model.dart';
import 'template_selection_view.dart';

class TemplateBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<TemplateController>(() => TemplateController());
  }
}

Future<void> openTemplateBottomSheet() async {
   Get.lazyPut<TemplateController>(() => TemplateController());
  final selectedTemplate = await Get.bottomSheet<TemplateModel>(
    const TemplateBottomSheet(),
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
  );
  
  if (selectedTemplate != null) {
    // Handle the selected template
    print('Selected template: ${selectedTemplate.title}');
    // You can use the template message, send it, etc.
  }
}
