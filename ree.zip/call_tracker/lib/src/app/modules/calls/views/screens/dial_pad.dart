import 'package:call_tracker/src/app/widgets/background.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:get/get.dart';

import '../../../../../core/app_style.dart';
import '../../contoller/call_log_contoller.dart';

class DialPad extends GetView<CallLogController> {
  const DialPad({super.key});

  @override
  Widget build(BuildContext context) {
    var size = Get.size;
    return Background(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            // Expanded(
            //   child: ListView.builder(
            //     itemBuilder: (context, i) {
            //       return Container();
            //     },
            //   ),
            // ),
            TextFormField(
              controller: controller.mobileController,
              autofocus: true,
              readOnly: true,
              showCursor: true,
              style: const TextStyle(
                fontSize: 35,
                color: Colors.black,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
              keyboardType: TextInputType.phone,
              maxLength: 10,
              decoration: const InputDecoration(border: InputBorder.none),
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
                LengthLimitingTextInputFormatter(10),
              ],
            ),
        
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                dialPadButton('1'),
                dialPadButton('2'),
                dialPadButton('3'),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                dialPadButton('4'),
                dialPadButton('5'),
                dialPadButton('6'),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                dialPadButton('7'),
                dialPadButton('8'),
                dialPadButton('9'),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Container(
                  // height: size.height * 0.15,
                  width: size.width * 0.33,
                  decoration: const BoxDecoration(),
                ),
        
                dialPadButton('0'),
                InkWell(
                  highlightColor: Colors.black45,
                  onTap: () {
                    final text = controller.mobileController.text;
                    final selection = controller.mobileController.selection;
                    final cursorPosition = selection.start;
        
                    if (text.isNotEmpty && cursorPosition > 0) {
                      final newText = text.replaceRange(
                        cursorPosition - 1,
                        cursorPosition,
                        '',
                      );
        
                      // setState(() {
                      controller.display = newText;
                      controller.mobileController.text = newText;
                      controller.mobileController.selection =
                          TextSelection.collapsed(offset: cursorPosition - 1);
                      // });
                    }
                  },
                  child: SizedBox(
                    // height: size.height * 0.15,
                    width: size.width * 0.33,
                    // decoration: BoxDecoration(
                    //   border: Border.all(color: Colors.grey, width: 0.025),
                    // ),
                    child: const Center(
                      child: Icon(
                        Icons.backspace,
                        size: 35,
                        color: Colors.black45,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(18.0),
              child: InkWell(
                child: Container(
                  height: 60,
                  width: 120,
                  decoration: BoxDecoration(
                    color: Colors.green,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: AppStyle.boxShadow,
                  ),
                  child: const Icon(Icons.call, color: Colors.white, size: 40),
                ),
                onTap: () async {
                  FlutterPhoneDirectCaller.callNumber(
                    controller.mobileController.text,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget dialPadButton(String value, {Color? color}) => Flexible(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        child: LayoutBuilder(
          builder: (context, constraints) {
            double size = constraints.maxWidth - 20;
            return InkWell(
              highlightColor: Colors.black45,
              onTap: () {
                final text = controller.mobileController.text;
                final selection = controller.mobileController.selection;
                final cursorPosition = selection.start;

                if (cursorPosition >= 0 && text.length < 10) {
                  final newText = text.replaceRange(
                    cursorPosition,
                    cursorPosition,
                    value,
                  );

                  // setState(() {
                  controller.display = newText;
                  controller.mobileController.text = newText;
                  controller.mobileController.selection =
                      TextSelection.collapsed(offset: cursorPosition + 1);
                  // });
                }
              },
              child: Container(
                width: size - 10,
                height: size - 10,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(50),
                  boxShadow: AppStyle.boxShadow,
                ),
                child: Center(
                  child: Text(
                    value,
                    style: TextStyle(
                      color: color ?? Colors.grey,
                      fontSize: 35,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
}
