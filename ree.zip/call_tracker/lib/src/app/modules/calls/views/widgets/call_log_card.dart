import 'dart:math';

import 'package:call_log/call_log.dart';
import 'package:flutter/material.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:get/get.dart';

import '../../../../../../tt.dart';
import '../../../../../core/app_colors.dart';
import '../../../../../core/app_icons.dart';
import '../../../../../core/app_style.dart';
import '../../../../utils/routes/app_pages.dart';
import '../../../../utils/utils.dart';
import '../../../../widgets/bottom_sheet_syle.dart';
import '../../../followups/views/widgets/add_follow_up_bottom_sheet.dart';
import '../../../main/view/widgets/action_button.dart';
import '../../../test/view/screens/template_bottom_sheet.dart';
import '../../binding/client_binding.dart';
import 'agent_selection_bottom_sheet.dart';

class CallLogCard extends StatelessWidget {
  const CallLogCard({
    super.key,
    required this.name,
    required this.number,
    required this.duration,
    required this.callType,
    required this.startTime,
    this.save,
    this.ontop,
    this.audioPath,
    this.isExpended = false,
    required this.endTime,
  });

  final String name;
  final String number;
  final String duration;
  final Function()? save;
  final Function()? ontop;
  final CallType callType;

  final String startTime;
  final bool isExpended;
  final String endTime;
  final String? audioPath;

  @override
  Widget build(BuildContext context) => Column(
    children: [
      InkWell(
        // onTap: ontop,
        // onTap: () {
        //   Get.toNamed(AppPages.logDetails);
        // },
        onTap: ontop,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 4),
          padding: const EdgeInsets.all(5),
          // decoration: AppStyle.decoration,
          child: Column(
            children: [
              Row(
                children: [
                  InkWell(
                    onTap: () {
                      Get.toNamed(AppPages.logDetails);
                    },
                    child: Stack(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10, right: 10),
                          child: CircleAvatar(
                            // backgroundColor: Get.theme.primaryColor.withAlpha(20),
                            backgroundColor: Color.fromARGB(
                              50,
                              Random().nextInt(256),
                              Random().nextInt(256),
                              Random().nextInt(256),
                            ),
                            child: Text(name[0].toUpperCase()),
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: AppColors.getCallTypeIcon(callType),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    flex: 3,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                name,
                                style: Get.theme.textTheme.bodyMedium?.copyWith(
                                  // color: 
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),    const SizedBox(height:5,),
                        InkWell(
                          onTap: (){
                            Get.toNamed(AppPages.logDetails);
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 3),
                            child: Row(
                              children: [
                                // Icon(
                                //   Icons.access_time,
                                //   color: Get.theme.primaryColor,
                                // ),
                                // ImageView(AppIcons.time2,width: AppStyle.iconsize2,height: AppStyle.iconsize2,),
                                Row(
                                  children: [
                                    Text(
                                      startTime,
                                      style: Get.theme.textTheme.bodySmall,
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      callType == CallType.missed
                                          ? "00:00"
                                          : Utils.formatDuration(
                                            int.tryParse(duration) ?? 0,
                                          ),
                                      style: Get.theme.textTheme.bodySmall,
                                    ),
                                    if (audioPath != null) ...[
                                      Container(
                                        decoration: AppStyle.decoration.copyWith(
                                          color: Colors.red.withAlpha(50),
                                          boxShadow: [],
                                        ),
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 4,
                                          vertical: 2,
                                        ),
                                        margin: const EdgeInsets.symmetric(
                                          horizontal: 4,
                                        ),
                                        child: Row(
                                          children: [
                                            const Icon(
                                              Icons.circle,
                                              color: Colors.red,
                                              size: 8,
                                            ),
                                            Text(
                                              "RCE",
                                              style: Get.theme.textTheme.bodySmall
                                                  ?.copyWith(
                                                    color: Colors.black,
                                                    fontSize: 9,
                                                  ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      // LocalAudioPlayer(audioPath: audioPath!),
                                    ],
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),    const SizedBox(height:5,),
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: [
                              TagCard(
                                onTap: () {
                                  showTagBottomSheet();
                                },
                                color: Colors.orange,
                                lable: "VIP",
                              ),
                              TagCard(
                                onTap: () {},
                                color: Colors.blueGrey,
                                lable: "Call Back",
                                // icon: Icons.add,
                              ),
                              TagCard(
                                onTap: () {
                                  showTagBottomSheet();
                                },
                                color: Colors.blue,
                                lable: "",
                                icon: Icons.add,
                                // icon: Icons.add,
                              ),

                              // Spacer(),
                              // Flexible(
                              //   child: ,
                              // ),
                              // Row(
                              //   children: [
                              //     IconButton(onPressed: (){}, icon: Icon(Icons.mic)),
                              //   ],
                              // )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  CircleAvatar(
                    backgroundColor: Get.theme.primaryColor.withAlpha(20),
                    child: InkWell(
                      onTap: () {
                        FlutterPhoneDirectCaller.callNumber(number.toString());
                      },
                      child: ImageView(
                        AppIcons.call,
                        color: Get.theme.primaryColor,
                        width: AppStyle.iconSize,
                        height: AppStyle.iconSize,
                      ),
                    ),
                  ),
                ],
              ),
              if (isExpended)
                Container(
                  margin: const EdgeInsets.symmetric(
                    vertical: 4,
                    horizontal: 4,
                  ),
                  padding: const EdgeInsets.all(5),
                  decoration: AppStyle.decoration.copyWith(boxShadow: []),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Expanded(
                        child: ActionButton(
                          icon: AppIcons.time2,
                          label: 'Add Follow Up',
                          color: Get.theme.primaryColor,
                          onTap: openAddFollowUpBottomSheet,
                        ),
                      ),
                      Expanded(
                        child: ActionButton(
                          icon: AppIcons.whatsapp,
                          label: 'Whatsapp',
                          color: Colors.green,
                          onTap: openTemplateBottomSheet,
                        ),
                      ),
                      Expanded(
                        child: ActionButton(
                          icon: AppIcons.sms,
                          label: 'SMS',
                          color: Colors.blue,
                          onTap: () {
                            openSMS(number);
                          },
                        ),
                      ),
                      Expanded(
                        child: ActionButton(
                          icon: AppIcons.useredit,
                          label: 'Assigned to',
                          color: Colors.indigo,
                          onTap: () {
                            ClientBinding().dependencies();

                            // loadAvailableAgents();
                            Get.bottomSheet(
                              AgentSelectionBottomSheet(),
                              isScrollControlled: true,
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              // if (audioPath != null) LocalAudioPlayer(audioPath: audioPath!),
            ],
          ),
        ),
      ),
       Divider(height: 6,color: Get.theme.primaryColor.withAlpha(10),),
    ],
  );
}

class TagCard extends StatelessWidget {
  const TagCard({
    super.key,
    required this.color,
    required this.lable,
    this.onTap,
    this.icon,
  });
  final void Function()? onTap;
  final MaterialColor color;
  final String lable;
  final IconData? icon;
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    child: Container(
      decoration: AppStyle.decoration.copyWith(
        color: (lable.isNotEmpty) ? color.withAlpha(30) : Colors.transparent,
        borderRadius: const BorderRadius.all(
          Radius.circular(AppStyle.borderRadiusClip),
        ),
        border:
            (lable.isNotEmpty)
                ? null
                : Border.all(color: Colors.grey.withAlpha(50)),
        boxShadow: [],
      ),

      margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
      padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 2),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) Icon(icon, color: color, size: AppStyle.iconSize2),

          if (lable.isNotEmpty) ...[
            const SizedBox(width: 3),
            Flexible(
              child: Text(
                lable,
                style: Get.theme.textTheme.bodySmall!.copyWith(
                  color: color,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          ],
        ],
      ),
    ),
  );
}
