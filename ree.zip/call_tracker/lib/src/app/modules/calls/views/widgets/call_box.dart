import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../../core/app_style.dart';
import '../../../main/view/widgets/action_button.dart';

class CallBox extends StatelessWidget {
  const CallBox({
    super.key,
    required this.icon,
    required this.label,
    required this.iconColor,
    required this.count,
    this.isSelected = false,
    this.onTap,
    this.color,
  });

  final String icon;
  final String label;
  final Color? color;
  final bool isSelected;
  final MaterialColor iconColor;
  final int count;
  final Function()? onTap;

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    child:SizedBox(
          // height: Get.size.width > 600 ? 150 : constraints.maxWidth - 10,
          // width: Get.size.width > 600 ? 150 : constraints.maxWidth,
  
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 5),
            padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 4),
            decoration: AppStyle.decoration.copyWith(
              boxShadow: (!isSelected) ? null: [],
              border: Border.all(color: isSelected ?iconColor:Get.theme.colorScheme.secondaryContainer),
              color:
                  isSelected
                      ? iconColor.withAlpha(20)
                      : Colors.transparent,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
              //  ImageView(
              //     icon,
              //     width: AppStyle.iconSize,
              //     height: AppStyle.iconSize,
              //   ),
  
                const SizedBox(height: 5),
                Text(
                  "$label ($count)",
                  style:Get.theme.textTheme.bodySmall,
                ),      const SizedBox(height: 5),
              ],
            ),
          ),
        ),
  );
}
