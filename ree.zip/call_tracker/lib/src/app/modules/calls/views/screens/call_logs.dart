import 'package:call_log/call_log.dart';
import 'package:call_tracker/src/core/app_icons.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../../utils/routes/app_pages.dart';
import '../../contoller/call_log_contoller.dart';
import '../../contoller/call_recording_controller.dart';
import '../widgets/call_box.dart';
import '../widgets/call_log_card.dart';

class CallLogs extends GetView<CallLogController> {
  const CallLogs({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
      backgroundColor: Colors.transparent,
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
          
            _buildCallTypeFilters(),
            const SizedBox(height: 8),
            Expanded(child: _buildCallLogList()),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        elevation: 0,
        backgroundColor: Get.theme.primaryColor.withAlpha(80),
        onPressed: () {
          Get.toNamed(AppPages.dialPad);
        },
        child: const Icon(Icons.dialpad),
      ),
    );

  Widget _buildCallTypeFilters() => Obx(
      () => SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            CallBox(
              icon: AppIcons.call,
              label: "All",
              iconColor: Colors.orange,
              isSelected: controller.filter.value == null,
              count: controller.totalCallsCount.value,
              onTap: () => controller.setFilter(),
            ),
            CallBox(
              icon: AppIcons.incoming,  label: "Incoming",
              iconColor: Colors.green,
              isSelected: controller.filter.value == CallType.incoming,
              count: controller.incomingCallsCount.value,
              onTap: () => controller.setFilter(selectedType: CallType.incoming),
            ),
            CallBox(
              icon: AppIcons.ougoing,  label: "Ougoing",
              iconColor: Colors.green,
              isSelected: controller.filter.value == CallType.outgoing,
              count: controller.outgoingCallsCount.value,
              onTap: () => controller.setFilter(selectedType: CallType.outgoing),
            ),
            CallBox(
              icon: AppIcons.missedCall,  label: "Missed",
              iconColor: Colors.red,
              isSelected: controller.filter.value == CallType.missed,
              count: controller.missedCallsCount.value,
              onTap: () => controller.setFilter(selectedType: CallType.missed),
            ),
            CallBox(
              icon: AppIcons.missedCall,  label: "Dialed",
              iconColor: Colors.red,
              isSelected: controller.filter.value == CallType.missed,
              count: controller.missedCallsCount.value,
              onTap: () => controller.setFilter(selectedType: CallType.missed),
            ),
            // CallBox(
            //   icon: AppIcons.missedCall,  label: "+",
            //   iconColor: Colors.red,
            //   // isSelected: controller.filter.value == CallType.missed,
            //   count: controller.missedCallsCount.value,
            //   // onTap: () => controller.setFilter(selectedType: CallType.missed),
            // ),
          ],
        ),
      ),
    );

  Widget _buildCallLogList() {
    final callrecordController = Get.put(
      CallRecordingController(),
    ); // Only once

    return Obx(() {
      if (controller.isLoadCallLog.value) {
        return const Center(child: CircularProgressIndicator());
      }

      final grouped = controller.filteredLogs;
      if (grouped.isEmpty) {
        return const Center(child: Text("No call logs found."));
      }

      return RefreshIndicator(
        onRefresh: () => controller.refreshLog(),
        child: ListView.separated(
          physics: const AlwaysScrollableScrollPhysics(),
          itemCount: grouped.length,
          separatorBuilder: (_, __) => const SizedBox(height: 3),
          itemBuilder: (context, index) {
            final date = grouped.keys.elementAt(index);
            final entries = grouped[date]!;

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(3),
                  child: Text(
                    date,
                    style:  TextStyle(
                      fontSize: Get.theme.textTheme.bodyMedium!.fontSize,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                ...entries.map((entry) => FutureBuilder<String?>(
                    future: callrecordController.findRecordingByCallLog(
                      number: entry.number ?? '',
                      timestamp: entry.timestamp ?? 0,
                      duration: entry.duration,
                      name: entry.name,
                      dateKey:
                          date, // pass the date string like "July 08, 2025"
                    ),
                    builder: (context, snapshot) {
                      final audioPath =
                          snapshot.connectionState == ConnectionState.done
                              ? snapshot.data
                              : null;

                      return Obx(()=> CallLogCard(
                        name:
                            entry.name?.isNotEmpty == true
                                ? entry.name!
                                : entry.number.toString(),
                        isExpended: controller.isExpended.value == entry.id,
                     number:entry.number.toString(),

                        duration: entry.duration.toString(),
                        startTime: DateFormat('hh:mm a').format(
                          DateTime.fromMillisecondsSinceEpoch(
                            entry.timestamp ?? 0,
                          ),
                        ),

                        ontop: () {
                          if (controller.isExpended.value == entry.id) {
                            controller.isExpended.value = "";
                          } else {
                            controller.isExpended.value = entry.id ?? "";
                          }
                          
                        },
                        endTime: entry.timestamp.toString(),
                        callType: entry.callType!,
                        audioPath: audioPath,
                      ));
                    },
                  )),
              ],
            );
          },
        ),
      );
    });
  }
}
