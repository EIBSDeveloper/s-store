import 'package:flutter/material.dart';
import 'package:get/get.dart';

class TitleText extends StatelessWidget {
  const TitleText(this.tr2, {super.key, this.color});
  final Color? color;
  final String tr2;

  @override
  Widget build(BuildContext context) => Text(
      tr2,
      style: Get.theme.textTheme.titleMedium?.copyWith(
        fontWeight: FontWeight.bold,
        color: color ?? Get.theme.primaryColor,
      ),
    );
}
