import 'package:call_tracker/src/app/modules/calls/model/client_model.dart';
import 'package:call_tracker/src/app/widgets/input_card_style.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../widgets/bottom_sheet_syle.dart';
import '../../contoller/client_controller.dart';

class AgentSelectionBottomSheet extends StatelessWidget {
  final ClientController controller = Get.find();

  AgentSelectionBottomSheet({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Get.theme;

    return BottomSheetStyle(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // --- Header ---
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Assign to',
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: theme.colorScheme.primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // --- Agent Dropdown ---
            Obx(() {
              if (controller.availableAgents.isEmpty) {
                return Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(
                    'No agents available',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurface.withOpacity(0.6),
                    ),
                  ),
                );
              }

              return InputCardStyle(
                // padding: const EdgeInsets.symmetric(
                //   horizontal: 12,
                //   vertical: 4,
                // ),
                // decoration: BoxDecoration(
                //   color: theme.colorScheme.surfaceContainerHighest,
                //   borderRadius: BorderRadius.circular(12),
                //   border: Border.all(
                //     color: theme.colorScheme.primary.withOpacity(0.4),
                //     width: 1,
                //   ),
                // ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<AgentModel>(
                    isExpanded: true,
                    value: controller.selectedAgent.value,
                    hint: Text(
                      "Select Agent",
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onSurface.withOpacity(0.6),
                      ),
                    ),
                    items:
                        controller.availableAgents
                            .map(
                              (agent) => DropdownMenuItem<AgentModel>(
                                value: agent,
                                child: Row(
                                  children: [
                                    CircleAvatar(
                                      radius: 18,
                                      backgroundColor:
                                          theme.colorScheme.primary,
                                      backgroundImage:
                                          agent.imageUrl != null
                                              ? NetworkImage(agent.imageUrl!)
                                              : null,
                                      child:
                                          agent.imageUrl == null
                                              ? Text(
                                                _getInitials(agent.name),
                                                style: theme
                                                    .textTheme
                                                    .bodyMedium
                                                    ?.copyWith(
                                                      color:
                                                          theme
                                                              .colorScheme
                                                              .onPrimary,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                    ),
                                              )
                                              : null,
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Text(
                                        agent.name,
                                        overflow: TextOverflow.ellipsis,
                                        style: theme.textTheme.bodyMedium
                                            ?.copyWith(
                                              color:
                                                  theme.colorScheme.onSurface,
                                              fontWeight: FontWeight.w600,
                                            ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            )
                            .toList(),
                    onChanged: (agent) {
                      controller.selectedAgent.value = agent;
                    },
                  ),
                ),
              );
            }),
            const SizedBox(height: 20),

            // --- Reason Field ---
            Text(
              "Reason",
                 style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: theme.colorScheme.primary,
                  ),
            ),
            const SizedBox(height: 8),
            InputCardStyle(
              // decoration: BoxDecoration(
              //   color: theme.colorScheme.surfaceContainerHighest,
              //   borderRadius: BorderRadius.circular(12),
              //   border: Border.all(
              //     color: theme.colorScheme.primary.withOpacity(0.4),
              //   ),
              // ),
              // padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: TextField(
                controller: controller.reasonTextController,
                minLines: 3,
                maxLines: 5,
                style: theme.textTheme.bodyMedium,
                decoration: InputDecoration(
                  hintText: "Enter reason",
                  hintStyle: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.onSurface.withOpacity(0.6),
                  ),
                  border: InputBorder.none,
                ),
              ),
            ),
            const SizedBox(height: 20),

            // --- Submit Button ---
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: Icon(Icons.send, color: theme.colorScheme.onPrimary),
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  backgroundColor: theme.colorScheme.primary,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  elevation: 3,
                ),
                label: Text(
                  "Submit",
                  style: theme.textTheme.titleMedium?.copyWith(
                    color: theme.colorScheme.onPrimary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _getInitials(String name) {
    final parts = name.split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return name.length >= 2
        ? name.substring(0, 2).toUpperCase()
        : name.toUpperCase();
  }
}
