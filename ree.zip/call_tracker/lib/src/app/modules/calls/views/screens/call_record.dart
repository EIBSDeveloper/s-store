import 'package:call_tracker/src/app/modules/calls/contoller/call_recording_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:path/path.dart' as path;

import '../../../../widgets/local_audio_player.dart';
import '../../../../../core/app_style.dart';

class CallRecordingScreen extends StatelessWidget {
  CallRecordingScreen({super.key});

  final CallRecordingController controller = Get.put(CallRecordingController());

  @override
  Widget build(BuildContext context) => Scaffold( backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Call Recordings'), backgroundColor: Colors.white,
        actions: [
          Obx(() => IconButton(
                icon: const Icon(Icons.refresh),
                onPressed: controller.isLoading.value ? null : controller.findCallRecordings,
              )),
        ],
      ),
      body: Obx(() {
        if (controller.errorMessage.value != null) {
          return Center(
            child: Text(
              controller.errorMessage.value!,
              style: TextStyle(color: Colors.red[700]),
            ),
          );
        }

        if (controller.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }

        if (controller.recordings.isEmpty) {
          return const Center(child: Text('No recordings found'));
        }

        return ListView.builder(
          itemCount: controller.recordings.keys.length,
          itemBuilder: (context, index) {
            final date = controller.recordings.keys.elementAt(index);
            final files = controller.recordings[date]!;
            
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    date,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
                ...files.map((file) => Container(
                  margin: const EdgeInsets.symmetric(
                    vertical: 4,
                    horizontal: 8,
                  ),
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    boxShadow: AppStyle.boxShadow,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        path.basename(file.path).split('(')[0],
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      LocalAudioPlayer(audioPath: file.path),
                    ],
                  ),
                )),
              ],
            );
          },
        );
      }),
    );
}