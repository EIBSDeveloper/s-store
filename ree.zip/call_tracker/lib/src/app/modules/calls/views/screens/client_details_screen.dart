import 'package:call_tracker/src/app/modules/calls/views/widgets/title_text.dart';
import 'package:call_tracker/src/app/widgets/custom_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../../../../call_log.dart';
import '../../../../../core/app_icons.dart';
import '../../../../../core/app_style.dart' show AppStyle;
import '../../../../utils/routes/app_pages.dart';
import '../../../../utils/utils.dart';
import '../../../../widgets/background.dart';
import '../../../../widgets/toggle_bar.dart';
import '../../../main/view/widgets/action_button.dart';
import '../../contoller/call_log_contoller.dart';
import '../../contoller/client_controller.dart';
import '../../model/client_model.dart';
import '../widgets/call_log_card.dart';

class ClientDetailsScreen extends GetView<ClientController> {
  const ClientDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) => Background(
    child: Scaffold(
      backgroundColor: Colors.transparent,
      appBar: CustomAppBar(
        title: Text(
          "Karthik",
          style: Get.theme.textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Obx(() {
        if (controller.isLoading.value && controller.client == null) {
          return const Center(child: CircularProgressIndicator());
        }

        if (controller.error.value.isNotEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(controller.error.value),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: controller.loadClientDetails,
                  child: Text('retry'.tr),
                ),
              ],
            ),
          );
        }

        if (controller.client == null) {
          return Center(child: Text('no_data'.tr));
        }

        return _buildClientDetails(controller.client!);
      }),
    ),
  );

  Widget _buildClientDetails(ClientModel client) => Padding(
    // physics: NeverScrollableScrollPhysics(),
    padding: const EdgeInsets.symmetric(vertical: 0),
    child: SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 16),
          // Profile Header
          _buildProfileHeader(client),
          const SizedBox(height: 8),

          // Contact Actions
          _buildContactActions(client),
          const SizedBox(height: 5),

          // Client Status
          // _buildClientStatusSection(client),
          // const SizedBox(height: 8),

          // Assigned Agent
          _buildAssignedAgentSection(client),
          const SizedBox(height: 2),
          const Divider(), const SizedBox(height: 2),
          // Lead Status
          _buildCallStatusSection(),
          const SizedBox(height: 5),

          // // Client Notes
          // _buildClientNotesSection(client),
          // const SizedBox(height: 8),

          // // Call Recordings
          // _buildCallRecordingsSection(client),
          Container(
            height: 600,
            decoration: const BoxDecoration(
              // gradient: LinearGradient(
              //   colors: [
              //     const Color.fromARGB(255, 217, 152, 228).withAlpha(40),
              //     // const Color.fromARGB(255, 96, 171, 194).withAlpha(40),
              //     const Color.fromARGB(255, 149, 207, 255).withAlpha(40),
              //   ],
              //   begin: Alignment.topLeft,
              //   end: Alignment.bottomRight,
              // ),
              // borderRadius: const BorderRadius.only(
              //   topLeft: Radius.circular(50),
              //   topRight: Radius.circular(50),
              // ),
              // boxShadow: AppStyle.boxShadow,
            ),
            margin: const EdgeInsets.only(top: 0),
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: ToggleBar(
                    onTap: (index) {
                      controller.tab.value = index;
                    },
                    activePageIndex: controller.tab.value,
                    buttonsList: ['Follows', "Call logs"],
                  ),
                ),
                const SizedBox(height: 10),
                if (controller.tab.value == 0)
                  Expanded(
                    child: ListView.builder(
                      // physics: A,
                      padding: const EdgeInsets.only(
                        bottom: 16,
                        right: 10,
                        left: 10,
                      ),
                      itemCount: controller.followUps.length,
                      itemBuilder: (context, index) {
                        final followUp = controller.followUps[index];

                        return FeedbackMessageCard(
                          title: followUp.reason,
                          dateTime: DateFormat(
                            "dd/MM/yyyy - h:mm a",
                          ).format(followUp.followUpDate),
                          message: followUp.notes,
                        );

                        // return FollowUpCard(
                        //   followUp: followUp,
                        //   noCall: false,
                        //   onTap:
                        //       () => Get.to(
                        //         () => FollowUpDetailPage(
                        //           followUp: followUp,
                        //         ),
                        //       ),
                        // );
                      },
                    ),
                  ),
                if (controller.tab.value == 1)
                  const Column(
                    children: [
                      VoiceMessageCard(),
                      VoiceMessageCard(),
                      VoiceMessageCard(),
                      VoiceMessageCard(),
                    ],
                  ),
                //  _buildCallLogList(client),
              ],
            ),
          ),
        ],
      ),
    ),
  );

  Widget _buildCallLogList(ClientModel client) {
    CallLogController callLogController = Get.put(CallLogController());

    return Expanded(
      child: Obx(() {
        if (callLogController.isLoadNumberCallsLog.value) {
          return const Center(child: CircularProgressIndicator());
        }

        final grouped = callLogController.numberCallLogs;
        if (grouped.isEmpty) {
          return const Center(child: Text("No call logs found."));
        }

        return RefreshIndicator(
          onRefresh:
              () => callLogController.fetchCallLogsByNumber(client.phone),
          child: ListView.separated(
            physics: const AlwaysScrollableScrollPhysics(),
            itemCount: grouped.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final date = grouped.keys.elementAt(index);
              final entries = grouped[date]!;

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: Text(
                      date,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  ...entries.map(
                    (entry) => CallLogCard(
                      name:
                          entry.name?.isNotEmpty == true
                              ? entry.name!
                              : entry.number.toString(),
                      duration: entry.duration.toString(),
                      number: entry.number.toString(),

                      startTime: DateFormat('hh:mm a').format(
                        DateTime.fromMillisecondsSinceEpoch(
                          entry.timestamp ?? 0,
                        ),
                      ),
                      endTime: entry.timestamp.toString(),
                      callType: entry.callType!,
                    ),
                  ),
                ],
              );
            },
          ),
        );
      }),
    );
  }

  Widget _buildProfileHeader(ClientModel client) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16),
    child: Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              _buildContactInfo(Icons.email, client.email),
              const SizedBox(height: 5),
              _buildContactInfo(Icons.phone, client.phone),
            ],
          ),
        ),
      ],
    ),
  );

  Widget _buildContactInfo(IconData icon, String text) => Row(
    children: [
      Icon(icon, size: 16, color: Get.theme.colorScheme.primary),
      const SizedBox(width: 8),
      Expanded(
        child: Text(text, style: Get.theme.textTheme.bodyMedium?.copyWith()),
      ),
    ],
  );

  Widget _buildContactActions(ClientModel client) => Container(
    margin: const EdgeInsets.symmetric(horizontal: 20),
    // padding: const EdgeInsets.all(5),
    // decoration: AppStyle.decoration,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Expanded(
          child: ActionButton(
            icon: AppIcons.time2,
            label: 'Follow ups',
            color: Get.theme.primaryColor,
            onTap: () {
              Get.toNamed(AppPages.addFollowup);
            },
          ),
        ),
        Expanded(
          child: ActionButton(
            icon: AppIcons.whatsapp,
            label: 'Whatsapp',
            color: Colors.green,
            onTap: () {
              openWhatsApp(client.phone);
            },
          ),
        ),
        Expanded(
          child: ActionButton(
            icon: AppIcons.call,
            label: 'Call',
            color: Colors.blue,
            onTap: () {
              openSMS(client.phone);
            },
          ),
        ),
        // Expanded(
        //   child: ActionButton(
        //     icon: AppIcons.useredit,
        //     label: 'Assigned to',
        //     color: Colors.indigo,
        //     onTap: () {
        //       Get.toNamed(AppPages.followups);
        //     },
        //   ),
        // ),
      ],
    ),
  );

  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    required Color color,
  }) => Column(
    children: [
      IconButton(
        icon: Icon(icon),
        color: color,
        onPressed: onTap,
        iconSize: 28,
      ),
      const SizedBox(height: 4),
      Text(
        label,
        style: Get.theme.textTheme.bodySmall?.copyWith(
          color: Get.theme.colorScheme.onSurface.withOpacity(0.7),
        ),
      ),
    ],
  );

  Widget _buildClientStatusSection(ClientModel client) => Container(
    decoration: AppStyle.decoration,
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'client_is'.tr,
            style: Get.theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _buildStatusChips(client.status),
          ),
        ],
      ),
    ),
  );

  List<Widget> _buildStatusChips(String currentStatus) {
    const statusOptions = ['Hot', 'Warm', 'Cold', 'Highlight', 'Escalate'];

    return statusOptions.map((status) {
      final isSelected = status == currentStatus;
      return ChoiceChip(
        label: Text(status),
        selected: isSelected,
        onSelected: (selected) {
          if (selected) {
            controller.updateClientStatus(status);
          }
        },
        selectedColor: _getStatusColor(status),
        labelStyle: TextStyle(
          color: isSelected ? Colors.white : Get.theme.colorScheme.onSurface,
        ),
      );
    }).toList();
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'hot':
        return Colors.red;
      case 'warm':
        return Colors.orange;
      case 'cold':
        return Colors.blue;
      case 'highlight':
        return Colors.yellow;
      case 'escalate':
        return Colors.purple;
      default:
        return Get.theme.colorScheme.primary;
    }
  }

  Widget _buildAssignedAgentSection(ClientModel client) => Container(
    decoration: AppStyle.decoration,
    margin: const EdgeInsets.symmetric(horizontal: 10),
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TitleText('assigned_to'.tr),

          Row(
            children: [
              if (client.assignedAgent != null)
                Expanded(child: _buildAgentCard(client.assignedAgent!)),

              OutlinedButton(
                onPressed: controller.showAgentSelectionModal,
                child: Text(
                  'reassign_lead'.tr,
                  style: Get.theme.textTheme.bodyMedium,
                ),
              ),
            ],
          ),
        ],
      ),
    ),
  );

  Widget _buildAgentCard(AgentModel agent) => Row(
    children: [
      // Avatar
      CircleAvatar(
        radius: 15,
        backgroundColor: Get.theme.colorScheme.primary,
        child:
            agent.imageUrl != null
                ? CircleAvatar(
                  radius: 15,
                  backgroundImage: NetworkImage(agent.imageUrl!),
                )
                : Text(
                  _getInitials(agent.name),
                  style: Get.theme.textTheme.bodyMedium?.copyWith(
                    color: Colors.white,
                  ),
                ),
      ),
      const SizedBox(width: 8),

      // Name & phone
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(agent.name, style: Get.theme.textTheme.bodyMedium?.copyWith()),
            const SizedBox(height: 5),
            if (agent.phone != null)
              Text(
                agent.phone!,
                style: Get.theme.textTheme.bodySmall?.copyWith(
                  color: Colors.grey[700],
                ),
              ),
          ],
        ),
      ),
    ],
  );

  Widget _buildCallStatusSection() => Container(
    decoration: AppStyle.decoration,
    margin: const EdgeInsets.symmetric(horizontal: 10),
    padding: const EdgeInsets.symmetric(horizontal: 10),

    child: Row(
      crossAxisAlignment: CrossAxisAlignment.center,

      children: [
        Expanded(child: TitleText('lead_status'.tr)),
        // const SizedBox(width: 10,),
        Expanded(
          child: InkWell(
            onTap: controller.showStatusUpdateDialog,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              decoration: BoxDecoration(
                color: Get.theme.colorScheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: DropdownButtonFormField<String>(
                value:
                    controller.selectedleadStatus.value.isEmpty
                        ? null
                        : controller.selectedleadStatus.value,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.all(0),
                  hintText: 'Select Status',
                  hintStyle: Get.theme.textTheme.bodySmall,
                ),
                isExpanded: true,
                style: Get.theme.textTheme.bodySmall,
                items:
                    controller.statusleadOptions
                        .map(
                          (String status) => DropdownMenuItem<String>(
                            value: status,
                            child: Text(
                              status,
                              style: Get.theme.textTheme.bodySmall,
                            ),
                          ),
                        )
                        .toList(),
                onChanged: (String? newValue) {
                  if (newValue != null) {
                    controller.selectedleadStatus.value = newValue;
                  }
                },
              ),
            ),
          ),
        ),
      ],
    ),
  );

  Widget _buildClientNotesSection(ClientModel client) {
    if (client.notes == null || client.notes!.isEmpty) {
      return const SizedBox();
    }

    return Container(
      decoration: AppStyle.decoration,
      margin: const EdgeInsets.symmetric(horizontal: 10),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TitleText('notes'.tr),
            const SizedBox(height: 8),
            Obx(() {
              final isExpanded = controller.isNotesExpanded.value;
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    client.notes!,
                    maxLines: !isExpanded ? null : 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (client.notes!.length > 100) ...[
                    const SizedBox(height: 8),
                    GestureDetector(
                      onTap: controller.toggleNotesExpansion,
                      child: Text(
                        isExpanded ? 'read_less'.tr : 'read_more'.tr,
                        style: Get.theme.textTheme.bodySmall?.copyWith(
                          color: Get.theme.colorScheme.primary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ],
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildCallRecordingsSection(ClientModel client) => Container(
    decoration: AppStyle.decoration,
    margin: const EdgeInsets.symmetric(horizontal: 10),
    child: Padding(
      padding: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              TitleText('Call Recording'.tr),
              const Spacer(),
              TextButton(
                onPressed: controller.navigateToCallRecordings,
                child: Text('view_all'.tr),
              ),
            ],
          ),
          if (client.callRecordings.isEmpty)
            Text(
              'no_recordings'.tr,
              style: Get.theme.textTheme.bodyMedium?.copyWith(
                color: Get.theme.colorScheme.onSurface.withOpacity(0.5),
              ),
            )
          else
            ...client.callRecordings.take(1).map(_buildRecordingItem),
        ],
      ),
    ),
  );

  Widget _buildRecordingItem(CallRecordingModel recording) => ListTile(
    title: Text(
      '${_formatDuration(recording.duration)} • ${_formatDate(recording.recordedAt)}',
    ),
    // subtitle:
    //     recording.callerNumber != null ? Text(recording.callerNumber!) : null,
    trailing: IconButton(
      icon: Icon(Icons.play_circle_fill, color: Get.theme.primaryColor),
      onPressed: () {
        // Implement download functionality
        controller.showSuccessToast('Playing recording');
      },
    ),
  );

  String _getInitials(String name) {
    final parts = name.split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return name.length >= 2
        ? name.substring(0, 2).toUpperCase()
        : name.toUpperCase();
  }

  String _formatDuration(int seconds) {
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  String _formatDate(DateTime date) => '${date.day}-${date.month}-${date.year}';
}
