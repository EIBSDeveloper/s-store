import 'package:call_tracker/src/app/modules/calls/contoller/call_log_contoller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class UnsaveCalls extends GetView<CallLogController> {
  const UnsaveCalls({super.key});

  @override
  Widget build(BuildContext context) => RefreshIndicator(
      onRefresh: () async => controller.fetchUnsavedCallLogs(),
      child: const Center(child: Text("Under Development")),
    );
}
