import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../contoller/client_controller.dart';

class StatusUpdateDialog extends StatelessWidget {
  final ClientController controller;

  const StatusUpdateDialog({super.key, required this.controller});

  @override
  Widget build(BuildContext context) => AlertDialog(
      title: Text('update_call_status'.tr),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Text('select_new_status'.tr),
          // const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _buildStatusOption('Call Back'),
              _buildStatusOption('Meeting Scheduled'),
              _buildStatusOption('Proposal Sent'),
              _buildStatusOption('Negotiation'),
              _buildStatusOption('Closed Won'),
              _buildStatusOption('Closed Lost'),
            ],
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: Get.back,
          child: Text('cancel'.tr),
        ),
      ],
    );

  Widget _buildStatusOption(String status) => ChoiceChip(
      label: Text(status),
      selected: false,
      onSelected: (selected) {
        if (selected) {
          controller.showSuccessToast('Status updated to $status');
          Get.back();
        }
      },
    );
}