import 'package:get/get.dart';

import '../contoller/client_controller.dart';
import '../repository/client_repository.dart';

class ClientBinding extends Bindings {


  ClientBinding();

  @override
  void dependencies() {
    Get.lazyPut<ClientRepository>(() => ClientRepository());

    Get.lazyPut<ClientController>(() => ClientController());
  }
}
