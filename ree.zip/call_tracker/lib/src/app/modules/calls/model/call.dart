

import 'dart:io';

import 'package:call_log/call_log.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';

import '../contoller/call_recording_controller.dart';

class Call {
  String id;
  String name;
  String number;
  CallType callType;
  String start;
  String end;
  String duration;
  
  Call({
    required this.id,
    required this.name,
    required this.number,
    required this.callType,
    required this.start,
    required this.end,
    required this.duration,
  });

  // Getter to find the most likely recording path for this call
  String? get recordingPath {
    try {
      final controller = Get.find<CallRecordingController>();
      final allRecordings = controller.recordings.values.expand((list) => list).toList();
      
      // Try to find by number and call time first
      final formattedNumber = _formatNumberForSearch(number);
      final callTime = DateTime.tryParse(start);
      
      
      // 1. Exact match with number and time
      if (formattedNumber != null && callTime != null) {
        final exactMatch = allRecordings.firstWhereOrNull((recording) {
          final fileName = recording.path.toLowerCase();
          return fileName.contains(formattedNumber.toLowerCase()) &&
                 _isTimeMatch(recording, callTime);
        });
        if (exactMatch != null) return exactMatch.path;
      }
      
      // 2. Number with approximate time (±5 minutes)
      if (formattedNumber != null && callTime != null) {
        final approximateMatch = allRecordings.firstWhereOrNull((recording) {
          final fileName = recording.path.toLowerCase();
          return fileName.contains(formattedNumber.toLowerCase()) &&
                 _isTimeApproximateMatch(recording, callTime);
        });
        if (approximateMatch != null) return approximateMatch.path;
      }
      
      // 3. Number only
      if (formattedNumber != null) {
        final numberMatch = allRecordings.firstWhereOrNull((recording) => recording.path.toLowerCase().contains(formattedNumber.toLowerCase()));
        if (numberMatch != null) return numberMatch.path;
      }
      
      // 4. Time only
      if (callTime != null) {
        final timeMatch = allRecordings.firstWhereOrNull((recording) => _isTimeMatch(recording, callTime));
        if (timeMatch != null) return timeMatch.path;
      }
      
      // 5. Duration match (last resort)
      final durationMatch = allRecordings.firstWhereOrNull((recording) => _isDurationMatch(recording, duration));
      if (durationMatch != null) return durationMatch.path;
      
      return null;
    } catch (e) {
      debugPrint('Error finding recording path: $e');
      return null;
    }
  }

  // Helper methods
  String? _formatNumberForSearch(String number) {
    // Remove all non-digit characters except '+'
    final cleaned = number.replaceAll(RegExp(r'[^\d+]'), '');
    return cleaned.isEmpty ? null : cleaned;
  }

  bool _isTimeMatch(FileSystemEntity recording, DateTime callTime) {
    try {
      final modified = recording.statSync().modified;
      return modified.year == callTime.year &&
             modified.month == callTime.month &&
             modified.day == callTime.day &&
             modified.hour == callTime.hour &&
             modified.minute == callTime.minute;
    } catch (e) {
      return false;
    }
  }

  bool _isTimeApproximateMatch(FileSystemEntity recording, DateTime callTime) {
    try {
      final modified = recording.statSync().modified;
      final diff = modified.difference(callTime).inMinutes.abs();
      return modified.year == callTime.year &&
             modified.month == callTime.month &&
             modified.day == callTime.day &&
             diff <= 5; // ±5 minutes
    } catch (e) {
      return false;
    }
  }

  bool _isDurationMatch(FileSystemEntity recording, String duration) {
    try {
      // Parse duration string (format may vary)
      final durParts = duration.split(':');
      if (durParts.length != 3) return false;
      
      final callDuration = Duration(
        hours: int.parse(durParts[0]),
        minutes: int.parse(durParts[1]),
        seconds: int.parse(durParts[2]),
      );
      
      final fileDuration = _getAudioDuration(recording.path);
      if (fileDuration == null) return false;
      
      // Consider it a match if within ±10 seconds
      return (fileDuration - callDuration).inSeconds.abs() <= 10;
    } catch (e) {
      return false;
    }
  }

  Duration? _getAudioDuration(String path) => null;
}
