class ClientModel {
  final String id;
  final String name;
  final String email;
  final String phone;
  final String status;
  final String? notes;
  final AgentModel? assignedAgent;
  final List<CallRecordingModel> callRecordings;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  ClientModel({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.status,
    this.notes,
    this.assignedAgent,
    this.callRecordings = const [],
    this.createdAt,
    this.updatedAt,
  });

  factory ClientModel.fromJson(Map<String, dynamic> json) => ClientModel(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      email: json['email'] ?? '',
      phone: json['phone'] ?? '',
      status: json['status'] ?? 'Warm',
      notes: json['notes'],
      assignedAgent: json['assigned_agent'] != null 
          ? AgentModel.fromJson(json['assigned_agent']) 
          : null,
      callRecordings: json['call_recordings'] != null
          ? List<CallRecordingModel>.from(
              json['call_recordings'].map((x) => CallRecordingModel.fromJson(x)))
          : [],
      createdAt: json['created_at'] != null ? DateTime.parse(json['created_at']) : null,
      updatedAt: json['updated_at'] != null ? DateTime.parse(json['updated_at']) : null,
    );

  Map<String, dynamic> toJson() => {
      'id': id,
      'name': name,
      'email': email,
      'phone': phone,
      'status': status,
      'notes': notes,
      'assigned_agent': assignedAgent?.toJson(),
      'call_recordings': callRecordings.map((x) => x.toJson()).toList(),
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };

  ClientModel copyWith({
    String? id,
    String? name,
    String? email,
    String? phone,
    String? status,
    String? notes,
    AgentModel? assignedAgent,
    List<CallRecordingModel>? callRecordings,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) => ClientModel(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      status: status ?? this.status,
      notes: notes ?? this.notes,
      assignedAgent: assignedAgent ?? this.assignedAgent,
      callRecordings: callRecordings ?? this.callRecordings,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
}

class AgentModel {
  final String id;
  final String name;
  final String? email;
  final String? phone;
  final String? imageUrl;

  AgentModel({
    required this.id,
    required this.name,
    this.email,
    this.phone,
    this.imageUrl,
  });

  factory AgentModel.fromJson(Map<String, dynamic> json) => AgentModel(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      email: json['email'],
      phone: json['phone'],
      imageUrl: json['image_url'],
    );

  Map<String, dynamic> toJson() => {
      'id': id,
      'name': name,
      'email': email,
      'phone': phone,
      'image_url': imageUrl,
    };
}

class CallRecordingModel {
  final String id;
  final String callId;
  final String url;
  final int duration;
  final DateTime recordedAt;
  final String? callerNumber;

  CallRecordingModel({
    required this.id,
    required this.callId,
    required this.url,
    required this.duration,
    required this.recordedAt,
    this.callerNumber,
  });

  factory CallRecordingModel.fromJson(Map<String, dynamic> json) => CallRecordingModel(
      id: json['id'] ?? '',
      callId: json['call_id'] ?? '',
      url: json['url'] ?? '',
      duration: json['duration'] ?? 0,
      recordedAt: DateTime.parse(json['recorded_at']),
      callerNumber: json['caller_number'],
    );

  Map<String, dynamic> toJson() => {
      'id': id,
      'call_id': callId,
      'url': url,
      'duration': duration,
      'recorded_at': recordedAt.toIso8601String(),
      'caller_number': callerNumber,
    };
}