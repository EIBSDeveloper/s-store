import 'package:call_log/call_log.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../../core/enums.dart';

class CallLogController extends GetxController {
  var allCallLogs = <CallLogEntry>[].obs;
    final TextEditingController mobileController = TextEditingController();
  var filteredLogs = <String, List<CallLogEntry>>{}.obs;
  var numberCallLogs = <String, List<CallLogEntry>>{}.obs;
  var unsavedCalls = <CallLogEntry>[].obs;
  var filter = Rx<CallType?>(null);
  var dateFilter = DateFilterType.all.obs;
  RxBool isLoadCallLog = false.obs;
  RxString isExpended = ''.obs;
  RxBool isLoadUnsaveCallLog = false.obs;
  RxBool isLoadNumberCallsLog = false.obs;
  String display = '';
  // Call count variables
  var totalCallsCount = 0.obs;
  var missedCallsCount = 0.obs;
  var incomingCallsCount = 0.obs;
  var outgoingCallsCount = 0.obs;
  var todayOverallCallCount = 0.obs;

  @override
  Future<void> onInit() async {
    super.onInit();
    await fetchCallLogs();
    setFilter();
    fetchUnsavedCallLogs();
    updateCallCounts();
  }

  refreshLog() async {
    await fetchCallLogs();
    setFilter();
    updateCallCounts();
    fetchUnsavedCallLogs();
    return;
  }

  refreshunSaveLog() async {
    await fetchUnsavedCallLogs();

    return;
  }

  Future<void> fetchCallLogs() async {
    try {
      isLoadCallLog.value = true;
      allCallLogs.clear();
      filteredLogs.clear();
      DateTime now = DateTime.now();
      DateTime startOfMonth = DateTime(now.year, now.month, 1);
      DateTime dateTimeFrom = startOfMonth.subtract(
        const Duration(days: 1),
      ); // One day before start of month

      if (await Permission.phone.request().isGranted) {
        final entries = await CallLog.query(
          dateTimeFrom: dateTimeFrom,
          dateTimeTo: now,
        );
        allCallLogs.assignAll(entries.toList());
        updateCallCounts();
        updateTodayOverallCount();
      }
    } finally {
      isLoadCallLog.value = false;
    }
  }

  fetchCallLogsByNumber(String number) async {
    isLoadNumberCallsLog.value = true;
    List<CallLogEntry> callLags = [];
    final Map<String, List<CallLogEntry>> grouped = {};

    DateTime now = DateTime.now();
    DateTime startOfMonth = DateTime(now.year, now.month, 1);
    DateTime dateTimeFrom = startOfMonth.subtract(const Duration(days: 1));

    if (await Permission.phone.request().isGranted) {
      final entries = await CallLog.query(
        dateTimeFrom: dateTimeFrom,
        dateTimeTo: now,
        number: number,
      );
      callLags.assignAll(entries.toList());
    }

    for (var entry in callLags) {
      final date = DateFormat(
        'dd MMM yyyy',
      ).format(DateTime.fromMillisecondsSinceEpoch(entry.timestamp ?? 0));
      if (!grouped.containsKey(date)) {
        grouped[date] = [];
      }
      grouped[date]!.add(entry);
    }

    numberCallLogs.value = grouped;
    isLoadNumberCallsLog.value = false;
  }

  // New method to calculate today's overall call count
  void updateTodayOverallCount() {
    final now = DateTime.now();
    todayOverallCallCount.value =
        allCallLogs.where((entry) {
          final date = DateTime.fromMillisecondsSinceEpoch(
            entry.timestamp ?? 0,
          );
          return date.year == now.year &&
              date.month == now.month &&
              date.day == now.day;
        }).length;
  }

  Future<void> fetchUnsavedCallLogs() async {
    isLoadUnsaveCallLog.value = true;
    unsavedCalls.clear();
    var status = await Permission.phone.status;
    if (!status.isGranted) {
      await Permission.phone.request();
    }

    final Iterable<CallLogEntry> entries = await CallLog.get();

    final unknown = entries.where(
      (entry) =>
          (entry.name == null || entry.name!.trim().isEmpty) &&
          entry.number != null,
    );

    unsavedCalls.assignAll(unknown);
    isLoadUnsaveCallLog.value = false;
  }

  void setFilter({CallType? selectedType, DateFilterType? selectedDate}) {
    isLoadCallLog.value = true;
    filter.value = selectedType;
    dateFilter.value = selectedDate ?? dateFilter.value;

    Iterable<CallLogEntry> calls = allCallLogs;

    // Apply call type filter
    if (selectedType != null) {
      calls = calls.where((e) => e.callType == selectedType).toList();
    }

    // Apply date filter
    final now = DateTime.now();

    calls = calls.where((entry) {
      final date = DateTime.fromMillisecondsSinceEpoch(entry.timestamp ?? 0);
      switch (dateFilter.value) {
        case DateFilterType.today:
          return date.year == now.year &&
              date.month == now.month &&
              date.day == now.day;
        case DateFilterType.thisWeek:
          final startOfWeek = now.subtract(Duration(days: now.weekday));
          final endOfWeek = startOfWeek.add(const Duration(days: 6));
          return (date.isAfter(startOfWeek) ||
                  date.isAtSameMomentAs(startOfWeek)) &&
              (date.isBefore(endOfWeek) || date.isAtSameMomentAs(endOfWeek));
        case DateFilterType.thisMonth:
          return date.year == now.year && date.month == now.month;
        case DateFilterType.all:
          return true;
      }
    });

    // Group by date
    final Map<String, List<CallLogEntry>> grouped = {};
    for (var entry in calls) {
      final dateStr = DateFormat(
        'dd MMM yyyy',
      ).format(DateTime.fromMillisecondsSinceEpoch(entry.timestamp ?? 0));
      grouped.putIfAbsent(dateStr, () => []).add(entry);
    }

    filteredLogs.value = grouped;
    if (selectedDate != null) {
      updateCallCounts();
    }
    isLoadCallLog.value = false;
  }

  void updateCallCounts() {
    final calls = filteredLogs.values.expand((list) => list).toList();

    totalCallsCount.value = calls.length;
    missedCallsCount.value =
        calls.where((e) => e.callType == CallType.missed).length;
    incomingCallsCount.value =
        calls.where((e) => e.callType == CallType.incoming).length;
    outgoingCallsCount.value =
        calls.where((e) => e.callType == CallType.outgoing).length;
  }

  Map<String, List<CallLogEntry>> groupedUnSaveLogsByDate() {
    final Map<String, List<CallLogEntry>> grouped = {};
    for (var entry in unsavedCalls) {
      final date = DateFormat(
        'dd MMM yyyy',
      ).format(DateTime.fromMillisecondsSinceEpoch(entry.timestamp ?? 0));
      if (!grouped.containsKey(date)) {
        grouped[date] = [];
      }
      grouped[date]!.add(entry);
    }
    return grouped;
  }
}
