import 'package:call_log/call_log.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import '../../followups/model/followup_model.dart';
import '../model/client_model.dart';
import '../repository/client_repository.dart';
import '../views/widgets/agent_selection_bottom_sheet.dart';
import '../views/widgets/status_update_dialog.dart';

class ClientController extends GetxController {
  final ClientRepository repository = Get.find();
  final String clientId = "";

  ClientController();

  final Rx<ClientModel?> _client = Rx<ClientModel?>(null);
  final RxBool isLoading = false.obs;
  RxBool isLoadCallLog = false.obs;
  final RxInt tab = 0.obs;
  var filteredLogs = <String, List<CallLogEntry>>{}.obs;
  final RxString error = ''.obs;
  final RxBool isNotesExpanded = false.obs;
  final RxList<AgentModel> availableAgents = <AgentModel>[].obs;

  final selectedAgent = Rxn<AgentModel>();
  final reasonTextController = TextEditingController();
  final selectedcallStatus = ''.obs;
  final selectedleadStatus = ''.obs;

  final List<String> statuscallOptions = [
    'Call Back',
    'Meeting Scheduled',
    'Proposal Sent',
    'Negotiation',
    'Closed Won',
    'Closed Lost',
  ];

  final List<String> statusleadOptions = ['Hot', 'Warm', 'Cold'];

  List<FollowUpModel> followUps = [
    // Next week follow-up
    FollowUpModel(
      id: 'f4',
      leadId: '100',
      followUpDate: DateTime.now().add(const Duration(days: 7)),
      reason: 'Follow-up Call',
      status: 'Scheduled',
      notes: 'Check on client satisfaction and address any concerns',
      createdAt: DateTime.now().subtract(const Duration(days: 1)),
    ),
    // Overdue follow-up
    FollowUpModel(
      id: '102',
      leadId: '5',
      followUpDate: DateTime.now().subtract(const Duration(days: 1)),
      reason: 'Payment Follow-up',
      status: 'Overdue',
      notes: 'Client missed payment deadline, need to follow up urgently',
      createdAt: DateTime.now().subtract(const Duration(days: 10)),
    ),
  ];
  List<CallLogEntry> callLogs = [];
  ClientModel? get client => _client.value;

  @override
  void onInit() {
    super.onInit();
    loadClientDetails();
    loadAvailableAgents();
    update();
  }

  // Future<void> update() async {

  //     // followUps = folloUpController.getFollowUpsByLeadId(widget.lead.id);
  //     // callLogController.fetchCallLogsByNumber(widget.lead.phone);

  // }

  Future<void> loadClientDetails() async {
    try {
      isLoading(true);
      error('');
      final clientData = await repository.getClientDetails(clientId);
      _client(clientData);
    } catch (e) {
      error(e.toString());
      showErrorToast('Failed to load client details');
    } finally {
      isLoading(false);
    }
  }

  Future<void> updateClientStatus(String status) async {
    try {
      isLoading(true);
      final updatedClient = await repository.updateClientStatus(
        clientId,
        status,
      );
      _client(updatedClient);
      showSuccessToast('Status updated successfully');
    } catch (e) {
      showErrorToast('Failed to update status');
    } finally {
      isLoading(false);
    }
  }

  Future<void> reassignAgent(String agentId) async {
    try {
      isLoading(true);
      final updatedClient = await repository.reassignAgent(clientId, agentId);
      _client(updatedClient);
      showSuccessToast('Agent reassigned successfully');
      Get.back(); // Close the agent selection modal
    } catch (e) {
      showErrorToast('Failed to reassign agent');
    } finally {
      isLoading(false);
    }
  }

  Future<void> loadAvailableAgents() async {
    try {
      final agents = await repository.getAvailableAgents();
      availableAgents.assignAll(agents);
    } catch (e) {
      showErrorToast('Failed to load agents');
    }
  }

  void toggleNotesExpansion() {
    isNotesExpanded.toggle();
  }

  void launchPhoneDialer() {
    if (client?.phone.isNotEmpty == true) {
      // Use url_launcher in real implementation
      // launchUrl(Uri.parse('tel:${client!.phone}'));
      showSuccessToast('Calling ${client!.phone}');
    } else {
      showErrorToast('Phone number not available');
    }
  }

  void launchSMS() {
    if (client?.phone.isNotEmpty == true) {
      // Use url_launcher in real implementation
      // launchUrl(Uri.parse('sms:${client!.phone}'));
      showSuccessToast('Opening SMS for ${client!.phone}');
    } else {
      showErrorToast('Phone number not available');
    }
  }

  void launchWhatsApp() {
    if (client?.phone.isNotEmpty == true) {
      // Use url_launcher in real implementation
      // launchUrl(Uri.parse('https://wa.me/${client!.phone}'));
      showSuccessToast('Opening WhatsApp for ${client!.phone}');
    } else {
      showErrorToast('Phone number not available');
    }
  }

  void navigateToCallRecordings() {
    if (client != null) {
      // Get.toNamed('/call-recordings', arguments: {
      //   'clientId': clientId,
      //   'clientName': client!.name,
      // });
    }
  }

  void navigateToEditClient() {
    if (client != null) {
      // Get.toNamed('/edit-client', arguments: client);
    }
  }

  void showAgentSelectionModal() {
    // loadAvailableAgents();
    Get.bottomSheet(AgentSelectionBottomSheet(), isScrollControlled: true);
  }

  void showStatusUpdateDialog() {
    Get.dialog(StatusUpdateDialog(controller: this));
  }

  void showSuccessToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.green,
      textColor: Colors.white,
    );
  }

  void showErrorToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.red,
      textColor: Colors.white,
    );
  }

  @override
  void onClose() {
    // Dispose any resources if needed
    super.onClose();
  }
}
