import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:just_audio/just_audio.dart';

class CallRecordingController extends GetxController {
  var recordings = <String, List<FileSystemEntity>>{}.obs;
  var recordingsList = <FileSystemEntity>[].obs;
  var isLoading = false.obs;
  var errorMessage = Rx<String?>(null);

  @override
  void onInit() {
    super.onInit();
    findCallRecordings();
  }

  Future<void> findCallRecordings() async {
    isLoading.value = true;
    errorMessage.value = null;
    recordings.clear();

    try {
      final hasPermission = await _checkAndRequestPermissions();
      if (!hasPermission) {
        isLoading.value = false;
        return;
      }

      final directoryResults = await _searchCallRecordingDirectories();
      recordingsList.value = directoryResults;
      _groupRecordingsByDate(directoryResults);
    } catch (e) {
      errorMessage.value = 'Error: ${e.toString()}';
    } finally {
      isLoading.value = false;
    }
  }

  void _groupRecordingsByDate(List<FileSystemEntity> files) {
    final grouped = <DateTime, List<FileSystemEntity>>{};

    for (final file in files) {
      final modified = file.statSync().modified;
      final dateKey = DateTime(modified.year, modified.month, modified.day);
      grouped.putIfAbsent(dateKey, () => []).add(file);
    }

    final sortedKeys = grouped.keys.toList()..sort((a, b) => b.compareTo(a));
    final sortedMap = <String, List<FileSystemEntity>>{};
    final dateFormat = DateFormat('dd MMM yyyy');
    for (final key in sortedKeys) {
      grouped[key]!.sort(
        (a, b) => b.statSync().modified.compareTo(a.statSync().modified),
      );
      sortedMap[dateFormat.format(key)] = grouped[key]!;
    }

    recordings.value = sortedMap;
  }

  Future<bool> _checkAndRequestPermissions() async {
    final androidInfo = await DeviceInfoPlugin().androidInfo;
    if (androidInfo.version.sdkInt >= 30) {
      final manageStatus = await Permission.manageExternalStorage.status;
      if (!manageStatus.isGranted) {
        if (await Permission.manageExternalStorage.shouldShowRequestRationale) {
          errorMessage.value =
              'This app needs storage access to find call recordings';
          await Future.delayed(const Duration(seconds: 2));
        }

        final result = await Permission.manageExternalStorage.request();
        if (!result.isGranted) {
          errorMessage.value = 'Full storage access is required';
          try {
            await openAppSettings();
          } catch (e) {
            debugPrint('Could not open app settings: $e');
          }
          return false;
        }
      }
    } else {
      final storageStatus = await Permission.storage.status;
      if (!storageStatus.isGranted) {
        final result = await Permission.storage.request();
        if (!result.isGranted) {
          errorMessage.value = 'Storage permission is required';
          return false;
        }
      }
    }
    return true;
  }

  Future<List<FileSystemEntity>> _searchCallRecordingDirectories() async {
    final List<FileSystemEntity> foundRecordings = [];

    const commonPaths = [
      '/storage/emulated/0/CallRecordings',
      '/storage/emulated/0/Recordings',
      '/storage/emulated/0/Record/Call',
      '/storage/emulated/0/Sounds/CallRecordings',
      '/storage/emulated/0/MIUI/sound_recorder/call_rec',
      '/storage/emulated/0/Android/media/com.android.phone/Recordings',
      '/storage/emulated/0/DCIM/CallRecordings',
      '/storage/emulated/0/VoiceRecorder/Call',
      '/storage/emulated/0/My Files/Call recordings',
    ];

    for (final dirPath in commonPaths) {
      try {
        final dir = Directory(dirPath);
        if (await dir.exists()) {
          final files = dir.listSync(recursive: true);
          foundRecordings.addAll(
            files.where((f) => f is File && _isAudioFile(f.path)),
          );
        }
      } catch (e) {
        debugPrint('Error accessing $dirPath: $e');
      }
    }

    return foundRecordings;
  }

  bool _isAudioFile(String path) {
    const audioExtensions = [
      '.mp3',
      '.wav',
      '.m4a',
      '.aac',
      '.amr',
      '.ogg',
      '.3gp',
    ];
    return audioExtensions.contains(
      path.substring(path.lastIndexOf('.')).toLowerCase(),
    );
  }

  Future<String?> findRecordingByCallLog({
    required String number,
    required int timestamp,
    int? duration,
    String? name,
    required String dateKey, // e.g. "July 08, 2025"
  }) async {
    try {
      if (recordings.isEmpty) return null;
      if (!recordings.containsKey(dateKey)) return null;

      final callTime = DateTime.fromMillisecondsSinceEpoch(timestamp);
      final normalizedNumber = _normalizeNumber(number);
      final last10Digits =
          normalizedNumber.length > 10
              ? normalizedNumber.substring(normalizedNumber.length - 10)
              : normalizedNumber;

      final dateRecordings = recordings[dateKey]!;

      for (final recording in dateRecordings) {
        try {
          final filePath = recording.path;
          final fileName = filePath.split('/').last.toLowerCase();

          final stat = await recording.stat();
          final createdTime = stat.changed;

          final audioDuration = await _getAudioDuration(filePath);

          final timeDiff = createdTime.difference(callTime).inSeconds.abs();
          final timeMatch = timeDiff <= 60; // within 10 minutes

          final numberMatch =
              fileName.contains(normalizedNumber) ||
              fileName.contains(last10Digits) ||
              _checkAlternativeNumberFormats(fileName, normalizedNumber);

          final nameMatch =
              name != null ? _checkNameMatch(fileName, name) : false;

          final durationMatch =
              (duration != null && audioDuration != null)
                  ? (audioDuration - duration).abs() <= 5
                  : false;

          if ((numberMatch || nameMatch) && timeMatch && durationMatch) {
            return filePath;
          }
        } catch (e) {
          debugPrint('Error processing recording ${recording.path}: $e');
          continue;
        }
      }
      return null;
    } catch (e) {
      debugPrint('Error in findRecordingByCallLog: $e');
      return null;
    }
  }

  String _normalizeNumber(String num) => num.replaceAll(RegExp(r'[^0-9]'), '')
        .replaceAll(RegExp(r'^00'), '') // Remove international prefix
        .replaceAll(RegExp(r'^\+'), '')
        .replaceFirst(RegExp(r'^0'), '');

  bool _checkAlternativeNumberFormats(
    String fileName,
    String normalizedNumber,
  ) {
    final digitsInFile = fileName.replaceAll(RegExp(r'[^0-9]'), '');
    final last10 =
        normalizedNumber.length > 10
            ? normalizedNumber.substring(normalizedNumber.length - 10)
            : normalizedNumber;
    return digitsInFile.contains(last10);
  }

  bool _checkNameMatch(String fileName, String name) {
    final normalizedFileName = fileName.replaceAll(RegExp(r'[^a-z0-9]'), '');
    final normalizedInputName = name.trim().toLowerCase().replaceAll(
      RegExp(r'[^a-z0-9]'),
      '',
    );
    return normalizedFileName.contains(normalizedInputName);
  }

  Future<int?> _getAudioDuration(String filePath) async {
    try {
      final player = AudioPlayer();
      await player.setFilePath(filePath);
      final duration = player.duration?.inSeconds;
      await player.dispose();
      return duration;
    } catch (e) {
      debugPrint('Error getting duration for $filePath: $e');
      return null;
    }
  }
}
