import 'package:call_tracker/src/app/widgets/background.dart';
import 'package:call_tracker/src/app/widgets/title_text.dart';
import 'package:call_tracker/src/core/app_icons.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../call_log.dart';
import '../../../../../core/app_style.dart';
import '../../../../utils/routes/app_pages.dart';
import '../../../main/view/widgets/action_button.dart';
import '../../contoller/bottombar_contoller.dart';
import '../../model/bottom_nav_bar_item.dart';
import '../widgets/bottom_nav_bar.dart';

class Home extends GetView<BottomBarContoller> {
  const Home({super.key});

  @override
  Widget build(BuildContext context) => Background(
    child: Scaffold(
      key: controller.scaffoldKey,
      backgroundColor: Colors.transparent,
      drawer: const CustomAppDrawer(selectedItem: "messafe"),
      // drawer: Drawer(
      //   child: ListView(
      //     padding: EdgeInsets.zero,
      //     children: <Widget>[
      //       const DrawerHeader(
      //         decoration: BoxDecoration(color: Colors.blue),
      //         child: Text(
      //           'CallTracker App',
      //           style: TextStyle(color: Colors.white),
      //         ),
      //       ),
      //       ListTile(
      //         title: const Text('Whatsapp Message'),
      //         onTap: () {
      //           Get.toNamed(AppPages.whatsAppMessage);
      //         },
      //       ),
      //       ListTile(
      //         title: const Text('Assing to me'),
      //         onTap: () {
      //           // Get.toNamed(AppPages.whatsAppMessage);
      //         },
      //       ),

      //       // ListTile(title: Text('Item 2')),
      //     ],
      //   ),
      // ),
      appBar: AppBar(
        title: const TitleText("Call Tracker"),
        toolbarHeight: 50,
        backgroundColor: Colors.white54,
        leading: IconButton(
          onPressed: controller.openDrawer,
          icon: ImageView(
            AppIcons.menuicon,
            width: AppStyle.iconSize2,
            height: AppStyle.iconSize2,
          ),
        ),
        actions: [
          // IconButton(
          //   onPressed: () {
          //     Get.toNamed(AppPages.callRecord);
          //   },
          //   icon: ImageView(
          //     AppIcons.callRing,
          //     width: AppStyle.iconsize,
          //     height: AppStyle.iconsize,
          //   ),
          // ),
          IconButton(
            onPressed: () {
              //  Get.toNamed(AppPages.dialPad);
              Get.toNamed(AppPages.notification);
            },
            icon: ImageView(
              AppIcons.notification,
              width: AppStyle.iconSizelarge,
              color: Get.theme.primaryColor,
              height: AppStyle.iconSizelarge,
            ),
          ),
          InkWell(
            onTap: () {
              Get.toNamed(AppPages.profile);
            },
            child: Icon(
              Icons.account_circle
              ,color: Get.theme.primaryColor,
            ),
            // child: ImageView(
            //   AppIcons.user,
            //   width: AppStyle.iconSizelarge,
                   
            //   height: AppStyle.iconSizelarge,
            // ),
          ),
          const SizedBox(width: 18,)
        ],
      ),
      body: SafeArea(
        child: PageView.builder(
          controller: controller.pageController,
          itemCount: controller.pages.length,
          itemBuilder: (context, index) => controller.pages[index],
          onPageChanged: (index) {
            controller.selectedIndex.value = index;
          },
        ),
      ),

      bottomNavigationBar: SafeArea(
        child: Obx(
          () => BottomNavBar(
            key: const ValueKey("ButtomBar"),
            curentIndex: controller.selectedIndex.value,
            backgroundColor: Colors.white,

            selectColor: Get.theme.colorScheme.secondaryContainer,
            onTap: (index) {
              controller.selectedIndex.value = index;
              controller.pageController.jumpToPage(index);
            },
            children: [
              BottomNavBarItem(
                title: 'Dashboard',
                icon: AppIcons.menu,
                color: Colors.deepOrange,
              ),
              BottomNavBarItem(
                title: 'Call Log',
                icon: AppIcons.call,
                color: Get.theme.primaryColor,
              ),
              // BottomNavBarItem(
              //   title: 'Message',
              //   icon: AppIcons.userlist,
              //   color: Colors.green,
              // ),
              BottomNavBarItem(
                title: 'Leads',
                icon: AppIcons.userlist,
                color: Colors.pink,
              ),
              BottomNavBarItem(
                title: "Unsave",
                icon: AppIcons.unknownUser,
                color: Colors.blue,
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
