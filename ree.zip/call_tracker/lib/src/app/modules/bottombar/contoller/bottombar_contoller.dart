import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../calls/views/screens/call_logs.dart';
import '../../calls/views/screens/unsave_calls.dart';
import '../../leads/views/screens/leads.dart';
import '../../main/view/screens/dashboard.dart';

class BottomBarContoller extends GetxController {
  final RxList<Widget> pages =
      <Widget>[const Dashboard(), const CallLogs(), const Leads(), const UnsaveCalls()].obs;
  final RxInt selectedIndex = 0.obs;
  late final PageController pageController;
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  void onInit() {
    super.onInit();
    pageController = PageController(initialPage: selectedIndex.value);
  }

  @override
  void onClose() {
    pageController.dispose();
    super.onClose();
  }

  void openDrawer() {
    scaffoldKey.currentState?.openDrawer();
  }

  void closeDrawer() {
    scaffoldKey.currentState?.openEndDrawer();
  }
}
