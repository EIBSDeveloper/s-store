import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../core/app_icons.dart';
import '../../../../../core/app_style.dart';
import '../../../../utils/utils.dart';
import '../../../../widgets/background.dart';
import '../../../main/view/widgets/action_button.dart';
import '../../controller/notes_controller.dart';
import '../../modules/note_model.dart';
import '../widget/search.dart';

class NotesScreen extends GetView<NotesController> {
  const NotesScreen({super.key});

  @override
  Widget build(BuildContext context) => Background(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(title: Text('Whatsapp Message templete'.tr)),
        body: Column(
          children: [
            SearchFilterBar(
              controller: controller.searchController,
              onFilterTap: _showMenu,
            ),
            // Labels Filter Bar
            _buildLabelsFilter(),

            // Notes List
            Expanded(
              child: Obx(() {
                if (controller.isLoading.value && controller.notes.isEmpty) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (controller.error.value.isNotEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(controller.error.value),
                        const SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: controller.loadNotes,
                          child: Text('retry'.tr),
                        ),
                      ],
                    ),
                  );
                }

                if (controller.filteredNotes.isEmpty) {
                  return Center(
                    child: Text(
                      controller.searchQuery.value.isEmpty
                          ? 'no_notes'.tr
                          : 'no_results'.tr,
                    ),
                  );
                }

                return _buildNotesList();
              }),
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () => Get.toNamed('/add-note'),
          child: const Icon(Icons.add),
        ),
      ),
    );

  Widget _buildLabelsFilter() => Obx(() {
      if (controller.labels.isEmpty) {
        return const SizedBox();
      }

      return Container(
        height: 60,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: controller.labels.length,
          itemBuilder: (context, index) {
            final filter = controller.labels[index];
            return Obx(() => Padding(
                padding: const EdgeInsets.only(right: 8),
                child: FilterChip(
                  label: Text(filter.label),
                  selected: controller.selectedLabel.value == filter.label,
                  onSelected: (selected) {
                    controller.filterByLabel(filter.label);
                  },
                ),
              ));
          },
        ),
      );
    });

  Widget _buildNotesList() => Padding(
      padding: const EdgeInsets.all(16),
      child: ListView.separated(
        itemCount: controller.filteredNotes.length,
        separatorBuilder: (context, index) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final note = controller.filteredNotes[index];
          return _buildNoteListItem(note);
        },
      ),
    );

  Widget _buildNoteListItem(NoteModel note) => Card(
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      color: Colors.white,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => Get.toNamed('/note-detail', arguments: note),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: getLabelColor(note.label).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            note.label,
                            style: Get.textTheme.labelSmall?.copyWith(
                              color: getLabelColor(note.label),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),

                        const SizedBox(height: 5),

                        Text(
                          note.title,
                          style: Get.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  // const SizedBox(width: 8),
                  // ImageView(
                  //   AppIcons.whatsapp,
                  //   width: AppStyle.iconsize,
                  //   height: AppStyle.iconsize,
                  // ),
                  const SizedBox(width: 8),
                  ImageView(
                    AppIcons.whatsapp,
                    width: AppStyle.iconSize,
                    height: AppStyle.iconSize,
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                note.previewContent,
                style: Get.textTheme.bodyMedium?.copyWith(
                  color: Get.theme.colorScheme.onSurface.withOpacity(0.7),
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );



  void _showMenu() {
    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Get.theme.colorScheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.sort),
              title: Text('sort_by_date'.tr),
              onTap: () {
                Get.back();
                // Implement sorting
              },
            ),
            ListTile(
              leading: const Icon(Icons.filter_list),
              title: Text('advanced_filters'.tr),
              onTap: () {
                Get.back();
                // Implement advanced filters
              },
            ),
            ListTile(
              leading: const Icon(Icons.settings),
              title: Text('settings'.tr),
              onTap: () {
                Get.back();
                // Navigate to settings
              },
            ),
          ],
        ),
      ),
    );
  }
}
