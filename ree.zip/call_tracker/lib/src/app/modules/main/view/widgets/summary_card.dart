import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../core/app_style.dart';
import 'action_button.dart';

class SummaryCard extends StatefulWidget {
  final String title;
  final String value;
  final String icon;
  final Color color;

  const SummaryCard({
    super.key,
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  State<SummaryCard> createState() => _SummaryCardState();
}

class _SummaryCardState extends State<SummaryCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _countAnimation;

  double _oldValue = 0;
  double _newValue = 0;
  String? _suffixPart;

  // Tilt effect variables
  double _rotateX = 0.0;
  double _rotateY = 0.0;
  double _scale = 1.0;

  @override
  void initState() {
    super.initState();
    _parseValue();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _countAnimation = Tween<double>(
      begin: 0,
      end: _newValue,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _controller.forward();
  }

  void _parseValue() {
    final parts = widget.value.split('/');
    if (parts.length == 2) {
      _newValue = double.tryParse(parts[0].trim()) ?? 0;
      _suffixPart = '/ ${parts[1].trim()}';
    } else {
      _newValue =
          double.tryParse(widget.value.replaceAll(RegExp('[^0-9.]'), '')) ?? 0;
      _suffixPart = null;
    }
  }

  @override
  void didUpdateWidget(covariant SummaryCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.value != oldWidget.value) {
      _oldValue = _newValue;
      _parseValue();

      _countAnimation = Tween<double>(
        begin: _oldValue,
        end: _newValue,
      ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

      _controller
        ..reset()
        ..forward();
    }
  }

  void _onPanUpdate(DragUpdateDetails details, Size size) {
    setState(() {
      // Calculate tilt based on pointer position
      _rotateY = (details.localPosition.dx - size.width / 2) / size.width * 0.3;
      _rotateX =
          (details.localPosition.dy - size.height / 2) / size.height * -0.3;
      _scale = 1.05;
    });
  }

  void _onPanEnd(DragEndDetails details) {
    setState(() {
      _rotateX = 0.0;
      _rotateY = 0.0;
      _scale = 1.0;
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Expanded(
    child: LayoutBuilder(
      builder:
          (context, constraints) => GestureDetector(
            onPanUpdate:
                (details) => _onPanUpdate(details, constraints.biggest),
            onPanEnd: _onPanEnd,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeOut,
              margin: const EdgeInsets.all(3),
              transform:
                  Matrix4.identity()
                    ..setEntry(3, 2, 0.001) // perspective
                    ..rotateX(_rotateX)
                    ..rotateY(_rotateY)
                    ..scale(_scale),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      widget.color.withOpacity(0.8),
                      widget.color.withOpacity(0.4),
                    ],
                  ),
                  boxShadow: [],
                ),
                child: Stack(
                  children: [
                    // Glossy overlay effect
                    Positioned(
                      top: 0,
                      left: 0,
                      right: 0,
                      child: Container(
                        height: 80,
                        decoration: BoxDecoration(
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20),
                          ),
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.white.withOpacity(0.3),
                              Colors.white.withOpacity(0.0),
                            ],
                          ),
                        ),
                      ),
                    ),

                    // Content
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8,horizontal: 8),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          // Icon with glow effect
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white.withOpacity(0.2),
                              boxShadow: [],
                            ),
                            child: ImageView(
                              widget.icon,
                              width: AppStyle.iconSize ,
                              height: AppStyle.iconSize  ,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 8),

                          // Animated count with premium styling
                          AnimatedBuilder(
                            animation: _countAnimation,
                            builder:
                                (context, child) => RichText(
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text: _countAnimation.value
                                            .toStringAsFixed(0),
                                        style: Get.theme.textTheme.titleLarge!
                                            .copyWith(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w900,

                                              shadows: [
                                                Shadow(
                                                  color: Colors.black
                                                      .withOpacity(0.3),
                                                  offset: const Offset(0, 2),
                                                  blurRadius: 4,
                                                ),
                                              ],
                                            ),
                                      ),
                                      if (_suffixPart != null)
                                        TextSpan(
                                          text: ' $_suffixPart',
                                          style: Get
                                              .theme
                                              .textTheme
                                              .titleMedium!
                                              .copyWith(
                                                color: Colors.white.withOpacity(
                                                  0.9,
                                                ),
                                                fontWeight: FontWeight.w600,
                                              ),
                                        ),
                                    ],
                                  ),
                                ),
                          ),

                          // Title with shadow
                          Center(
                            child: Text(
                              widget.title,
                              textAlign: TextAlign.center,
                              style: Get.theme.textTheme.bodySmall!.copyWith(
                                color: Colors.white.withOpacity(0.95),

                                // fontWeight: FontWeight.w600,
                                letterSpacing: 0.5,
                                shadows: [
                                  Shadow(
                                    color: Colors.black.withOpacity(0.2),
                                    offset: const Offset(0, 1),
                                    blurRadius: 2,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
    ),
  );
}
