import 'package:call_tracker/src/core/app_icons.dart';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:get/get.dart';

import '../../../../../../re.dart';
import '../../../../../core/app_style.dart';
import '../../../../utils/routes/app_pages.dart';
import '../../../calls/contoller/call_log_contoller.dart';
import '../../../followups/contoller/followup_controller.dart';
import '../../../followups/views/screens/followup_detail_page.dart';
import '../../../followups/views/widgets/followup_card.dart';
import '../widgets/action_button.dart';
import '../widgets/summary_card.dart';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  final followUpController = Get.put(FollowUpController());
  final callLogsController = Get.put(CallLogController());
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
    child: Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Padding(
        //   padding: EdgeInsets.symmetric(vertical: 4),
        //   child: Text(
        //     "Hi  Bala!🖐..",
        //     style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
        //   ),
        // ),
        // 🔹 Total Calls Duration widget
        // Container(
        //   width: double.infinity,
        //   decoration: BoxDecoration(
        //     color: const Color(0xFF3C3E5E),
        //     borderRadius: BorderRadius.circular(16),
        //   ),
        //   padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
        //   child: Column(
        //     crossAxisAlignment: CrossAxisAlignment.center,
        //     children: [
        //       // Header
        //       Container(
        //         padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 14),
        //         decoration: BoxDecoration(
        //           color: Colors.white,
        //           borderRadius: BorderRadius.circular(12),
        //         ),
        //         child: const Text(
        //           "Total Calls Duration :  09:34:27",
        //           style: TextStyle(
        //             color: Color(0xFF3C3E5E),
        //             fontWeight: FontWeight.w600,
        //           ),
        //         ),
        //       ),
        //       const SizedBox(height: 18),
        //       // Items Row
        //       const Row(
        //         mainAxisAlignment: MainAxisAlignment.spaceAround,
        //         children: [
        //           _CallStatTile(title: "MR", value: "30%"),
        //           _CallStatTile(title: "AOCR", value: "30%"),
        //           _CallStatTile(title: "OTH", value: "30%"),
        //         ],
        //       ),
        //     ],
        //   ),
        // ),

        // const SizedBox(height: 24),

        // // 🔹 Follow-ups widget
        // Container(
        //   width: double.infinity,
        //   decoration: BoxDecoration(
        //     color: Colors.white,
        //     borderRadius: BorderRadius.circular(16),
        //     // boxShadow: [
        //     //   BoxShadow(
        //     //     color: Colors.grey.shade300,
        //     //     blurRadius: 10,
        //     //     offset: const Offset(0, 5),
        //     //   )
        //     // ],
        //   ),
        //   padding: const EdgeInsets.all(20),
        //   child: Column(
        //     crossAxisAlignment: CrossAxisAlignment.start,
        //     children: [
        //       const Text(
        //         "Follow-ups",
        //         style: TextStyle(
        //           fontWeight: FontWeight.bold,
        //           fontSize: 16,
        //           color: Color(0xFF3C3E5E),
        //         ),
        //       ),
        //       const SizedBox(height: 16),

        //       Row(
        //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //         children: [
        //           // Left legend
        //           const Column(
        //             crossAxisAlignment: CrossAxisAlignment.start,
        //             children: [
        //               _FollowUpLegend(color: Color(0xFF3C3E5E), text: "Completed", count: "30"),
        //               SizedBox(height: 8),
        //               _FollowUpLegend(color: Color(0xFFB9BACC), text: "Pending", count: "08"),
        //               SizedBox(height: 8),
        //               _FollowUpLegend(color: Color(0xFFFFA363), text: "Cancelled", count: "12"),
        //             ],
        //           ),

        //           // Right circular chart
        //           Stack(
        //             alignment: Alignment.center,
        //             children: [
        //               SizedBox(
        //                 height: 120,
        //                 width: 120,
        //                 child: PieChart(
        //                   PieChartData(
        //                     startDegreeOffset: -90,
        //                     centerSpaceRadius: 45,
        //                     sectionsSpace: 2,
        //                     sections: [
        //                       PieChartSectionData(
        //                         color: const Color(0xFF3C3E5E),
        //                         value: 30,
        //                         radius: 15,
        //                       ),
        //                       PieChartSectionData(
        //                         color: const Color(0xFFB9BACC),
        //                         value: 8,
        //                         radius: 15,
        //                       ),
        //                       PieChartSectionData(
        //                         color: const Color(0xFFFFA363),
        //                         value: 12,
        //                         radius: 15,
        //                       ),
        //                     ],
        //                   ),
        //                 ),
        //               ),
        //               const Column(
        //                 mainAxisAlignment: MainAxisAlignment.center,
        //                 children: [
        //                   Text(
        //                     "Total Follow-ups",
        //                     style: TextStyle(
        //                       fontSize: 11,
        //                       color: Color(0xFF9A9AAC),
        //                     ),
        //                   ),
        //                   SizedBox(height: 4),
        //                   Text(
        //                     "50",
        //                     style: TextStyle(
        //                       fontWeight: FontWeight.bold,
        //                       fontSize: 22,
        //                       color: Color(0xFF3C3E5E),
        //                     ),
        //                   ),
        //                 ],
        //               )
        //             ],
        //           ),
        //         ],
        //       )
        //     ],
        //   ),
        // ),

        // Summary Cards
        Obx(
          () => Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SummaryCard(
                title: 'Today Calls',
                value:
                    callLogsController.todayOverallCallCount.value.toString(),
                icon: AppIcons.call,
                // color: Get.theme.primaryColor,
                color: const Color.fromARGB(255, 240, 70, 135),
              ),
              SummaryCard(
                title: 'FollowUps',
                value:
                    '${followUpController.todayUpdatedFollowUpsCount.value} / ${followUpController.todayOverallFollowUpsCount.value}',
                icon: AppIcons.analitics,
                color: const Color.fromARGB(255, 34, 214, 158),
              ),
              SummaryCard(
                title: 'Pending',
                value:
                    followUpController.todayPendingFollowUpsCount.value
                        .toString(),
                //  color: Get.theme.primaryColor,
                //rgb(230,131,80)
                color: const Color.fromARGB(255, 228, 115, 59),
                icon: AppIcons.chart,
              ),
            ],
          ),
        ),

        // const SizedBox(height: 5),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            ActionButton(
              icon: AppIcons.addCall,
              label: 'Add Follow Up',
              color: const Color.fromARGB(255, 240, 70, 135),
              onTap: () {
                Get.toNamed(AppPages.addFollowup);
              },
            ),
            ActionButton(
              icon: AppIcons.userAdd2,
              label: 'Add Lead',
              color: const Color.fromARGB(255, 34, 214, 158),
              onTap: () {
                Get.toNamed(AppPages.addLead);
              },
            ),
            ActionButton(
              icon: AppIcons.calendar,
              label: 'Follow Ups',
              color: const Color.fromARGB(255, 228, 115, 59),
              onTap: () async {
                // Get.toNamed(AppPages.followups);
                //  showOverlay();
                // showDialog(
                //   context: context,
                //   builder: (context) => const ContactPopup(),
                // );

                if (await FlutterOverlayWindow.isActive()) return;
                await FlutterOverlayWindow.showOverlay(
                  enableDrag: true,
                  overlayTitle: "X-SLAYER",
                  overlayContent: 'Overlay Enabled',
                  flag: OverlayFlag.defaultFlag,
                  visibility: NotificationVisibility.visibilityPublic,
                  positionGravity: PositionGravity.auto,
                  height: ( MediaQuery.of(context).size.height).toInt(),
                  width: WindowSize.matchParent,
                  // startPosition: const OverlayPosition(0, -259),
                );
              
               },
            ),
          ],
        ),
        const SizedBox(height: 5),

        // Lead List Title
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Today\'s Follow ups',
              style: Get.theme.textTheme.titleLarge!.copyWith(
                // color: Get.theme.primaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
            IconButton(
              onPressed: () {
                Get.toNamed(AppPages.todayFollowups);
              },
              icon: ImageView(
                AppIcons.list1,
                color: Get.theme.primaryColor,
                width: AppStyle.iconSize,
                height: AppStyle.iconSize,
              ),
            ),
          ],
        ),
        // const SizedBox(height: 5),

        // Lead List
        Expanded(
          child: Obx(
            () => ListView.builder(
              padding: const EdgeInsets.only(bottom: 16),
              itemCount: followUpController.todayFollowUps.length,
              itemBuilder: (context, index) {
                final followUp = followUpController.todayFollowUps[index];
                return FollowUpCard(
                  followUp: followUp,
                  onTap:
                      () =>
                          Get.to(() => FollowUpDetailPage(followUp: followUp)),
                );
              },
            ),
          ),
        ),
      ],
    ),
  );
}

class _CallStatTile extends StatelessWidget {
  final String title;
  final String value;
  const _CallStatTile({required this.title, required this.value});

  @override
  Widget build(BuildContext context) => Column(
    children: [
      Text(
        title,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
      ),
      const SizedBox(height: 4),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 13,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    ],
  );
}

class _FollowUpLegend extends StatelessWidget {
  final Color color;
  final String text;
  final String count;
  const _FollowUpLegend({
    required this.color,
    required this.text,
    required this.count,
  });

  @override
  Widget build(BuildContext context) => Row(
    children: [
      Container(
        width: 26,
        height: 26,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(6),
        ),
        alignment: Alignment.center,
        child: Text(
          count,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 11,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      const SizedBox(width: 8),
      Text(
        text,
        style: const TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w500,
          color: Color(0xFF3C3E5E),
        ),
      ),
    ],
  );
}
