import 'package:call_tracker/src/app/modules/profile/controller/profilecontroller.dart';
import 'package:call_tracker/src/app/modules/profile/repository/profile_repository.dart';
import 'package:get/get.dart';

class ProfileBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ProfileRepository>(() => ProfileRepository());
    Get.lazyPut<Profilecontroller>(() => Profilecontroller());
  }
}
