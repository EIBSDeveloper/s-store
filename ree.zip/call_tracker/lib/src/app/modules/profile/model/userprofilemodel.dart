class UserprofileModel {
  final String name;
  final String mobile;
  final String username;
  final String password;
  final String role;

  UserprofileModel({
    required this.name,
    required this.mobile,
    required this.username,
    required this.password,
    required this.role,
  });

  factory UserprofileModel.fromJson(Map<String, dynamic> json) {
    return UserprofileModel(
      name: json['name']?.toString() ?? '',
      mobile: json['mobile']?.toString() ?? '',
      username: json['username']?.toString() ?? '',
      password: json['password']?.toString() ?? '',
      role: json['role']?.toString() ?? '',
    );
  }
}
