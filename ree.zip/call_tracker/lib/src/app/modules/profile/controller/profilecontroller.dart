import 'dart:io';

import 'package:call_tracker/src/app/modules/profile/model/userprofilemodel.dart';
import 'package:call_tracker/src/app/modules/profile/repository/profile_repository.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

class Profilecontroller extends GetxController {
  final ProfileRepository _repository = ProfileRepository();
  var isprofileLoading = false.obs;
  var profileData = Rxn<UserprofileModel>();

  Rx<File?> selectedImage = Rx<File?>(null);

  @override
  void onInit() {
    super.onInit();
    fetchUserProfile();
  }

  /// 🔹 Load hardcoded user data
  Future<void> fetchUserProfile() async {
    try {
      isprofileLoading.value = true;
      final data = await _repository.fetchProfile();
      profileData.value = data;
    } catch (e) {
      print("Error fetching profile: $e");
    } finally {
      isprofileLoading.value = false;
    }
  }

  Future<void> pickImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? pickedFile = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
    );

    if (pickedFile != null) {
      selectedImage.value = File(pickedFile.path);
    }
  }
}
