import 'dart:io';

import 'package:call_tracker/src/app/modules/profile/controller/profilecontroller.dart';
import 'package:call_tracker/src/app/widgets/loading.dart';
import 'package:call_tracker/src/core/app_icons.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ProfileCardWidget extends GetView<Profilecontroller> {
  const ProfileCardWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Obx(() {
      final isLoading = controller.isprofileLoading.value;
      final profile = controller.profileData.value;

      // 🔹 Single Loader for entire screen
      if (isLoading || profile == null) {
        return const Center(child: Loading());
      }

      return SingleChildScrollView(
        child: Column(
          children: [
            /// 🔹 Top profile header section
            Stack(
              alignment: Alignment.center,
              children: [
                // 🔹 Background
                Container(
                  height: size.height * 0.32,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Get.theme.colorScheme.primary.withAlpha(50),
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(25),
                      bottomRight: Radius.circular(25),
                    ),
                  ),
                ),

                // 🔹 Back button (Top Left)
                Positioned(
                  top: size.height * 0.03,
                  left: 16,
                  child: GestureDetector(
                    onTap: () => Get.back(),
                    child: const Icon(
                      Icons.arrow_back_ios_new,
                      color: Colors.white,
                      size: 18,
                    ),
                  ),
                ),

                // 🔹 Center Profile Section
                Positioned(
                  top: size.height * 0.03,
                  child: Column(
                    children: [
                      const Text(
                        "My Profile",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 10),

                      // Profile Image + Camera Icon
                      Stack(
                        alignment: Alignment.bottomRight,
                        children: [
                          Obx(() {
                            File? image = controller.selectedImage.value;
                            ImageProvider avatarImage =
                                image != null
                                    ? FileImage(image)
                                    : AssetImage(AppIcons.user);

                            return CircleAvatar(
                              backgroundColor: Get.theme.colorScheme.primary,
                              radius: size.width * 0.13,
                              backgroundImage: avatarImage,
                            );
                          }),
                          GestureDetector(
                            onTap: () => controller.pickImage(),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Get.theme.colorScheme.onPrimary,
                                shape: BoxShape.circle,
                              ),
                              padding: const EdgeInsets.all(5),
                              child: const Icon(
                                Icons.camera_alt,
                                size: 18,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),

                      // Name & Mobile
                      Text(
                        profile.name.isNotEmpty ? profile.name : "--",
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        profile.mobile.isNotEmpty
                            ? "+91 ${profile.mobile}"
                            : "--",
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            /// 🔹 Profile Details Fields
            Transform.translate(
              offset: const Offset(
                0,
                -40,
              ), // ⬅️ Move upward (adjust as needed)(
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 18),
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 24,
                ),
                decoration: BoxDecoration(
                  color: Get.theme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 15,
                      offset: const Offset(0, 5),
                    ),
                  ],
                  border: Border.all(
                    color: Get.theme.colorScheme.primary.withOpacity(0.15),
                    width: 1,
                  ),
                ),
                child: Column(
                  children: [
                    _buildProfileItem(
                      icon: Icons.person_outline,
                      title: "Username",
                      value: profile.username,
                    ),
                    const Divider(height: 1),
                    _buildProfileItem(
                      icon: Icons.lock_outline,
                      title: "Password",
                      value: profile.password,
                    ),
                    const Divider(height: 1),
                    _buildProfileItem(
                      icon: Icons.badge_outlined,
                      title: "Role",
                      value: profile.role,
                    ),
                  ],
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Get.theme.colorScheme.primary,
                  foregroundColor: Get.theme.colorScheme.onPrimary,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  minimumSize: const Size(double.infinity, 55),
                  elevation: 4,
                ),
                onPressed: _showLogoutConfirmation,
                icon: const Icon(Icons.logout_rounded, size: 22),
                label: const Text(
                  "Logout",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ),
            ),

            const SizedBox(height: 40),
          ],
        ),
      );
    });
  }

  Widget _buildProfileItem({
    required IconData icon,
    required String title,
    required String value,
  }) {
    final theme = Get.theme.colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: theme.primary.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: theme.primary, size: 22),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 13,
                    color: theme.onSurface.withOpacity(0.6),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value.isNotEmpty ? value : "--",
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: theme.onSurface,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showLogoutConfirmation() {
    final theme = Get.theme.colorScheme;
    Get.dialog(
      AlertDialog(
        backgroundColor: theme.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          'Logout',
          style: TextStyle(fontWeight: FontWeight.bold, color: theme.primary),
        ),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: Get.back,
            child: Text('Cancel', style: TextStyle(color: theme.primary)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: theme.primary,
              foregroundColor: theme.onPrimary,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            onPressed: () {
              Get.back();
            },
            child: const Text('Logout'),
          ),
        ],
      ),
    );
  }
}
