import 'package:call_tracker/src/app/modules/profile/view/widgets/profilecardwidget.dart';
import 'package:call_tracker/src/app/widgets/background.dart';
import 'package:flutter/material.dart';

class Profilescreen extends StatelessWidget {
  const Profilescreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Background(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: const ProfileCardWidget(),
        ),
      ),
    );
  }
}
