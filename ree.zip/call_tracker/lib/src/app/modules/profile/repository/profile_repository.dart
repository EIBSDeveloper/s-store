import 'package:call_tracker/src/app/modules/profile/model/userprofilemodel.dart';

class ProfileRepository {
  Future<UserprofileModel> fetchProfile() async {
    await Future.delayed(const Duration(seconds: 1)); // simulate API delay

    // ✅ Hardcoded response
    final response = {
      "name": "Vetrivijayan",
      "mobile": "9877899870",
      "username": "VetriVijayan007",
      "password": "********",
      "role": "Administrator",
    };

    return UserprofileModel.fromJson(response);
  }
}
