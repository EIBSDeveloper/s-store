import 'package:get/get.dart';

import '../controller/app_controller.dart';
import '../controller/call_controller.dart';
import '../controller/network_contoller.dart';
import '../modules/auth/controller/auth_controller.dart';
import '../modules/bottombar/contoller/bottombar_contoller.dart';
import '../modules/calls/contoller/call_log_contoller.dart';
import '../modules/followups/contoller/followup_controller.dart';
import '../modules/leads/contoller/lead_controller.dart';
import '../utils/http/http_service.dart';
import '../utils/repository/followup_repository.dart';
import '../utils/repository/lead_repository.dart';

class AppBinding implements Bindings {
  @override
  void dependencies() {
    // Register repositories
    // Initialize NetworkController first since it's used globally

    Get.put(AppDataController(), permanent: true);
    // Get.put(GetStorage(), permanent: true);
    Get.put(GetConnect(), permanent: true);

    //Service
    Get.put(NetworkController(), permanent: true);
    // Get.lazyPut(() => StorageService(), fenix: true);
    Get.lazyPut(() => HttpService(), fenix: true);

    Get.put(CallController(), permanent: true);
    Get.lazyPut(() => BottomBarContoller(), fenix: true);
    Get.lazyPut(() => LeadRepository(), fenix: true);
    Get.lazyPut(() => FollowUpRepository(), fenix: true);

    // Register controllers
    Get.lazyPut(() => AuthController(), fenix: true);
    Get.lazyPut(() => CallLogController(), fenix: true);
    Get.lazyPut(() => FollowUpController(), fenix: true);
    Get.lazyPut(() => LeadController(), fenix: true);
    Get.lazyPut(() => FollowUpController(), fenix: true);
    Get.lazyPut(() => LeadController(), fenix: true);
    Get.lazyPut(() => FollowUpController(), fenix: true);
  }
}
