class AppInjection {
  
  
}