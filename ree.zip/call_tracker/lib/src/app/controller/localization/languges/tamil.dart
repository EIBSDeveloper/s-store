class Tamil {
  static Map<String, String> list = {
   

  };
}
