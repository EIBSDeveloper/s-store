class Hindi {
  static  Map<String, String> list =  {
      
      };
    
}