
import 'package:get/get.dart';

import 'languges/english.dart';
import 'languges/hindi.dart';
import 'languges/tamil.dart';

class AppTranslations extends Translations {
  @override
  Map<String, Map<String, String>> get keys => {
    'ta_IN': Tamil.list,
    'hi_IN': Hindi.list,
    'en_US': English.list,
  };
}
