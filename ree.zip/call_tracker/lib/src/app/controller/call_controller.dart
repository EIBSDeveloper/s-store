
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:phone_state/phone_state.dart';

import '../modules/calls/contoller/call_log_contoller.dart';
import '../modules/calls/contoller/call_recording_controller.dart';

class CallController extends GetxController {
  final callStatus = PhoneStateStatus.NOTHING.obs;
  final callNumber = ''.obs;
  final callDuration = Duration.zero.obs;
  final isPermissionGranted = false.obs;

  @override
  void onInit() {
    super.onInit();
    requestPermissions();
    initPhoneStateListener();
  }

  Future<void> initPhoneStateListener() async {
    PhoneState.stream.listen((event) {
      callStatus.value = event.status;
      callNumber.value = event.number ?? '';
      callDuration.value = event.duration ?? Duration.zero;

      if (event.status == PhoneStateStatus.CALL_ENDED) {
        onCallEnded();
      }
    });
  }

  void onCallEnded() {
    // This function will be called automatically when a call ends
    debugPrint('Call ended - refreshing data...');
    refreshData();
  }

  Future<void> refreshData() async {
    // Your refresh logic here
    final callController = Get.put(CallLogController());
    final callRecordController = Get.put(CallRecordingController());
    await callRecordController.findCallRecordings();
    callController.refreshLog();
    callController.fetchUnsavedCallLogs();
    debugPrint('Refreshing data after call ended...');
    // Example: fetch new data from API, update UI, etc.
  }

  Future<void> requestPermissions() async {
    if (GetPlatform.isAndroid) {
      final status = await Permission.phone.request();
      isPermissionGranted.value = status.isGranted;
    } else {
      isPermissionGranted.value = true;
    }
  }
}
