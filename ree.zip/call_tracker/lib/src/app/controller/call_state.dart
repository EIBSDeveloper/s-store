// import 'package:get/get.dart';
// import 'package:phone_state/phone_state.dart';
// import 'package:flutter_local_notifications/flutter_local_notifications.dart';

// class CallController extends GetxController {
//   final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

//   @override
//   void onInit() {
//     super.onInit();
//     _initializeNotification();
//     _startPhoneStateListener();
//   }

//   void _initializeNotification() async {
//     const AndroidInitializationSettings initializationSettingsAndroid =
//         AndroidInitializationSettings('@mipmap/ic_launcher');

//     const InitializationSettings initializationSettings = InitializationSettings(
//       android: initializationSettingsAndroid,
//     );

//     await flutterLocalNotificationsPlugin.initialize(initializationSettings);
//   }

//   void _startPhoneStateListener() async {
//     PhoneStateStatus status = await PhoneState.phoneStateStream.listen((PhoneStateStatus status) {
//       if (status == PhoneStateStatus.callStarted || status == PhoneStateStatus.callEnded) {
//         _showNotification("Call state changed: ${status.name}");
//       }
//     }).asFuture(); // Optional if you want to await a single result
//   }

//   void _showNotification(String message) async {
//     const AndroidNotificationDetails androidPlatformChannelSpecifics = AndroidNotificationDetails(
//       'call_channel',
//       'Call Updates',
//       channelDescription: 'Call state updates',
//       importance: Importance.max,
//       priority: Priority.high,
//     );

//     const NotificationDetails platformChannelSpecifics = NotificationDetails(
//       android: androidPlatformChannelSpecifics,
//     );

//     await flutterLocalNotificationsPlugin.show(
//       0,
//       'Call State Updated',
//       message,
//       platformChannelSpecifics,
//     );
//   }
// }
