import 'enums.dart';

class AppData {
  static const leadTypes = ['Hot', 'Warm', 'Cold', 'Lost', 'Converted'];

  //Don't change  index  beacuse that used on dashboad followup value
  static const List<String> followupStatus = [
    'Scheduled',
    'Pending',
    'Completed',
    'Cancelled',
    'Postponed',
  ];

  static const List<Map<String, dynamic>> callFilterByDay = [
    {'title': 'Today', 'value': DateFilterType.today},
    {'title': 'This Week', 'value': DateFilterType.thisWeek},
    {'title': 'This Month', 'value': DateFilterType.thisMonth},
  ];
}
