// app_theme.dart
import 'package:call_log/call_log.dart';
import 'package:call_tracker/src/core/app_style.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AppColors {
  // Standard Material Design colors (500-700 range for better visibility)
  static const Color error = Color(0xFFD32F2F);       // Red 700
  static const Color success = Color(0xFF388E3C);     // Green 700
  static const Color warning = Color(0xFFF57C00);     // Orange 700
  static const Color info = Color(0xFF1976D2);        // Blue 700
  static const Color primary = Color(0xFF6200EE);     // Deep Purple 500
  
  // Extended palette for specific use cases
  static const Color converted = Color(0xFF7B1FA2);   // Purple 700
  static const Color lost = Color(0xFF616161);       // Gray 700
  static const Color scheduled = Color(0xFFAB47BC);   // Purple 400
  static const Color pending = Color(0xFFFFA000);     // Amber 600
  static const Color active = Color(0xFF43A047);     // Green 600
  static const Color draft = Color(0xFF757575);       // Gray 600

  static Icon getCallTypeIcon(CallType? type) {
    switch (type) {
      case CallType.incoming:
        return const Icon(Icons.call_received, color: success,size: AppStyle.iconSizelarge,);
      case CallType.outgoing:
        return const Icon(Icons.call_made, color: success,size: AppStyle.iconSizelarge);
      case CallType.missed:
        return const Icon(Icons.call_missed, color: error,size: AppStyle.iconSizelarge);
      case CallType.rejected:
        return const Icon(Icons.call_end, color: error,size: AppStyle.iconSizelarge);
      default:
        return const Icon(Icons.phone, color: warning,size: AppStyle.iconSizelarge);
    }
  }

  static Color getFolloupsStatusColor(String? status) {
    switch (status?.toLowerCase()) {
      case 'completed':
        return success;
      case 'cancelled':
        return error;
      case 'postponed':
        return warning;
      case 'scheduled':
        return scheduled;
      case 'pending':
        return pending;
      case 'active':
        return active;
      case 'draft':
        return draft;
      default:
        return Get.theme.primaryColor;
    }
  }

  static Color getLeadTypeColor(String? type) {
    switch (type?.toLowerCase()) {
      case 'hot':
        return error;
      case 'warm':
        return warning;
      case 'cold':
        return info;
      case 'converted':
        return converted;
      case 'lost':
        return lost;
      default:
        return Get.theme.primaryColor;
    }
  }
}