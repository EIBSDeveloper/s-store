class Constant {
  static String dbName ="User Box";
}