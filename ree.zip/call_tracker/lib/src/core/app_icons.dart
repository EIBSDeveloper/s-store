class AppIcons {
  //  icon
  static String addCall = "assets/images/add-phone-fill.png";
  static String leadAdd = "assets/images/add-team.png";
  static String analitics = "assets/images/bar-chart-fill.png";
  static String calendar = "assets/images/calendar-fill.png";
  static String headphone = "assets/images/customer-service-fill.png";
  static String chart = "assets/images/donut-chart-fill.png";
  static String incoming = "assets/images/incoming-call-fill.png";
  static String list1 = "assets/images/list1.png";
  static String menuicon = "assets/images/menuicon.png";
  // static  String home = "assets/images/list-menu1.png";
  static String list = "assets/images/list.png";
  static String menu = "assets/images/menu.png";
  static String missedCall = "assets/images/missed-call-fill.png";
  static String ougoing = "assets/images/outgoing-call-fill.png";
  static String callAdd = "assets/images/phone-add.png";
  static String call = "assets/images/phone-fill.png";
  static String callRing = "assets/images/ringer-volumen-fill.png";
  static String scheduleAdd = "assets/images/schedule.png";
  static String schedule = "assets/images/schedule1.png";
  // static  String template = "assets/images/template.png";
  static String time = "assets/images/time.png";
  static String unknown = "assets/images/unknown-call.png";
  static String userlist = "assets/images/user-list.png";
  static String useradd = "assets/images/addUser.png";
  static String location = "assets/images/location.png";
  static String search = "assets/images/search.png";
  static String time2 = "assets/images/time1.png";
  static String unknownUser = "assets/images/unknown.png";
  static String userAdd2 = "assets/images/user-add.png";
  static String user = "assets/images/user-circle.png";
  static String useredit = "assets/images/user-edit.png";
  static String users = "assets/images/user-multiple.png";
  static String user1 = "assets/images/user-profile.png";
  static String userserch = "assets/images/user-search.png";
  static String userseting = "assets/images/user-settings.png";
  static String user3 = "assets/images/user-sharing.png";
  static String edit = "assets/images/volume-mixer.png";
  static String notification = "assets/images/notification.png";
  static String sms =
      "https://raw.githubusercontent.com/BalaB5/deeplink123/refs/heads/main/sms.png";
  static String whatsapp =
      "https://raw.githubusercontent.com/BalaB5/deeplink123/refs/heads/main/whatsapp.png";
}
