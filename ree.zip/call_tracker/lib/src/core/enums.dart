enum Calltype { all, today, thisWeek, thisMonth }

enum DateFilterType { all, today, thisWeek, thisMonth }
