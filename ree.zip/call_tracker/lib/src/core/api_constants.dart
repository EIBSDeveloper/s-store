class APIConstants {
  static const String apiBaseUrl =
      "http://eibs.elysiumproduct.com/zeus_call_tracker/services";

  static const String tSecretAPIKey =
      "cwt_live_b2da6ds3df3e785v8ddc59198f7615ba";
}
