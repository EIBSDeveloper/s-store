import 'package:flutter/material.dart';

class AppStyle {
  static const double iconSizelarge = 25;
  static const double iconSize = 20;
  static const double iconSize2 = 15;
  static const double iconSize3 = 10;

  static const double borderRadiusBox = 10;
  static const double borderRadiusClip = 5;
  static const double borderRadiusBottom = 50;
    static BoxDecoration inputDecoration = const BoxDecoration(
    borderRadius: BorderRadius.all(Radius.circular(borderRadiusBox)),
  );
  static const BoxDecoration decoration =  BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.all(Radius.circular(20)),
      
        // boxShadow: AppStyle.boxShadow,
      );
  static const List<BoxShadow> boxShadow = [
      BoxShadow(
      color: Color.fromRGBO(0, 0, 0, 0.05),
      blurRadius: 2,
      spreadRadius: 0,
      offset: Offset(0, 1),
    )
  ];
}
