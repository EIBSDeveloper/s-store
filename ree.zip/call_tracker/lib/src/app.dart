import 'package:call_tracker/src/app/utils/routes/routes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
// import 'package:flutter_overlay_window_plus/flutter_overlay_window_plus.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:phone_state/phone_state.dart';
import '../cover_window.dart';
import '../test/dashboard_page.dart';
import 'app/bindings/app_binding.dart';
import 'app/controller/localization/app_translations.dart';
import 'app/utils/routes/app_pages.dart';
import 'core/theme.dart';

class App extends StatefulWidget {
  const App({super.key});

  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  bool granted = false;
  DateTime? callStartTime;
  String? callNumber;

  @override
  void initState() {
    super.initState();
    _requestPermissions();
  }

  /// Request phone & overlay permissions
  Future<void> _requestPermissions() async {
    final phonePerm = await Permission.phone.request();
    granted = phonePerm.isGranted;

    if (!await FlutterOverlayWindow.isPermissionGranted()) {
      await FlutterOverlayWindow.requestPermission();
    }

    if (granted) {
      _startPhoneListener();
    } else {
      debugPrint("Phone permission denied");
    }
  }

  /// Start listening for phone call states
  void _startPhoneListener() {
    PhoneState.stream.listen((PhoneState? state) async {
      if (state == null) return;

      switch (state.status) {
        case PhoneStateStatus.CALL_STARTED:
          callStartTime = DateTime.now();
          callNumber = state.number;
          break;

        case PhoneStateStatus.CALL_ENDED:
          if (callStartTime != null) {
            final duration = DateTime.now().difference(callStartTime!);
            await _showOverlay(callNumber ?? "Unknown", duration);
          }
          break;

        default:
          break;
      }
    });
  }

  /// Show overlay window after call ends
  Future<void> _showOverlay(String number, Duration duration) async {
    final minutes = duration.inMinutes.remainder(60).toString().padLeft(2, '0');
    final seconds = duration.inSeconds.remainder(60).toString().padLeft(2, '0');
    final formattedDuration = "$minutes:$seconds";
    // await showOverlay();
    await FlutterOverlayWindow.showOverlay(
      // height: 180,
      // width: 280,
      alignment: OverlayAlignment.center,
      overlayTitle: "Call Ended",
      // overlayContent:
      //     "Number: $number\nDuration: $formattedDuration\nTap 'Close' to dismiss",
      enableDrag: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    TextTheme textTheme = createTextTheme(context, "Roboto", "Roboto");
    MaterialTheme theme = MaterialTheme(textTheme);
    return GetMaterialApp(
      // initialRoute: AppPages.home,
      home: DashboardPage(),
      debugShowCheckedModeBanner: false,
      initialBinding: AppBinding(),
      locale: Get.deviceLocale,
      translations: AppTranslations(),
      fallbackLocale: const Locale('en', 'US'),
      theme: theme.light(),
      darkTheme: theme.dark(),
      themeMode: ThemeMode.light,
      getPages: Routes.pages,
    );
  }
}
