import 'package:get/get.dart';

class DashboardController extends GetxController {
  var callsMade = 128.obs;
  var successRate = 65.obs;
  var totalLeads = 150.obs;

  // ✅ Properly type the map as <String, int>
  var leadStages = <Map<String, int>>[
    {'count': 60, 'total': 150},
    {'count': 45, 'total': 150},
    {'count': 30, 'total': 150},
    {'count': 15, 'total': 150},
  ].obs;

  // ✅ Keep a matching label list separately
  final stageNames = ['New', 'Contacted', 'Qualified', 'Lost'];

  var selectedTab = 0.obs;
}
