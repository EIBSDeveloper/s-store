import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF007BFF);
  static const Color cyanActive = Color(0xFF17A2B8);
  static const Color backgroundLight = Color(0xFFF7F8FA);
  static const Color surfaceLight = Color(0xFFFFFFFF);
  static const Color textPrimaryLight = Color(0xFF111827);
  static const Color textSecondaryLight = Color(0xFF6B7280);
  static const Color success = Color(0xFF28A745);
  static const Color danger = Color(0xFFDC3545);
  static const Color warning = Color(0xFFFFC107);
  static const Color info = Color(0xFF17A2B8);
  static const Color viz1 = Color(0xFF007BFF);
  static const Color viz2 = Color(0xFF28A745);
  static const Color viz3 = Color(0xFFFFC107);
  static const Color viz4 = Color(0xFFDC3545);
  static const Color viz5 = Color(0xFF6F42C1);
  static const Color viz6 = Color(0xFFFd7E14);
}
