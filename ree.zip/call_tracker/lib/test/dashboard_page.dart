import 'package:call_tracker/test/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart'; 
import 'dashboard_controller.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(DashboardController());
    final textTheme = Get.textTheme;

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      body: SafeArea(
        child: Column(
          children: [
            // ===== HEADER =====
            Container(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Hello, Alex',
                            style: textTheme.bodySmall?.copyWith(
                                color: AppColors.textSecondaryLight)),
                        Text('Dashboard',
                            style: textTheme.titleLarge?.copyWith(
                                color: AppColors.textPrimaryLight,
                                fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                        height: 40,
                        width: 40,
                        decoration: BoxDecoration(
                          color: AppColors.surfaceLight,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black.withOpacity(0.05),
                                blurRadius: 8)
                          ],
                        ),
                        child: const Icon(Icons.notifications_outlined,
                            color: AppColors.textSecondaryLight),
                      ),
                      const SizedBox(width: 8),
                      const CircleAvatar(
                        radius: 20,
                        backgroundImage: NetworkImage(
                            "https://lh3.googleusercontent.com/aida-public/AB6AXuAI3f-egjHat8F9Ypd-1r_7dhDcvxD6kdoVrWDfluFo6YHolqj6QeacQE10Fq32VrMTG_XIGBu8fWQ46nCnQRzpt5Lcyh00pPbcvfV2yzPL10PpaSIqUEzjjYuHMrAwwnO8g-ou9YTeZXGqwZGCY0WO6oGDLhXSXiDbtaDdnuxPRWkpBYxCn3uE-0gBWOHR4vl7VQr6csfFcvWXJUGe5lg59pwgHKhOQz2P4rWkiBZqHbNWkolATp3NQmF_1YMRuOnZc68O6zOt-TE"),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // ===== SHORTCUT GRID =====
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _ShortcutCard(icon: Icons.badge, label: "Agents"),
                  _ShortcutCard(icon: Icons.groups, label: "Leads"),
                  _ShortcutCard(icon: Icons.history, label: "Call Logs"),
                ],
              ),
            ),

            // ===== BODY (scrollable) =====
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  children: [
                    // ---- Agent Performance ----
                    _AgentPerformanceCard(controller: controller),

                    const SizedBox(height: 16),

                    // ---- Lead Stage Progression ----
                    _LeadStageCard(controller: controller),

                    const SizedBox(height: 16),

                    // ---- Lead Distribution & Call Summary ----
                    Row(
                      children: const [
                        Expanded(child: _LeadDistributionCard()),
                        SizedBox(width: 12),
                        Expanded(child: _CallSummaryCard()),
                      ],
                    ),
                    const SizedBox(height: 80),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),

      // ===== Bottom Nav =====
      bottomNavigationBar: Container(
          decoration: BoxDecoration(
            color: AppColors.surfaceLight.withOpacity(0.9),
            border: Border(
              top: BorderSide(
                  color: Colors.grey.withOpacity(0.3), width: 0.5),
            ),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  offset: const Offset(0, -2),
                  blurRadius: 6)
            ],
          ),
          height: 70,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _BottomNavItem(
                  icon: Icons.dashboard,
                  label: "Dashboard",
                  index: 0,
                  controller: controller),
              _BottomNavItem(
                  icon: Icons.groups,
                  label: "Leads",
                  index: 1,
                  controller: controller),
              _BottomNavItem(
                  icon: Icons.phone_in_talk,
                  label: "Calls",
                  index: 2,
                  controller: controller),
              _BottomNavItem(
                  icon: Icons.bar_chart,
                  label: "Stats",
                  index: 3,
                  controller: controller),
              _BottomNavItem(
                  icon: Icons.person,
                  label: "Profile",
                  index: 4,
                  controller: controller),
            ],
          ),
        ),
    );
  }
}

class _ShortcutCard extends StatelessWidget {
  final IconData icon;
  final String label;
  const _ShortcutCard({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    final textTheme = Get.textTheme;
    return Expanded(
      child: Container(
        margin: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: AppColors.surfaceLight,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 8,
                offset: const Offset(0, 4))
          ],
        ),
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: AppColors.primary, size: 28),
            const SizedBox(height: 4),
            Text(label,
                style: textTheme.bodySmall?.copyWith(
                    color: AppColors.textPrimaryLight,
                    fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}

class _AgentPerformanceCard extends StatelessWidget {
  final DashboardController controller;
  const _AgentPerformanceCard({required this.controller});

  @override
  Widget build(BuildContext context) {
    final textTheme = Get.textTheme;
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceLight,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Agent Performance",
              style: textTheme.titleLarge
                  ?.copyWith(color: AppColors.textPrimaryLight)),
          const SizedBox(height: 8),
          Obx(() => Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Calls Made",
                          style: textTheme.bodySmall?.copyWith(
                              color: AppColors.textSecondaryLight)),
                      Text("${controller.callsMade}",
                          style: textTheme.titleLarge
                              ?.copyWith(color: AppColors.textPrimaryLight)),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text("Success Rate",
                          style: textTheme.bodySmall?.copyWith(
                              color: AppColors.textSecondaryLight)),
                      Text("${controller.successRate}%",
                          style: textTheme.titleLarge
                              ?.copyWith(color: AppColors.success)),
                    ],
                  ),
                ],
              )),
        ],
      ),
    );
  }
}
class _LeadStageCard extends StatelessWidget {
  final DashboardController controller;
  const _LeadStageCard({required this.controller});

  @override
  Widget build(BuildContext context) {
    final textTheme = Get.textTheme;
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceLight,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Lead Stage Progression",
              style: textTheme.titleLarge
                  ?.copyWith(color: AppColors.textPrimaryLight)),
          const SizedBox(height: 12),

          // ✅ Now all values are typed correctly
          Obx(() => Column(
                children: List.generate(controller.leadStages.length, (index) {
                  final stage = controller.leadStages[index];
                  final stageName = controller.stageNames[index];
                  final count = stage['count'] ?? 0;
                  final total = stage['total'] ?? 1; // avoid division by zero
                  final progress = count / total;
                  final color = [
                    AppColors.viz1,
                    AppColors.viz2,
                    AppColors.viz3,
                    AppColors.viz4
                  ][index];

                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(stageName,
                                  style: textTheme.bodyMedium?.copyWith(
                                      color: AppColors.textPrimaryLight)),
                              Text("$count/$total",
                                  style: textTheme.bodySmall?.copyWith(
                                      color: AppColors.textSecondaryLight)),
                            ]),
                        const SizedBox(height: 4),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: LinearProgressIndicator(
                            value: progress,
                            color: color,
                            backgroundColor: Colors.grey[300],
                            minHeight: 6,
                          ),
                        )
                      ],
                    ),
                  );
                }),
              )),
        ],
      ),
    );
  }
}

class _LeadDistributionCard extends StatelessWidget {
  const _LeadDistributionCard();

  @override
  Widget build(BuildContext context) {
    final textTheme = Get.textTheme;
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceLight,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Lead Distribution",
              style: textTheme.titleLarge
                  ?.copyWith(color: AppColors.textPrimaryLight)),
          const SizedBox(height: 16),
          Center(
            child: Column(
              children: [
                Text("150",
                    style: textTheme.titleLarge?.copyWith(
                        fontSize: 28, color: AppColors.textPrimaryLight)),
                Text("Total Leads",
                    style: textTheme.bodySmall
                        ?.copyWith(color: AppColors.textSecondaryLight)),
              ],
            ),
          )
        ],
      ),
    );
  }
}

class _CallSummaryCard extends StatelessWidget {
  const _CallSummaryCard();

  @override
  Widget build(BuildContext context) {
    final textTheme = Get.textTheme;
    final bars = [
      {'color': AppColors.success, 'label': 'Success', 'height': 64.0},
      {'color': AppColors.warning, 'label': 'No Ans.', 'height': 32.0},
      {'color': AppColors.info, 'label': 'Follow Up', 'height': 48.0},
      {'color': AppColors.danger, 'label': 'Voicemail', 'height': 24.0},
    ];
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceLight,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Call Summary",
              style: textTheme.titleLarge
                  ?.copyWith(color: AppColors.textPrimaryLight)),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: bars.map((b) {
              return Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    width: 12,
                    height: b['height'] as double,
                    decoration: BoxDecoration(
                        color: b['color'] as Color,
                        borderRadius: BorderRadius.circular(4)),
                  ),
                  const SizedBox(height: 4),
                  Text(b['label'] as String,
                      style: textTheme.bodySmall
                          ?.copyWith(color: AppColors.textSecondaryLight)),
                ],
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

class _BottomNavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final int index;
  final DashboardController controller;

  const _BottomNavItem(
      {required this.icon,
      required this.label,
      required this.index,
      required this.controller});

  @override
  Widget build(BuildContext context) {
    final textTheme = Get.textTheme;
    return Obx(() {
      final isActive = controller.selectedTab.value == index;
      return GestureDetector(
        onTap: () => controller.selectedTab.value = index,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                color: isActive
                    ? AppColors.cyanActive
                    : AppColors.textSecondaryLight),
            Text(label,
                style: textTheme.bodySmall?.copyWith(
                  color: isActive
                      ? AppColors.cyanActive
                      : AppColors.textSecondaryLight,
                  fontWeight: isActive ? FontWeight.bold : FontWeight.w500,
                )),
          ],
        ),
      );
    });
  }
}
