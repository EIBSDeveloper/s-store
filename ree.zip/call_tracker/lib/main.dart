import 'package:call_tracker/overlayer.dart';
import 'package:call_tracker/re.dart';
import 'package:call_tracker/src/app.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
// import 'package:flutter_overlay_window_plus/flutter_overlay_window_plus.dart';

import 'package:hive_flutter/hive_flutter.dart';

import 'src/app/modules/followups/model/followup_model.dart';
import 'src/app/modules/leads/model/lead_model.dart';
import 'package:permission_handler/permission_handler.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Hive.initFlutter();

  Hive.registerAdapter(LeadModelAdapter());
  Hive.registerAdapter(FollowUpModelAdapter());

  // Open Hive boxes
  await Hive.openBox<LeadModel>('leads');
  await Hive.openBox('tagsBox');
  await Hive.openBox<FollowUpModel>('followups');
  await _requestPermissions();

  runApp(const App());
}

@pragma("vm:entry-point")
void overlayMain() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    const GetMaterialApp(
      debugShowCheckedModeBanner: false,
      home: ContactPopup(),
    ),
  );
}

Future<void> _requestPermissions() async {
  await [
    Permission.phone,
    Permission.contacts,
    // Permission.,
    Permission.systemAlertWindow,
  ].request();
  if (!await FlutterOverlayWindow.isPermissionGranted()) {
    await FlutterOverlayWindow.requestPermission();
  }
}
