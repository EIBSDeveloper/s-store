import 'package:call_tracker/src/app/modules/main/view/widgets/action_button.dart';
import 'package:call_tracker/src/core/app_icons.dart';
import 'package:call_tracker/src/core/app_style.dart';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

class ContactPopup extends StatefulWidget {
  const ContactPopup({super.key});

  @override
  State<ContactPopup> createState() => _ContactPopupState();
}

class _ContactPopupState extends State<ContactPopup> {
  final TextEditingController callSummaryController = TextEditingController();
  final TextEditingController followupReasonController =
      TextEditingController();

  String? selectedStatus = "Capsule";
  TimeOfDay? selectedTime;
  DateTime? selectedDate;

  final List<String> statuses = [
    "Capsule",
    "Interested",
    "Not Interested",
    "Callback",
  ];

  Future<void> pickTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() => selectedTime = picked);
    }
  }

  Future<void> pickDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() => selectedDate = picked);
    }
  }

  @override
  Widget build(BuildContext context) => Dialog(
    backgroundColor: Colors.white,
    insetPadding: const EdgeInsets.all(12),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Header Section
        Container(
          decoration: BoxDecoration(
            color: Get.theme.primaryColor,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
          ),
          padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 16),
          child: Row(
            children: [
              InkWell(
                onTap: (){
                   FlutterOverlayWindow.closeOverlay();
                },
                child: const CircleAvatar(
                  radius: 24,
                  backgroundColor: Colors.white24,
                  child: Text(
                    "DT",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "DEMO Rajesh Testington",
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Get.theme.textTheme.bodyMedium?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "+91 9403890435",
                      style: Get.theme.textTheme.bodySmall?.copyWith(
                        color: Colors.white70,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 15,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.green.shade50,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            "VIP",
                            style: Get.theme.textTheme.bodySmall?.copyWith(
                              color: Colors.green,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          width: 22,
                          height: 22,
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.white38),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Icon(
                            Icons.add,
                            size: 14,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: ImageView(
                  AppIcons.whatsapp,
                  width: AppStyle.iconSize,
                  height: AppStyle.iconSize,
                ),
                onPressed: () {},
              ),
              IconButton(
                icon: const Icon(Icons.phone, color: Colors.white),
                onPressed: () {},
              ),
            ],
          ),
        ),

        // Lead and Assign info
        SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                color: const Color.fromARGB(255, 255, 255, 255),
                padding: const EdgeInsets.symmetric(
                  vertical: 4,
                  horizontal: 16,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Lead stage: Demo",
                      style: Get.theme.textTheme.bodyMedium,
                    ),
                    Text(
                      "Assigned to: Sales",
                      style: Get.theme.textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 10),
              Text(
                "Call Summary",
                style: Get.theme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 3),
              _textBox(
                controller: callSummaryController,
                hint: "Enter call summary",
              ),

              // const SizedBox(height: 8),
              // Text(
              //   "Followup info:",
              //   style: Get.theme.textTheme.bodyMedium?.copyWith(
              //     fontWeight: FontWeight.w600,
              //   ),
              // ),
              // Text(
              //   "Followup eiubbnnnionbiubjiikjknk",
              //   style: Get.theme.textTheme.bodySmall?.copyWith(),
              // ),

              const SizedBox(height: 8),
              Text(
                "Followup Status",
                style: Get.theme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 3),
              DropdownButtonFormField<String>(
                initialValue: selectedStatus,
                decoration: _inputDecoration(),
                padding: EdgeInsets.symmetric(vertical: 0),
                items:
                    statuses.map((status) {
                      return DropdownMenuItem(
                        value: status,
                        child: Text(status),
                      );
                    }).toList(),
                onChanged: (value) => setState(() => selectedStatus = value),
              ),
              // const SizedBox(height: 8),
              // Text(
              //   "Next Followp",
              //   style: Get.theme.textTheme.bodyMedium?.copyWith(
              //     color: Colors.black87,
              //   ),
              // ),
              // const SizedBox(height: 3),
              // Row(
              //   children: [
              //     Expanded(
              //       child: GestureDetector(
              //         onTap: pickTime,
              //         child: _readonlyBox(
              //           selectedTime != null
              //               ? selectedTime!.format(context)
              //               : "12:00",
              //         ),
              //       ),
              //     ),
              //     const SizedBox(width: 12),
              //     Expanded(
              //       child: GestureDetector(
              //         onTap: pickDate,
              //         child: _readonlyBox(
              //           selectedDate != null
              //               ? DateFormat("dd-MM-yyyy").format(selectedDate!)
              //               : "11-11-2025",
              //         ),
              //       ),
              //     ),
              //   ],
              // ),

              // const SizedBox(height: 16),
              // const Text(
              //   "Followup Reason",
              //   style: TextStyle(fontWeight: FontWeight.w600),
              // ),
              // const SizedBox(height: 8),
              // _textBox(
              //   controller: followupReasonController,
              //   hint: "Enter reason",
              // ),
            ],
          ),
        ),

        const SizedBox(height: 24),
        Center(
          child: SizedBox(
            width: 120,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Get.theme.primaryColor,
                // textStyle: TextStyle(
                //   color: Colors.white
                // ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: () {
                FlutterOverlayWindow.closeOverlay();
                // Navigator.pop(context);
              },
              child: Text(
                "Saved",
                style: Get.theme.textTheme.bodyMedium?.copyWith(
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ),

        // Tabs
        // DefaultTabController(
        //   length: 2,
        //   child: Column(
        //     children: [
        //       TabBar(
        //         labelColor: Colors.blue,
        //         unselectedLabelColor: Colors.grey,
        //         tabs: [const Tab(text: "Activity"), const Tab(text: "Info")],
        //         labelStyle: Get.theme.textTheme.bodyMedium,
        //       ),
        //       Container(
        //         height: 250,
        //         padding: const EdgeInsets.symmetric(
        //           vertical: 0,
        //           horizontal: 16,
        //         ),
        //         child: ListView(
        //           children: [
        //             ListTile(
        //               leading: const Icon(
        //                 Icons.note_alt_outlined,
        //                 color: Colors.blue,
        //               ),
        //               title: const Text("Notes"),
        //               trailing: const Icon(Icons.arrow_forward_ios, size: 14),
        //               onTap: () {},
        //             ),
        //             ListTile(
        //               leading: const Icon(
        //                 Icons.message_outlined,
        //                 color: Colors.green,
        //               ),
        //               title: const Text("Quick Message"),
        //               trailing: const Icon(Icons.arrow_forward_ios, size: 14),
        //               onTap: () {},
        //             ),
        //             ListTile(
        //               leading: const Icon(Icons.alarm, color: Colors.orange),
        //               title: const Text("Reminders"),
        //               trailing: const Icon(Icons.arrow_forward_ios, size: 14),
        //               onTap: () {},
        //             ),
        //             ListTile(
        //               leading: const Icon(
        //                 Icons.business,
        //                 color: Colors.deepPurple,
        //               ),
        //               title: const Text("Boost your Google Business Profile"),
        //               trailing: const Icon(Icons.arrow_forward_ios, size: 14),
        //               onTap: () {},
        //             ),
        //           ],
        //         ),
        //       ),
        //     ],
        //   ),
        // ),
      ],
    ),
  );

  Widget _circleIcon(IconData icon, Color bg) => CircleAvatar(
    backgroundColor: bg,
    radius: 20,
    child: Icon(icon, color: Colors.black87, size: 20),
  );

  InputDecoration _inputDecoration() => InputDecoration(
    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: Colors.grey),
    ),
  );

  Widget _readonlyBox(String text) => Container(
    padding: const EdgeInsets.symmetric(vertical: 5),
    decoration: BoxDecoration(
      border: Border.all(color: Colors.grey),
      borderRadius: BorderRadius.circular(8),
      // color: Colors.grey.shade50,
    ),
    alignment: Alignment.center,
    child: Text(
      text,
      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
    ),
  );

  Widget _textBox({
    required TextEditingController controller,
    required String hint,
  }) => TextField(
    controller: controller,
    maxLines: 3,

    decoration: InputDecoration(
      hintText: hint,
      hintStyle: Get.theme.textTheme.bodySmall,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        // borderSide: const BorderSide(color: Colors.blueAccent),
      ),
    ),
  );
}
