# call_tracker

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
# Call icons : (https://iconscout.com/icon-pack/communication-342_97580)
# Other icons : (https://iconscout.com/icon-pack/business-1056_97598)
https://iconscout.com/icon-pack/user-138_290044
https://github.com/healer-125/gbpn_dialer
https://github.com/user-grinch/RivoPhoneApp
https://github.com/Mercurysoftech/PicturoEnglish
https://github.com/Ranjeetda/Africall
