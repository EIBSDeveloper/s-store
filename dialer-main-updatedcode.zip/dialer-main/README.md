#	Name	Type	Collation	Attributes	Null	Default	Comments	Extra	 
	1	sno Primary	int(11)			No	None		AUTO_INCREMENT		
	2	company_id	int(11)			No	1				
	3	appointment_id	tinytext	latin1_swedish_ci		No	None				
	4	branch_id	int(11)			No	0				
	5	lead_id	int(11)			No	None				
	6	appointment_date	date			No	None				
	7	appointment_time	time			No	None				
	8	demo_type	text	latin1_swedish_ci		Yes	NULL				
	9	follow_up_reason	text	latin1_swedish_ci		Yes	NULL				
	10	progressed	int(11)			Yes	0	1-Yes 2-No			
	11	replay_message	text	latin1_swedish_ci		Yes	NULL				
	12	app_score	int(11)			Yes	NULL	1-Postive -1- Negative 0-Neutral			
	13	staff_id	int(11)			Yes	NULL				
	14	updated_at	datetime			Yes	current_timestamp()				
	15	updated_by	int(11)			No	None				
	16	created_at	datetime			Yes	current_timestamp()				
	17	created_by	int(11)			No	None				
	18	status	int(11)			No	0				
