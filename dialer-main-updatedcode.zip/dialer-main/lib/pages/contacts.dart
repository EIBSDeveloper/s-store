import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';

import 'contactservice.dart';

class ContactHomePage extends StatefulWidget {
  const ContactHomePage({super.key});

  @override
  State<ContactHomePage> createState() => _ContactHomePageState();
}

class _ContactHomePageState extends State<ContactHomePage> {
  final ContactSyncService syncService = ContactSyncService();
  List<Contact> newContacts = [];

  @override
  void initState() {
    super.initState();
    loadInitial();
  }

  Future<void> loadInitial() async {
    await syncService.initialFetch();
    await fetchNewContacts();
  }

  /// Manual fetch of newly added contacts
  Future<void> fetchNewContacts() async {
    List<Contact> added = await syncService.detectNewContacts();
    setState(() => newContacts.addAll(added));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("New Contacts Added"),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: fetchNewContacts,
          ),
        ],
      ),

      body: newContacts.isEmpty
          ? const Center(child: Text("No new contacts found"))
          : ListView.builder(
              itemCount: newContacts.length,
              itemBuilder: (context, index) {
                final c = newContacts[index];
                return ListTile(
                  title: Text(c.displayName),
                  subtitle: Text(
                    c.phones.isNotEmpty ? c.phones.first.number : "No number",
                  ),
                );
              },
            ),
    );
  }
}
