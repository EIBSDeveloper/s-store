import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ContactSyncService {
  /// Initial fetch (first time)
  Future<void> initialFetch() async {
    if (!await FlutterContacts.requestPermission()) return;

    final prefs = await SharedPreferences.getInstance();
    List<Contact> contacts = await FlutterContacts.getContacts(
      withProperties: true,
    );

    List<String> ids = contacts.map((c) => c.id).toList();
    prefs.setStringList("saved_contact_ids", ids);
  }

  /// Manual sync - detect newly added contacts
  Future<List<Contact>> detectNewContacts() async {
    if (!await FlutterContacts.requestPermission()) return [];

    final prefs = await SharedPreferences.getInstance();

    // Latest device contacts
    List<Contact> latest = await FlutterContacts.getContacts(
      withProperties: true,
    );
    List<String> newIds = latest.map((c) => c.id).toList();

    // Previously saved IDs
    List<String> oldIds = prefs.getStringList("saved_contact_ids") ?? [];

    // Newly added IDs
    List<String> addedIds = newIds.where((id) => !oldIds.contains(id)).toList();

    // Convert to contact objects
    List<Contact> addedContacts = latest
        .where((c) => addedIds.contains(c.id))
        .toList();

    // Update SharedPreferences
    prefs.setStringList("saved_contact_ids", newIds);

    return addedContacts;
  }
}
