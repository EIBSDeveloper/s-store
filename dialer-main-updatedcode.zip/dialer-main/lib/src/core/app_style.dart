import 'package:flutter/material.dart';
import 'package:itracker/src/core/app_colors.dart';

class AppStyle {
  static const double iconSizelarge = 25;
  static const double iconSize = 20;
  static const double iconSize2 = 15;
  static const double iconSize3 = 10;

  static const double listGap = 8;
  static const double widgetsGap = 8;
  static const double borderRadiusBox = 8;
  static const double borderRadiusClip = 5;
  static const double borderRadiusBottom = 50;
  static const BoxDecoration inputDecoration = BoxDecoration(
    borderRadius: BorderRadius.all(Radius.circular(borderRadiusBox)),
  );
  static BoxDecoration decoration = BoxDecoration(
    color: AppColors.card,
    borderRadius: BorderRadius.circular(10),
    // border: Border.all(color: AppColors.border),
    boxShadow: [
      const BoxShadow(
        color: Color.fromRGBO(204, 219, 232, 1),
        blurRadius: 6,
        spreadRadius: 0,
        offset: Offset(3, 3),
      ),
      const BoxShadow(
        color: Color.fromRGBO(255, 255, 255, 0.5),
        blurRadius: 6,
        spreadRadius: 1,
        offset: Offset(-3, -3),
      ),
      const BoxShadow(
        color: Color.fromRGBO(0, 0, 0, 1.0),
        blurRadius: 0,
        spreadRadius: 0,
        offset: Offset(0, 0),
      ),
    ],
  );
  static BoxDecoration decorationDark = BoxDecoration(
    color: Colors.grey[850],
    borderRadius: BorderRadius.circular(10),
    border: Border.all(color: Colors.grey[800]!),
  );
  static const List<BoxShadow> boxShadow = [
    BoxShadow(
      color: Color.fromRGBO(0, 0, 0, 0.05),
      blurRadius: 2,
      spreadRadius: 0,
      offset: Offset(0, 1),
    ),
  ];
}
