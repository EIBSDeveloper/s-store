import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:itracker/src/app/widgets/custom_app_bar.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:itracker/src/core/app_style.dart';

import 'notification_controller.dart';

class NotificationPage extends StatelessWidget {
  const NotificationPage({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(NotificationController());
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: CustomAppBar(
        title: Text(
          "Notification",
          style: Theme.of(context).textTheme.titleLarge,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: controller.notificationList.length,
                itemBuilder: (context, index) {
                  final notification = controller.notificationList[index];

                  return TweenAnimationBuilder(
                    duration: Duration(milliseconds: 1000 + (index * 120)),
                    curve: Curves.linear,
                    tween: Tween<double>(begin: 0, end: 1),

                    builder: (context, value, child) => Opacity(
                      opacity: value,
                      child: Transform.translate(
                        offset: Offset(0, 20 * (1 - value)),
                        child: child,
                      ),
                    ),

                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Obx(() {
                        bool isExpanded = controller.isExpand.value == index;

                        return GestureDetector(
                          onTap: () {
                            controller.isExpand.value = isExpanded ? -1 : index;
                          },

                          /// =========== Horizontal Move to Delete Both Sides
                          child: Dismissible(
                            key: Key(notification["id"].toString()),
                            direction: DismissDirection.horizontal,
                            background: Container(
                              alignment: Alignment.centerLeft,
                              // padding: const EdgeInsets.symmetric(
                              //   horizontal: 20,
                              // ),
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [
                                    Colors.red,
                                    Colors.orangeAccent,
                                    Colors.red,
                                  ],
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.2),
                                    offset: const Offset(0, 4),
                                    blurRadius: 6,
                                    spreadRadius: 1,
                                  ),
                                ],
                              ),
                              child: const Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  Icon(Icons.delete, color: Colors.white),
                                ],
                              ),
                            ),
                            onDismissed: (direction) {},

                            /// ============ Main Notification Card =============
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 400),
                              curve: Curves.fastOutSlowIn,
                              padding: const EdgeInsets.all(12),

                              decoration: AppStyle.decoration,

                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // TOP ROW → Always visible
                                  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      // CircleAvatar(
                                      //   radius: 25,
                                      //   backgroundColor: Colors.orange,
                                      //   child: Icon(
                                      //     Icons.call,
                                      //     color: Colors.white,
                                      //     size: 26,
                                      //   ),
                                      // ),
                                      // const SizedBox(width: 16),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  notification["title"],
                                                  style: Theme.of(
                                                    context,
                                                  ).textTheme.titleLarge,
                                                ),
                                                Text(
                                                  notification["time_ago"],
                                                  style: Theme.of(
                                                    context,
                                                  ).textTheme.bodySmall,
                                                ),
                                              ],
                                            ),

                                            const SizedBox(height: 4),

                                            Text(
                                              notification["description"],
                                              style: Theme.of(
                                                context,
                                              ).textTheme.bodyMedium,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),

                                  /// ========== Expanded Section Part =============
                                  AnimatedCrossFade(
                                    firstChild: const SizedBox(),
                                    secondChild: Padding(
                                      padding: const EdgeInsets.only(top: 12),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              const Icon(Icons.call),
                                              Text(
                                                notification["phone_number"],
                                                style: Theme.of(
                                                  context,
                                                ).textTheme.bodySmall,
                                              ),
                                            ],
                                          ),
                                          const SizedBox(height: 10),
                                          Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              // const Icon(
                                              //   Icons.message_outlined,
                                              // ),
                                              Flexible(
                                                child: Text(
                                                  notification["detailed_message"],
                                                  textAlign: TextAlign.justify,
                                                  style: Theme.of(
                                                    context,
                                                  ).textTheme.bodySmall,
                                                ),
                                              ),
                                            ],
                                          ),

                                          const SizedBox(height: 3),

                                          Align(
                                            alignment: Alignment.centerRight,
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              children: [  Text(
                                                  "${notification["formatted_date"]} - ",
                                                  style: Theme.of(context).textTheme.bodySmall,
                                                ),
                                                Text(
                                                  notification["formatted_time"],
                                                  style:  Theme.of(context).textTheme.bodySmall,
                                                ),
                                                
                                              
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    crossFadeState: isExpanded
                                        ? CrossFadeState.showSecond
                                        : CrossFadeState.showFirst,
                                    duration: const Duration(milliseconds: 300),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      }),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
