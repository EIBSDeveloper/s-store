import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:itracker/src/app/modules/auth/logincontroller.dart';
import 'package:itracker/src/app/modules/auth/otpscreen.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:itracker/src/core/app_style.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final LoginController controller = Get.put(LoginController());

  String? validateMobile(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your mobile number';
    }

    final regex = RegExp(r'^\d{10}$');
    if (!regex.hasMatch(value)) {
      return 'Enter a valid 10-digit number';
    }

    return null;
  }

  void _submit() {
    if (controller.formKey.currentState!.validate()) {
      final mobile = controller.mobileController.text;
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const OtpScreen()),
      );

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Mobile number entered: $mobile',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: AppColors.card,
              fontWeight: FontWeight.w700,
            ),
          ),
          backgroundColor: AppColors.primary,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Form(
            key: controller.formKey,
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Logo
                  Hero(
                    tag: "app-logo",
                    child: Container(
                      width: 64,
                      height: 64,
                      decoration: AppStyle.decoration,
                      child: Icon(
                        Icons.trending_up,
                        color: AppColors.primary,
                        size: 32,
                      ),
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Title
                  Text(
                    'Welcome Back',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 8),

                  Text(
                    'Enter your mobile number to continue',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.w400,
                    ),
                  ),

                  const SizedBox(height: 32),

                  // Input Field (Inside Form)
                  Container(
                    height: 80, // your custom height
                    width: double.infinity, // full width
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 15,
                    ),
                    decoration: AppStyle.decoration,
                    child: TextFormField(
                      controller: controller.mobileController,
                      keyboardType: TextInputType.phone,
                      inputFormatters: [
                        DigitsOnlyFormatter(),
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(10),
                      ],
                      validator: validateMobile,
                      decoration: const InputDecoration(
                        label: LableText('Mobile No', isrequired: true),
                        border: InputBorder.none,
                        isDense: true,
                      ),
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: AppColors.textPrimary,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ),

                  const SizedBox(height: 30),

                  // Submit button
                  SizedBox(
                    width: 150,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: _submit,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                            AppStyle.borderRadiusBox,
                          ),
                        ),
                      ),
                      child: Text(
                        'Continue',
                        style: Theme.of(context).textTheme.titleMedium
                            ?.copyWith(
                              color: AppColors.card,
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ----------------------------------------------------------------------
class LableText extends StatelessWidget {
  const LableText(this.text, {super.key, this.isrequired = false});

  final String text;
  final bool isrequired;

  @override
  Widget build(BuildContext context) => RichText(
    text: TextSpan(
      text: text,
      style: const TextStyle(color: AppColors.textPrimary, fontSize: 14),
      children: [
        if (isrequired)
          const TextSpan(
            text: " *",
            style: TextStyle(color: AppColors.danger, fontSize: 18),
          ),
      ],
    ),
  );
}

// Only digits formatter
class DigitsOnlyFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final text = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');
    return TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: text.length),
    );
  }
}
