import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LoginController extends GetxController {
  final formKey = GlobalKey<FormState>();
  final TextEditingController mobileController = TextEditingController();

  @override
  void dispose() {
    mobileController.dispose();
    super.dispose();
  }

  // 6 controllers for 6 boxes
  final List<TextEditingController> otpControllers = List.generate(
    6,
    (_) => TextEditingController(),
  );

  // Focus nodes
  final List<FocusNode> focusNodes = List.generate(6, (_) => FocusNode());

  String getOtp() => otpControllers.map((e) => e.text).join();

  bool validateOtp() {
    final otp = getOtp();
    if (otp.length != 6) return false;
    return true;
  }
}
