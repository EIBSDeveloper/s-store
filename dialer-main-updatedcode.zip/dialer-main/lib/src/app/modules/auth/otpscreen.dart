import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:itracker/src/app/modules/auth/logincontroller.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:itracker/src/core/app_style.dart';

class OtpScreen extends StatefulWidget {
  const OtpScreen({super.key});

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  final LoginController controller = Get.put(LoginController());

  void _submit() {
    if (controller.validateOtp()) {
      final otp = controller.getOtp();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "OTP entered: $otp",
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: AppColors.card,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: AppColors.primary,
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Please enter 6-digit OTP"),
          backgroundColor: AppColors.danger,
        ),
      );
    }
  }

  Widget _otpBox(int index) {
    return Container(
      width: 50,
      height: 60,
      decoration: AppStyle.decoration,
      child: TextFormField(
        controller: controller.otpControllers[index],
        focusNode: controller.focusNodes[index],
        keyboardType: TextInputType.number,
        textAlign: TextAlign.center,
        maxLength: 1,
        style: Theme.of(context).textTheme.titleLarge?.copyWith(
          color: AppColors.textPrimary,
          fontWeight: FontWeight.bold,
        ),
        decoration: const InputDecoration(
          counterText: "",
          border: InputBorder.none,
        ),
        onChanged: (value) {
          if (value.isNotEmpty) {
            if (index < 5) {
              controller.focusNodes[index + 1].requestFocus();
            } else {
              FocusScope.of(context).unfocus();
            }
          } else {
            if (index > 0) {
              controller.focusNodes[index - 1].requestFocus();
            }
          }
          setState(() {});
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Logo
                Hero(
                  tag: "app-logo",
                  child: Container(
                    width: 64,
                    height: 64,
                    decoration: AppStyle.decoration,
                    child: Icon(Icons.lock, color: AppColors.primary, size: 32),
                  ),
                ),

                const SizedBox(height: 24),

                Text(
                  "Enter OTP",
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: AppColors.textPrimary,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 8),

                Text(
                  "We have sent a 6-digit code to your mobile",
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: AppColors.textPrimary,
                    fontWeight: FontWeight.w400,
                  ),
                ),

                const SizedBox(height: 30),

                // OTP BOXES ROW
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(6, (i) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 5),
                      child: _otpBox(i),
                    );
                  }),
                ),

                const SizedBox(height: 30),

                SizedBox(
                  width: 150,
                  height: 48,
                  child: ElevatedButton(
                    onPressed: _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(
                          AppStyle.borderRadiusBox,
                        ),
                      ),
                    ),
                    child: Text(
                      'Verify',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: AppColors.card,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                // RESEND
                TextButton(
                  onPressed: () {},
                  child: Text(
                    "Resend OTP",
                    style: TextStyle(
                      color: AppColors.primary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
