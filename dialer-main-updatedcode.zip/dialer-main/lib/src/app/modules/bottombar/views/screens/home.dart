import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../core/app_colors.dart';
import '../../../dashboard/views/screens/dashboard_screen.dart';
import '../../contoller/bottombar_contoller.dart';
import '../widgets/bottom_nav_bar.dart';

class Home extends GetView<BottomBarContoller> {
  const Home({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    key: controller.scaffoldKey,
    backgroundColor: AppColors.background,
    body: SafeArea(
      child: Column(
        children: [
          Obx(
            () => MainAppBar(
              title: Text(
                controller.pages[controller.selectedIndex.value].title,
                style: Theme.of(context).textTheme.titleLarge!,
              ),
            ),
          ),
          Expanded(
            child: PageView.builder(
              controller: controller.pageController,
              itemCount: controller.pages.length,
              itemBuilder: (context, index) => controller.pages[index].screen,
              onPageChanged: (index) {
                controller.selectedIndex.value = index;
              },
            ),
          ),
        ],
      ),
    ),

    bottomNavigationBar: SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Obx(
          () => BottomNavBar(
            key: const ValueKey("ButtomBar"),
            curentIndex: controller.selectedIndex.value,
            backgroundColor: AppColors.card,

            selectColor: Theme.of(context).colorScheme.secondaryContainer,
            onTap: (index) {
              controller.selectedIndex.value = index;
              controller.pageController.jumpToPage(index);
            },
            children: controller.pages,
          ),
        ),
      ),
    ),
  );
}
