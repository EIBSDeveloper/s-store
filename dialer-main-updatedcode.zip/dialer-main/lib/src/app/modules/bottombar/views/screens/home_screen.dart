import 'package:flutter/material.dart';

import '../../../../../core/app_colors.dart';
import '../../../payment_tracker/view/widgets/chart_card.dart';

class HomeDashboard extends StatefulWidget {
  const HomeDashboard({super.key});

  @override
  State<HomeDashboard> createState() => _HomeDashboardState();
}

class _HomeDashboardState extends State<HomeDashboard>
    with SingleTickerProviderStateMixin {
  int selectedIndex = 0;
  late AnimationController animCtrl;
  late Animation<double> progress;
  @override
  void initState() {
    super.initState();

    animCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    progress = CurvedAnimation(parent: animCtrl, curve: Curves.easeInOutCubic);

    animCtrl.forward();
  }

  @override
  void dispose() {
    animCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xfff5f6ff),
    body: SingleChildScrollView(
      // padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _balanceCard(),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              children: [
                _todayStatsHeader(),
                const SizedBox(height: 8),
                _statsGrid(),
              ],
            ),
          ),
        ],
      ),
    ),
  );

  // -----------------------------------------------------------
  // HEADER
  // -----------------------------------------------------------
  Widget _header() => SafeArea(
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Hi, Jakes!",
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              "Welcome Back!",
              style: Theme.of(
                context,
              ).textTheme.titleLarge?.copyWith(color: Colors.white),
            ),
          ],
        ),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: const BoxDecoration(
            color: Color(0xffeaf0ff),
            shape: BoxShape.circle,
          ),
          child: const Icon(
            Icons.notifications_active_rounded,
            color: Color(0xff3259ff),
            size: 26,
          ),
        ),
      ],
    ),
  );

  // -----------------------------------------------------------
  // BALANCE CARD
  // -----------------------------------------------------------
  Widget _balanceCard() => Container(
    padding: const EdgeInsets.all(18),
    decoration: const BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xff4665ff), Color(0xff6286ff)],
      ),
      borderRadius: BorderRadius.only(
        bottomLeft: Radius.circular(22),
        bottomRight: Radius.circular(22),
      ),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _header(),

        // // Search Bar
        // Container(
        //   padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        //   decoration: BoxDecoration(
        //     color: const Color(0xFF5B7FE8),
        //     borderRadius: BorderRadius.circular(12),
        //   ),
        //   child: Row(
        //     children: const [
        //       Icon(Icons.search, color: Colors.white70, size: 20),
        //       SizedBox(width: 12),
        //       Text(
        //         'Search for Stats',
        //         style: TextStyle(color: Colors.white70, fontSize: 15),
        //       ),
        //     ],
        //   ),
        // ),
        const SizedBox(height: 8),

        // Balance Card
        Stack(
          children: [
            Container(
              // padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color.fromARGB(255, 231, 249, 255),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Total Balance',
                              style: TextStyle(
                                color: Colors.black54,
                                fontSize: 14,
                              ),
                            ),
                            // Container(
                            //   padding: const EdgeInsets.all(6),
                            //   decoration: BoxDecoration(
                            //     color: Colors.white,
                            //     borderRadius: BorderRadius.circular(8),
                            //   ),
                            //   child: const Icon(
                            //     Icons.remove_red_eye_outlined,
                            //     size: 16,
                            //     color: Colors.black54,
                            //   ),
                            // ),
                          ],
                        ),
                        SizedBox(height: 2),
                        Text(
                          '₹10,000.00',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 36,
                            fontWeight: FontWeight.bold,
                          ),
                        ),

                        SizedBox(height: 2),
                      ],
                    ),
                  ),

                  // Graph
                  Stack(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xFF7CB342),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: const Text(
                                '+20%',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            const SizedBox(width: 4),
                            const Text(
                              'Profit & Loss',
                              style: TextStyle(
                                color: Colors.black54,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                      // SizedBox(
                      //   height: 100,
                      //   child: CustomPaint(
                      //     size: const Size(double.infinity, 100),
                      //     painter: StockGraphPainter(),
                      //   ),
                      // ),
                      // Obx(() {
                      // final points = List<double>.from();

                      // if (points.length < 2) {
                      //   return const Center(
                      //     child: Text("Not enough data to draw chart"),
                      //   );
                      // }

                      // return
                      AnimatedBuilder(
                        animation: progress,
                        builder: (_, __) => SizedBox(
                          height: 100,
                          width: double.infinity,
                          child: CustomPaint(
                            painter: ChartPainter(
                              points: [
                                0.73,
                                0.14,
                                0.27,
                                0.61,
                                0.34,
                                0.68,
                                0.95,
                                0.55,
                              ],
                              color: AppColors.primary,
                              progress: progress.value,
                            ),
                          ),
                        ),
                        //   );
                        // }
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xffebf1ff),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Row(
                      children: [
                        Text(
                          "Analyze",
                          style: TextStyle(
                            fontSize: 14,
                            color: Color(0xff3259ff),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(width: 6),
                        Icon(
                          Icons.auto_awesome,
                          size: 18,
                          color: Color(0xff3259ff),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    ),
  );

  // TODAY'S STATS HEADER
  Widget _todayStatsHeader() => const Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(
        "Today's Stats",
        style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
      ),
    ],
  );

  // STATS GRID (4 CARDS)
  Widget _statsGrid() => GridView.count(
    shrinkWrap: true,
    crossAxisCount: 4,
    physics: const NeverScrollableScrollPhysics(),
    mainAxisSpacing: 14,
    padding: const EdgeInsets.all(0),
    crossAxisSpacing: 14,
    childAspectRatio: 0.90,
    children: [
      statCard(
        title: "Sales",
        subtitle: "Total sales today",
        value: "₹200,000",
        bg: Colors.green.shade100,
        color: Colors.green,
        percent: 0.60,
      ),
      statCard(
        title: "Profit",
        subtitle: "Total profit today",
        value: "₹128,000",
        bg: Colors.amber.shade100,
        color: Colors.orange,
        percent: 0.40,
      ),
      statCard(
        title: "Orders",
        subtitle: "Total orders today",
        value: "07",
        bg: Colors.blue.shade100,
        color: Colors.blue,
        percent: 0.80,
      ),
      statCard(
        title: "Loss",
        subtitle: "Total loss today",
        value: "₹2,800",
        bg: Colors.red.shade100,
        color: Colors.red,
        percent: 0.60,
      ),
    ],
  );

  Widget statCard({
    required String title,
    required String subtitle,
    required String value,
    required Color bg,
    required Color color,
    required double percent,
  }) {
    final bool isLoss = title.toLowerCase() == "loss"; // detect loss

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Stack(
        children: [
          // --------------------------
          // TOP RIGHT ARROW ICON
          // --------------------------
          Positioned(
            right: 0,
            child: Icon(
              isLoss ? Icons.arrow_downward : Icons.arrow_upward,
              size: 22,
              color: isLoss ? Colors.red : color,
            ),
          ),

          // --------------------------
          // MAIN CONTENT
          // --------------------------
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 4),

              // 3D GLASS CIRCULAR PROGRESS
              SizedBox(
                width: 62,
                height: 62,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // BACKGROUND GLASS RING
                    Container(
                      width: 62,
                      height: 62,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [
                            Colors.white.withOpacity(0.55),
                            Colors.white.withOpacity(0.15),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                    ),

                    // ACTUAL PROGRESS RING
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0, end: percent),
                      duration: const Duration(milliseconds: 900),
                      curve: Curves.easeOutBack,
                      builder: (context, value, _) => CircularProgressIndicator(
                        value: value,
                        strokeWidth: 7,
                        backgroundColor: Colors.white.withOpacity(0.25),
                        valueColor: AlwaysStoppedAnimation(
                          color.withOpacity(0.9),
                        ),
                      ),
                    ),

                    // INNER GLASS DISC
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [
                            Colors.white.withOpacity(0.8),
                            Colors.white.withOpacity(0.4),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                    ),

                    // PERCENT TEXT
                    Text(
                      "${(percent * 100).toInt()}%",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: color,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),

              Text(
                title,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),

              const SizedBox(height: 4),

              Text(
                subtitle,
                style: const TextStyle(fontSize: 13, color: Colors.black54),
              ),

              const SizedBox(height: 8),

              Text(
                value,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class StockGraphPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // Define data points for the lines
    final List<Offset> greenLinePoints = [
      Offset(0, size.height * 0.7),
      Offset(size.width * 0.15, size.height * 0.5),
      Offset(size.width * 0.3, size.height * 0.6),
      Offset(size.width * 0.45, size.height * 0.4),
      Offset(size.width * 0.6, size.height * 0.3),
      Offset(size.width * 0.75, size.height * 0.45),
      Offset(size.width * 0.9, size.height * 0.25),
      Offset(size.width, size.height * 0.2),
    ];

    // final List<Offset> redLinePoints = [
    //   Offset(0, size.height * 0.6),
    //   Offset(size.width * 0.15, size.height * 0.7),
    //   Offset(size.width * 0.3, size.height * 0.5),
    //   Offset(size.width * 0.45, size.height * 0.6),
    //   Offset(size.width * 0.6, size.height * 0.5),
    //   Offset(size.width * 0.75, size.height * 0.35),
    //   Offset(size.width * 0.9, size.height * 0.4),
    //   Offset(size.width, size.height * 0.4),
    // ];

    // Paint for green line
    final greenPaint = Paint()
      ..color = const Color(0xFF7CB342)
      ..strokeWidth = 5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    // Paint for red line

    // Draw green line with smooth curves
    Path greenPath = Path();
    greenPath.moveTo(greenLinePoints[0].dx, greenLinePoints[0].dy);

    for (int i = 0; i < greenLinePoints.length - 1; i++) {
      final current = greenLinePoints[i];
      final next = greenLinePoints[i + 1];
      final controlPoint = Offset(
        (current.dx + next.dx) / 2,
        (current.dy + next.dy) / 2,
      );
      greenPath.quadraticBezierTo(
        current.dx,
        current.dy,
        controlPoint.dx,
        controlPoint.dy,
      );
    }
    greenPath.lineTo(greenLinePoints.last.dx, greenLinePoints.last.dy);
    canvas.drawPath(greenPath, greenPaint);

    // Draw red line with smooth curves
    // Path redPath = Path();
    // redPath.moveTo(redLinePoints[0].dx, redLinePoints[0].dy);

    // for (int i = 0; i < redLinePoints.length - 1; i++) {
    //   final current = redLinePoints[i];
    //   final next = redLinePoints[i + 1];
    //   final controlPoint = Offset(
    //     (current.dx + next.dx) / 2,
    //     (current.dy + next.dy) / 2,
    //   );
    //   redPath.quadraticBezierTo(
    //     current.dx,
    //     current.dy,
    //     controlPoint.dx,
    //     controlPoint.dy,
    //   );
    // }
    // redPath.lineTo(redLinePoints.last.dx, redLinePoints.last.dy);
    // canvas.drawPath(redPath, redPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
