import 'package:flutter/material.dart';

class BottomNavBarItem {
  final String title;
  final Widget screen;
  final List<List<dynamic>> icon;
  final Color color;
  const BottomNavBarItem({
    required this.screen,
    required this.title,
    required this.icon,
    required this.color,
  });
}
