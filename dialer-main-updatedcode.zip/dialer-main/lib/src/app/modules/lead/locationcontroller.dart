import 'package:get/get.dart';
import 'package:itracker/src/app/modules/lead/model/dropdownmodel.dart';
import 'package:itracker/src/app/modules/lead/repo/locationRepo.dart';

class LocationController extends GetxController {
  final LocationRepository repo = LocationRepository();

  // Reactive lists for UI
  RxList<String> countries = <String>[].obs;
  RxList<String> states = <String>[].obs;
  RxList<String> cities = <String>[].obs;

  // Selected values
  RxString selectedCountry = ''.obs;
  RxString selectedState = ''.obs;
  RxString selectedCity = ''.obs;

  // Validation / Error
  RxString countryError = ''.obs;
  RxString stateError = ''.obs;
  RxString cityError = ''.obs;

  // Keep full model lists to get IDs for dependent fetches
  List<LocationModel> countriesList = [];
  List<LocationModel> statesList = [];
  List<LocationModel> citiesList = [];

  @override
  void onInit() {
    super.onInit();
    fetchCountries();
  }

  /// Fetch all countries
  Future<void> fetchCountries() async {
    try {
      final list = await repo.getCountries();
      countriesList = list;
      countries.assignAll(list.map((e) => e.name));
    } catch (e) {
      print("Error fetching countries: $e");
    }
  }

  /// Fetch states by country name
  Future<void> fetchStates(String countryName) async {
    try {
      final country = countriesList.firstWhere(
        (c) => c.name == countryName,
        orElse: () => LocationModel(id: '', name: ''),
      );
      if (country.id.isEmpty) return;

      final list = await repo.getStates(country.id);
      statesList = list;
      states.assignAll(list.map((e) => e.name));
    } catch (e) {
      print("Error fetching states: $e");
    }
  }

  /// Fetch cities by state name
  Future<void> fetchCities(String stateName) async {
    try {
      final state = statesList.firstWhere(
        (s) => s.name == stateName,
        orElse: () => LocationModel(id: '', name: ''),
      );
      if (state.id.isEmpty) return;

      final list = await repo.getCities(state.id);
      citiesList = list;
      cities.assignAll(list.map((e) => e.name));
    } catch (e) {
      print("Error fetching cities: $e");
    }
  }

  /// Set selected country
  void setCountry(String value) {
    selectedCountry.value = value;
    selectedState.value = '';
    selectedCity.value = '';
    states.clear();
    cities.clear();
    fetchStates(value);
  }

  /// Set selected state
  void setStateValue(String value) {
    selectedState.value = value;
    selectedCity.value = '';
    cities.clear();
    fetchCities(value);
  }

  /// Set selected city
  void setCity(String value) {
    selectedCity.value = value;
  }
}
