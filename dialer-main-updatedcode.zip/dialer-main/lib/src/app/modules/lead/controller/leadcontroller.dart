// lib/controllers/lead_controller.dart
// import 'package:calltrackerui/src/app/utils/validator.dart';
import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';

import '../../../utils/validator.dart';

// lib/models/lead_model.dart
class LeadModel {
  String? name;
  String? gender;
  String? mobile;
  String? country;
  String? state;
  String? city;
  String? leadSource;
  String? email;
  String? locationUrl;
  String? address;
  String? leadTag;
  String? leadType;
  String? description;

  LeadModel({
    this.name,
    this.gender,
    this.mobile,
    this.country,
    this.state,
    this.city,
    this.leadSource,
    this.email,
    this.locationUrl,
    this.address,
    this.leadTag,
    this.leadType,
    this.description,
  });

  factory LeadModel.fromJson(Map<String, dynamic> json) => LeadModel(
      name: json['name'],
      gender: json['gender'],
      mobile: json['mobile'],
      country: json['country'],
      state: json['state'],
      city: json['city'],
      leadSource: json['leadSource'],
      email: json['email'],
      locationUrl: json['locationUrl'],
      address: json['address'],
      leadTag: json['leadTag'],
      leadType: json['leadType'],
      description: json['description'],
    );

  Map<String, dynamic> toJson() => {
    'name': name,
    'gender': gender,
    'mobile': mobile,
    'country': country,
    'state': state,
    'city': city,
    'leadSource': leadSource,
    'email': email,
    'locationUrl': locationUrl,
    'address': address,
    'leadTag': leadTag,
    'leadType': leadType,
    'description': description,
  };
}

class LeadController extends GetxController {
  final lead = LeadModel(gender: '').obs;

  // Text Controllers
  final nameCtrl = TextEditingController();
  final mobileCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  final locationUrlCtrl = TextEditingController();
  final addressCtrl = TextEditingController();
  final descriptionCtrl = TextEditingController();

  final countries = <String>['United States', 'Canada', 'United Kingdom'].obs;

  final gender = <String>['Male', 'Female', 'Others'].obs;

  final states = <String>['Tamilnadu', 'Kerala', 'Karnataka'].obs;

  final cities = <String>['Madurai', 'Kochin', 'Bangalore'].obs;

  final leadSources = <String>['Website', 'Referral', 'Cold Call'].obs;

  final leadTags = <String>['Low Priority', 'High Priority', 'Follow-up'].obs;

  final leadTypes = <String>['Business', 'Corporate', 'Individual'].obs;

  // Selected values (MUST be RxString)
  final selectedGender = ''.obs;
  final selectedCountry = ''.obs;
  final selectedState = ''.obs;
  final selectedCity = ''.obs;
  final selectedLeadSource = ''.obs;
  final selectedLeadTag = ''.obs;
  final selectedLeadType = ''.obs;

  // Add these Rx error variables (7 errors)
  final nameError = ''.obs;
  final genderError = ''.obs;
  final mobileError = ''.obs;
  final countryError = ''.obs;
  final stateError = ''.obs;
  final cityError = ''.obs;
  final sourceError = ''.obs;

  @override
  void onInit() {
    super.onInit();

    nameCtrl.text = lead.value.name ?? '';
    mobileCtrl.text = lead.value.mobile ?? '';
    emailCtrl.text = lead.value.email ?? '';
    locationUrlCtrl.text = lead.value.locationUrl ?? '';
    addressCtrl.text = lead.value.address ?? '';
    descriptionCtrl.text = lead.value.description ?? '';

    selectedCountry.value = lead.value.country ?? "";
    selectedState.value = lead.value.state ?? "";
    selectedCity.value = lead.value.city ?? "";
    selectedLeadSource.value = lead.value.leadSource ?? "";
    selectedLeadTag.value = lead.value.leadTag ?? "";
    selectedLeadType.value = lead.value.leadType ?? "";
  }

  @override
  void onClose() {
    nameCtrl.dispose();
    mobileCtrl.dispose();
    emailCtrl.dispose();
    locationUrlCtrl.dispose();
    addressCtrl.dispose();
    descriptionCtrl.dispose();
    super.onClose();
  }

  // Sync data into model
  void _syncToModel() {
    lead.update((l) {
      if (l == null) return;

      l.name = nameCtrl.text.trim();
      l.mobile = mobileCtrl.text.trim();
      l.email = emailCtrl.text.trim();
      l.locationUrl = locationUrlCtrl.text.trim();
      l.address = addressCtrl.text.trim();
      l.description = descriptionCtrl.text.trim();

      l.country = selectedCountry.value.isEmpty ? null : selectedCountry.value;
      l.state = selectedState.value.isEmpty ? null : selectedState.value;
      l.city = selectedCity.value.isEmpty ? null : selectedCity.value;
      l.leadSource = selectedLeadSource.value.isEmpty
          ? null
          : selectedLeadSource.value;
      l.leadTag = selectedLeadTag.value.isEmpty ? null : selectedLeadTag.value;
      l.leadType = selectedLeadType.value.isEmpty
          ? null
          : selectedLeadType.value;
    });
  }

  // Setters
  void setGender(String value) {
    selectedGender.value = value;
    _syncToModel();
  }

  void setCountry(String value) {
    selectedCountry.value = value;
    _syncToModel();
  }

  void setStateValue(String value) {
    selectedState.value = value;
    _syncToModel();
  }

  void setCity(String value) {
    selectedCity.value = value;
    _syncToModel();
  }

  void setLeadSource(String value) {
    selectedLeadSource.value = value;
    _syncToModel();
  }

  void setLeadTag(String value) {
    selectedLeadTag.value = value;
    _syncToModel();
  }

  void setLeadType(String value) {
    selectedLeadType.value = value;
    _syncToModel();
  }

  // Validation
  String? validateLead() {
    nameError.value = '';
    genderError.value = '';
    mobileError.value = '';
    countryError.value = '';
    stateError.value = '';
    cityError.value = '';
    sourceError.value = '';

    final nErr = Validator.validateName(nameCtrl.text);
    if (nErr != null) nameError.value = nErr;

    final gErr = Validator.validateGender(lead.value.gender);
    if (gErr != null) genderError.value = gErr;

    final mErr = Validator.validateMobile(mobileCtrl.text);
    if (mErr != null) mobileError.value = mErr;

    final cErr = Validator.validateCountry(selectedCountry.value);
    if (cErr != null) countryError.value = cErr;

    final sErr = Validator.validateState(selectedState.value);
    if (sErr != null) stateError.value = sErr;

    final ciErr = Validator.validateCity(selectedCity.value);
    if (ciErr != null) cityError.value = ciErr;

    final soErr = Validator.validateLeadSource(selectedLeadSource.value);
    if (soErr != null) sourceError.value = soErr;

    if (nameError.value.isNotEmpty ||
        genderError.value.isNotEmpty ||
        mobileError.value.isNotEmpty ||
        countryError.value.isNotEmpty ||
        stateError.value.isNotEmpty ||
        cityError.value.isNotEmpty ||
        sourceError.value.isNotEmpty) {
      return "Please fill all required fields";
    }

    return null;
  }

  Future<void> createLead() async {
    _syncToModel();

    final error = validateLead();
    if (error != null) {
      showToast(error, success: false); // 🔴 Red toast
      return;
    }

    try {
      showToast("Lead created successfully", success: true); // 🟢 Green toast

      clearForm();
    } catch (e) {
      showToast("Failed to create lead", success: false); // 🔴 Error toast
    }
  }

  Future<void> pickCurrentLocation() async {
    // try {
    //   bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    //   if (!serviceEnabled) {
    //     showToast("Please enable GPS", success: false);
    //     return;
    //   }

    //   LocationPermission permission = await Geolocator.checkPermission();

    //   if (permission == LocationPermission.denied) {
    //     permission = await Geolocator.requestPermission();
    //   }

    //   if (permission == LocationPermission.denied ||
    //       permission == LocationPermission.deniedForever) {
    //     showToast("Location permission denied", success: false);
    //     return;
    //   }

    //   Position pos = await Geolocator.getCurrentPosition(
    //     desiredAccuracy: LocationAccuracy.high,
    //   );

    //   String url =
    //       "https://www.google.com/maps/search/?api=1&query=${pos.latitude},${pos.longitude}";
    //   locationUrlCtrl.text = url;

    //   showToast("Location picked successfully", success: true);
    // } catch (e) {
    //   print("LOCATION ERROR: $e");
    //   showToast("Unable to get current location", success: false);
    // }
  }

  void clearForm() {
    nameCtrl.clear();
    mobileCtrl.clear();
    emailCtrl.clear();
    locationUrlCtrl.clear();
    addressCtrl.clear();
    descriptionCtrl.clear();

    selectedCountry.value = "";
    selectedState.value = "";
    selectedCity.value = "";
    selectedLeadSource.value = "";
    selectedLeadTag.value = "";
    selectedLeadType.value = "";

    lead.value = LeadModel(gender: "Male");
  }
}

void showToast(String message, {bool success = false}) {
  // Fluttertoast.showToast(
  //   msg: message,
  //   toastLength: Toast.LENGTH_SHORT,
  //   gravity: ToastGravity.BOTTOM,
  //   backgroundColor: success ? Colors.green : Colors.red,
  //   textColor: Colors.white,
  //   fontSize: Get.textTheme.bodySmall?.fontSize,
  // );
}
