import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LineItem {
  TextEditingController descriptionController = TextEditingController();
  TextEditingController qtyController = TextEditingController(text: '1');
  TextEditingController rateController = TextEditingController(text: '0');

  double get amount {
    final qty = double.tryParse(qtyController.text) ?? 0;
    final rate = double.tryParse(rateController.text) ?? 0;
    return qty * rate;
  }

  void dispose() {
    descriptionController.dispose();
    qtyController.dispose();
    rateController.dispose();
  }
}

class CustomerConvertController extends GetxController {
  // Selected values
  var conversionType = "Send Document".obs;
  var salesDocument = "Proposal".obs;
  var communicationVia = "Whatsapp".obs;
  var paymentType = "With Payment".obs;
  var paymentMode = "Cash In Hand".obs;

  var minPaymentAmount = "".obs;

  // Available items (optional)
  List<String> salesDocList = ["Proposal", "Quotation", "Brochure"];

  final proposalTitleController = TextEditingController();
  final taxController = TextEditingController(text: '18');
  final termsController = TextEditingController(
    text: 'Payment is due within 15 days of invoice date.',
  );

  final lineItems = <LineItem>[LineItem()].obs;
  final currentStep = 0.obs;

  double get subtotal {
    return lineItems.fold(0, (sum, item) => sum + item.amount);
  }

  double get taxAmount {
    final taxPercent = double.tryParse(taxController.text) ?? 0;
    return subtotal * (taxPercent / 100);
  }

  double get total {
    return subtotal + taxAmount;
  }

  void addLineItem() {
    lineItems.add(LineItem());
  }

  void removeLineItem(int index) {
    if (lineItems.length > 1) {
      lineItems[index].dispose();
      lineItems.removeAt(index);
    }
  }

  void updateCalculation() {
    lineItems.refresh();
  }

  @override
  void onClose() {
    proposalTitleController.dispose();
    taxController.dispose();
    termsController.dispose();
    for (var item in lineItems) {
      item.dispose();
    }
    super.onClose();
  }
}
