import 'dart:convert';

import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:itracker/src/app/controller/app_controller.dart';
import 'package:itracker/src/app/modules/lead/model/dropdownmodel.dart';
import 'package:itracker/src/app/utils/apiconstants.dart';

class LocationRepository {
  final appData = Get.find<AppDataController>();

  Future<List<LocationModel>> getCountries() async {
    final url = "${appData.baseUrl}${ApiConstants.countryList}";
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final body = jsonDecode(response.body);
      final List list = body['data'];
      return list.map((e) => LocationModel.fromJson(e)).toList();
    } else {
      throw Exception("Failed to fetch countries");
    }
  }

  Future<List<LocationModel>> getStates(String countryId) async {
    final url = "${appData.baseUrl}${ApiConstants.stateList}/$countryId";
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final body = jsonDecode(response.body);
      final List list = body['data'];
      return list.map((e) => LocationModel.fromJson(e)).toList();
    } else {
      throw Exception("Failed to fetch states");
    }
  }

  Future<List<LocationModel>> getCities(String stateId) async {
    final url = "${appData.baseUrl}${ApiConstants.cityList}/$stateId";
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final body = jsonDecode(response.body);
      final List list = body['data'];
      return list.map((e) => LocationModel.fromJson(e)).toList();
    } else {
      throw Exception("Failed to fetch cities");
    }
  }
}
