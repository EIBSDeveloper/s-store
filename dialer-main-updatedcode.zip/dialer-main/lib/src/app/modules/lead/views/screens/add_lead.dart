import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:itracker/app.dart';
import 'package:itracker/src/app/modules/lead/locationcontroller.dart';

import '../../../../../core/app_colors.dart';
import '../../../../widgets/custom_app_bar.dart';
import '../../../../widgets/input_card_style.dart';
import '../../controller/leadcontroller.dart';

class AddNewLeadScreen extends StatelessWidget {
  AddNewLeadScreen({super.key});

  final LeadController controller = Get.put(LeadController());
  final locationcontroller = Get.put(LocationController());

  Widget sectionTitle(String title, {Color? color}) => Padding(
    padding: const EdgeInsets.only(right: 10, bottom: 8.0),
    child: Text(
      title,
      style: Theme.of(navigatorKey.currentContext!).textTheme.bodyLarge!
          .copyWith(
            color: color ?? AppColors.textPrimary,
            fontWeight: FontWeight.w600,
          ),
    ),
  );

  Widget errorText(RxString error) => Obx(
    () => error.value.isEmpty
        ? const SizedBox.shrink()
        : Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              error.value,
              style: Theme.of(
                navigatorKey.currentContext!,
              ).textTheme.bodySmall!.copyWith(color: AppColors.danger),
            ),
          ),
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.background,
    appBar: CustomAppBar(
      title: Text("Add Lead", style: Theme.of(context).textTheme.titleLarge!),
    ),
    body: SafeArea(
      bottom: false,
      child: Stack(
        children: [
          Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(
                        children: [
                          InputCardStyle(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: TextFormField(
                              controller: controller.nameCtrl,
                              decoration: const InputDecoration(
                                label: LableText(" Name", isrequired: true),
                                border: InputBorder.none,
                              ),
                              validator: (value) =>
                                  value == null || value.isEmpty
                                  ? 'Required field'
                                  : null,
                            ),
                          ),
                          const SizedBox(height: 8),

                          InputCardStyle(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: TextFormField(
                              controller: controller.mobileCtrl,
                              keyboardType: TextInputType.phone,
                              inputFormatters: [
                                DigitsOnlyFormatter(),
                                FilteringTextInputFormatter
                                    .digitsOnly, // only digits
                                LengthLimitingTextInputFormatter(
                                  10,
                                ), // max 6 digits
                              ],
                              validator: (value) {
                                if (value?.isEmpty ?? true)
                                  return 'required_field'.tr;
                                if (!GetUtils.isPhoneNumber(value!)) {
                                  return 'invalid_phone'.tr;
                                }

                                if (!RegExp(r'^[6-9]\d{9}$').hasMatch(value)) {
                                  return 'mibile_number_valitation'.tr;
                                }

                                return null;
                              },
                              decoration: const InputDecoration(
                                label: LableText('Mobile No', isrequired: true),
                                border: InputBorder.none,
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),

                          InputCardStyle(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: TextFormField(
                              controller: controller.emailCtrl,
                              decoration: const InputDecoration(
                                label: LableText("Email ID "),
                                border: InputBorder.none,
                              ),
                              validator: (value) {
                                if (value?.isNotEmpty ?? false) {
                                  if (!GetUtils.isEmail(value!)) {
                                    return 'invalid_email'.tr;
                                  }
                                }
                                return null;
                              },
                            ),
                          ),
                          const SizedBox(height: 8),

                          InputCardStyle(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Obx(
                              () => DropdownButtonFormField<String>(
                                dropdownColor: AppColors.card,
                                value: controller.selectedGender.value.isEmpty
                                    ? null
                                    : controller.selectedGender.value,
                                icon: const Icon(Icons.keyboard_arrow_down),
                                items: controller.gender
                                    .map(
                                      (g) => DropdownMenuItem(
                                        value: g,
                                        child: Text(g),
                                      ),
                                    )
                                    .toList(),
                                onChanged: (value) {
                                  if (value != null) {
                                    controller.setGender(value);
                                  }
                                },
                                decoration: const InputDecoration(
                                  label: LableText(
                                    "Select Gender",
                                    isrequired: true,
                                  ),
                                  border: InputBorder.none,
                                ),
                                validator: (value) =>
                                    value == null ? 'Required field' : null,
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),

                          // Country Dropdown
                          InputCardStyle(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Obx(
                              () => DropdownButtonFormField<String>(
                                dropdownColor: AppColors.card,
                                value:
                                    locationcontroller
                                        .selectedCountry
                                        .value
                                        .isEmpty
                                    ? null
                                    : locationcontroller.selectedCountry.value,
                                icon: const Icon(Icons.keyboard_arrow_down),
                                items: locationcontroller.countries
                                    .map(
                                      (g) => DropdownMenuItem(
                                        value: g,
                                        child: Text(g),
                                      ),
                                    )
                                    .toList(),
                                onChanged: (value) {
                                  if (value != null) {
                                    locationcontroller.setCountry(value);
                                  }
                                },
                                decoration: const InputDecoration(
                                  label: LableText(
                                    "Select Country",
                                    isrequired: true,
                                  ),
                                  border: InputBorder.none,
                                ),
                                validator: (value) =>
                                    value == null ? 'Required field' : null,
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),

                          // State
                          InputCardStyle(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Obx(
                              () => DropdownButtonFormField<String>(
                                dropdownColor: AppColors.card,
                                value:
                                    locationcontroller
                                        .selectedState
                                        .value
                                        .isEmpty
                                    ? null
                                    : locationcontroller.selectedState.value,
                                icon: const Icon(Icons.keyboard_arrow_down),
                                items: locationcontroller.states
                                    .map(
                                      (g) => DropdownMenuItem(
                                        value: g,
                                        child: Text(g),
                                      ),
                                    )
                                    .toList(),
                                onChanged: (value) {
                                  if (value != null) {
                                    locationcontroller.setStateValue(value);
                                  }
                                },
                                decoration: const InputDecoration(
                                  label: LableText(
                                    "Select State",
                                    isrequired: true,
                                  ),
                                  border: InputBorder.none,
                                ),
                                validator: (value) =>
                                    value == null ? 'Required field' : null,
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),

                          //city
                          InputCardStyle(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Obx(
                              () => DropdownButtonFormField<String>(
                                dropdownColor: AppColors.card,
                                value:
                                    locationcontroller
                                        .selectedCity
                                        .value
                                        .isEmpty
                                    ? null
                                    : locationcontroller.selectedCity.value,
                                icon: const Icon(Icons.keyboard_arrow_down),
                                items: locationcontroller.cities
                                    .map(
                                      (g) => DropdownMenuItem(
                                        value: g,
                                        child: Text(g),
                                      ),
                                    )
                                    .toList(),
                                onChanged: (value) {
                                  if (value != null) {
                                    locationcontroller.setCity(value);
                                  }
                                },
                                decoration: const InputDecoration(
                                  label: LableText(
                                    "Select City",
                                    isrequired: true,
                                  ),
                                  border: InputBorder.none,
                                ),
                                validator: (value) =>
                                    value == null ? 'Required field' : null,
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),

                          //source
                          InputCardStyle(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Obx(
                              () => DropdownButtonFormField<String>(
                                dropdownColor: AppColors.card,
                                value:
                                    controller.selectedLeadSource.value.isEmpty
                                    ? null
                                    : controller.selectedLeadSource.value,
                                icon: const Icon(Icons.keyboard_arrow_down),
                                items: controller.leadSources
                                    .map(
                                      (g) => DropdownMenuItem(
                                        value: g,
                                        child: Text(g),
                                      ),
                                    )
                                    .toList(),
                                onChanged: (value) {
                                  if (value != null) {
                                    controller.setLeadSource(value);
                                  }
                                },
                                decoration: const InputDecoration(
                                  label: LableText(
                                    "Lead Source",
                                    isrequired: true,
                                  ),
                                  border: InputBorder.none,
                                ),
                                validator: (value) =>
                                    value == null ? 'Required field' : null,
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),

                          InputCardStyle(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: TextFormField(
                              controller: controller.locationUrlCtrl,
                              decoration: const InputDecoration(
                                label: LableText("Location "),
                                border: InputBorder.none,
                              ),
                              readOnly: true,
                              onTap: () {},
                            ),
                          ),
                          const SizedBox(height: 8),

                          InputCardStyle(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: TextFormField(
                              controller: controller.addressCtrl,
                              maxLines: 3,
                              decoration: const InputDecoration(
                                labelText: 'Address',
                                border: InputBorder.none,
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),

                          Row(
                            children: [
                              Expanded(
                                child: InputCardStyle(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                  ),
                                  child: Obx(
                                    () => DropdownButtonFormField<String>(
                                      dropdownColor: AppColors.card,
                                      value:
                                          controller
                                              .selectedLeadTag
                                              .value
                                              .isEmpty
                                          ? null
                                          : controller.selectedLeadTag.value,
                                      icon: const Icon(
                                        Icons.keyboard_arrow_down,
                                      ),
                                      items: controller.leadTags
                                          .map(
                                            (g) => DropdownMenuItem(
                                              value: g,
                                              child: Text(g),
                                            ),
                                          )
                                          .toList(),
                                      onChanged: (value) {
                                        if (value != null) {
                                          controller.setLeadTag(value);
                                        }
                                      },
                                      decoration: const InputDecoration(
                                        label: LableText(
                                          "Lead Tag",
                                          isrequired: false,
                                        ),
                                        border: InputBorder.none,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: InputCardStyle(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                  ),
                                  child: Obx(
                                    () => DropdownButtonFormField<String>(
                                      dropdownColor: AppColors.card,
                                      value:
                                          controller
                                              .selectedLeadType
                                              .value
                                              .isEmpty
                                          ? null
                                          : controller.selectedLeadType.value,
                                      icon: const Icon(
                                        Icons.keyboard_arrow_down,
                                      ),
                                      items: controller.leadTypes
                                          .map(
                                            (g) => DropdownMenuItem(
                                              value: g,
                                              child: Text(g),
                                            ),
                                          )
                                          .toList(),
                                      onChanged: (value) {
                                        if (value != null) {
                                          controller.setLeadType(value);
                                        }
                                      },
                                      decoration: const InputDecoration(
                                        label: LableText(
                                          "Lead Type",
                                          isrequired: false,
                                        ),
                                        border: InputBorder.none,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),

                          InputCardStyle(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: TextFormField(
                              controller: controller.descriptionCtrl,
                              maxLines: 3,
                              decoration: const InputDecoration(
                                labelText: 'Description',
                                border: InputBorder.none,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              color: AppColors.background,
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: SafeArea(
                top: false,
                child: SizedBox(
                  height: 56,
                  child: ElevatedButton(
                    onPressed: () async {
                      await controller.createLead();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 0,
                    ),
                    child: Text(
                      'Create Lead',
                      style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                        color: AppColors.card,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

class LableText extends StatelessWidget {
  const LableText(this.text, {super.key, this.isrequired = false});

  final String text;
  final bool isrequired;

  @override
  Widget build(BuildContext context) => RichText(
    text: TextSpan(
      text: text,
      style: const TextStyle(color: Colors.black),
      children: [
        if (isrequired)
          const TextSpan(
            text: " *",
            style: TextStyle(color: Colors.red, fontSize: 20),
          ),
      ],
    ),
  );
}

class DigitsOnlyFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final filtered = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');
    return TextEditingValue(
      text: filtered,
      selection: TextSelection.collapsed(offset: filtered.length),
    );
  }
}
