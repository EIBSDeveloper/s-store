import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:itracker/src/app/modules/lead/controller/customer_convert_controller.dart';
import 'package:itracker/src/app/widgets/custom_app_bar.dart';
import 'package:itracker/src/core/app_colors.dart';

import '../../../../../../app.dart';

class PreviewProposalScreen extends StatelessWidget {
  PreviewProposalScreen({super.key});

  final controller = Get.find<CustomerConvertController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: CustomAppBar(title: Text("Preview & Share")),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Review and send document to customer",
              style: Theme.of(
                context,
              ).textTheme.bodyMedium?.copyWith(color: AppColors.textSecondary),
            ),

            const SizedBox(height: 8),

            _buildStepper(context),

            const SizedBox(height: 10),

            // MAIN WHITE CARD
            Container(
              decoration: BoxDecoration(
                color: AppColors.card,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.border),
              ),
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // HEADER
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        controller.proposalTitleController.text,
                        style: Theme.of(context).textTheme.titleMedium
                            ?.copyWith(fontWeight: FontWeight.bold),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            "Date",
                            style: Theme.of(context).textTheme.bodySmall
                                ?.copyWith(color: AppColors.textSecondary),
                          ),
                          Text(
                            "26/11/2025",
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        ],
                      ),
                    ],
                  ),

                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.primary.withOpacity(.1),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      "Proposal",
                      style: Theme.of(
                        context,
                      ).textTheme.bodySmall?.copyWith(color: AppColors.primary),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // BILL TO BOX
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.background,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Bill To:",
                          style: Theme.of(context).textTheme.bodyMedium
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Michael Anderson",
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                        Text(
                          "michael.a@example.com",
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                        Text(
                          "9876543210",
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  // TABLE HEADERS
                  Row(
                    children: [
                      Expanded(
                        flex: 3,
                        child: Text(
                          "Description",
                          style: Theme.of(context).textTheme.bodySmall
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          "Qty",
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.bodySmall
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          "Rate",
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.bodySmall
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          "Amount",
                          textAlign: TextAlign.end,
                          style: Theme.of(context).textTheme.bodySmall
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 8),

                  // LINE ITEM ROWS
                  ...controller.lineItems.map((item) {
                    return Column(
                      children: [
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Expanded(
                              flex: 3,
                              child: Text(
                                item.descriptionController.text.isEmpty
                                    ? "Item"
                                    : item.descriptionController.text,
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                            ),
                            Expanded(
                              child: Text(
                                item.qtyController.text,
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Expanded(
                              child: Text(
                                "₹${item.rateController.text}",
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Expanded(
                              child: Text(
                                "₹${item.amount.toStringAsFixed(0)}",
                                textAlign: TextAlign.end,
                              ),
                            ),
                          ],
                        ),
                        const Divider(),
                      ],
                    );
                  }),

                  const SizedBox(height: 20),

                  // SUBTOTAL
                  _buildAmountRow(
                    context,
                    "Subtotal:",
                    "₹${controller.subtotal.toStringAsFixed(0)}",
                  ),
                  const SizedBox(height: 8),

                  // TAX
                  _buildAmountRow(
                    context,
                    "Tax (${controller.taxController.text}%):",
                    "₹${controller.taxAmount.toStringAsFixed(0)}",
                  ),

                  const SizedBox(height: 12),
                  const Divider(),
                  const SizedBox(height: 8),

                  // TOTAL
                  _buildAmountRow(
                    context,
                    "Total:",
                    "₹${controller.total.toStringAsFixed(0)}",
                    isBold: true,
                  ),

                  const SizedBox(height: 4),

                  GestureDetector(
                    onTap: () {},
                    child: Text(
                      "Minimum Payment: ₹200",
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppColors.primary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // TERMS
                  Text(
                    "Terms & Conditions",
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    controller.termsController.text,
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            _readyToShareBox(context),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: _borderButton(
                    title: "Cancel",
                    onTap: () => navigatorKey.currentState!.pop(),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _primaryButton(
                    title: "Share & Convert",
                    onTap: () {
                      /* Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PreviewProposalScreen(),
                        ),
                      );*/
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _borderButton({required String title, required VoidCallback onTap}) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFDBE2E6)),
          ),
          alignment: Alignment.center,
          child: Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
      );

  Widget _primaryButton({required String title, required VoidCallback onTap}) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: AppColors.primary,
            borderRadius: BorderRadius.circular(12),
          ),
          alignment: Alignment.center,
          child: const Text(
            "Share & Convert",
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
          ),
        ),
      );

  Widget _buildAmountRow(
    BuildContext context,
    String label,
    String value, {
    bool isBold = false,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
          ),
        ),
        Text(
          value,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ],
    );
  }

  Widget _buildStepper(BuildContext context) {
    return Row(
      children: [
        _step(context, completed: true, active: true, label: "Settings"),
        _line(true),
        _step(context, completed: true, active: true, label: "Create"),
        _line(true),
        _step(
          context,
          completed: false,
          active: true,
          label: "Share",
        ), // last blue active
      ],
    );
  }

  Widget _step(
    BuildContext context, {
    required bool active,
    required bool completed,
    required String label,
  }) {
    return Column(
      children: [
        Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: completed
                ? AppColors
                      .primary // completed → solid blue
                : (active
                      ? AppColors.primary.withOpacity(
                          0.2,
                        ) // active → light blue border
                      : AppColors
                            .border // inactive → grey
                            ),
            border: Border.all(
              color: active ? AppColors.primary : AppColors.border,
              width: 2,
            ),
          ),
          child: Center(
            child: completed
                ? const Icon(Icons.check, color: Colors.white, size: 18)
                : Text(
                    (label == "Share") ? "3" : "", // optional number
                    style: TextStyle(
                      color: AppColors.primary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: active ? AppColors.primary : AppColors.textSecondary,
            fontWeight: active ? FontWeight.w600 : FontWeight.normal,
          ),
        ),
      ],
    );
  }

  Widget _line(bool active) {
    return Expanded(
      child: Container(
        height: 2,
        color: active ? AppColors.primary : AppColors.border,
      ),
    );
  }

  Widget _readyToShareBox(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.primary.withOpacity(0.2)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.send, color: AppColors.primary, size: 22),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Ready to share",
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: AppColors.textPrimary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 6),
                RichText(
                  text: TextSpan(
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppColors.textPrimary,
                    ),
                    children: [
                      const TextSpan(text: "This proposal will be sent to "),
                      TextSpan(
                        text: "Michael Anderson",
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const TextSpan(text: " via "),
                      TextSpan(
                        text: "email",
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const TextSpan(
                        text: " with a minimum payment requirement of ",
                      ),
                      TextSpan(
                        text: "₹200.",
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
