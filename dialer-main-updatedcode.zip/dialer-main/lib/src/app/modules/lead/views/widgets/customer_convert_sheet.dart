import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:itracker/src/app/modules/lead/controller/customer_convert_controller.dart';
import 'package:itracker/src/app/modules/lead/views/widgets/create_proposal.dart';
import 'package:itracker/src/app/widgets/bottom_sheet_syle.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:itracker/src/core/app_style.dart';

import '../../../../../../app.dart';

class ConvertLeadToCustomer extends StatefulWidget {
  const ConvertLeadToCustomer({Key? key}) : super(key: key);

  @override
  State<ConvertLeadToCustomer> createState() => _ConvertLeadToCustomerState();
}

class _ConvertLeadToCustomerState extends State<ConvertLeadToCustomer> {
  final controller = Get.put(CustomerConvertController());
  String selectedConversionType = 'send_document';
  String selectedSalesDocument = 'Invoice';
  String selectedCommunication = 'Email';
  String selectedPaymentType = 'with_payment';
  bool isDark = Get.isDarkMode;
  @override
  Widget build(BuildContext context) {
    return BottomSheetStyle(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Title
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
            child: Text(
              'Convert Lead to Customer',
              style: Theme.of(
                context,
              ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w600),
            ),
          ),

          // Scrollable Content
          Flexible(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Configure conversion settings and payment options',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: AppColors.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 8),

                  // Lead Info Card
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.blue[50],
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Michael Anderson',
                                style: Theme.of(context).textTheme.bodyMedium
                                    ?.copyWith(fontWeight: FontWeight.w600),
                              ),
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: AppColors.success,
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                    child: Text(
                                      'Interested',
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodySmall
                                          ?.copyWith(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w500,
                                          ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: AppColors.primary,
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                    child: Text(
                                      'LinkedIn',
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodySmall
                                          ?.copyWith(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w500,
                                          ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: AppColors.textPrimary,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            '9876543210',
                            style: Theme.of(context).textTheme.bodySmall
                                ?.copyWith(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),

                  // Conversion Type
                  Row(
                    children: [
                      Text(
                        'Conversion Type',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '*',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: AppColors.danger,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),

                  _buildRadioOption(
                    value: 'send_document',
                    groupValue: selectedConversionType,
                    title: 'Send Document',
                    subtitle: 'Send proposal or invoice before conversion',
                    onChanged: (value) {
                      setState(() {
                        selectedConversionType = value!;
                      });
                    },
                  ),
                  const SizedBox(height: 8),

                  _buildRadioOption(
                    value: 'direct_convert',
                    groupValue: selectedConversionType,
                    title: 'Direct Convert',
                    subtitle: 'Convert directly without sending documents',
                    onChanged: (value) {
                      setState(() {
                        selectedConversionType = value!;
                      });
                    },
                  ),
                  const SizedBox(height: 8),

                  // Sales Document and Communication Row
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  'Sales Document',
                                  style: Theme.of(context).textTheme.bodyMedium
                                      ?.copyWith(fontWeight: FontWeight.w600),
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  '*',
                                  style: Theme.of(context).textTheme.bodyMedium
                                      ?.copyWith(color: AppColors.danger),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            _buildDropdown(
                              value: selectedSalesDocument,
                              items: const ['Invoice', 'Proposal', 'Quote'],
                              onChanged: (value) {
                                setState(() {
                                  selectedSalesDocument = value!;
                                });
                              },
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  'Communication Via',
                                  style: Theme.of(context).textTheme.bodyMedium
                                      ?.copyWith(fontWeight: FontWeight.w600),
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  '*',
                                  style: Theme.of(context).textTheme.bodyMedium
                                      ?.copyWith(color: AppColors.danger),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            _buildDropdown(
                              value: selectedCommunication,
                              items: const ['Email', 'SMS', 'WhatsApp'],
                              onChanged: (value) {
                                setState(() {
                                  selectedCommunication = value!;
                                });
                              },
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),

                  // Payment Type
                  Row(
                    children: [
                      Text(
                        'Payment Type',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '*',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: AppColors.danger,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),

                  _buildRadioOption(
                    value: 'with_payment',
                    groupValue: selectedPaymentType,
                    title: 'With Payment',
                    subtitle: 'Require payment before conversion',
                    onChanged: (value) {
                      setState(() {
                        selectedPaymentType = value!;
                      });
                    },
                  ),
                  const SizedBox(height: 8),

                  _buildRadioOption(
                    value: 'without_payment',
                    groupValue: selectedPaymentType,
                    title: 'Without Payment',
                    subtitle: 'Convert without immediate payment',
                    onChanged: (value) {
                      setState(() {
                        selectedPaymentType = value!;
                      });
                    },
                  ),
                  const SizedBox(height: 8),
                  _minPayment(isDark),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _borderButton(
                          title: "Cancel",
                          onTap: () => navigatorKey.currentState!.pop(),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _primaryButton(
                          title: "Convert Customer",
                          onTap: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) => CreateProposalScreen(),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _borderButton({required String title, required VoidCallback onTap}) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFDBE2E6)),
          ),
          alignment: Alignment.center,
          child: Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
      );

  Widget _primaryButton({required String title, required VoidCallback onTap}) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: AppColors.primary,
            borderRadius: BorderRadius.circular(12),
          ),
          alignment: Alignment.center,
          child: const Text(
            "Convert Customer",
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
          ),
        ),
      );

  Widget _minPayment(bool isDark) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      RichText(
        text: TextSpan(
          text: "Min Payment Amount ",
          style: Theme.of(
            navigatorKey.currentContext!,
          ).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
          children: const [
            TextSpan(
              text: "*",
              style: TextStyle(color: Colors.red),
            ),
          ],
        ),
      ),
      const SizedBox(height: 8),
      TextField(
        onChanged: (v) => controller.minPaymentAmount.value = v,
        keyboardType: TextInputType.number,
        style: Theme.of(navigatorKey.currentContext!).textTheme.bodySmall,
        scrollPadding: const EdgeInsets.symmetric(horizontal: 8),
        decoration: InputDecoration(
          contentPadding: const EdgeInsets.symmetric(horizontal: 8),
          hintText: "Enter Minimum Payment Amount",
          filled: true,
          fillColor: isDark ? const Color(0xFF101C22) : AppColors.background,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    ],
  );

  Widget _groupTitle(String title, {required List<Widget> children}) => Padding(
    padding: const EdgeInsets.only(top: 10),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(
            navigatorKey.currentContext!,
          ).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 3),
        if (children.length == 1) children[0] else Row(children: children),
      ],
    ),
  );
  Widget _buildRadioOption({
    required String value,
    required String groupValue,
    required String title,
    required String subtitle,
    required ValueChanged<String?> onChanged,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.card,
        border: Border.all(color: Colors.grey[300]!),
        borderRadius: BorderRadius.circular(AppStyle.borderRadiusBox),
      ),
      child: RadioListTile<String>(
        value: value,
        groupValue: groupValue,
        onChanged: onChanged,
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        title: Text(
          title,
          style: Theme.of(
            context,
          ).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w500),
        ),
        subtitle: Text(
          subtitle,
          style: Theme.of(
            context,
          ).textTheme.bodySmall?.copyWith(color: Colors.grey[600]),
        ),
      ),
    );
  }

  Widget _buildDropdown({
    required String value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        dropdownColor: AppColors.card,
        value: value,
        isExpanded: true,
        underline: const SizedBox(),
        items: items.map((String item) {
          return DropdownMenuItem<String>(
            value: item,
            child: Text(item, style: Theme.of(context).textTheme.bodyMedium),
          );
        }).toList(),
        onChanged: onChanged,
      ),
    );
  }
}
