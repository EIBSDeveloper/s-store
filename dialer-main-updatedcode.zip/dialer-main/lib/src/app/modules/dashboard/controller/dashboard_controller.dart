import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';

import '../repository/dashboardRepo.dart';

class DashboardController extends GetxController {
  final DashboardRepository repo = DashboardRepository();

  RxInt outgoing = 0.obs;
  RxInt incoming = 0.obs;
  RxInt missed = 0.obs;
  RxInt rejected = 0.obs;
  RxInt totalCalls = 0.obs;

  RxString totalDuration = "0".obs;
  RxMap<String, int> weekly = <String, int>{}.obs;

  @override
  void onInit() {
    fetchDashboardData();
    super.onInit();
  }

  Future<void> fetchDashboardData() async {
    final today = await repo.getTodaySummary();
    if (today != null) {
      totalCalls.value = today.totalCalls;
      totalDuration.value = today.totalDuration ?? "0";
    }

    final statusMap = await repo.getCallStatusCount();
    incoming.value = statusMap[1] ?? 0;
    outgoing.value = statusMap[2] ?? 0;
    missed.value = statusMap[3] ?? 0;
    rejected.value = statusMap[4] ?? 0;

    final week = await repo.getWeeklySummary();
    if (week != null) {
      weekly.value = week.weekData;
    }
  }
}
