import 'dart:math';

import 'package:flutter/material.dart';

class DonutPieChart extends StatefulWidget {
  final List<double> values;
  final List<Color> colors;
  final double strokeWidth;
  final Duration animationDuration;

  const DonutPieChart({
    super.key,
    required this.values,
    required this.colors,
    this.strokeWidth = 14,
    this.animationDuration = const Duration(seconds: 1),
  });

  @override
  State<DonutPieChart> createState() => _DonutPieChartState();
}

class _DonutPieChartState extends State<DonutPieChart>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: widget.animationDuration,
    )..forward();

    _animation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final total = widget.values.fold(0.0, (p, e) => p + e);

    return AnimatedBuilder(
      animation: _animation,
      builder: (context, _) => Transform.rotate(
        angle: _animation.value * 2 * pi, // gentle spin effect
        child: CustomPaint(
          painter: _DonutPainter(
            values: widget.values,
            colors: widget.colors,
            strokeWidth: widget.strokeWidth,
            total: total,
            progress: _animation.value, // animate sweep
          ),
        ),
      ),
    );
  }
}

class _DonutPainter extends CustomPainter {
  final List<double> values;
  final List<Color> colors;
  final double strokeWidth;
  final double total;
  final double progress;

  _DonutPainter({
    required this.values,
    required this.colors,
    required this.strokeWidth,
    required this.total,
    required this.progress,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final center = rect.center;
    final radius = min(size.width, size.height) / 2;

    final bgPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..color = Colors.grey.withOpacity(0.12);
    canvas.drawCircle(center, radius - strokeWidth / 2, bgPaint);

    double startAngle = -pi / 2;
    double drawn = 0;
    for (int i = 0; i < values.length; i++) {
      final sweep = (values[i] / (total == 0 ? 1 : total)) * 2 * pi;
      if (drawn / (2 * pi) > progress) {
        break; // stop drawing when reaching animation progress
      }

      final effectiveSweep = sweep * progress.clamp(0.0, 1.0);

      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeWidth = strokeWidth
        ..color = colors[i % colors.length];

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius - strokeWidth / 2),
        startAngle,
        effectiveSweep,
        false,
        paint,
      );

      startAngle += sweep;
      drawn += sweep;
    }

    // inner white hole
    final holePaint = Paint()..color = Colors.white;
    canvas.drawCircle(center, radius - strokeWidth - 6, holePaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
