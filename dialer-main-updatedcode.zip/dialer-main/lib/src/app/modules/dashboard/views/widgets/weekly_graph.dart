import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../../../../../core/app_colors.dart';

class SmoothCallsGraph extends StatefulWidget {
  final List<int> values;

  const SmoothCallsGraph({super.key, required this.values});

  @override
  State<SmoothCallsGraph> createState() => _SmoothCallsGraphState();
}

class _SmoothCallsGraphState extends State<SmoothCallsGraph> {
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(10),
    decoration: BoxDecoration(
      color: AppColors.card,
      borderRadius: BorderRadius.circular(16),
    ),
    child: LineChart(
      LineChartData(
        minY: 0,
        maxY: 30,
        minX: 0,
        maxX: 6,

        // Remove chart borders
        borderData: FlBorderData(show: false),

        // ✅ GRID LINES (horizontal + vertical)
        gridData: FlGridData(
          show: true,
          drawHorizontalLine: true,
          drawVerticalLine: true,
          horizontalInterval: 10,
          verticalInterval: 1,
          getDrawingHorizontalLine: (value) => FlLine(
            // color: const Color.fromARGB(255, 255, 255, 255).withAlpha(30),
            color: const Color.fromARGB(255, 134, 128, 128).withAlpha(30),
            strokeWidth: 1,
            dashArray: [4, 4],
          ),
          getDrawingVerticalLine: (value) => FlLine(
            color: const Color.fromARGB(255, 255, 255, 255).withAlpha(30),
            strokeWidth: 1,
          ),
        ),

        // ---------------- AXIS LABELS ----------------
        titlesData: FlTitlesData(
          topTitles: const AxisTitles(
            sideTitles: SideTitles(showTitles: false),
          ),
          rightTitles: const AxisTitles(
            sideTitles: SideTitles(showTitles: false),
          ),

          // ✅ LEFT Y-AXIS LABELS
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              interval: 10,
              reservedSize: 38,
              getTitlesWidget: (value, meta) {
                if (value % 5 == 0) {
                  return Text(
                    value.toInt().toString(),
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppColors.textSecondary,
                    ),
                  );
                }
                return const SizedBox.shrink();
              },
            ),
          ),

          // ✅ BOTTOM X-AXIS LABELS
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              interval: 1,
              getTitlesWidget: (value, meta) {
                const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
                if (value.toInt() >= 0 && value.toInt() < days.length) {
                  return Text(
                    days[value.toInt()],
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppColors.textSecondary,
                    ),
                  );
                }
                return const SizedBox.shrink();
              },
            ),
          ),
        ),

        // ---------------- TOUCH TOOLTIP ----------------
        lineTouchData: LineTouchData(
          enabled: true,
          touchTooltipData: LineTouchTooltipData(
            // tooltipBgColor: AppColors.danger,
            // tooltipRoundedRadius: 10,
            getTooltipItems: (spots) {
              const months = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
              return spots
                  .map(
                    (spot) => LineTooltipItem(
                      "${months[spot.x.toInt()]}\n${spot.y.toInt()} Calls",
                      const TextStyle(color: AppColors.card),
                    ),
                  )
                  .toList();
            },
          ),
        ),

        // ---------------- LINE SERIES ----------------
        lineBarsData: [
          LineChartBarData(
            spots: List.generate(
              widget.values.length,
              (i) => FlSpot(i.toDouble(), widget.values[i] + 0.0),
            ),
            isCurved: true,
            color: AppColors.danger,
            barWidth: 2,

            // Show dots on the graph
            dotData: FlDotData(
              show: true,
              getDotPainter: (spot, _, __, ___) => FlDotCirclePainter(
                radius: 4,
                color: AppColors.danger,
                strokeWidth: 1,
                strokeColor: AppColors.danger,
              ),
            ),

            // Smooth gradient fill under the line
            belowBarData: BarAreaData(
              show: true,
              gradient: LinearGradient(
                colors: [
                  AppColors.danger.withAlpha(35),
                  AppColors.danger.withAlpha(30),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
        ],
      ),
    ),
  );
}
