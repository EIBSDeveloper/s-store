class TodaySummaryModel {
  final int totalCalls;
  final String? totalDuration;

  TodaySummaryModel({required this.totalCalls, required this.totalDuration});

  factory TodaySummaryModel.fromJson(Map<String, dynamic> json) =>
      TodaySummaryModel(
        totalCalls: json['totalCalls'] ?? 0, // <-- fix key here
        totalDuration: json['totalDuration'], // <-- fix key here
      );
}

class WeeklySummaryModel {
  final Map<String, int> weekData;

  WeeklySummaryModel({required this.weekData});

  factory WeeklySummaryModel.fromJson(Map<String, dynamic> json) =>
      WeeklySummaryModel(
        weekData: {
          "Mo": (json["weekData"]?["Mo"] ?? 0),
          "Tu": (json["weekData"]?["Tu"] ?? 0),
          "We": (json["weekData"]?["We"] ?? 0),
          "Th": (json["weekData"]?["Th"] ?? 0),
          "Fr": (json["weekData"]?["Fr"] ?? 0),
          "Sa": (json["weekData"]?["Sa"] ?? 0),
          "Su": (json["weekData"]?["Su"] ?? 0),
        },
      );
}
