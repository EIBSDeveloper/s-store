import '../model/dashboardmodel.dart';

class DashboardRepository {
  Future<TodaySummaryModel?> getTodaySummary() async {
    await Future.delayed(const Duration(milliseconds: 500)); // simulate network
    final dummyJson = {"totalCalls": 42, "totalDuration": "02:45:30"};
    return TodaySummaryModel.fromJson(dummyJson);
  }

  Future<Map<int, int>> getCallStatusCount() async {
    // Dummy data
    await Future.delayed(const Duration(milliseconds: 300));
    return {
      1: 10, // Incoming
      2: 15, // Outgoing
      3: 5, // Missed
      4: 2, // Rejected
    };
  }

  Future<WeeklySummaryModel?> getWeeklySummary() async {
    // Dummy JSON
    await Future.delayed(const Duration(milliseconds: 400));
    final dummyJson = {
      "weekData": {
        "Su": 5,
        "Mo": 8,
        "Tu": 7,
        "We": 10,
        "Th": 6,
        "Fr": 4,
        "Sa": 2,
      },
    };
    return WeeklySummaryModel.fromJson(dummyJson);
  }
}
