class ProfileModel {
  final int? id;
  final String? name;
  final String? email;
  final String? profileImage;

  ProfileModel({this.id, this.name, this.email, this.profileImage});

  factory ProfileModel.fromJson(Map<String, dynamic> json) => ProfileModel(
    id: json['staff_id'], // FIXED
    name: json['name'] ?? '',
    email: json['email'] ?? '',
    profileImage: json['image'] ?? '', // CORRECT
  );
}
