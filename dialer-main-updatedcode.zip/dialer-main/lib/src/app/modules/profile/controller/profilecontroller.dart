import 'package:get/get.dart';
import 'package:itracker/src/app/modules/profile/model/profile.dart';
import 'package:itracker/src/app/modules/profile/repo/profileRepo.dart';

class ProfileController extends GetxController {
  final ProfileRepository repo = ProfileRepository();

  RxBool isLoading = false.obs;
  Rxn<ProfileModel> profile = Rxn<ProfileModel>();

  Future<void> fetchProfile() async {
    isLoading.value = true;
    try {
      profile.value = await repo.getProfileDetails();
    } finally {
      isLoading.value = false;
    }
  }
}
