import 'package:get/get.dart';
import 'package:itracker/src/app/controller/app_controller.dart';
import 'package:itracker/src/app/modules/profile/model/profile.dart';

class ProfileRepository {
  final AppDataController appData = Get.find<AppDataController>();

  Future<ProfileModel?> getProfileDetails() async {
    try {
      // Dummy JSON (replace values as needed)
      const dummyJson = {
        "data": {
          "id": 101,
          "name": "John Doe",
          "email": "johndoe@example.com",
          "mobile": "+91 9876543210",
          "department": "IT",
          "designation": "Software Engineer",
          "profile_image": "https://i.pravatar.cc/300?img=12",
        },
      };

      await Future.delayed(const Duration(milliseconds: 500)); // simulate delay

      // Convert dummy data to ProfileModel
      return ProfileModel.fromJson(dummyJson["data"]!);
    } catch (e) {
      rethrow;
    }
  }
}
