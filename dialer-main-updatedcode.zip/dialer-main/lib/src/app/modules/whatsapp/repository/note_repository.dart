import 'package:get/get.dart';
import '../../../utils/http/http_service.dart';
import '../modules/note_model.dart';

class NoteRepository {
  final HttpService httpService = Get.find();

  NoteRepository();

  Future<List<NoteModel>> getNotes({String? labelFilter}) async {
    try {
      // Hardcoded response for development
      await Future.delayed(const Duration(milliseconds: 500));

      final notes = _getHardcodedNotes();

      if (labelFilter != null && labelFilter != 'All') {
        return notes.where((note) => note.label == labelFilter).toList();
      }

      return notes;
    } catch (e) {
      throw Exception('Failed to fetch notes: $e');
    }
  }

  Future<NoteModel> createNote(NoteModel note) async {
    try {
      // Hardcoded response for development
      await Future.delayed(const Duration(milliseconds: 300));

      final newNote = note.copyWith(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      return newNote;
    } catch (e) {
      throw Exception('Failed to create note: $e');
    }
  }

  Future<NoteModel> updateNote(NoteModel note) async {
    try {
      // Hardcoded response for development
      await Future.delayed(const Duration(milliseconds: 300));

      final updatedNote = note.copyWith(updatedAt: DateTime.now());
      return updatedNote;
    } catch (e) {
      throw Exception('Failed to update note: $e');
    }
  }

  Future<bool> deleteNote(String noteId) async {
    try {
      // Hardcoded response for development
      await Future.delayed(const Duration(milliseconds: 200));
      return true;
    } catch (e) {
      throw Exception('Failed to delete note: $e');
    }
  }

  Future<List<NoteFilter>> getAvailableLabels() async {
    try {
      // Hardcoded labels for development
      await Future.delayed(const Duration(milliseconds: 100));

      return [
        NoteFilter(label: 'All'),
        NoteFilter(label: 'Welcome'),
        NoteFilter(label: 'Onboard'),

        NoteFilter(label: 'Projects'),
        NoteFilter(label: 'Follows'),
        NoteFilter(label: 'Goals'),
        NoteFilter(label: 'Personal'),
      ];
    } catch (e) {
      throw Exception('Failed to fetch labels: $e');
    }
  }

  // Helper method for hardcoded notes data
  List<NoteModel> _getHardcodedNotes() {
    final now = DateTime.now();
    return [
      NoteModel(
        id: '1',
        title: 'Welcome Message',
        content: 'Welcome [UserName]! We\'re glad to have you heret',
        label: 'Welcome',
        createdAt: now.subtract(const Duration(hours: 2)),
        updatedAt: now.subtract(const Duration(hours: 2)),
      ),
      NoteModel(
        id: '2',
        title: 'Onboard',
        content:
            'Hi [UserName], let\'s get started! Follow these steps to set up your account and explore',
        label: 'Onboard',
        createdAt: now.subtract(const Duration(days: 1)),
        updatedAt: now.subtract(const Duration(days: 1)),
      ),
    ];
  }
}
