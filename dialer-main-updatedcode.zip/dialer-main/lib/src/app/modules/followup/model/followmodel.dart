class FollowModel {
  final int followupId;
  final int leadId;
  final String leadName;
  final String leadMobile;
  final String appointmentDate;
  final String appointmentTime;
  final String? demoType;
  final String followUpReason;
  final int progressed;
  final String? replayMessage;
  final String? appScore;
  final int status;
  final String createdAt;

  FollowModel({
    required this.followupId,
    required this.leadId,
    required this.leadName,
    required this.leadMobile,
    required this.appointmentDate,
    required this.appointmentTime,
    this.demoType,
    required this.followUpReason,
    required this.progressed,
    this.replayMessage,
    this.appScore,
    required this.status,
    required this.createdAt,
  });

  factory FollowModel.fromJson(Map<String, dynamic> json) => FollowModel(
      followupId: json["followup_id"] ?? 0,
      leadId: json["lead_id"] ?? 0,
      leadName: json["lead_name"] ?? "",
      leadMobile: json["lead_mobile"]?.toString() ?? "",
      appointmentDate: json["appointment_date"] ?? "",
      appointmentTime: json["appointment_time"] ?? "",
      demoType: json["demo_type"],
      followUpReason: json["follow_up_reason"] ?? "",
      progressed: json["progressed"] ?? 0,
      replayMessage: json["replay_message"],
      appScore: json["app_score"],
      status: json["status"] ?? 0,
      createdAt: json["created_at"] ?? "",
    );
}
