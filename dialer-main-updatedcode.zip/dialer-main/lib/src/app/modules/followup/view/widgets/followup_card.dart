import 'package:flutter/material.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:intl/intl.dart';
import 'package:itracker/src/app/modules/followup/controller/followup_controller.dart';
import 'package:itracker/src/app/modules/followup/view/widgets/reason_dialog.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:itracker/src/core/app_style.dart';

class FollowUpCard extends StatelessWidget {
  final int followupId;
  final String name;
  final String task;
  final String time;
  final String date;
  final int progressed; // 0 = pending, 1 = completed
  final FollowUpController controller;

  const FollowUpCard({
    super.key,
    required this.name,
    required this.task,
    required this.time,
    required this.date,
    required this.controller,
    required this.followupId,
    this.progressed = 0,
  });

  @override
  Widget build(BuildContext context) {
    bool isDark = Theme.of(context).brightness == Brightness.dark;

    String formattedDate = "-";
    try {
      final datePart = date.split(' ').first;
      final dt = DateTime.parse(datePart);
      formattedDate = DateFormat('dd MM yyyy').format(dt);
    } catch (e) {
      formattedDate = date; // fallback
    }

    Color progressColor = progressed == 0 ? Colors.orange : Colors.green;

    return Container(
      decoration: AppStyle.decoration,
      padding: const EdgeInsets.all(10),
      child: Column(
        children: [
          Row(
            children: [
              const SizedBox(width: 5),
              Container(
                width: 6,
                height: 60,
                decoration: BoxDecoration(
                  color: progressColor,
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: isDark
                            ? AppColors.textLight
                            : AppColors.textPrimary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      task,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: isDark
                            ? AppColors.textSecondary
                            : AppColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        if (time.isNotEmpty) ...[
                          Row(
                            children: [
                              Icon(
                                Icons.schedule,
                                size: AppStyle.iconSize2,
                                color: AppColors.primary,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                time,
                                style: Theme.of(context).textTheme.bodySmall
                                    ?.copyWith(color: AppColors.textPrimary),
                              ),
                            ],
                          ),
                          const SizedBox(width: 16),
                        ],
                        Row(
                          children: [
                            Icon(
                              Icons.calendar_today,
                              size: AppStyle.iconSize2,
                              color: AppColors.primary,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              formattedDate,
                              style: Theme.of(context).textTheme.bodySmall
                                  ?.copyWith(color: AppColors.textPrimary),
                            ),

                            /*QuickAlert.show(
                  context: context,
                  type: QuickAlertType.confirm,
                  text: 'The reminder is completed.',
                  confirmBtnText: 'Yes',
                  cancelBtnText: 'No',
                  confirmBtnColor: AppColors.primary,
                  headerBackgroundColor: AppColors.primary,
                  borderRadius: 10.0,
                );*/
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                height: 40,
                width: 40,
                decoration: BoxDecoration(
                  color: AppColors.primary.withAlpha(20),
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.primary.withAlpha(100)),
                ),
                child: Icon(
                  Icons.call,
                  color: AppColors.primary,
                  size: AppStyle.iconSize,
                ),
              ),
            ],
          ),
          // Mark as Done button
          Container(
            width: double.infinity,
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.vertical(
                bottom: Radius.circular(AppStyle.borderRadiusBox),
              ),
            ),
            child: ElevatedButton(
              onPressed: progressed == 1
                  ? null // 🔒 disable button
                  : () {
                      showDialog(
                        context: context,
                        builder: (context) {
                          return ReasonDialog(
                            controller: controller.reasonCtrl,
                            onConfirm: () {
                              controller.markAsDone(followupId);
                              controller.fetchFollowups();
                            },
                          );
                        },
                      );
                    },

              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary10(0.1),
                elevation: 0,
                foregroundColor: AppColors.primary,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppStyle.borderRadiusBox),
                ),
              ),
              child: Obx(() {
                final isLoading = controller.loadingMap[followupId] ?? false;

                if (progressed == 1) {
                  return const Text(
                    "Completed",
                    style: TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.bold,
                    ),
                  );
                }

                return isLoading
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Text("Mark as Done");
              }),
            ),
          ),
        ],
      ),
    );
  }
}
