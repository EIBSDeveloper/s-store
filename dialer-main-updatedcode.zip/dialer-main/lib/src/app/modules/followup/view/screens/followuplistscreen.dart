import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:itracker/src/app/modules/followup/controller/followup_controller.dart';
import 'package:itracker/src/app/modules/followup/view/widgets/followup_card.dart';
import 'package:itracker/src/app/widgets/appsearch_bar.dart';

import '../../../../../../app.dart';
import '../../../../../../core/models/call_log_entry.dart';
import '../../../../../core/app_colors.dart';
import '../../../../../core/app_style.dart';

class FollowUpsScreen extends GetView<FollowUpController> {
  const FollowUpsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const AppSearchBar(),
          const SizedBox(height: 8),
          _filterChips(),

          Expanded(
            child: RefreshIndicator(
              onRefresh: () async {
                await controller.fetchFollowups();
              },
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    minHeight: MediaQuery.of(context).size.height - 100,
                  ),
                  child: Obx(() {
                    if (controller.isfollowLoading.value) {
                      return const Center(
                        child: Padding(
                          padding: EdgeInsets.only(top: 40),
                          child: CircularProgressIndicator(),
                        ),
                      );
                    }

                    if (controller.followups.isEmpty) {
                      return const Padding(
                        padding: EdgeInsets.all(20),
                        child: Text("No followups found"),
                      );
                    }

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: controller.followups.entries.map((entry) {
                        final date = entry.key;
                        final list = entry.value;

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              date,
                              style: Theme.of(context).textTheme.bodyMedium
                                  ?.copyWith(
                                    color: AppColors.textSecondary,
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
                            const SizedBox(height: 8),
                            Column(
                              children: list
                                  .map(
                                    (f) => Padding(
                                      padding: const EdgeInsets.only(
                                        bottom: 10,
                                      ),
                                      child: FollowUpCard(
                                        name: f.leadName ?? "-",
                                        task: f.followUpReason ?? "-",
                                        time: f.appointmentTime ?? "",
                                        date: f.appointmentDate ?? "",
                                        progressed: f.progressed ?? 0,
                                        controller: controller,
                                        followupId: f.followupId,
                                      ),
                                    ),
                                  )
                                  .toList(),
                            ),
                            const SizedBox(height: 16),
                          ],
                        );
                      }).toList(),
                    );
                  }),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _filterChips() => SizedBox(
    height: 43,
    child: ListView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.only(bottom: 8, right: 10, left: 10),
      children: [
        _chip("All", CallType.all, AppColors.primary, 30),
        _chip("Today", CallType.all, AppColors.primary, 20),
        _chip("Yeasterday", CallType.all, AppColors.primary, 20),
        _chip("Pending", CallType.all, AppColors.primary, 20),
        _chip("Completed", CallType.all, AppColors.secondary, 10),
      ],
    ),
  );

  Widget _chip(
    String label,
    CallType type,
    Color color,
    int count, [
    IconData? icon,
  ]) {
    final theme = Theme.of(navigatorKey.currentContext!).textTheme;
    final bool active = ("pending" == label);
    return GestureDetector(
      // onTap: () => controller.changeFilter(type),
      child: Container(
        margin: const EdgeInsets.only(right: 10),
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: AppStyle.decoration.copyWith(
          color: active ? AppColors.primary : AppColors.card,
          borderRadius: BorderRadius.circular(AppStyle.borderRadiusClip),
        ),
        child: Row(
          children: [
            if (icon != null)
              Icon(icon, color: active ? Colors.white : color, size: 18),
            if (icon != null) const SizedBox(width: 6),
            Text(
              label,
              style: theme.bodyMedium?.copyWith(
                color: active ? Colors.white : AppColors.textPrimary,
              ),
            ),
            // const SizedBox(width: 2),
            // Text(
            //   "($count)",
            //   style: theme.bodyMedium?.copyWith(
            //     color: active ? Colors.white : AppColors.textPrimary,
            //   ),
            // ),
          ],
        ),
      ),
    );
  }
}
