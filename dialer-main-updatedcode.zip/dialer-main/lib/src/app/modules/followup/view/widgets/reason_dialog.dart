import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:itracker/src/app/widgets/input_card_style.dart';
import 'package:itracker/src/app/widgets/labeltext.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:itracker/src/core/app_style.dart';

class ReasonDialog extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onConfirm;

  const ReasonDialog({
    super.key,
    required this.controller,
    required this.onConfirm,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: AppColors.background,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppStyle.borderRadiusBox),
      ),
      title: Center(child: const Text("Mark as Done")),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          InputCardStyle(
            child: TextFormField(
              controller: controller,
              maxLines: 3,
              decoration: InputDecoration(
                label: LableText('Reason'.tr, isrequired: true),
                border: InputBorder.none,
              ),
              inputFormatters: [LengthLimitingTextInputFormatter(100)],
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text("Cancel"),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primary,
            foregroundColor: Colors.white,
          ),
          onPressed: () {
            if (controller.text.trim().isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  backgroundColor: AppColors.danger,
                  content: Text(
                    "Reason is required",
                    style: Theme.of(
                      context,
                    ).textTheme.bodyLarge?.copyWith(color: AppColors.card),
                  ),
                ),
              );
              return;
            }
            Navigator.pop(context);
            onConfirm();
          },
          child: const Text("Yes"),
        ),
      ],
    );
  }
}
