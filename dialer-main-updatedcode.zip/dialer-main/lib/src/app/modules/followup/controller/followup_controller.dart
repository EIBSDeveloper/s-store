import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:itracker/src/app/controller/app_controller.dart';
import 'package:itracker/src/app/modules/callLogs/model/model/reminderpopupmodel.dart';
import 'package:itracker/src/app/modules/followup/model/followmodel.dart';

import '../../../../../../app.dart';
import '../../callLogs/views/widgets/add_follow_up_bottom_sheet.dart';
import '../repository/followup_repository.dart';

class FollowUpController extends GetxController {
  final FollowUpRepository _repository = FollowUpRepository();
  final appData = Get.find<AppDataController>();

  TextEditingController reasonCtrl = TextEditingController();

  Rx<ReminderPopupModel?> reminderData = Rx<ReminderPopupModel?>(null);
  RxMap<String, List<FollowModel>> followups =
      <String, List<FollowModel>>{}.obs;

  var selectedTab = 'Followups'.obs;
  var selectedWhenOption = ''.obs;
  var selectedDateOption = ''.obs;
  var selectedTimeOption = ''.obs;
  Rx<DateTime?> selectedCustomDate = Rx<DateTime?>(null);
  Rx<TimeOfDay?> selectedCustomTime = Rx<TimeOfDay?>(null);
  var noteDescription = ''.obs;

  RxBool isReminderLoading = false.obs;
  RxBool isfollowLoading = false.obs;
  RxMap<int, bool> loadingMap = <int, bool>{}.obs;

  @override
  void onInit() {
    fetchFollowups();
    super.onInit();
  }

  Future<void> fetchReminder(int id) async {
    try {
      isReminderLoading.value = true;
      final data = await _repository.getReminderPopup();
      reminderData.value = data;
    } catch (e) {
      Get.snackbar("Error", e.toString());
    } finally {
      isReminderLoading.value = false;
    }
  }

  Future<void> submitReminder(int id) async {
    final ctx = navigatorKey.currentContext;
    if (ctx == null) return;

    try {
      final popup = await _repository.getReminderPopup();
      if (popup == null) return;

      DateTime scheduledTime;
      if (selectedWhenOption.value == 'Custom' &&
          selectedCustomDate.value != null &&
          selectedCustomTime.value != null) {
        final d = selectedCustomDate.value!;
        final t = selectedCustomTime.value!;
        scheduledTime = DateTime(d.year, d.month, d.day, t.hour, t.minute);
      } else {
        // Use presets
        switch (selectedWhenOption.value) {
          case "2 sec":
            scheduledTime = DateTime.now().add(const Duration(seconds: 2));
            break;
          case "15 min":
            scheduledTime = DateTime.now().add(const Duration(minutes: 15));
            break;
          case "30 min":
            scheduledTime = DateTime.now().add(const Duration(minutes: 30));
            break;
          case "1 hour":
            scheduledTime = DateTime.now().add(const Duration(hours: 1));
            break;
          case "2 hours":
            scheduledTime = DateTime.now().add(const Duration(hours: 2));
            break;
          default:
            scheduledTime = DateTime.now();
        }
      }

      InAppReminderDialog.schedule(ctx, scheduledTime, popup);
    } catch (e) {
      Get.snackbar("Error", e.toString());
    }
  }

  Future<void> submitFollowup(int leadId) async {
    final staffId = appData.roleId.value;

    DateTime appointmentDateTime;

    if (selectedWhenOption.value == 'Custom' &&
        selectedCustomDate.value != null &&
        selectedCustomTime.value != null) {
      final d = selectedCustomDate.value!;
      final t = selectedCustomTime.value!;
      appointmentDateTime = DateTime(d.year, d.month, d.day, t.hour, t.minute);
    } else {
      switch (selectedWhenOption.value) {
        case '2 sec':
          appointmentDateTime = DateTime.now().add(const Duration(seconds: 2));
          break;
        case '15 min':
          appointmentDateTime = DateTime.now().add(const Duration(minutes: 15));
          break;
        case '30 min':
          appointmentDateTime = DateTime.now().add(const Duration(minutes: 30));
          break;
        case '1 hour':
          appointmentDateTime = DateTime.now().add(const Duration(hours: 1));
          break;
        case '2 hours':
          appointmentDateTime = DateTime.now().add(const Duration(hours: 2));
          break;
        default:
          appointmentDateTime = DateTime.now();
      }
    }

    final appointmentDate = DateFormat(
      'yyyy-MM-dd',
    ).format(appointmentDateTime);
    final appointmentTime = DateFormat('HH:mm:ss').format(appointmentDateTime);

    final success = await _repository.addFollowUp(
      staffId: staffId,
      leadId: leadId,
      appointmentDate: appointmentDate,
      appointmentTime: appointmentTime,
      followUpReason: noteDescription.value,
    );

    if (success) {
      navigatorKey.currentState!.pop();
      fetchFollowups();
      submitReminder(leadId);
      Get.snackbar("Success", "Follow-up added successfully");
    } else {
      Get.snackbar("Error", "Failed to add follow-up");
    }
  }

  @override
  void onClose() {
    reasonCtrl.dispose();
    super.onClose();
  }

  Future<void> fetchFollowups() async {
    isfollowLoading.value = true;
    final data = await _repository.getFollowupList();
    followups.value = data;
    isfollowLoading.value = false;
  }

  Future<void> markAsDone(int followupId) async {
    final reason = reasonCtrl?.text.trim() ?? '';
    if (reason.isEmpty) return;

    int staffId = appData.roleId?.value ?? 0; // default to 0 if null

    loadingMap[followupId] = true;
    loadingMap.refresh();

    bool success = false;
    if (_repository != null) {
      success = await _repository.closeFollowup(followupId, reason, staffId);
    }

    loadingMap[followupId] = false;
    loadingMap.refresh();

    if (success) {
      Get.snackbar(
        "Success",
        "Follow-up marked as done",
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );
    } else {
      Get.snackbar(
        "Error",
        "Failed to update follow-up",
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }

    reasonCtrl?.clear();
  }
}
