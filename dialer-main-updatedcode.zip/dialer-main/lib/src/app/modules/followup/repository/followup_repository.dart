/*
import 'dart:convert';

import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:itracker/src/app/controller/app_controller.dart';
import 'package:itracker/src/app/modules/callLogs/model/model/reminderpopupmodel.dart';
import 'package:itracker/src/app/modules/followup/model/followmodel.dart';
import 'package:itracker/src/app/utils/apiconstants.dart';

class FollowUpRepository {
  final appData = Get.find<AppDataController>();

  Future<ReminderPopupModel?> getReminderPopup() async {
    int id = appData.roleId.value;
    final url = "${appData.baseUrl}${ApiConstants.reminderPopup}/$id";
    final res = await http.get(Uri.parse(url));

    if (res.statusCode == 200) {
      final jsonResponse = jsonDecode(res.body);

      if (jsonResponse['status'] == true && jsonResponse['data'] != null) {
        return ReminderPopupModel.fromJson(jsonResponse['data']);
      } else {
        return null;
      }
    } else {
      return null;
    }
  }

  Future<Map<String, List<FollowModel>>> getFollowupList() async {
    int id = appData.roleId.value;
    final url = Uri.parse("${appData.baseUrl}${ApiConstants.followuplist}/$id");

    final response = await http.get(url);

    if (response.statusCode == 200) {
      final jsonRes = jsonDecode(response.body);

      if (jsonRes["status"] == true && jsonRes["data"] != null) {
        Map<String, List<FollowModel>> result = {};

        jsonRes["data"].forEach((date, list) {
          result[date] = (list as List)
              .map((item) => FollowModel.fromJson(item))
              .toList();
        });

        return result;
      }
    }

    return {};
  }

  Future<bool> addFollowUp({
    required int staffId,
    required int leadId,
    required String appointmentDate,
    required String appointmentTime,
    required String followUpReason,
  }) async {
    final url = Uri.parse("${appData.baseUrl}${ApiConstants.followUpAdd}");

    final body = {
      "staff_id": staffId,
      "lead_id": leadId,
      "appointment_date": appointmentDate,
      "appointment_time": appointmentTime,
      "follow_up_reason": followUpReason,
    };

    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: jsonEncode(body),
    );

    if (response.statusCode == 200) {
      final jsonRes = jsonDecode(response.body);
      return jsonRes["status"] == true;
    } else {
      return false;
    }
  }

  Future<bool> closeFollowup(int id, String message, int staffId) async {
    final url = Uri.parse(
      "${appData.baseUrl}${ApiConstants.reminderclose}/$id",
    );

    final body = {
      "replay_message": message,
      "progressed": 1, // ✔ update followup as completed
      "staff_id": staffId, // ✔ send staff id
    };

    final res = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: jsonEncode(body),
    );

    if (res.statusCode == 200) {
      final jsonRes = jsonDecode(res.body);
      return jsonRes["success"] == true;
    }

    return false;
  }
}
*/
import 'package:dio/dio.dart';
import 'package:get/get.dart';
import 'package:itracker/src/app/controller/app_controller.dart';
import 'package:itracker/src/app/modules/callLogs/model/model/reminderpopupmodel.dart';
import 'package:itracker/src/app/modules/followup/model/followmodel.dart';

class FollowUpRepository {
  final appData = Get.find<AppDataController>();
  final Dio _dio = Dio();

  /// Get Reminder Popup - Dummy Data
  Future<ReminderPopupModel?> getReminderPopup() async {
    await Future.delayed(const Duration(milliseconds: 500)); // simulate network

    // Corrected dummy JSON matching ReminderPopupModel
    final dummyJson = {
      "id": 1,
      "name": "John Doe",
      "mobile": "9876543210",
      "notes": "Follow-up scheduled today at 10:00 AM",
    };

    return ReminderPopupModel.fromJson(dummyJson);
  }

  /// Get Follow-up List - Dummy Data
  Future<Map<String, List<FollowModel>>> getFollowupList() async {
    await Future.delayed(const Duration(milliseconds: 500)); // simulate network

    // Corrected dummy JSON with snake_case keys
    final dummyJson = {
      "06-12-2025": [
        {
          "followup_id": 1,
          "lead_id": 101,
          "lead_name": "John Doe",
          "lead_mobile": "9876543210",
          "appointment_date": "2025-12-06",
          "appointment_time": "10:00 AM",
          "follow_up_reason": "Call about product",
          "progressed": 0,
          "status": 1,
          "created_at": "2025-12-05 09:00:00",
        },
        {
          "followup_id": 2,
          "lead_id": 102,
          "lead_name": "Jane Smith",
          "lead_mobile": "9876543211",
          "appointment_date": "2025-12-06",
          "appointment_time": "11:00 AM",
          "follow_up_reason": "Demo follow-up",
          "progressed": 0,
          "status": 1,
          "created_at": "2025-12-05 10:00:00",
        },
      ],
      "05-12-2025": [
        {
          "followup_id": 3,
          "lead_id": 103,
          "lead_name": "Alice Johnson",
          "lead_mobile": "9876543212",
          "appointment_date": "2025-12-05",
          "appointment_time": "02:00 PM",
          "follow_up_reason": "Send proposal",
          "progressed": 0,
          "status": 1,
          "created_at": "2025-12-06 14:00:00",
        },
      ],
      "04-12-2025": [
        {
          "followup_id": 4,
          "lead_id": 105,
          "lead_name": "Johnson",
          "lead_mobile": "9876543212",
          "appointment_date": "2025-12-04",
          "appointment_time": "02:00 PM",
          "follow_up_reason": "Send proposal",
          "progressed": 0,
          "status": 1,
          "created_at": "2025-12-06 14:00:00",
        },
        {
          "followup_id": 5,
          "lead_id": 106,
          "lead_name": "Smith",
          "lead_mobile": "9876543212",
          "appointment_date": "2025-12-04",
          "appointment_time": "02:00 PM",
          "follow_up_reason": "Send proposal",
          "progressed": 0,
          "status": 1,
          "created_at": "2025-12-06 14:00:00",
        },
      ],
    };

    Map<String, List<FollowModel>> result = {};
    dummyJson.forEach((date, list) {
      result[date] = (list as List)
          .map((item) => FollowModel.fromJson(item))
          .toList();
    });

    return result;
  }

  /// Add Follow-up - Dummy Response
  Future<bool> addFollowUp({
    required int staffId,
    required int leadId,
    required String appointmentDate,
    required String appointmentTime,
    required String followUpReason,
  }) async {
    await Future.delayed(const Duration(milliseconds: 300)); // simulate network
    return true; // always return success
  }

  /// Close Follow-up - Dummy Response
  Future<bool> closeFollowup(int id, String message, int staffId) async {
    await Future.delayed(const Duration(milliseconds: 300)); // simulate network
    return true; // always return success
  }
}
