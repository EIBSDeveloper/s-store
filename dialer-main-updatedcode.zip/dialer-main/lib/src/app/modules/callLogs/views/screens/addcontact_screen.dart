import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:itracker/src/app/modules/auth/loginscreen.dart';
import 'package:itracker/src/app/modules/callLogs/controller/call_logcontroller.dart';
import 'package:itracker/src/app/widgets/custom_app_bar.dart';
import 'package:itracker/src/app/widgets/input_card_style.dart';
import 'package:itracker/src/core/app_colors.dart';

class AddContactScreen extends GetView<CallLogsController> {
  final String phoneNumber;
  AddContactScreen({super.key, required this.phoneNumber});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    controller.phone.text = phoneNumber;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: CustomAppBar(title: Text("Add New Contact")),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(22),
        child: Form(
          key: controller.formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Fill in the details to add a new contact to your directory.",
                style: theme.textTheme.bodySmall,
              ),

              const SizedBox(height: 20),

              // NAME
              InputCardStyle(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: TextFormField(
                  controller: controller.name,
                  decoration: const InputDecoration(
                    label: LableText(" Name", isrequired: true),
                    border: InputBorder.none,
                  ),
                  validator: (value) =>
                      value == null || value.isEmpty ? 'Required field' : null,
                ),
              ),
              const SizedBox(height: 10),

              // PHONE
              InputCardStyle(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: TextFormField(
                  controller: controller.phone,
                  keyboardType: TextInputType.phone,
                  readOnly: true, // prevent editing
                  inputFormatters: [
                    DigitsOnlyFormatter(),
                    FilteringTextInputFormatter.digitsOnly, // only digits
                    LengthLimitingTextInputFormatter(10), // max 6 digits
                  ],
                  decoration: const InputDecoration(
                    label: LableText(" Mobile Number", isrequired: true),
                    border: InputBorder.none,
                  ),
                  validator: (value) =>
                      value == null || value.isEmpty ? 'Required field' : null,
                ),
              ),
              const SizedBox(height: 10),

              // EMAIL
              InputCardStyle(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: TextFormField(
                  controller: controller.email,
                  decoration: const InputDecoration(
                    label: LableText(" Email", isrequired: true),
                    border: InputBorder.none,
                  ),
                  validator: (value) =>
                      value == null || value.isEmpty ? 'Required field' : null,
                ),
              ),
              const SizedBox(height: 10),

              // COMPANY
              InputCardStyle(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: TextFormField(
                  controller: controller.company,
                  decoration: const InputDecoration(
                    label: LableText(" Company", isrequired: false),
                    border: InputBorder.none,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              // ROLE
              InputCardStyle(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: TextFormField(
                  controller: controller.role,
                  decoration: const InputDecoration(
                    label: LableText(" Role/Position", isrequired: false),
                    border: InputBorder.none,
                  ),
                ),
              ),
              const SizedBox(height: 10),

              // NOTES
              InputCardStyle(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: TextFormField(
                  controller: controller.notes,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'Notes',
                    border: InputBorder.none,
                  ),
                ),
              ),
              const SizedBox(height: 25),

              // BUTTONS
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.card,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 22,
                        vertical: 12,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(6),
                      ),
                    ),
                    onPressed: () {},
                    child: Text(
                      "Cancel",
                      style: theme.textTheme.bodyMedium!.copyWith(
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),

                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 22,
                        vertical: 12,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(6),
                      ),
                    ),
                    onPressed: controller.submit,
                    child: Text(
                      "Add Contact",
                      style: theme.textTheme.bodyMedium!.copyWith(
                        color: AppColors.card,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
