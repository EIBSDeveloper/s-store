import 'package:flutter/material.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:intl/intl.dart';
import 'package:itracker/src/app/modules/callLogs/views/widgets/voice_message_card.dart';
import 'package:itracker/src/app/modules/lead/views/widgets/customer_convert_sheet.dart';

import '../../../../../../app.dart';
import '../../../../../../bottom_sheet.dart';
import '../../../../../core/app_colors.dart';
import '../../../../../core/app_style.dart';
import '../../../../controller/app_controller.dart';
import '../../../../widgets/action_button.dart';
import '../../../../widgets/widget_gap.dart';
import '../../../payment_tracker/controller/customercontroller.dart';
import '../../../test/view/screens/template_bottom_sheet.dart';
import '../../controller/call_log_detailscontroller.dart';
import '../widgets/add_follow_up_bottom_sheet.dart';
import '../widgets/agent_selection_bottom_sheet.dart';
import '../widgets/feedback_message_card.dart';

class CallDetailsScreen extends GetView<CallDetailsController> {
  CallDetailsScreen({super.key});
  final AppDataController appDeta = Get.find();

  Future<void> convertCustomer() async {
    final selectedTemplate = await openButtomsheet(ConvertLeadToCustomer());
    //final selectedTemplate = await openButtomsheet(ConvertToCustomerSheet());
    if (selectedTemplate != null) {
      // Handle the selected template

      // You can use the template message, send it, etc.
    }
  }

  Map<String, String> convertedChips = {};
  @override
  Widget build(BuildContext context) {
    final data = controller.contact;
    final theme = Theme.of(context).textTheme;

    final bg = AppColors.background;
    final cardBg = AppColors.card;

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _topAppBar(theme),
              Column(
                children: [
                  _contactCard(context, data, theme),
                  const WidgetGap(),
                  _callMetaCard(data, theme),
                  const WidgetGap(),
                  _notesCard(data, theme),
                  // const SizedBox(height: 16),
                  // _categoriesCard(data, theme),
                ],
              ),
              const WidgetGap(),
              // Segmented Buttons
              Obx(() {
                final sel = controller.selectedTab.value;
                return Container(
                  padding: const EdgeInsets.all(4),
                  decoration: AppStyle.decoration.copyWith(
                    color: Colors.grey.withAlpha(50),
                    boxShadow: [],
                  ),
                  child: Row(
                    children: [
                      _segmentButton('Activity log', 0, sel == 0, controller),
                      _segmentButton('Calls', 1, sel == 1, controller),

                      _segmentButton('Folloups', 2, sel == 2, controller),

                      // if (appDeta.roleId.value == 2)
                      //   _segmentButton(
                      //     'Payments',
                      //     2,
                      //     sel == 2,
                      //     controller,
                      //     isDark,
                      //   ),
                      // if (appDeta.roleId.value == 2)
                      //   _segmentButton(
                      //     'Proposals',
                      //     3,
                      //     sel == 3,
                      //     controller,
                      //     isDark,
                      //   ),
                    ],
                  ),
                );
              }),

              const SizedBox(height: 8),

              // List content section — Payments list when Payments selected
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Obx(() {
                  final tab = controller.selectedTab.value;
                  if (tab == 0) {
                    if (controller.interactions.isEmpty) {
                      return _emptyBox(cardBg, theme, 'No interactions yet');
                    }

                    return Stack(
                      children: [
                        // Vertical Line
                        Positioned(
                          left: 10,
                          top: 0,
                          bottom: 0,
                          child: Container(width: 2, color: AppColors.border),
                        ),

                        // Timeline Items
                        Column(
                          children: controller.interactions.map((it) {
                            final iconColor = _colorForType(it.type);

                            return Padding(
                              padding: const EdgeInsets.only(
                                left: 0,
                                bottom: AppStyle.widgetsGap,
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // Left Icon circle
                                  SizedBox(
                                    width: 20,
                                    child: Container(
                                      decoration: const BoxDecoration(
                                        color: AppColors.background,
                                        shape: BoxShape.circle,
                                      ),
                                      child: Container(
                                        margin: const EdgeInsets.only(
                                          top: 6,
                                          bottom: 6,
                                        ),
                                        width: 20,
                                        height: 20,
                                        decoration: BoxDecoration(
                                          color: iconColor.withOpacity(0.12),
                                          shape: BoxShape.circle,
                                        ),
                                        child: Center(
                                          child: Icon(
                                            Icons.circle,
                                            color: iconColor,
                                            size: 10,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  // Card UI
                                  Expanded(
                                    child: Container(
                                      decoration: AppStyle.decoration,
                                      padding: const EdgeInsets.all(10),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          // Title
                                          Text(
                                            it.title,
                                            style: theme.bodyMedium?.copyWith(
                                              color: AppColors.textPrimary,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                          // const SizedBox(height: 6),

                                          // Date
                                          Text(
                                            _formatDateTime(it.at),
                                            style: theme.bodySmall?.copyWith(
                                              color: AppColors.textSecondary,
                                            ),
                                          ),
                                          const SizedBox(height: 5),

                                          // Body
                                          Text(
                                            it.body,
                                            textAlign: TextAlign.justify,
                                            style: theme.bodyMedium?.copyWith(
                                              color: AppColors.textSecondary,
                                              height: 1,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          }).toList(),
                        ),
                      ],
                    );
                  }

                  if (tab == 1) {
                    return const Column(
                      children: [
                        VoiceMessageCard(
                          title: 'Needs confirmation about service dates.',
                          dateTime: '3/12/25 - 2.00pm',
                          duration: '5 min',
                        ),
                        VoiceMessageCard(
                          color: AppColors.danger,
                          title: 'Needs confirmation about service dates.',
                          dateTime: '3/12/25 - 2.00pm',
                          duration: '2min',
                        ),
                        VoiceMessageCard(
                          title: 'Needs confirmation about service dates.',
                          dateTime: '3/12/25 - 2.00pm',
                          duration: '2min',
                        ),
                        VoiceMessageCard(
                          title: 'Needs confirmation about service dates.',
                          dateTime: '3/12/25 - 2.00pm',
                          duration: '2min',
                        ),
                      ],
                    );
                  }
                  /* if (tab == 1) {
                    if (controller.callLogslist.isEmpty) {
                      return _emptyBox(cardBg, theme, 'No call logs yet');
                    }

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: controller.callLogslist.entries.map((entry) {
                        final date = entry.key;
                        final logs = entry.value;

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 6),
                              child: Text(date, style: theme.titleMedium),
                            ),
                            ...logs.map(
                              (log) => VoiceMessageCard(
                                title: log.callerName,
                                duration: log.callDuration,
                                dateTime:
                                    "${log.callStartDate} ${log.callStartTime}",
                              ),
                            ),
                            const SizedBox(height: 12),
                          ],
                        );
                      }).toList(),
                    );
                  }*/

                  if (tab == 2) {
                    return Column(
                      children: [
                        ...controller.followUps.map(
                          (followUp) => FeedbackMessageCard(
                            title: followUp.reason,
                            dateTime: DateFormat(
                              "dd/MM/yyyy - h:mm a",
                            ).format(followUp.followUpDate),
                            message: followUp.notes,
                            progressed: 0,
                          ),
                        ),
                      ],
                    );
                  }
                  /* if (tab == 2) {
                    if (controller.followUpslist.isEmpty) {
                      return _emptyBox(cardBg, theme, 'No followups yet');
                    }

                    return Column(
                      children: controller.followUpslist
                          .map(
                            (f) => FeedbackMessageCard(
                              title: f.followUpReason,
                              dateTime:
                                  "${DateFormat('dd/MM/yyyy').format(f.appointmentDate)} - ${f.appointmentTime}",
                              message: f.replayMessage ?? "",
                              progressed: f.progressed,
                            ),
                          )
                          .toList(),
                    );
                  }*/

                  if (tab == 3) {
                    return Column(
                      children: controller.invoices
                          .asMap()
                          .entries
                          .map(
                            (e) => Column(
                              children: [
                                _invoiceRow(e.value, e.key, theme),
                                const SizedBox(height: AppStyle.listGap),
                              ],
                            ),
                          )
                          .toList(),
                    );
                  }

                  if (tab == 4) {
                    if (controller.proposals.isEmpty) {
                      return _emptyBox(cardBg, theme, 'No proposals yet');
                    }

                    return Column(
                      children: controller.proposals.map((p) {
                        final color = _statusColor(p.status);

                        return Container(
                          margin: const EdgeInsets.only(
                            bottom: AppStyle.listGap,
                          ),
                          padding: const EdgeInsets.all(10),
                          decoration: AppStyle.decoration,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              // LEFT SECTION
                              Row(
                                children: [
                                  // ICON BOX
                                  Container(
                                    decoration: BoxDecoration(
                                      color: AppColors.background,
                                      borderRadius: BorderRadius.circular(
                                        AppStyle.borderRadiusBox,
                                      ),
                                    ),
                                    padding: const EdgeInsets.all(10),
                                    child: Icon(
                                      Icons.description,
                                      color: Colors.grey[700],
                                    ),
                                  ),
                                  const SizedBox(width: 10),

                                  // TEXT DETAILS
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Proposal #${p.id}",
                                        style: theme.bodyMedium?.copyWith(
                                          color: AppColors.textPrimary,
                                        ),
                                      ),
                                      Text(
                                        "${p.date} - ${p.amount}",
                                        style: theme.bodySmall?.copyWith(
                                          color: AppColors.textSecondary,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),

                              // STATUS BADGE
                              Row(
                                children: [
                                  Container(
                                    width: 8,
                                    height: 8,
                                    decoration: BoxDecoration(
                                      color: color,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    p.status,
                                    style: theme.bodySmall?.copyWith(
                                      color: color,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    );
                  }

                  return const SizedBox.shrink();
                }),
              ),

              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  // 🔹 App Bar
  Widget _topAppBar(TextTheme theme) => Container(
    padding: const EdgeInsets.symmetric(vertical: 14),
    decoration: const BoxDecoration(
      color: Colors.transparent,
      // border: Border(
      //   bottom: BorderSide(color: AppColors.border.withOpacity(0.5)),
      // ),
    ),
    child: Row(
      children: [
        InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => navigatorKey.currentState!.pop(),
          child: const Padding(
            padding: EdgeInsets.all(6.0),
            child: Icon(
              Icons.arrow_back_ios_new,
              color: AppColors.textPrimary,
              size: 22,
            ),
          ),
        ),
        const Spacer(),
        Text(
          "Call Details",
          style: theme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
            color: AppColors.textPrimary,
          ),
        ),
        const Spacer(),
        Text(
          "Edit",
          style: theme.bodyMedium?.copyWith(
            color: AppColors.primary,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    ),
  );

  //
  // 🔹 Contact Information Card
  Widget _contactCard(
    BuildContext context,
    RxMap<String, dynamic> data,
    TextTheme theme,
  ) => Container(
    padding: const EdgeInsets.all(10),
    decoration: AppStyle.decoration,
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            InkWell(
              onTap: () {},
              child: CircleAvatar(
                radius: 28,
                backgroundImage: NetworkImage(data['image']),
              ),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  data['name'],
                  style: theme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: AppColors.textPrimary,
                  ),
                ),

                Text(
                  data['phone'],
                  style: theme.bodySmall?.copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 5),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    ...(data['categories'] as List<String>).map(
                      (e) => InkWell(
                        onTap: () =>
                            _openCategorySheet(context, e, data['categories']),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          decoration: AppStyle.decoration.copyWith(
                            color: _chipColor(e),
                            borderRadius: BorderRadius.circular(
                              AppStyle.borderRadiusClip,
                            ),
                          ),
                          child: Row(
                            children: [
                              Text(
                                e,
                                style: theme.bodySmall?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: _chipTextColor(e),
                                ),
                              ),
                              Icon(
                                Icons.arrow_drop_down_rounded,
                                color: _chipTextColor(e),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: convertCustomer,
                      child: const Icon(Icons.sync),
                    ),
                  ],
                ),
              ],
            ),

            const Spacer(),
            InkWell(
              onTap: () {
                FlutterPhoneDirectCaller.callNumber("8608080510");
              },
              child: Container(
                height: 40,
                width: 40,
                decoration: BoxDecoration(
                  color: AppColors.primary.withAlpha(20),
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.primary.withAlpha(100)),
                ),
                child: Icon(
                  Icons.call,
                  color: AppColors.primary,
                  size: AppStyle.iconSize,
                ),
              ),
            ),
          ],
        ),
        // const SizedBox(height: 12),
        // Text(
        //   data['phone'],
        //   style: theme.bodyMedium?.copyWith(
        //     color: AppColors.textSecondary,
        //     fontSize: 16,
        //   ),
        // ),
        const WidgetGap(),
        Container(
          margin: const EdgeInsets.symmetric(
            vertical: 4,
            // horizontal: 4,
          ),
          // padding: const EdgeInsets.all(5),
          // decoration: AppStyle.decoration.copyWith(boxShadow: []),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Expanded(
                child: ActionButton(
                  icon: HugeIcons.strokeRoundedPropertyAdd,
                  label: 'Add Follow Up',
                  color: Theme.of(navigatorKey.currentContext!).primaryColor,
                  onTap: openAddFollowUpBottomSheet,
                ),
              ),
              const Expanded(
                child: ActionButton(
                  icon: HugeIcons.strokeRoundedWhatsapp,
                  label: 'Whatsapp',
                  color: Colors.green,
                  onTap: openTemplateBottomSheet,
                ),
              ),
              Expanded(
                child: ActionButton(
                  icon: HugeIcons.strokeRoundedBubbleChat,
                  label: 'SMS',
                  color: Colors.blue,
                  onTap: () {
                    // openSMS(number);
                  },
                ),
              ),
              Expanded(
                child: ActionButton(
                  icon: HugeIcons.strokeRoundedUserSwitch,
                  label: 'Assigned to',
                  color: Colors.indigo,
                  onTap: () {
                    openButtomsheet(AgentSelectionBottomSheet());
                  },
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
  void _openCategorySheet(
    BuildContext context,
    String selectedValue,
    List<String> categories,
  ) {
    String tempSelected = selectedValue;

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    "Select Category",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),

                  /// Radio list
                  ...categories.map((value) {
                    return RadioListTile(
                      title: Text(value),
                      value: value,
                      groupValue: tempSelected,
                      onChanged: (v) {
                        setState(() => tempSelected = v.toString());
                      },
                    );
                  }).toList(),

                  const SizedBox(height: 15),

                  /// OK Button
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text("OK"),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Color _colorForType(InteractionType type) {
    switch (type) {
      case InteractionType.meeting:
        return AppColors.primary;
      case InteractionType.email:
        return AppColors.danger;
      case InteractionType.call:
        return AppColors.secondary;
      case InteractionType.note:
        return AppColors.tertiary;
    }
  }

  Color _statusColor(String status) {
    switch (status) {
      case "Approved":
        return AppColors.secondary;
      case "Pending":
        return AppColors.tertiary;
      case "Rejected":
        return AppColors.danger;
      default:
        return AppColors.textSecondary;
    }
  }

  // 🔹 Call Metadata
  Widget _callMetaCard(RxMap<String, dynamic> data, TextTheme theme) =>
      Container(
        padding: const EdgeInsets.all(12),
        decoration: AppStyle.decoration,
        child: Column(
          children: [
            // _metaItem(
            //   Icons.call_made,
            //   "Call Type",
            //   data['callType'],
            //   color: Colors.green,
            //   theme: theme,
            // ),
            // const Divider(color: AppColors.border, height: 1),
            _metaItem(
              HugeIcons.strokeRoundedCallIncoming04,
              "Last Call",
              color: Colors.green,
              data['dateTime'],
              theme: theme,
            ),
            const Divider(color: AppColors.border, height: 8),
            _metaItem(
              HugeIcons.strokeRoundedHourglass,
              "Duration",
              data['duration'],
              theme: theme,
            ),
          ],
        ),
      );

  Widget _metaItem(
    List<List<dynamic>> icon,
    String label,
    String value, {
    Color? color,
    required TextTheme theme,
  }) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 0),
    child: Row(
      children: [
        // Icon(icon, color: color ?? AppColors.textSecondary, size: 22),
        HugeIcon(
          icon: icon,
          size: AppStyle.iconSizelarge,
          color: color ?? AppColors.primary,
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: theme.bodySmall?.copyWith(
                  color: AppColors.textSecondary,
                ),
              ),
              Text(
                value,
                style: theme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w500,
                  color: AppColors.textPrimary,
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  // 🔹 Notes
  Widget _notesCard(RxMap<String, dynamic> data, TextTheme theme) => Container(
    padding: const EdgeInsets.all(10),
    decoration: AppStyle.decoration,
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Notes",
          style: theme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
            color: AppColors.textPrimary,
          ),
        ),

        Text(
          data['notes'],
          textAlign: TextAlign.justify,
          style: theme.bodyMedium?.copyWith(
            color: AppColors.textSecondary,
            height: 1,
          ),
        ),
      ],
    ),
  );

  // 🔹 Categories

  Color _chipColor(String label) {
    switch (label) {
      case "Lead":
        return Colors.blue.shade100;
      case "Follow-up":
        return Colors.orange.shade100;
      case "Q4-Pipeline":
        return Colors.green.shade100;
      default:
        return AppColors.card;
    }
  }

  Color _chipTextColor(String label) {
    switch (label) {
      case "Lead":
        return Colors.blue.shade800;
      case "Follow-up":
        return Colors.orange.shade800;
      case "Q4-Pipeline":
        return Colors.green.shade800;
      default:
        return AppColors.textPrimary;
    }
  }

  // 🔹 Bottom Action Bar

  Widget _emptyBox(Color cardBg, TextTheme theme, String text) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: cardBg,
      borderRadius: BorderRadius.circular(12),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.03),
          blurRadius: 6,
          offset: const Offset(0, 2),
        ),
      ],
    ),
    child: Center(
      child: Text(
        text,
        style: theme.bodyMedium?.copyWith(color: AppColors.textPrimary),
      ),
    ),
  );

  Widget _segmentButton(
    String label,
    int idx,
    bool selected,
    CallDetailsController controller,
  ) {
    final theme = Theme.of(navigatorKey.currentContext!).textTheme;
    return Expanded(
      child: InkWell(
        onTap: () => controller.setTab(idx),
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: selected ? (Colors.white) : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Center(
            child: Text(
              label,
              style: selected
                  ? theme.bodyMedium?.copyWith(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w700,
                    )
                  : theme.bodySmall?.copyWith(
                      color: Colors.grey[600],
                      fontWeight: FontWeight.w700,
                    ),
            ),
          ),
        ),
      ),
    );
  }

  String _formatDateTime(DateTime dt) {
    // simple formatting similar to HTML: "May 28, 2024 at 2:15 PM"
    final monthNames = [
      '',
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    final month = monthNames[dt.month];
    final day = dt.day;
    final year = dt.year;
    final hour = dt.hour > 12 ? dt.hour - 12 : (dt.hour == 0 ? 12 : dt.hour);
    final minute = dt.minute.toString().padLeft(2, '0');
    final ampm = dt.hour >= 12 ? 'PM' : 'AM';
    return '$month $day, $year at $hour:$minute $ampm';
  }

  Widget _invoiceRow(Invoice inv, int index, TextTheme theme) {
    final status = inv.status.toLowerCase();
    Color dotColor;
    Color bgColor;
    switch (status) {
      case 'paid':
        dotColor = AppColors.secondary;
        bgColor = AppColors.secondary.withOpacity(0.12);
        break;
      case 'overdue':
        dotColor = AppColors.tertiary; // close to amber
        bgColor = AppColors.tertiary.withOpacity(0.12);
        break;
      default:
        dotColor = AppColors.primary;
        bgColor = AppColors.primary.withOpacity(0.12);
    }

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: AppStyle.decoration,
      child: Row(
        children: [
          // icon box
          Container(
            decoration: BoxDecoration(
              color: AppColors.background,
              borderRadius: BorderRadius.circular(AppStyle.borderRadiusBox),
            ),
            padding: const EdgeInsets.all(10),
            child: Icon(Icons.receipt_long, color: Colors.grey[700]),
          ),
          const SizedBox(width: 10),
          // text
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  inv.id,
                  style: theme.bodyMedium?.copyWith(
                    color: AppColors.textPrimary,
                  ),
                ),
                // const SizedBox(height: 4),
                Text(
                  '${DateFormat.yMMMMd().format(inv.date)} - \$${inv.amount.toStringAsFixed(2)}',
                  style: theme.bodySmall?.copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          // status pill
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: bgColor,
              borderRadius: BorderRadius.circular(999),
            ),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: dotColor,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  inv.status,
                  style: theme.bodySmall?.copyWith(
                    color: dotColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
