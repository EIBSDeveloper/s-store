import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:itracker/src/app/modules/callLogs/model/model/reminderpopupmodel.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:itracker/src/core/app_style.dart';
import 'package:lottie/lottie.dart';

import '../../../../../../app.dart';
import '../../../../../../bottom_sheet.dart';
import '../../../../utils/notificationservice.dart';
import '../../../followup/controller/followup_controller.dart';

class AddFollowUpBottomSheet extends GetView<FollowUpController> {
  const AddFollowUpBottomSheet({super.key});

  @override
  Widget build(BuildContext context) => Obx(
    () => Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 10),
            _buildHeader(),
            const SizedBox(height: 8),
            _buildTabs(),
            const SizedBox(height: 8),
            if (controller.selectedTab.value == 'Add Notes')
              _buildAddNotesSection()
            else ...[
              _buildWhenSection(context),
              const SizedBox(height: 8),
              if (controller.selectedWhenOption.value == 'Custom') ...[
                _buildDateSection(context),
                const SizedBox(height: 8),
                _buildTimeSection(context),
              ],
              const SizedBox(height: 8),
              _buildRemarksSection(),
              const SizedBox(height: 8),
              _buildActionButtons(),
              const SizedBox(height: 16),
              _buildPreviousReminders(),
            ],
            const SizedBox(height: 30),
          ],
        ),
      ),
    ),
  );

  // Header
  Widget _buildHeader() => Center(
    child: Container(
      width: 60,
      height: 4,
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.grey[300],
        borderRadius: BorderRadius.circular(4),
      ),
    ),
  );

  // Tabs
  Widget _buildTabs() => Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: [
      _buildTab(Icons.note_add, 'Add Notes'),
      _buildTab(Icons.alarm, 'Followups'),
    ],
  );

  Widget _buildTab(IconData icon, String label) => GestureDetector(
    onTap: () => controller.selectedTab.value = label,
    child: Obx(() {
      final isSelected = controller.selectedTab.value == label;
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 20,
                color: isSelected
                    ? Theme.of(navigatorKey.currentContext!).colorScheme.primary
                    : Colors.grey,
              ),
              const SizedBox(width: 6),
              Text(
                label,
                style: Theme.of(navigatorKey.currentContext!)
                    .textTheme
                    .bodyMedium
                    ?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: isSelected
                          ? Theme.of(
                              navigatorKey.currentContext!,
                            ).colorScheme.primary
                          : Colors.grey,
                    ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Container(
            height: 2,
            width: 80,
            color: isSelected
                ? Theme.of(navigatorKey.currentContext!).colorScheme.primary
                : Colors.transparent,
          ),
        ],
      );
    }),
  );

  // Add Notes Section
  Widget _buildAddNotesSection() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        'Note',
        style: TextStyle(fontWeight: FontWeight.w600, color: Colors.grey[700]),
      ),
      const SizedBox(height: 7),
      TextField(
        maxLines: 5,
        onChanged: (val) => controller.noteDescription.value = val,
        decoration: InputDecoration(
          hintText: 'Type your note here...',
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Theme.of(navigatorKey.currentContext!).colorScheme.primary,
              width: 1.5,
            ),
          ),
        ),
      ),
      const SizedBox(height: 24),
    ],
  );

  // Remarks Section
  Widget _buildRemarksSection() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        'Remarks',
        style: TextStyle(fontWeight: FontWeight.w600, color: Colors.grey[700]),
      ),
      const SizedBox(height: 8),
      TextField(
        maxLines: 3,
        onChanged: (val) => controller.noteDescription.value = val,
        decoration: InputDecoration(
          hintText: 'Enter Remarks',
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Theme.of(navigatorKey.currentContext!).colorScheme.primary,
              width: 1.5,
            ),
          ),
        ),
      ),
    ],
  );

  // When Section
  Widget _buildWhenSection(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        children: [
          Icon(
            Icons.timelapse,
            color: Theme.of(navigatorKey.currentContext!).colorScheme.primary,
          ),
          const SizedBox(width: 6),
          Text('WHEN?', style: sectionTitleStyle),
        ],
      ),
      const SizedBox(height: 12),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          _buildOption('2 sec', controller.selectedWhenOption),
          _buildOption('15 min', controller.selectedWhenOption),
          _buildOption('30 min', controller.selectedWhenOption),
          _buildOption('1 hour', controller.selectedWhenOption),
          _buildOption('2 hours', controller.selectedWhenOption),
          _buildCustomOption('Custom', controller.selectedWhenOption),
        ],
      ),
      const SizedBox(height: 8),
    ],
  );

  // Date Section
  Widget _buildDateSection(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        children: [
          Icon(
            Icons.calendar_today,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(width: 6),
          Text('DATE', style: sectionTitleStyle),
        ],
      ),
      const SizedBox(height: 12),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          _buildOption('Today', controller.selectedDateOption),
          _buildOption('Tomorrow', controller.selectedDateOption),
          _buildOption('In 7 days', controller.selectedDateOption),
          GestureDetector(
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: DateTime.now(),
                firstDate: DateTime(2020),
                lastDate: DateTime(2100),
              );
              if (picked != null) {
                controller.selectedDateOption.value = "";
                controller.selectedCustomDate.value = picked;
              }
            },
            child: Obx(() {
              final hasDate = controller.selectedCustomDate.value != null;
              return Container(
                padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(
                    color: hasDate
                        ? Theme.of(context).colorScheme.primary
                        : Colors.black87,
                  ),
                ),
                child: Text(
                  hasDate
                      ? DateFormat(
                          'MMM dd, yyyy',
                        ).format(controller.selectedCustomDate.value!)
                      : 'Select date',
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    color: hasDate
                        ? Theme.of(context).colorScheme.primary
                        : Colors.black,
                  ),
                ),
              );
            }),
          ),
        ],
      ),
      const SizedBox(height: 8),
    ],
  );

  // Time Section
  Widget _buildTimeSection(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        children: [
          Icon(Icons.access_time, color: Theme.of(context).colorScheme.primary),
          const SizedBox(width: 6),
          Text('TIME', style: sectionTitleStyle),
        ],
      ),
      const SizedBox(height: 12),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          _buildOption('Morning 5 am', controller.selectedTimeOption),
          _buildOption('Afternoon 1 pm', controller.selectedTimeOption),
          _buildOption('Evening 5 pm', controller.selectedTimeOption),
          _buildOption('Night 8 pm', controller.selectedTimeOption),
          GestureDetector(
            onTap: () async {
              final picked = await showTimePicker(
                context: context,
                initialTime: TimeOfDay.now(),
              );
              if (picked != null) {
                controller.selectedTimeOption.value = "";
                controller.selectedCustomTime.value = picked;
              }
            },
            child: Obx(() {
              final hasTime = controller.selectedCustomTime.value != null;
              return Container(
                padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(
                    color: hasTime
                        ? Theme.of(context).colorScheme.primary
                        : Colors.black87,
                  ),
                ),
                child: Text(
                  hasTime
                      ? controller.selectedCustomTime.value!.format(context)
                      : 'Select time',
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    color: hasTime
                        ? Theme.of(context).colorScheme.primary
                        : Colors.black,
                  ),
                ),
              );
            }),
          ),
        ],
      ),
      const SizedBox(height: 8),
    ],
  );

  // Generic Option Widget
  Widget _buildOption(String text, RxString selected) => Obx(() {
    final isSelected = selected.value == text;
    return GestureDetector(
      onTap: () {
        selected.value = text;
        if (selected == controller.selectedDateOption) {
          controller.selectedCustomDate.value = null;
        }
        if (selected == controller.selectedTimeOption) {
          controller.selectedCustomTime.value = null;
        }
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? Theme.of(navigatorKey.currentContext!).colorScheme.primary
              : Colors.transparent,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: isSelected
                ? Theme.of(navigatorKey.currentContext!).colorScheme.primary
                : Colors.black87,
          ),
        ),
        child: Text(
          text,
          style: Theme.of(navigatorKey.currentContext!).textTheme.bodyMedium
              ?.copyWith(
                color: isSelected ? Colors.white : Colors.black,
                fontWeight: FontWeight.w500,
              ),
        ),
      ),
    );
  });

  // Custom Option Widget
  Widget _buildCustomOption(String text, RxString selected) => Obx(() {
    final isSelected = selected.value == text;
    return GestureDetector(
      onTap: () => selected.value = text,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: isSelected
                ? Theme.of(navigatorKey.currentContext!).colorScheme.primary
                : Colors.black87,
          ),
        ),
        child: Text(
          text,
          style: Theme.of(navigatorKey.currentContext!).textTheme.bodyMedium
              ?.copyWith(
                color: isSelected
                    ? Theme.of(navigatorKey.currentContext!).colorScheme.primary
                    : Colors.black,
                fontWeight: FontWeight.w500,
              ),
        ),
      ),
    );
  });

  // Action Buttons
  Widget _buildActionButtons() => Row(
    children: [
      Expanded(
        child: OutlinedButton(
          onPressed: Get.back,
          style: OutlinedButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: 6),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: Text(
            'CANCEL',
            style: Theme.of(navigatorKey.currentContext!).textTheme.bodyMedium,
          ),
        ),
      ),
      const SizedBox(width: 12),
      Expanded(
        child: ElevatedButton(
          onPressed: () {
            int leadId = 2; // Replace with actual lead id
            final controller = Get.put(FollowUpController());
            controller.submitFollowup(leadId);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Theme.of(
              navigatorKey.currentContext!,
            ).primaryColor,
            padding: const EdgeInsets.symmetric(vertical: 6),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: Text(
            'SAVE',
            style: Theme.of(
              navigatorKey.currentContext!,
            ).textTheme.bodyMedium?.copyWith(color: Colors.white),
          ),
        ),
      ),
    ],
  );

  Widget _buildPreviousReminders() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Previous reminders',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Theme.of(navigatorKey.currentContext!).colorScheme.primary,
            ),
          ),
          GestureDetector(
            onTap: () {},
            child: Text(
              'VIEW ALL',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Theme.of(
                  navigatorKey.currentContext!,
                ).colorScheme.primary,
              ),
            ),
          ),
        ],
      ),
      const SizedBox(height: 16),
      _buildReminderItem(
        'Reminder to explore Superfone trial',
        'Nov 09, 2025, 09:45 am',
      ),
      const SizedBox(height: 16),
      _buildReminderItem('Remind me!', 'Nov 08, 2025, 09:50 am'),
    ],
  );

  Widget _buildReminderItem(String title, String date) => Container(
    padding: const EdgeInsets.all(16),
    width: double.infinity,
    decoration: AppStyle.decoration,
    child: Row(
      children: [
        Container(
          width: 6,
          height: 60,
          decoration: BoxDecoration(
            color: Colors.green,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: Theme.of(
                navigatorKey.currentContext!,
              ).textTheme.bodyMedium,
            ),

            Text(
              date,
              style: Theme.of(navigatorKey.currentContext!).textTheme.bodySmall!
                  .copyWith(color: Colors.grey[600], fontSize: 12),
            ),
          ],
        ),
      ],
    ),
  );

  TextStyle get sectionTitleStyle =>
      TextStyle(fontWeight: FontWeight.w600, color: Colors.grey[700]);
}

// Open bottom sheet
Future<void> openAddFollowUpBottomSheet() async {
  Get.lazyPut(() => FollowUpController());
  await openButtomsheet(const AddFollowUpBottomSheet());
}

// -------------------- InAppReminderDialog --------------------
class InAppReminderDialog {
  static Timer? _timer;

  static void schedule(
    BuildContext context,
    DateTime time,
    ReminderPopupModel reminder,
  ) {
    final diff = time.difference(DateTime.now());
    if (diff.isNegative) return;

    _timer?.cancel();
    _timer = Timer(diff, () => _showBeautifulDialog(context, reminder));
  }

  static void _showBeautifulDialog(
    BuildContext context,
    ReminderPopupModel reminder,
  ) {
    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.7),
      transitionDuration: const Duration(milliseconds: 300),
      pageBuilder: (context, animation, secondaryAnimation) {
        return Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
            child: Container(
              width: double.infinity,
              height: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 18),
              decoration: BoxDecoration(color: AppColors.background),
              child: _buildAlarmStyleUI(context, reminder),
            ),
          ),
        );
      },
      transitionBuilder: (context, animation, secondaryAnimation, child) {
        return FadeTransition(
          opacity: animation,
          child: SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0, 0.2),
              end: Offset.zero,
            ).animate(animation),
            child: child,
          ),
        );
      },
    );
  }

  static Widget _buildAlarmStyleUI(
    BuildContext context,
    ReminderPopupModel reminder,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const SizedBox(height: 40),

        // ALARM ANIMATION
        Lottie.asset("assets/AlarmClock.json", height: 180, repeat: true),

        const SizedBox(height: 20),

        // BIG TITLE
        Text(
          "Reminder Alert!",
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
            fontWeight: FontWeight.w900,
            color: AppColors.textPrimary,
          ),
        ),

        const SizedBox(height: 10),

        // NAME + NUMBER
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.textPrimary.withAlpha(20),
            borderRadius: BorderRadius.circular(AppStyle.borderRadiusBox),
          ),
          child: Row(
            children: [
              // User Info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      reminder.name,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      reminder.mobile,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ],
                ),
              ),

              // CALL
              Container(
                height: 55,
                width: 55,
                decoration: BoxDecoration(
                  color: AppColors.success.withAlpha(50),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.call,
                  color: AppColors.success,
                  size: 28,
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 20),

        // NOTES
        Text(
          reminder.notes.isNotEmpty
              ? reminder.notes
              : "You have a reminder right now.",
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),

        const Spacer(),

        // SNOOZE BUTTONS
        Wrap(
          spacing: 15,
          runSpacing: 10,
          children: [
            _alarmSnoozeBtn(context, "5 min", 5, reminder),
            _alarmSnoozeBtn(context, "10 min", 10, reminder),
            _alarmSnoozeBtn(context, "15 min", 15, reminder),
          ],
        ),

        const SizedBox(height: 25),

        // DISMISS BUTTON
        GestureDetector(
          onTap: () {
            Navigator.pop(context);
            _timer?.cancel();
            _timer = null;
          },
          child: Container(
            width: 100,
            padding: const EdgeInsets.symmetric(vertical: 16),
            decoration: BoxDecoration(
              color: AppColors.danger,
              borderRadius: BorderRadius.circular(AppStyle.borderRadiusBox),
            ),
            child: Text(
              "Dismiss",
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: AppColors.card,
              ),
            ),
          ),
        ),

        const SizedBox(height: 30),
      ],
    );
  }

  static Widget _alarmSnoozeBtn(
    BuildContext context,
    String label,
    int minutes,
    ReminderPopupModel reminder,
  ) {
    return GestureDetector(
      onTap: () {
        final newTime = DateTime.now().add(Duration(minutes: minutes));

        NotificationService.scheduleNotification(
          1,
          "Reminder",
          reminder.notes.isNotEmpty ? reminder.notes : "Snoozed reminder",
          newTime,
        );

        schedule(context, newTime, reminder);
        Navigator.pop(context);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 22),
        decoration: BoxDecoration(
          color: AppColors.primary.withAlpha(20),
          borderRadius: BorderRadius.circular(AppStyle.borderRadiusBox),
          border: Border.all(color: AppColors.primary, width: 1.4),
        ),
        child: Text(
          label,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: AppColors.primary,
          ),
        ),
      ),
    );
  }
}
