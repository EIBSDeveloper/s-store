import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../widgets/bottom_sheet_syle.dart';
import '../../../../widgets/input_card_style.dart';
import '../../controller/call_logcontroller.dart';
import '../../model/client_model.dart';

class AgentSelectionBottomSheet extends StatelessWidget {
  final CallLogsController controller = Get.find();

  AgentSelectionBottomSheet({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return BottomSheetStyle(
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // --- Header ---
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Assign to',
                    style: theme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: theme.colorScheme.primary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              /* // --- Agent Dropdown ---
              Obx(() {
                if (controller.callLog.isEmpty) {
                  return Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(
                      'No agents available',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onSurface.withOpacity(0.6),
                      ),
                    ),
                  );
                }

                return InputCardStyle(
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<AgentModel>(
                      isExpanded: true,
                      value: controller.selectedAgent.value,
                      hint: Text(
                        "Select Agent",
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onSurface.withOpacity(0.6),
                        ),
                      ),
                      items:[

                        // controller.callLog
                        //   .map(
                        //     (agent) => DropdownMenuItem<AgentModel>(
                        //       value: agent,
                        //       child: Row(
                        //         children: [
                        //           CircleAvatar(
                        //             radius: 18,
                        //             backgroundColor: theme.colorScheme.primary,
                        //             backgroundImage: agent.imageUrl != null
                        //                 ? NetworkImage(agent.imageUrl!)
                        //                 : null,
                        //             child: agent.imageUrl == null
                        //                 ? Text(
                        //                     _getInitials(agent.name),
                        //                     style: theme.textTheme.bodyMedium
                        //                         ?.copyWith(
                        //                           color:
                        //                               theme.colorScheme.onPrimary,
                        //                           fontWeight: FontWeight.w600,
                        //                         ),
                        //                   )
                        //                 : null,
                        //           ),
                        //           const SizedBox(width: 10),
                        //           Expanded(
                        //             child: Text(
                        //               agent.name,
                        //               overflow: TextOverflow.ellipsis,
                        //               style: theme.textTheme.bodyMedium?.copyWith(
                        //                 color: theme.colorScheme.onSurface,
                        //                 fontWeight: FontWeight.w600,
                        //               ),
                        //             ),
                        //           ),
                        //         ],
                        //       ),
                        //     ),
                        //   )
                        //   .toList()


                          ],
                      onChanged: (agent) {
                        controller.selectedAgent.value = agent;
                      },
                    ),
                  ),
                );
              }),
              const SizedBox(height: 20),*/

              // Dropdown for agents
              Obx(() {
                if (controller.dummyagentList.isEmpty) {
                  return Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(
                      'No agents available',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onSurface.withOpacity(0.6),
                      ),
                    ),
                  );
                }

                return InputCardStyle(
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<AgentModel>(
                      isExpanded: true,
                      value: controller.selectedAgent.value,
                      hint: Text(
                        "Select Agent",
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onSurface.withOpacity(0.6),
                        ),
                      ),
                      items: controller.dummyagentList
                          .map(
                            (agent) => DropdownMenuItem<AgentModel>(
                              value: agent,
                              child: Row(
                                children: [
                                  CircleAvatar(
                                    radius: 18,
                                    backgroundColor: theme.colorScheme.primary,
                                    backgroundImage: agent.imageUrl != null
                                        ? NetworkImage(agent.imageUrl!)
                                        : null,
                                    child: agent.imageUrl == null
                                        ? Text(
                                            _getInitials(agent.name),
                                            style: theme.textTheme.bodyMedium
                                                ?.copyWith(
                                                  color: theme
                                                      .colorScheme
                                                      .onPrimary,
                                                  fontWeight: FontWeight.w600,
                                                ),
                                          )
                                        : null,
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Text(
                                      agent.name,
                                      overflow: TextOverflow.ellipsis,
                                      style: theme.textTheme.bodyMedium
                                          ?.copyWith(
                                            color: theme.colorScheme.onSurface,
                                            fontWeight: FontWeight.w600,
                                          ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (agent) {
                        controller.selectedAgent.value = agent;
                      },
                    ),
                  ),
                );
              }),
              const SizedBox(height: 20),

              // --- Reason Field ---
              Text(
                "Reason",
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: theme.colorScheme.primary,
                ),
              ),
              const SizedBox(height: 8),
              InputCardStyle(
                child: TextField(
                  controller: controller.reasonTextController,
                  minLines: 3,
                  maxLines: 5,
                  style: theme.textTheme.bodyMedium,
                  decoration: InputDecoration(
                    hintText: "Enter reason",
                    hintStyle: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurface.withOpacity(0.6),
                    ),
                    border: InputBorder.none,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // --- Submit Button ---
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  icon: Icon(Icons.send, color: theme.colorScheme.onPrimary),
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: theme.colorScheme.primary,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    elevation: 3,
                  ),
                  label: Text(
                    "Submit",
                    style: theme.textTheme.titleLarge?.copyWith(
                      color: theme.colorScheme.onPrimary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _getInitials(String name) {
    final parts = name.split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return name.length >= 2
        ? name.substring(0, 2).toUpperCase()
        : name.toUpperCase();
  }
}
