import 'package:flutter/material.dart';

import '../../../../../core/app_colors.dart';
import '../../../../../core/app_style.dart';

class FeedbackMessageCard extends StatelessWidget {
  final String title;
  final String dateTime;
  final String message;
  final int progressed; // Add this

  const FeedbackMessageCard({
    super.key,
    required this.title,
    required this.dateTime,
    required this.message,
    required this.progressed,
  });

  @override
  Widget build(BuildContext context) => Container(
    decoration: AppStyle.decoration,
    padding: const EdgeInsets.all(10),
    margin: const EdgeInsets.only(bottom: 10),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Vertical black bar
        Container(
          width: 6,
          height: 60,
          decoration: BoxDecoration(
            color: progressed == 1 ? Colors.green : Colors.orange,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        const SizedBox(width: 12),

        // Text content
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 4),
              // Title
              Text(
                dateTime,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w600,
                ),
              ),
              // const SizedBox(height: 5),
              // Date and time
              // Text(
              //   dateTime,
              //   style: Theme.of(
              //     context,
              //   ).textTheme.bodySmall?.copyWith(color: AppColors.textSecondary),
              // ),
              const SizedBox(height: 2),
              // Message text
              Text(
                message,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppColors.textSecondary,
                  height: 1,
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}
