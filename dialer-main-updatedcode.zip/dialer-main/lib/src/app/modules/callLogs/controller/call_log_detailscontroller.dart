import 'package:get/get.dart';
import 'package:itracker/src/app/modules/callLogs/model/model/call_log_model.dart';
import 'package:itracker/src/app/modules/callLogs/model/model/followupitem.dart';
import 'package:itracker/src/app/modules/callLogs/repository/client_repository.dart';

import '../../payment_tracker/controller/customercontroller.dart';
import '../model/followup_model.dart';

class CallDetailsController extends GetxController {
  final RxInt tab = 0.obs;

  // Tabs: 0 = Payments, 1 = Proposals, 2 = Interactions
  final selectedTab = 0.obs;
  // notes
  final notes = <NoteItem>[].obs;
  // sample invoices
  final invoices = <Invoice>[].obs;

  @override
  void onInit() {
    super.onInit();
    // Load data
    loadCallLogs();
    loadFollowUps();
    //customer list
    loadData();
  }

  RxList<ProposalModel> proposals = <ProposalModel>[
    ProposalModel(
      id: "P2024-015",
      date: "May 20, 2024",
      amount: "\$5,500.00",
      status: "Approved",
    ),
    ProposalModel(
      id: "P2024-012",
      date: "Apr 28, 2024",
      amount: "\$3,200.00",
      status: "Pending",
    ),
    ProposalModel(
      id: "P2024-011",
      date: "Apr 15, 2024",
      amount: "\$8,900.00",
      status: "Rejected",
    ),
    ProposalModel(
      id: "P2024-009",
      date: "Mar 10, 2024",
      amount: "\$4,750.00",
      status: "Approved",
    ),
    ProposalModel(
      id: "P2024-005",
      date: "Feb 05, 2024",
      amount: "\$12,300.00",
      status: "Approved",
    ),
  ].obs;

  // sample interactions (mirrors the HTML sample)
  final interactions = <Interaction>[
    Interaction(
      id: 'i1',
      title: 'Quarterly Review Meeting',
      body:
          'Discussed Q2 performance and upcoming projects. Agreed on new payment terms for next phase.',
      at: DateTime(2024, 6, 5, 10, 0),
      type: InteractionType.meeting,
    ),
    Interaction(
      id: 'i2',
      title: 'Email: Follow-up on Proposal',
      body:
          'Sent the revised proposal as discussed. Awaiting confirmation from their finance team.',
      at: DateTime(2024, 5, 28, 14, 15),
      type: InteractionType.email,
    ),
    Interaction(
      id: 'i3',
      title: 'Phone Call: Invoice Query',
      body:
          'John called to confirm receipt of Invoice #2024-051. Confirmed payment will be processed this week.',
      at: DateTime(2024, 5, 15, 11, 30),
      type: InteractionType.call,
    ),
    Interaction(
      id: 'i4',
      title: 'Internal Note Added',
      body:
          'Followed up on the overdue invoice. John mentioned payment will be processed by EOD Friday.',
      at: DateTime(2024, 5, 10, 16, 45),
      type: InteractionType.note,
    ),
  ].obs;

  void setTab(int idx) => selectedTab.value = idx;

  void loadData() {
    //customer details
    invoices.assignAll([
      Invoice(
        id: 'Invoice #2024-051',
        date: DateTime(2024, 5, 15),
        amount: 1250.00,
        status: 'Paid',
      ),
      Invoice(
        id: 'Invoice #2024-043',
        date: DateTime(2024, 4, 12),
        amount: 875.50,
        status: 'Overdue',
      ),
      Invoice(
        id: 'Invoice #2024-037',
        date: DateTime(2024, 3, 21),
        amount: 2500.00,
        status: 'Paid',
      ),
    ]);

    notes.assignAll([
      NoteItem(
        date: DateTime(2024, 5, 10),
        text:
            'Followed up on the overdue invoice. John mentioned payment will be processed by EOD Friday.',
      ),
    ]);
  }

  final contact = {
    "name": "Eleanor Vance",
    "company": "Innovate Inc.",
    "phone": "+91 9876543210",
    "image":
        "https://lh3.googleusercontent.com/aida-public/AB6AXuBrdw_52nYPkOU_ctQ9MhL0T7jkaVm3gpwXCY_VM2Ae67Y8dJMDk0fBSopuLV6VdXgPVc8NqoViiX2-g4sVwQ2XqXp7RPV5bSulh8ORGhOd1qmEI1sN4UYzWVaKLRJXxj4EdBBpX6C31KjVItGFRymcDrK6i8XpRxQZ-CNG-HesN1x2G9V0NjaASBenIyFMuX4ctwoFrsWcp0eboG0OLbCcKdgbtx78C_LK2Vs18uMuDFi_sjOo7WOPNWgU3mXfkjST1d-ZR45i8_0V",
    "callType": "Outgoing",
    "iconColor": "green",
    "dateTime": "21/02/2025 10:32 am",
    "duration": "5m 32s",
    "notes":
        "Discussed the new product line and potential for a bulk order. Follow-up required next week to finalize the details and pricing.",
    "categories": ["Follow-up"],
  }.obs;

  List<FollowUpModel> followUps = [
    // Next week follow-up
    FollowUpModel(
      id: 'f4',
      leadId: '100',
      followUpDate: DateTime.now().add(const Duration(days: 7)),
      reason: 'Follow-up Call',
      status: 'Scheduled',
      notes: 'Check on client satisfaction and address any concerns',
      createdAt: DateTime.now().subtract(const Duration(days: 1)),
    ),
    // Overdue follow-up
    FollowUpModel(
      id: '102',
      leadId: '5',
      followUpDate: DateTime.now().subtract(const Duration(days: 1)),
      reason: 'Payment Follow-up',
      status: 'Overdue',
      notes: 'Client missed payment deadline, need to follow up urgently',
      createdAt: DateTime.now().subtract(const Duration(days: 10)),
    ),
  ];

  final ClientRepository repository = Get.find();
  var callLogslist = <String, List<CallLogItem>>{}.obs;
  var followUpslist = <FollowUpItem>[].obs;
  Future<void> loadCallLogs() async {
    callLogslist.value = await repository.getCallLogs(1);
  }

  Future<void> loadFollowUps() async {
    followUpslist.value = await repository.getFollowUps(1);
  }
}
