import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../app.dart';
import '../../../../../core/models/call_log_entry.dart';
import '../../../utils/routes/api_service.dart';
import '../model/call.dart';
import '../model/client_model.dart';
import '../repository/client_repository.dart';

class CallLogsController extends GetxController {
  RxInt isExpended = 0.obs;
  final api = ApiService();
  final ClientRepository repository = Get.find();
  RxMap callLogsByDate = {}.obs;
  RxBool isLogLoad = false.obs;
  var selectedFilter = CallType.all.obs;
  final RxList<CallLog> callLog = <CallLog>[].obs;

  final selectedAgent = Rxn<AgentModel>();
  final reasonTextController = TextEditingController();
  final selectedcallStatus = ''.obs;
  final selectedleadStatus = ''.obs;

  final dummyagentList = <AgentModel>[].obs;

  void changeFilter(CallType filter) {
    selectedFilter.value = filter;
  }

  @override
  void onInit() {
    super.onInit();
    loadDummyCalls();
    loadDummyAgents();
    loadAvailableAgents();
    update();
  }

  var dummycallLogs = <Map<String, dynamic>>[].obs; // reactive list

  final formKey = GlobalKey<FormState>();
  final name = TextEditingController();
  final phone = TextEditingController();
  final email = TextEditingController();
  final company = TextEditingController();
  final role = TextEditingController();
  final notes = TextEditingController();

  void loadDummyCalls() async {
    final res = await ApiService.getData('dummy_endpoint');
    dummycallLogs.assignAll(List<Map<String, dynamic>>.from(res.data));
  }

  void submit() {
    if (!formKey.currentState!.validate()) return;

    final newContact = {
      "name": name.text.trim(),
      "phone": phone.text.trim(),
      "email": email.text.trim(),
      "company": company.text.trim(),
      "role": role.text.trim(),
      "notes": notes.text.trim(),
      "statusIcon": "incoming",
      "leadId": null,
    };

    int index = dummycallLogs.indexWhere(
      (c) => c['phone'] == phone.text.trim(),
    );

    if (index != -1) {
      // Replace the map entirely so GetX detects change
      dummycallLogs[index] = {
        ...dummycallLogs[index],
        'name': name.text.trim(),
        'email': email.text.trim(),
        'company': company.text.trim(),
        'role': role.text.trim(),
        'notes': notes.text.trim(),
      };
    } else {
      dummycallLogs.add(newContact);
    }

    navigatorKey.currentState!.pop();
  }

  void loadDummyAgents() {
    const String dummyJson = '''
  [
    {"id":"1","name":"John Doe","email":"john@example.com","phone":"1234567890","image_url":null},
    {"id":"2","name":"Jane Smith","email":"jane@example.com","phone":"9876543210","image_url":null},
    {"id":"3","name":"Alice Johnson","email":"alice@example.com","phone":"5551234567","image_url":null},
    {"id":"4","name":"Bob Williams","email":"bob@example.com","phone":"5559876543","image_url":null},
    {"id":"5","name":"Charlie Brown","email":"charlie@example.com","phone":"5555555555","image_url":null}
  ]
  ''';

    final List<dynamic> jsonList = jsonDecode(dummyJson);
    dummyagentList.value = jsonList.map((e) => AgentModel.fromJson(e)).toList();
  }

  @override
  void onClose() {
    name.dispose();
    phone.dispose();
    email.dispose();
    company.dispose();
    role.dispose();
    notes.dispose();
    super.onClose();
  }

  Future<void> loadAvailableAgents() async {
    try {
      callLogsByDate.clear();
      isLogLoad(true);
      final CallResponse response = await getCallLogs();

      response.data.forEach((date, logs) {
        callLogsByDate[date] = (logs as List)
            .map((ee) => CallLog.fromJson(ee))
            .toList();
      });
    } finally {
      isLogLoad(false);
    }
  }

  Future<CallResponse> getCallLogs() async {
    try {
      final response = await ApiService.getData("/call/staff/1");

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = response.data;
        return CallResponse.fromJson(data);
      } else {
        throw Exception('Failed to load call logs: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to load call logs: $e');
    }
  }

  void onSnooze(String value) {}

  void onCustom() {}

  // Show/hide custom fields
  var showCustomFields = false.obs;

  // Store the selected date and time
  var customDateTime = Rxn<DateTime>();

  void toggleCustomFields() {
    showCustomFields.value = !showCustomFields.value;
  }
}
