import 'dart:convert';

import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:itracker/src/app/controller/app_controller.dart';
import 'package:itracker/src/app/modules/callLogs/model/model/call_log_model.dart';
import 'package:itracker/src/app/modules/callLogs/model/model/followupitem.dart';
import 'package:itracker/src/app/utils/apiconstants.dart';
import 'package:itracker/src/app/utils/routes/api_service.dart';

import '../../../utils/http/http_service.dart';
import '../model/client_model.dart';

class ClientRepository {
  final HttpService httpService = Get.find();
  final appData = Get.find<AppDataController>();
  ClientRepository();

  Future<ClientModel> getClientDetails(String clientId) async {
    try {
      // Hardcoded response for development
      await Future.delayed(
        const Duration(milliseconds: 500),
      ); // Simulate network delay

      final hardcodedResponse = {
        "status": true,
        "message": "Success",
        "data": {
          "id": clientId,
          "name": "Karthik Rajeev",
          "email": "karthik.r@example.com",
          "phone": "+919876543210",
          "status": "Warm",
          "notes":
              "Interested in premium services. Prefers communication via WhatsApp. Available for calls after 3 PM. Has requested detailed pricing information for enterprise package.",
          "assigned_agent": {
            "id": "agent_001",
            "name": "Priya Sharma",
            "email": "priya.sharma@company.com",
            "phone": "+919887766554",
            "image_url": null,
          },
          "call_recordings": [
            {
              "id": "rec_001",
              "call_id": "call_001",
              "url": "https://example.com/recordings/rec001.mp3",
              "duration": 324,
              "recorded_at": "2024-01-15T10:30:00Z",
              "caller_number": "+919876543210",
            },
            {
              "id": "rec_002",
              "call_id": "call_002",
              "url": "https://example.com/recordings/rec002.mp3",
              "duration": 187,
              "recorded_at": "2024-01-10T14:20:00Z",
              "caller_number": "+919876543210",
            },
            {
              "id": "rec_003",
              "call_id": "call_003",
              "url": "https://example.com/recordings/rec003.mp3",
              "duration": 456,
              "recorded_at": "2024-01-05T11:15:00Z",
              "caller_number": "+919876543210",
            },
          ],
          "created_at": "2024-01-01T09:00:00Z",
          "updated_at": "2024-01-15T10:30:00Z",
        },
      };

      if (hardcodedResponse['status'] == true) {
        return ClientModel.fromJson(
          hardcodedResponse['data'] as Map<String, dynamic>,
        );
      } else {
        throw Exception(
          hardcodedResponse['message'] ?? 'Failed to load client details',
        );
      }
    } catch (e) {
      throw Exception('Failed to fetch client details: $e');
    }
  }

  Future<ClientModel> updateClientStatus(String clientId, String status) async {
    try {
      // Hardcoded response for development
      await Future.delayed(const Duration(milliseconds: 300));

      final hardcodedResponse = {
        "status": true,
        "message": "Status updated successfully",
        "data": {
          "id": clientId,
          "name": "Karthik Rajeev",
          "email": "karthik.r@example.com",
          "phone": "+919876543210",
          "status": status, // Updated status
          "notes":
              "Interested in premium services. Prefers communication via WhatsApp.",
          "assigned_agent": {
            "id": "agent_001",
            "name": "Priya Sharma",
            "email": "priya.sharma@company.com",
            "phone": "+919887766554",
            "image_url": null,
          },
          "call_recordings": [],
          "created_at": "2024-01-01T09:00:00Z",
          "updated_at": DateTime.now().toIso8601String(),
        },
      };

      if (hardcodedResponse['status'] == true) {
        return ClientModel.fromJson(
          hardcodedResponse['data'] as Map<String, dynamic>,
        );
      } else {
        throw Exception(
          hardcodedResponse['message'] ?? 'Failed to update status',
        );
      }
    } catch (e) {
      throw Exception('Failed to update client status: $e');
    }
  }

  Future<ClientModel> reassignAgent(String clientId, String agentId) async {
    try {
      // Hardcoded response for development
      await Future.delayed(const Duration(milliseconds: 400));

      // Find agent name from hardcoded agents list
      final agents = _getHardcodedAgents();
      final agent = agents.firstWhere(
        (a) => a.id == agentId,
        orElse: () => agents.first,
      );

      final hardcodedResponse = {
        "status": true,
        "message": "Agent reassigned successfully",
        "data": {
          "id": clientId,
          "name": "Karthik Rajeev",
          "email": "karthik.r@example.com",
          "phone": "+919876543210",
          "status": "Warm",
          "notes":
              "Interested in premium services. Prefers communication via WhatsApp.",
          "assigned_agent": {
            "id": agent.id,
            "name": agent.name,
            "email": agent.email,
            "phone": agent.phone,
            "image_url": agent.imageUrl,
          },
          "call_recordings": [],
          "created_at": "2024-01-01T09:00:00Z",
          "updated_at": DateTime.now().toIso8601String(),
        },
      };

      if (hardcodedResponse['status'] == true) {
        return ClientModel.fromJson(
          hardcodedResponse['data'] as Map<String, dynamic>,
        );
      } else {
        throw Exception(
          hardcodedResponse['message'] ?? 'Failed to reassign agent',
        );
      }
    } catch (e) {
      throw Exception('Failed to reassign agent: $e');
    }
  }

  Future<List<AgentModel>> getAvailableAgents() async {
    try {
      // Hardcoded response for development
      await Future.delayed(const Duration(milliseconds: 200));

      return _getHardcodedAgents();
    } catch (e) {
      throw Exception('Failed to fetch available agents: $e');
    }
  }

  // Helper method for hardcoded agents data
  List<AgentModel> _getHardcodedAgents() => [
    AgentModel(
      id: "agent_001",
      name: "Priya Sharma",
      email: "priya.sharma@company.com",
      phone: "+919887766554",
      imageUrl: null,
    ),
    AgentModel(
      id: "agent_002",
      name: "Rahul Verma",
      email: "rahul.verma@company.com",
      phone: "+919776655443",
      imageUrl: null,
    ),
    AgentModel(
      id: "agent_003",
      name: "Anjali Patel",
      email: "anjali.patel@company.com",
      phone: "+919665544332",
      imageUrl: null,
    ),
    AgentModel(
      id: "agent_004",
      name: "Vikram Singh",
      email: "vikram.singh@company.com",
      phone: "+919554433221",
      imageUrl: null,
    ),
  ];

  Future<bool> addCaller({
    required int callerId,
    required String callerName,
  }) async {
    final url = Uri.parse("${appData.baseUrl}${ApiConstants.editcaller}");

    final body = jsonEncode({"caller_id": callerId, "caller_name": callerName});

    final headers = {"Content-Type": "application/json"};

    final response = await http.post(url, headers: headers, body: body);

    if (response.statusCode == 200) {
      final jsonResponse = jsonDecode(response.body);
      if (jsonResponse['status'] == true) {
        return true;
      } else {
        Get.snackbar(
          "Error",
          jsonResponse['message'] ?? "Failed to add caller",
        );
        return false;
      }
    } else {
      Get.snackbar("Error", "Failed to connect to server");
      return false;
    }
  }

  Future<List<FollowUpItem>> getFollowUps(int id) async {
    final url = Uri.parse(
      "${appDeta.baseUrl}${ApiConstants.leadFollowUpslist}/$id",
    );

    final response = await http.get(url);

    final body = jsonDecode(response.body);

    if (body["success"] == true) {
      List data = body["data"];
      return data.map((e) => FollowUpItem.fromJson(e)).toList();
    }

    return [];
  }

  Future<Map<String, List<CallLogItem>>> getCallLogs(int id) async {
    final url = Uri.parse(
      "${appDeta.baseUrl}${ApiConstants.leadCallLogslist}/$id",
    );

    final response = await http.get(url);

    final body = jsonDecode(response.body);

    Map<String, dynamic> data = body["data"];

    return data.map(
      (date, list) => MapEntry(
        date,
        (list as List).map((e) => CallLogItem.fromJson(e)).toList(),
      ),
    );
  }
}
