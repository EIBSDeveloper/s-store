class CallLogItem {
  final int sno;
  final String callerName;
  final int callerMobile;
  final int callStatus;
  final String callDuration;
  final String callStartDate;
  final String callStartTime;

  CallLogItem({
    required this.sno,
    required this.callerName,
    required this.callerMobile,
    required this.callStatus,
    required this.callDuration,
    required this.callStartDate,
    required this.callStartTime,
  });

  factory CallLogItem.fromJson(Map<String, dynamic> json) {
    return CallLogItem(
      sno: json["sno"],
      callerName: json["caller_name"],
      callerMobile: json["caller_mobile"],
      callStatus: json["call_status"],
      callDuration: json["call_duration"],
      callStartDate: json["call_start_date"],
      callStartTime: json["call_start_time"],
    );
  }
}
