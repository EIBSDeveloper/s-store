class ReminderPopupModel {
  final int id;
  final String name;
  final String mobile;
  final String notes;

  ReminderPopupModel({
    required this.id,
    required this.name,
    required this.mobile,
    required this.notes,
  });

  factory ReminderPopupModel.fromJson(Map<String, dynamic> json) => ReminderPopupModel(
      id: json["id"] ?? 0,
      name: json["name"] ?? "",
      mobile: json["mobile"] ?? "",
      notes: json["notes"] ?? "",
    );
}
