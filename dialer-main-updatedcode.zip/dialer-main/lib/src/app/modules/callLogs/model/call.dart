 import 'package:intl/intl.dart';

import '../../../../../core/models/call_log_entry.dart';

class CallResponse {
  final bool status;
  final String message;
  final Map<String, dynamic> data;

  CallResponse({
    required this.status,
    required this.message,
    required this.data,
  });

  factory CallResponse.fromJson(Map<String, dynamic> json) => CallResponse(
      status: json['status'],
      message: json['message'],
      data: json['data'],
    );
}
 

class CallLog {
  final int id;
  final int callerId;
  final String mobile;
  final int? leadId;
  final String name;
  final String duration;
  final String time;
  final int status;
  final String createdAt;

  CallLog({
    required this.id,
    required this.callerId,
    required this.mobile,
    this.leadId,
    required this.name,
    required this.duration,
    required this.time,
    required this.status,
    required this.createdAt,
  });

  // Factory method to create from JSON
  factory CallLog.fromJson(Map<String, dynamic> json) {
    // Format time to 12-hour format
    String formattedTime = '';
    if (json['call_start_time'] != null) {
      DateTime parsedTime = DateFormat("HH:mm:ss").parse(json['call_start_time']);
      formattedTime = DateFormat("hh:mm a").format(parsedTime);
    }

    // Convert duration "HH:MM:SS" to "MM mins" or "HH:MM mins"
    String formattedDuration = '';
    if (json['call_duration'] != null) {
      List<String> parts = (json['call_duration'] as String).split(':');
      int hours = int.parse(parts[0]);
      int minutes = int.parse(parts[1]);
      if (hours > 0) {
        formattedDuration = "${hours}h ${minutes}m";
      } else {
        formattedDuration = "$minutes mins";
      }
    }

    return CallLog(
      id: json['sno'],
      callerId: json['caller_id'],
      mobile: json['caller_mobile'].toString(),
      leadId: json['lead_id'],
      name: json['caller_name'],
      duration: formattedDuration,
      time: formattedTime,
      status: json['call_status'],
      createdAt: json['created_at'],
    );
  }

  // Getter for call type
  CallType get statusIcon {
    switch (status) {
      case 1:
        return CallType.incoming;
      case 2:
        return CallType.outgoing;
      case 3:
        return CallType.missed;
      default:
        return CallType.rejected;
    }
  }



  String get formattedTime {
    try {
      final dateTime = DateTime.parse(createdAt);
      return '${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
    } catch (e) {
      return '--:--';
    }
  }
}