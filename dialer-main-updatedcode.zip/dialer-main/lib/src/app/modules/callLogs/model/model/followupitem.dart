class FollowUpItem {
  final int sno;
  final int companyId;
  final String appointmentId;
  final int leadId;
  final DateTime appointmentDate;
  final String appointmentTime;
  final String followUpReason;
  final int progressed;
  final String? replayMessage;
  final int staffId;
  final DateTime updatedAt;
  final int updatedBy;
  final DateTime createdAt;
  final int createdBy;
  final int status;

  FollowUpItem({
    required this.sno,
    required this.companyId,
    required this.appointmentId,
    required this.leadId,
    required this.appointmentDate,
    required this.appointmentTime,
    required this.followUpReason,
    required this.progressed,
    this.replayMessage,
    required this.staffId,
    required this.updatedAt,
    required this.updatedBy,
    required this.createdAt,
    required this.createdBy,
    required this.status,
  });

  factory FollowUpItem.fromJson(Map<String, dynamic> json) {
    return FollowUpItem(
      sno: json['sno'],
      companyId: json['company_id'],
      appointmentId: json['appointment_id'],
      leadId: json['lead_id'],
      appointmentDate: DateTime.parse(json['appointment_date']),
      appointmentTime: json['appointment_time'],
      followUpReason: json['follow_up_reason'],
      progressed: json['progressed'],
      replayMessage: json['replay_message'],
      staffId: json['staff_id'],
      updatedAt: DateTime.parse(json['updated_at']),
      updatedBy: json['updated_by'],
      createdAt: DateTime.parse(json['created_at']),
      createdBy: json['created_by'],
      status: json['status'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'sno': sno,
      'company_id': companyId,
      'appointment_id': appointmentId,
      'lead_id': leadId,
      'appointment_date': appointmentDate.toIso8601String(),
      'appointment_time': appointmentTime,
      'follow_up_reason': followUpReason,
      'progressed': progressed,
      'replay_message': replayMessage,
      'staff_id': staffId,
      'updated_at': updatedAt.toIso8601String(),
      'updated_by': updatedBy,
      'created_at': createdAt.toIso8601String(),
      'created_by': createdBy,
      'status': status,
    };
  }
}
