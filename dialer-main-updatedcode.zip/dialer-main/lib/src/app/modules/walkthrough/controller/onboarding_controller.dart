import 'package:get/get.dart';
class OnboardingController extends GetxController {
  RxInt pageIndex = 0.obs;

  void next() {
    if (pageIndex.value < 2) {
      pageIndex.value++;
    }
  }

  // RxBool callLogs = false.obs;
  // RxBool overlay = false.obs;
  // RxBool storage = false.obs;
  // RxBool notifications = false.obs;

  // void toggleCallLogs() => callLogs.toggle();
  // void       toggleOverlay() => overlay.toggle();
  // void toggleStorage() => storage.toggle();
  // void toggleNotifications() => notifications.toggle();

  // void allowAll() {
  //   callLogs.value = true;
  //   overlay.value = true;
  //   storage.value = true;
  //   notifications.value = true;
  // }
 

  void skip() {
    // Go next screen
  }

  RxBool is12Hour = true.obs;
  RxDouble fontSize = 50.0.obs;

  void changeTimeFormat(bool value) => is12Hour.value = value;
  void changeFontSize(double value) => fontSize.value = value;
}
