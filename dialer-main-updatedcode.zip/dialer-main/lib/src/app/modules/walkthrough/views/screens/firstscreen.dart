// lib/modules/onboarding/onboarding_screen.dart
import 'package:itracker/src/app/widgets/widget_gap.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_swipe_button/flutter_swipe_button.dart';
import 'package:get/get.dart';

import '../../controller/onboarding_controller.dart';

class OnboardingScreen extends GetView<OnboardingController> {
 const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context).textTheme;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Container(
          width: double.infinity,
          height: double.infinity,
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Obx(
                    () => Row(
                      children: [
                        _dot(active: controller.pageIndex.value == 0),
                        const SizedBox(width: 6),
                        _dot(active: controller.pageIndex.value == 1),
                        const SizedBox(width: 6),
                        _dot(active: controller.pageIndex.value == 2),
                      ],
                    ),
                  ),
                  TextButton(
                    onPressed: controller.skip,
                    child: Text(
                      "Skip",
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppColors.primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),

              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 10),
                    Text(
                      "Welcome to CallTrack",
                      textAlign: TextAlign.center,
                      style: theme.titleLarge?.copyWith(
                        color: AppColors.textPrimary,
                        fontWeight: FontWeight.bold,
                        fontSize: 32,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Center(
                      child: Container(
                        width: 280,
                        height: 280,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          image: const DecorationImage(
                            image: NetworkImage(
                              "https://www.telecmi.com/v2/images/features/callmasking.webp",
                            ),
                            fit: BoxFit.contain,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),

                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Close Faster , Call Smarter.",
                          textAlign: TextAlign.center,

                          style: theme.titleLarge?.copyWith(
                            color: AppColors.textPrimary,
                            fontWeight: FontWeight.bold,
                            // fontSize: 32,
                          ),
                        ),
                      ],
                    ),
                    const WidgetGap(),

                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Text(
                        "With CallTrack, you can easily track every sales call, understand key performance metrics, and make informed decisions that support consistent sales growth.",
                        textAlign: TextAlign.justify,

                        style: theme.bodyMedium?.copyWith(
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              //------------------------------------
              // BOTTOM BUTTON
              //------------------------------------
              Padding(
                padding: const EdgeInsets.only(bottom: 20),
                child: SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: SwipeButton(
                    thumb: const Icon(Icons.arrow_forward, color: AppColors.card),

                    activeThumbColor: AppColors.primary,
                    activeTrackColor: AppColors.primary.withOpacity(0.15),

                    // When swipe completed
                    onSwipeEnd: controller.next,

                    child: Text(
                      "Get Started",
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  //--------------------------------------------
  // DOT WIDGET (MATCHES HTML EXACT)
  //--------------------------------------------
  Widget _dot({required bool active}) => AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      width: active ? 32 : 8,
      height: 8,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: active ? AppColors.primary : AppColors.primary.withOpacity(0.3),
      ),
    );
}
