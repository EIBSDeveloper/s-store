import 'package:itracker/src/core/app_colors.dart';
import 'package:itracker/src/core/app_style.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../app.dart';
import '../../../../utils/routes/app_pages.dart';
import '../../controller/onboarding_controller.dart';

class AppSettingsScreen extends GetView<OnboardingController> {
  const AppSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context).textTheme;
    final isDark = Get.isDarkMode;

    return Scaffold(
      backgroundColor: isDark ? AppColors.backgroundDark : AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _header(),

            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("App Settings", style: theme.titleLarge),
                    const SizedBox(height: 8),
                    Text(
                      "Customize your experience. These settings can be changed later.",
                      textAlign: TextAlign.justify,
                      style: theme.bodyMedium?.copyWith(
                        color: isDark
                            ? AppColors.textLight
                            : AppColors.textSecondary,
                      ),
                    ),

                    const SizedBox(height: 8),

                    _card(
                      isDark,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _iconTitle(
                            isDark,
                            icon: Icons.schedule,
                            title: "Time Format",
                            subtitle: "Choose 12-hour or 24-hour format.",
                          ),
                          const SizedBox(height: 8),

                          Obx(
                            () => Row(
                              children: [
                                Expanded(
                                  child: _optionButton(
                                    text: "12-hour",
                                    isSelected: controller.is12Hour.value,
                                    onTap: () =>
                                        controller.changeTimeFormat(true),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: _optionButton(
                                    text: "24-hour",
                                    isSelected: !controller.is12Hour.value,
                                    onTap: () =>
                                        controller.changeTimeFormat(false),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 8),

                    _card(
                      isDark,
                      child: Row(
                        children: [
                          Expanded(
                            child: _iconTitle(
                              isDark,
                              icon: Icons.public,
                              title: "Timezone",
                              subtitle: "Select your local timezone.",
                            ),
                          ),
                          Row(
                            children: [
                              Text(
                                "GMT-5:00",
                                style: theme.bodySmall?.copyWith(
                                  color: isDark
                                      ? AppColors.textLight
                                      : AppColors.textSecondary,
                                ),
                              ),
                              const SizedBox(width: 4),
                              Icon(
                                Icons.arrow_forward_ios,
                                size: 16,
                                color: isDark
                                    ? AppColors.textLight
                                    : Colors.grey,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 8),

                    _card(
                      isDark,
                      child: Row(
                        children: [
                          Expanded(
                            child: _iconTitle(
                              isDark,
                              icon: Icons.translate,
                              title: "Language",
                              subtitle: "Choose your preferred language.",
                            ),
                          ),
                          Row(
                            children: [
                              Text(
                                "English (US)",
                                style: theme.bodySmall?.copyWith(
                                  color: isDark
                                      ? AppColors.textLight
                                      : AppColors.textSecondary,
                                ),
                              ),
                              const SizedBox(width: 4),
                              const Icon(
                                Icons.arrow_forward_ios,
                                size: 16,
                                color: Colors.grey,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 8),

                    _card(
                      isDark,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _iconTitle(
                            isDark,
                            icon: Icons.format_size,
                            title: "Font Size",
                            subtitle:
                                "Adjust text size for better readability.",
                          ),

                          // const SizedBox(height: 8),
                          Obx(
                            () => Slider(
                              value: controller.fontSize.value,
                              min: 0,
                              max: 100,
                              activeColor: AppColors.primary,
                              padding: const EdgeInsets.symmetric(
                                vertical: 10,
                                horizontal: 10,
                              ),
                              inactiveColor: AppColors.primary10(0.4),
                              onChanged: controller.changeFontSize,
                            ),
                          ),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("Small", style: theme.bodySmall),
                              Text("Default", style: theme.bodySmall),
                              Text("Large", style: theme.bodySmall),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            _finishButton(),
          ],
        ),
      ),
    );
  }

  // ----------------- UI COMPONENTS ----------------------

  Widget _header() => Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              _dot(false),
              const SizedBox(width: 6),
              _dot(false),
              const SizedBox(width: 6),
              _bar(),
            ],
          ),
          TextButton(
            onPressed: controller.skip,
            child: Text(
              "Skip",
              style: Theme.of(navigatorKey.currentContext!).textTheme.bodyMedium
                  ?.copyWith(
                    color: AppColors.primary,
                    fontWeight: FontWeight.bold,
                  ),
            ),
          ),
        ],
      ),
    );

  Widget _dot(bool active) => Container(
      height: 8,
      width: 8,
      decoration: BoxDecoration(
        color: active ? AppColors.primary : AppColors.primary10(0.3),
        borderRadius: BorderRadius.circular(50),
      ),
    );

  Widget _bar() => Container(
      height: 8,
      width: 32,
      decoration: BoxDecoration(
        color: AppColors.primary,
        borderRadius: BorderRadius.circular(50),
      ),
    );

  Widget _finishButton() => Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      child: SizedBox(
        height: 56,
        width: double.infinity,
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primary,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(AppStyle.borderRadiusBox),
            ),
          ),
          onPressed: () {
            navigatorKey.currentState!.pushNamedAndRemoveUntil(
              RouteNames.home,
              (Route<dynamic> route) => false,
            );
          },
          child: Text(
            "Finish Setup",
            style: Theme.of(
              navigatorKey.currentContext!,
            ).textTheme.bodyMedium?.copyWith(color: AppColors.card),
          ),
        ),
      ),
    );

  Widget _card(bool isDark, {required Widget child}) => Container(
      padding: const EdgeInsets.all(10),
      decoration: AppStyle.decoration,
      child: child,
    );

  Widget _iconTitle(
    bool isDark, {
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    final theme = Theme.of(navigatorKey.currentContext!).textTheme;

    return Row(
      children: [
        Container(
          height: 48,
          width: 48,
          decoration: BoxDecoration(
            color: AppColors.primary.withAlpha(20),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: AppColors.primary, size: AppStyle.iconSize),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: theme.bodyMedium?.copyWith(fontWeight: FontWeight.bold),
              ),
              Text(subtitle, style: theme.bodySmall),
            ],
          ),
        ),
      ],
    );
  }

  Widget _optionButton({
    required bool isSelected,
    required String text,
    required VoidCallback onTap,
  }) {
    final theme = Theme.of(navigatorKey.currentContext!).textTheme;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 30,
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primary : AppColors.card,
          borderRadius: BorderRadius.circular(50),
          border: Border.all(color: AppColors.primary),
        ),
        alignment: Alignment.center,
        child: Text(
          text,
          style: theme.bodyMedium?.copyWith(
            color: isSelected ? Colors.white : AppColors.textPrimary,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
