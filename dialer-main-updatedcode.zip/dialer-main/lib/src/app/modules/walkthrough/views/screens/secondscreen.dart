// lib/modules/permissions/permission_screen.dart

import 'package:flutter/services.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:itracker/src/core/app_style.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../../../widgets/widget_gap.dart';
import '../../controller/onboarding_controller.dart';

class PermissionScreen extends StatefulWidget {
  const PermissionScreen({super.key});

  @override
  State<PermissionScreen> createState() => _PermissionScreenState();
}

class _PermissionScreenState extends State<PermissionScreen>
    with WidgetsBindingObserver {
  final OnboardingController controller = Get.find();
  static const MethodChannel _roleChannel = MethodChannel(
    'app.call_manager/role',
  );

  bool _hasCallPermission = false;
  bool _hasContactsPermission = false;
  bool _isDefaultDialer = false;
  bool _isRequestingDefaultDialer = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initializeState();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.resumed) {
      _checkPermissions();
      _refreshDefaultDialerStatus();
    }
  }

  Future<void> _initializeState() async {
    await _checkPermissions();
    await _refreshDefaultDialerStatus();
  }

  // Check existing permissions
  Future<void> _checkPermissions() async {
    final PermissionStatus phoneStatus = await Permission.phone.status;
    final PermissionStatus contactsStatus = await Permission.contacts.status;

    debugPrint('Phone permission status (check): $phoneStatus');
    debugPrint('Contacts permission status (check): $contactsStatus');

    if (!mounted) return;
    setState(() {
      _hasCallPermission = phoneStatus.isGranted;
      _hasContactsPermission = contactsStatus.isGranted;
    });
  }

  Future<void> _refreshDefaultDialerStatus() async {
    try {
      debugPrint('🔄 Refreshing default dialer state...');
      final bool? isDefault = await _roleChannel.invokeMethod<bool>(
        'isDefaultDialer',
      );
      debugPrint('📱 Is default dialer: $isDefault');
      if (!mounted) return;
      setState(() {
        _isDefaultDialer = isDefault ?? false;
      });
    } on PlatformException catch (error) {
      debugPrint('❌ Default dialer check failed: $error');
      if (!mounted) return;
      setState(() {
        _isDefaultDialer = false;
      });
    }
  }

  Future<void> _handlePhonePermissionTap() async {
    final PermissionStatus status = await Permission.phone.request();
    debugPrint('Phone permission status (tap): $status');

    if (status.isGranted) {
      await _checkPermissions();
      return;
    }

    if (status.isPermanentlyDenied) {
      _showSnackBar(
        'Phone permission permanently denied. Enable it in Settings.',
      );
      await openAppSettings();
    } else {
      _showSnackBar('Phone permission required to continue.');
    }

    await _checkPermissions();
  }

  Future<void> _handleContactsPermissionTap() async {
    final PermissionStatus status = await Permission.contacts.request();
    debugPrint('Contacts permission status (tap): $status');

    if (status.isGranted) {
      await _checkPermissions();
      return;
    }

    if (status.isPermanentlyDenied) {
      _showSnackBar(
        'Contacts permission permanently denied. Enable it in Settings.',
      );
      await openAppSettings();
    } else {
      _showSnackBar('Contacts permission required to continue.');
    }

    await _checkPermissions();
  }

  // Request permissions through batch toggle
  Future<void> _requestPermissions() async {
    final Map<Permission, PermissionStatus> statuses = await <Permission>[
      Permission.phone,
      Permission.contacts,
    ].request();

    final PermissionStatus phoneStatus =
        statuses[Permission.phone] ?? PermissionStatus.denied;
    final PermissionStatus contactsStatus =
        statuses[Permission.contacts] ?? PermissionStatus.denied;

    debugPrint('Phone permission status (batch): $phoneStatus');
    debugPrint('Contacts permission status (batch): $contactsStatus');

    if (mounted) {
      setState(() {
        _hasCallPermission = phoneStatus.isGranted;
        _hasContactsPermission = contactsStatus.isGranted;
      });
    }

    if (phoneStatus.isGranted && contactsStatus.isGranted) {
      if (!mounted) return;
      controller.next();
      return;
    }

    if (phoneStatus.isPermanentlyDenied || contactsStatus.isPermanentlyDenied) {
      _showSnackBar('Permissions permanently denied. Enable them in Settings.');
      await openAppSettings();
    } else {
      _showSnackBar('Permissions required to continue.');
    }

    await _checkPermissions();
  }

  Future<void> _requestSetDefaultDialer() async {
    if (_isRequestingDefaultDialer) return;

    setState(() => _isRequestingDefaultDialer = true);
    try {
      debugPrint('📞 Requesting default dialer role via MethodChannel...');
      final bool? result = await _roleChannel.invokeMethod<bool>(
        'requestDefaultDialer',
      );
      debugPrint('✅ Default dialer request result: $result');
      await Future.delayed(const Duration(seconds: 1));
      await _refreshDefaultDialerStatus();
      if (result != true) {
        _showSnackBar('Please set this app as your default phone app.');
      }
    } on PlatformException catch (error, stackTrace) {
      debugPrint('❌ Default dialer request failed: $error');
      debugPrint('$stackTrace');
      _showSnackBar('Error requesting default dialer.');
    } catch (error, stackTrace) {
      debugPrint('❌ Unexpected error requesting default dialer: $error');
      debugPrint('$stackTrace');
      _showSnackBar('Error requesting default dialer.');
    } finally {
      if (mounted) {
        setState(() => _isRequestingDefaultDialer = false);
      }
    }
  }

  void _showSnackBar(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: const Color(0xFFEF5350),
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    const bool notificationsEnabled = false;
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      _dot(false),
                      const SizedBox(width: 6),
                      _dot(true), // Active dot
                      const SizedBox(width: 6),
                      _dot(false),
                    ],
                  ),
                  // TextButton(
                  //   onPressed: controller.skip,
                  //   child: Text(
                  //     "Skip",
                  //     style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  //       color: AppColors.primary,
                  //       fontWeight: FontWeight.bold,
                  //     ),
                  //   ),
                  // ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "App Permissions",
                      style: textTheme.titleLarge?.copyWith(
                        color: AppColors.textPrimary,

                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),

                    Text(
                      "To work correctly, CallTrack needs a few permissions. Your data is always secure and private.",
                      textAlign: TextAlign.justify,
                      style: textTheme.bodyMedium?.copyWith(
                        color: AppColors.textSecondary,
                      ),
                    ),
                    const WidgetGap(),
                    _permissionTile(
                      icon: HugeIcons.strokeRoundedCall02,
                      title: "Phone Acces",
                      subtitle:
                          "To identify callers and manage incoming/outgoing calls.",
                      toggle: _hasCallPermission,
                      onToggle: _handlePhonePermissionTap,
                    ),
                    const WidgetGap(),

                    // _permissionTile(
                    //   icon: HugeIcons.strokeRoundedAlbum01,
                    //   title: "App Overlay",
                    //   subtitle: "For caller ID popups.",
                    //   toggle: controller.overlay,
                    //   onToggle: controller.toggleOverlay,
                    // ),
                    // WidgetGap(),
                    _permissionTile(
                      icon: HugeIcons.strokeRoundedContact01,
                      title: "Contacts",
                      subtitle:
                          "To display contact names for your call history.",
                      toggle: _hasContactsPermission,
                      onToggle: _handleContactsPermissionTap,
                    ),
                    const WidgetGap(),

                    _permissionTile(
                      icon: HugeIcons.strokeRoundedNotification01,
                      title: "Notifications",
                      subtitle: "For call reminders.",
                      toggle: notificationsEnabled,
                      onToggle: () {},
                    ),
                    const WidgetGap(),

                    _permissionTile(
                      icon: HugeIcons.strokeRoundedHome01,
                      title: "Set as Default",
                      subtitle: 'Make this app your primary call manager.',
                      toggle: _isDefaultDialer,
                      onToggle: _requestSetDefaultDialer,
                    ),

                    const WidgetGap(),
                    const WidgetGap(),
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: ElevatedButton(
                        onPressed: _requestPermissions,

                        style: ElevatedButton.styleFrom(
                          elevation: 0,
                          backgroundColor: AppColors.primary.withAlpha(30),
                          foregroundColor: AppColors.primary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(
                              AppStyle.borderRadiusBox,
                            ),
                          ),
                        ),
                        child: Text(
                          "Allow All",
                          style: textTheme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: AppColors.primary,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.only(
                left: 10,
                right: 10,
                bottom: 20,
                top: 10,
              ),
              child: SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed:
                      ( _isDefaultDialer &&
                          _hasContactsPermission & _hasCallPermission)
                      ? controller.next
                      : null,

                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                          AppColors.primary
                       ,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                        AppStyle.borderRadiusBox,
                      ),
                    ),
                  ),
                  child: Text(
                    "Continue",
                    style: textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: AppColors.card,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  //----------------------------------------------------------
  Widget _dot(bool active) => AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      width: active ? 32 : 8,
      height: 8,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: active ? AppColors.primary : AppColors.primary.withOpacity(0.3),
      ),
    );

 
  Widget _permissionTile({
    required List<List<dynamic>> icon,
    required String title,
    required String subtitle,
    required bool toggle,
    required VoidCallback onToggle,
  }) {
    final textTheme = Theme.of(context).textTheme;

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: AppStyle.decoration,
      child: Row(
        children: [
          Container(
            height: 48,
            width: 48,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.primary.withAlpha(30),
              borderRadius: BorderRadius.circular(40),
            ),
            child: HugeIcon(
              icon: icon,
              color: AppColors.primary,
              size: AppStyle.iconSize,
            ),

            //  Icon(icon, color: , size: AppStyle.iconSize),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  maxLines: 2,
                  style: textTheme.bodySmall?.copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: onToggle,
            child: Container(
              width: 50,
              height: 26,
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                color: toggle ? AppColors.primary : Colors.grey.shade400,
                borderRadius: BorderRadius.circular(40),
              ),
              child: AnimatedAlign(
                duration: const Duration(milliseconds: 200),
                alignment: toggle
                    ? Alignment.centerRight
                    : Alignment.centerLeft,
                child: Container(
                  width: 18,
                  height: 18,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(40),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
