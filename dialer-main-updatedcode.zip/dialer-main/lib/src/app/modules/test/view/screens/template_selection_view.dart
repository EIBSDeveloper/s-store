import 'package:hugeicons/hugeicons.dart';
import 'package:itracker/src/app/widgets/widget_gap.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../../../app.dart';
import '../../../../../core/app_colors.dart';
import '../../../../../core/app_style.dart';
import '../../../../utils/utils.dart';
import '../../../../widgets/bottom_sheet_syle.dart';
import '../../../../widgets/input_card_style.dart';
import '../../controller/template_controller.dart';
import '../../model/template_model.dart';

class TemplateBottomSheet extends GetView<TemplateController> {
  const TemplateBottomSheet({super.key});

  @override
  Widget build(BuildContext context) => BottomSheetStyle(
    child: Column(
      children: [
        // Header
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            children: [
              const SizedBox(width: 8),
              Text(
                'Selection',
                style: Theme.of(
                  context,
                ).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),

        // Search field
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: InputCardStyle(
            child: TextFormField(
              decoration: InputDecoration(
                hintText: 'Search',
                hintStyle: Theme.of(context).textTheme.bodySmall,
                prefixIcon: Icon(
                  Icons.search,
                  color: Theme.of(
                    context,
                  ).colorScheme.onSurface.withOpacity(0.6),
                ),
                border: InputBorder.none,
              ),
              onChanged: controller.searchTemplates,
              textInputAction: TextInputAction.search,
            ),
          ),
        ),
        const WidgetGap(),
        // Template list
        _buildTemplateList(),
      ],
    ),
  );

  Widget _buildTemplateList() => Obx(() {
    if (controller.isLoading && controller.templates.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }

    if (controller.filteredTemplates.isEmpty) {
      return Center(
        child: Text(
          controller.isSearching ? 'No Results'.tr : 'No Templates'.tr,
          style: Theme.of(navigatorKey.currentContext!).textTheme.bodyMedium
              ?.copyWith(
                color: Theme.of(
                  navigatorKey.currentContext!,
                ).colorScheme.onSurface.withOpacity(0.6),
              ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Column(
        children: [
         ... controller.filteredTemplates.map((template)=> _buildTemplateCard(template))
        ],
      ),
    );

    
  });

  Widget _buildTemplateCard(TemplateModel template) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => controller.selectTemplate(template),
      child: Container(
        decoration: AppStyle.decoration,
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    template.title,
                    style: Theme.of(
                      navigatorKey.currentContext!,
                    ).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold),
                  ),
                ),
                _buildActionIcons(template),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              template.message,
              style: Theme.of(navigatorKey.currentContext!).textTheme.bodySmall
                  ?.copyWith(
                    color: Theme.of(
                      navigatorKey.currentContext!,
                    ).colorScheme.onSurface.withOpacity(0.8),
                  ),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    ),
  );

  Widget _buildActionIcons(TemplateModel template) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      const SizedBox(width: 10),

      InkWell(
        onTap: () {
          openSMS("+918608080510", message: template.message);
        },
        child: HugeIcon(
          icon: HugeIcons.strokeRoundedBubbleChat,
          color: AppColors.primary,
          size: AppStyle.iconSizelarge,
        ),
      ),
      const SizedBox(width: 20),

      InkWell(
        onTap: () {
          openWhatsApp("+918608080510", message: template.message);
        },
        child: const HugeIcon(
          icon: HugeIcons.strokeRoundedWhatsapp,
          color: AppColors.secondary,
          size: AppStyle.iconSizelarge,
        ),
      ),
    ],
  );
}
