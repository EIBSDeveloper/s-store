import 'package:get/get.dart';
import 'package:itracker/src/app/modules/addressbook/model/addressbook.dart';
import 'package:itracker/src/app/modules/addressbook/repo/addressRepo.dart';

class AddressbookController extends GetxController {
  final AddressbookRepository _repo = AddressbookRepository();
  RxList<AddressbookModel> addressbooklist = <AddressbookModel>[].obs;
  var expandedCardId = Rxn<int>(); // null = none expanded

  void toggleExpand(int id) {
    if (expandedCardId.value == id) {
      expandedCardId.value = null; // collapse if already expanded
    } else {
      expandedCardId.value = id; // expand this card
    }
  }

  @override
  void onInit() {
    super.onInit();
    fetchcontactlist();
    //fetchAddressbookLists();
  }

  /*  Future<void> fetchAddressbookLists() async {
    try {
      final result = await _repo.getAddressbookList();
      addressbooklist.assignAll(result);
    } catch (e) {
      print("Error: $e");
    }
  }*/

  RxList<Map<String, dynamic>> contactlist = <Map<String, dynamic>>[].obs;

  // Simulate fetching from API by using dummy JSON in-app
  Future<void> fetchcontactlist() async {
    try {
      // Dummy JSON data with reason field
      final List<Map<String, dynamic>> dummy = [
        {
          "id": 1,
          "callerName": "Ravi Kumar",
          "callerMobileNo": "+91 98765 43210",
          "status": "active",
          "tags": ["Customer", "Retail"],
          "source": "Website",
          "assignedFrom": "Suresh",
          "assignedTo": "Meena",
          "avatar": "https://i.pravatar.cc/150?img=3",
          "reason": "Customer requested a callback regarding the new package.",
        },
        {
          "id": 2,
          "callerName": "Anita Singh",
          "callerMobileNo": "+91 91234 56789",
          "status": "inactive",
          "tags": ["Lead", "Enterprise"],
          "source": "Referral",
          "assignedFrom": "Ramesh",
          "assignedTo": "Ajay",
          "avatar": "https://i.pravatar.cc/150?img=5",
          "reason": "Follow-up pending for contract renewal.",
        },
        {
          "id": 3,
          "callerName": "Karthik R",
          "callerMobileNo": "+91 99887 66554",
          "status": "active",
          "tags": ["Marketing", "Lead"],
          "source": "Walk-in",
          "assignedFrom": "Admin",
          "assignedTo": "Priya",
          "avatar": "https://i.pravatar.cc/150?img=7",
          "reason": "Interested in the marketing workshop next week.",
        },
        {
          "id": 4,
          "callerName": "Ravi Kumar",
          "callerMobileNo": "+91 98765 43210",
          "status": "active",
          "tags": ["Customer", "Retail"],
          "source": "Website",
          "assignedFrom": "Suresh",
          "assignedTo": "Meena",
          "avatar": "https://i.pravatar.cc/150?img=3",
          "reason": "Requested invoice for last order.",
        },
        {
          "id": 5,
          "callerName": "Anita Singh",
          "callerMobileNo": "+91 91234 56789",
          "status": "inactive",
          "tags": ["Lead", "Enterprise"],
          "source": "Referral",
          "assignedFrom": "Ramesh",
          "assignedTo": "Ajay",
          "avatar": "https://i.pravatar.cc/150?img=5",
          "reason": "Needs confirmation about service dates.",
        },
        {
          "id": 6,
          "callerName": "Karthik R",
          "callerMobileNo": "+91 99887 66554",
          "status": "active",
          "tags": ["Marketing", "Lead"],
          "source": "Walk-in",
          "assignedFrom": "Admin",
          "assignedTo": "Priya",
          "avatar": "https://i.pravatar.cc/150?img=7",
          "reason": "Interested in premium membership plans.",
        },
      ];

      // Simulate network delay (optional)
      await Future.delayed(const Duration(milliseconds: 300));

      contactlist.assignAll(dummy);
    } catch (e) {
      print("Error loading dummy addressbook: $e");
    }
  }
}
