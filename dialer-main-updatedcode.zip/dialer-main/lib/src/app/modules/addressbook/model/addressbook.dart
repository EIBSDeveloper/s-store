class AddressbookModel {
  final int callerId;
  final String callerName;
  final String callerMobileNo;

  AddressbookModel({
    required this.callerId,
    required this.callerName,
    required this.callerMobileNo,
  });

  factory AddressbookModel.fromJson(Map<String, dynamic> json) => AddressbookModel(
      callerId: json['caller_id'] ?? 0,
      callerName: json['caller_name'] ?? '',
      callerMobileNo: json['caller_mobile_no'] ?? '',
    );
}
