import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:itracker/src/app/modules/addressbook/controller/addressbookcontroller.dart';
import 'package:itracker/src/app/modules/addressbook/view/widgets/customer_card.dart';
import 'package:itracker/src/app/widgets/appsearch_bar.dart';
import 'package:itracker/src/core/app_colors.dart';

import '../../../../../../app.dart';
import '../../../../../core/app_style.dart';
import '../../../../controller/app_controller.dart';
import '../../../../utils/routes/app_pages.dart';
import '../../../../widgets/widget_gap.dart';

class CustomerScreen extends GetView<AddressbookController> {
  CustomerScreen({super.key});

  final AppDataController appDeta = Get.find();

  @override
  Widget build(BuildContext context) {
    final isDark = Get.isDarkMode;
    int role = appDeta.roleId.value;
    return Scaffold(
      backgroundColor: isDark ? AppColors.backgroundDark : AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            // HEADER
            const AppSearchBar(),

            if (role == 2) ...[
              const WidgetGap(),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: SizedBox(
                  height: 35,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      _filterChip("All POS", selected: true, isDark: isDark),
                      const SizedBox(width: 10),
                      _filterChip("Proposal Status", isDark: isDark),
                      const SizedBox(width: 10),
                      _filterChip("Reminder Status", isDark: isDark),
                    ],
                  ),
                ),
              ),
            ] else ...[
              const WidgetGap(),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: SizedBox(
                  height: 35,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      _filterChip("All", selected: true),
                      const SizedBox(width: 10),
                      _filterChip("CRM"),
                      const SizedBox(width: 10),
                      _filterChip("Assign to"),
                      const SizedBox(width: 10),
                      _filterChip("Address book"),
                    ],
                  ),
                ),
              ),
            ],
            const WidgetGap(),
            Expanded(
              child: Obx(
                () => RefreshIndicator(
                  onRefresh: () async {
                    await controller.fetchcontactlist();
                  },
                  child: controller.contactlist.isEmpty
                      ? ListView(
                          physics: const AlwaysScrollableScrollPhysics(),
                          children: const [
                            SizedBox(
                              height: 200,
                              child: Center(child: Text("No contacts found")),
                            ),
                          ],
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          itemCount: controller.contactlist.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 10),
                          itemBuilder: (context, index) {
                            final caller = controller.contactlist[index];
                            return CustomerCard(address: caller);
                          },
                        ),
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushNamed(context, RouteNames.addLead);
        },
        backgroundColor: AppColors.primary,
        child: const HugeIcon(
          icon: HugeIcons.strokeRoundedUserAdd02,
          color: AppColors.card,
          size: AppStyle.iconSizelarge,
        ),
      ),
    );
  }

  // Filter Chip Widget
  Widget _filterChip(
    String label, {
    bool selected = false,
    bool isDark = false,
  }) {
    final theme = Theme.of(navigatorKey.currentContext!).textTheme;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: AppStyle.decoration.copyWith(
        color: selected ? AppColors.primary : AppColors.card,
        borderRadius: BorderRadius.circular(AppStyle.borderRadiusClip),
      ),
      child: Row(
        children: [
          Text(
            label,
            style: theme.bodyMedium?.copyWith(
              color: selected ? AppColors.card : AppColors.textDark,
            ),
          ),
          const SizedBox(width: 4),
          Icon(
            Icons.expand_more,
            color: selected ? AppColors.card : AppColors.textDark,
            size: AppStyle.iconSize,
          ),
        ],
      ),
    );
  }
}
