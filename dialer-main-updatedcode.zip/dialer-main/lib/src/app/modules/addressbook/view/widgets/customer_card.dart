import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:itracker/src/app/modules/addressbook/controller/addressbookcontroller.dart';
import 'package:itracker/src/app/modules/callLogs/views/widgets/tag_card.dart';
import 'package:itracker/src/app/utils/routes/app_pages.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:itracker/src/core/app_style.dart';

import '../../../../../../bottom_sheet.dart';
import '../../../../../../tt.dart';

class CustomerCard extends StatefulWidget {
  final Map<String, dynamic> address;

  CustomerCard({required this.address, Key? key}) : super(key: key);

  @override
  State<CustomerCard> createState() => _CustomerCardState();
}

class _CustomerCardState extends State<CustomerCard> {
  List<Tag> selectedTags = [];
  final controller = Get.put(AddressbookController());
  void showTagBottomSheet() async {
    final controller = Get.put(TagController());
    controller.clearSelections();
    await openButtomsheet(TagBottomSheet());
    setState(() {
      selectedTags = controller.tags.where((tag) => tag.isSelected).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Get.isDarkMode;
    final theme = Theme.of(context).textTheme;
    final reason = widget.address['reason'] ?? 'No reason provided';
    final callerName = widget.address['callerName'] ?? 'Unknown';
    final status = (widget.address['status'] ?? 'inactive')
        .toString()
        .toLowerCase();
    final tags = List<String>.from(widget.address['tags'] ?? []);
    final source = widget.address['source'] ?? '';
    final assignedFrom = widget.address['assignedFrom'] ?? '';
    final assignedTo = widget.address['assignedTo'] ?? '';
    final avatarUrl = widget.address['avatar'] ?? null;

    return GestureDetector(
      onTap: () {
        // keep navigation behaviour similar to before
        Navigator.pushNamed(
          context,
          '/leadsDetails',
        ); // adjust route name if needed
      },
      child: Container(
        decoration: isDark ? AppStyle.decorationDark : AppStyle.decoration,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Status vertical bar
            Container(
              width: 6,
              height: 70, // same as avatar height
              decoration: BoxDecoration(
                color: status == 'active' ? Colors.green : Colors.red,
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            const SizedBox(width: 10),
            // Avatar with status dot
            InkWell(
              onTap: () {
                Navigator.pushNamed(context, RouteNames.leadsDetails);
              },
              child: Container(
                margin: EdgeInsets.symmetric(vertical: 8),
                height: 50,
                width: 50,
                decoration: const BoxDecoration(shape: BoxShape.circle),
                child: ClipOval(
                  child: avatarUrl != null
                      ? Image.network(
                          avatarUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                              Container(color: Colors.grey[300]),
                        )
                      : Container(color: Colors.grey[300]),
                ),
              ),
            ),

            const SizedBox(width: 12),

            // Name + Mobile + details
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // name + status
                  Row(
                    children: [
                      Text(
                        callerName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: theme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: isDark ? Colors.white : AppColors.textDark,
                        ),
                      ),
                      SizedBox(width: 10),
                      if (source != '')
                        Text(
                          "($source)",
                          style: theme.bodySmall?.copyWith(
                            color: isDark
                                ? Colors.grey[300]
                                : AppColors.textSecondary,
                          ),
                        ),
                    ],
                  ),

                  // tags
                  if (tags.isNotEmpty)
                    SizedBox(
                      height: 28,
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Transform.translate(
                          offset: const Offset(
                            -5.0,
                            0.0,
                          ), // shift 50 pixels to the left
                          child: Row(
                            children: [
                              // Map tags from JSON
                              ...tags.map((t) {
                                Color tagColor =
                                    {
                                      'Customer': Colors.orange,
                                      'Finance': Colors.blueGrey,
                                      'Retail': Colors.teal,
                                      'Lead': Colors.red,
                                      'Enterprise': Colors.grey,
                                      'Marketing': Colors.purple,
                                    }[t] ??
                                    Colors.grey;

                                return TagCard(
                                  lable: t,
                                  color: tagColor,
                                  onTap: () => print("Tapped tag: $t"),
                                );
                              }).toList(),

                              // Map selected tags
                              ...selectedTags.map(
                                (tag) => TagCard(
                                  lable: tag.label,
                                  color: tag.color,
                                  onTap: () {},
                                ),
                              ),

                              // “+” button to add more tags
                              TagCard(
                                lable: "",
                                color: Colors.blue,
                                icon: Icons.add,
                                onTap: showTagBottomSheet,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                  const SizedBox(height: 8),

                  // source + assigned from/to
                  Row(
                    children: [
                      if (assignedFrom != '')
                        Flexible(
                          child: Text(
                            "From: $assignedFrom",
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: theme.bodySmall?.copyWith(
                              color: isDark
                                  ? Colors.grey[300]
                                  : AppColors.textSecondary,
                            ),
                          ),
                        ),
                      const SizedBox(width: 12),
                      if (assignedTo != '')
                        Text(
                          "To: $assignedTo",
                          style: theme.bodySmall?.copyWith(
                            color: isDark
                                ? Colors.grey[300]
                                : AppColors.textSecondary,
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 4),

                  // Reason with expand/collapse
                  Obx(() {
                    final id = widget.address["id"];
                    final reason = widget.address["reason"] ?? "";

                    bool isExpanded = controller.expandedCardId.value == id;

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Text(
                                "Reason: $reason",
                                maxLines: isExpanded ? null : 1,
                                overflow: isExpanded
                                    ? TextOverflow.visible
                                    : TextOverflow.ellipsis,
                                style: theme.bodySmall?.copyWith(
                                  color: isDark
                                      ? Colors.grey[300]
                                      : AppColors.textSecondary,
                                ),
                              ),
                            ),
                            GestureDetector(
                              onTap: () => controller.toggleExpand(id),
                              child: Icon(
                                isExpanded
                                    ? Icons.keyboard_arrow_up
                                    : Icons.keyboard_arrow_down,
                                size: 22,
                              ),
                            ),
                          ],
                        ),
                        if (isExpanded)
                          const SizedBox(
                            height: 8,
                          ), // optional spacing when expanded
                      ],
                    );
                  }),
                ],
              ),
            ),

            // Call Icon
            Container(
              height: 44,
              width: 44,
              decoration: BoxDecoration(
                color: AppColors.primary10(0.1),
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.primary.withAlpha(100)),
              ),
              child: Icon(
                Icons.call,
                color: AppColors.primary,
                size: AppStyle.iconSize,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
