import 'dart:convert';

import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:itracker/src/app/controller/app_controller.dart';
import 'package:itracker/src/app/modules/addressbook/model/addressbook.dart';
import 'package:itracker/src/app/utils/apiconstants.dart';

class AddressbookRepository {
  final appData = Get.find<AppDataController>();

  Future<List<AddressbookModel>> getAddressbookList() async {
    final url = "${appData.baseUrl}${ApiConstants.calllist}";

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final body = jsonDecode(response.body);
      final List list = body["data"];

      return list.map((e) => AddressbookModel.fromJson(e)).toList();
    } else {
      throw Exception("Failed to load caller list");
    }
  }
}
