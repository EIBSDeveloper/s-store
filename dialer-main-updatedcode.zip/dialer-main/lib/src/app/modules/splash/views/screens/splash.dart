import 'package:itracker/src/app/modules/splash/controller/splashcontroller.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Splashscreen extends GetView<SplashController> {
  const Splashscreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context).textTheme;
    final size = MediaQuery.of(context).size;
    final h = size.height;
    final w = size.width;

    return Scaffold(
      backgroundColor: Get.isDarkMode
          ? AppColors.backgroundDark
          : AppColors.background,

      body: Center(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: w * 0.08),

          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // ---------- LOGO ANIMATION ----------
              TweenAnimationBuilder(
                tween: Tween<double>(begin: 0, end: 1),
                duration: const Duration(milliseconds: 900),
                curve: Curves.easeOut,
                builder: (context, value, child) => Transform.translate(
                    offset: Offset(0, 40 * (1 - value)),
                    child: Opacity(opacity: value, child: child),
                  ),
                child: Container(
                  width: w * 0.27,
                  height: w * 0.27,
                  decoration: BoxDecoration(
                    color: AppColors.primary,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Icon(
                    Icons.phone_in_talk,
                    color: Colors.white,
                    size: w * 0.15,
                  ),
                ),
              ),

              SizedBox(height: h * 0.03),

              // ---------- TITLE + TAGLINE ----------
              Column(
                children: [
                  Text(
                    "CallTracker",
                    style: theme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                      fontSize: w * 0.09,
                      color: Get.isDarkMode
                          ? AppColors.textLight
                          : AppColors.textPrimary,
                    ),
                  ),
                  SizedBox(height: h * 0.008),
                  Text(
                    "Track. Analyze. Sell.",
                    style: theme.bodyMedium?.copyWith(
                      color: Get.isDarkMode
                          ? AppColors.textLight.withOpacity(0.7)
                          : AppColors.textSecondary,
                      fontSize: w * 0.042,
                    ),
                  ),
                ],
              ),

              SizedBox(height: h * 0.065),

              // ---------- PROGRESS + ANIMATED BAR ----------
              Obx(() => Column(
                  children: [
                    Text(
                      "Initializing...",
                      textAlign: TextAlign.center,
                      style: theme.bodySmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        fontSize: w * 0.035,
                        color: Get.isDarkMode
                            ? AppColors.textLight.withOpacity(0.7)
                            : AppColors.textSecondary,
                      ),
                    ),

                    SizedBox(height: h * 0.015),

                    // OUTER PROGRESS BAR WITH GLOW EFFECT
                    Container(
                      height: h * 0.014,
                      width: w * 0.65,
                      decoration: BoxDecoration(
                        color: Get.isDarkMode
                            ? AppColors.accent.withOpacity(0.3)
                            : AppColors.border,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.primary.withOpacity(0.25),
                            blurRadius: 15,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                      child: Stack(
                        children: [
                          // ANIMATED PROGRESS
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            width: (w * 0.65) * controller.progress.value,
                            decoration: BoxDecoration(
                              color: AppColors.primary,
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                        ],
                      ),
                    ),

                    SizedBox(height: h * 0.03),

                    // ---------- ROUND SPINNING INDICATOR ----------
                    // SizedBox(
                    //   height: 26,
                    //   width: 26,
                    //   child: CircularProgressIndicator(
                    //     strokeWidth: 3.2,
                    //     valueColor: AlwaysStoppedAnimation<Color>(
                    //       AppColors.primary,
                    //     ),
                    //   ),
                    // ),
                  ],
                )),
            ],
          ),
        ),
      ),
    );
  }
}
