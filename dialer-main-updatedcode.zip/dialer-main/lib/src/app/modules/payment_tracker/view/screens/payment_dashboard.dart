import 'package:itracker/src/app/modules/payment_tracker/controller/paymentcontroller.dart';
import 'package:itracker/src/app/modules/payment_tracker/view/widgets/chart_card.dart';
import 'package:itracker/src/app/modules/payment_tracker/view/widgets/pending_item.dart';
import 'package:itracker/src/app/modules/payment_tracker/view/widgets/segment_buttons.dart';
import 'package:itracker/src/app/modules/payment_tracker/view/widgets/stats_card.dart';
import 'package:itracker/src/app/modules/payment_tracker/view/widgets/top_bar.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PaymentScreen extends GetView<Paymentcontroller> {
  const PaymentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context).textTheme;
    final isDark = Get.isDarkMode;

    return Scaffold(
      backgroundColor: isDark
          ? AppColors.backgroundDark
          : AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            // Top app bar
            const TopBar(),

            // Scrollable body
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.only(bottom: 80),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Headline
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16.0,
                        vertical: 12.0,
                      ),
                      child: Text(
                        'Collections Analytics',
                        style: theme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),

                    // Segmented Buttons
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: SegmentButtons(controller: controller),
                    ),

                    // Charts Card
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: ChartCard(controller: controller),
                    ),

                    // Stats Cards row
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Row(
                        children: [
                          Expanded(
                            child: StatsCard(
                              title: 'Total Pending',
                              valueBuilder: () => Obx(
                                () => AnimatedCounter(
                                  value: controller.totalPending.value,
                                  duration: const Duration(milliseconds: 500),
                                  style: theme.titleLarge?.copyWith(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: StatsCard(
                              title: 'Overdue Amount',
                              valueBuilder: () => Obx(
                                () => AnimatedCounter(
                                  value: controller.overdueAmount.value,
                                  duration: const Duration(milliseconds: 500),
                                  style: theme.titleLarge?.copyWith(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.danger,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 18),

                    // Pending Collections heading
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Pending Collections',
                            style: theme.titleLarge?.copyWith(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          TextButton(
                            onPressed: () {
                     
                            },
                            child: Text(
                              'View All',
                              style: theme.bodyMedium?.copyWith(
                                color: AppColors.primary,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Pending items list
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16.0,
                        vertical: 6,
                      ),
                      child: Obx(() => Column(
                          children: controller.pendingItems
                              .map((p) => PendingItemWidget(item: p))
                              .toList(),
                        )),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
