// import 'dart:developer';

// import 'package:animated_custom_dropdown/custom_dropdown.dart';
// import 'package:itracker/src/app/modules/payment_tracker/controller/schedulecontroller.dart';
// import 'package:flutter/material.dart';

// List<LeadNames> _list = [
//   LeadNames("John Doe"),
//   LeadNames("Michael"),
//   LeadNames("df"),
//   LeadNames("Kaviya"),
//   LeadNames("Arul"),
//   LeadNames("Nithish"),
//   LeadNames("Sanjay"),
// ];

// class SearchDropdown extends StatelessWidget {
//   const SearchDropdown({super.key});

//   Future<List<LeadNames>> _searchJobs(String query) async {
//     // Simulate async search
//     return _list
//         .where((job) => job.name.toLowerCase().contains(query.toLowerCase()))
//         .toList();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return CustomDropdown<LeadNames>.searchRequest(
//       hintText: 'Select lead',
//       items: _list,
//       onChanged: (value) {
//         log('Selected: ${value?.name}');
//       },
//       futureRequest: _searchJobs, // This is how search works
//     );
//   }
// }
