import 'package:flutter/material.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:itracker/src/core/app_style.dart';

class AppSearchBar extends StatelessWidget {
  const AppSearchBar({super.key});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.symmetric(horizontal: 10),
    padding: const EdgeInsets.symmetric(horizontal: 8),
    decoration: AppStyle.decoration,
    child: Row(
      children: [
        Container(
          width: 42,
          height: 42,
          padding: const EdgeInsets.all(10),

          child: HugeIcon(
            icon: HugeIcons.strokeRoundedSearch01,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(width: 10),
        const Expanded(
          child: TextField(
            decoration: InputDecoration(
              hintText: "Search by name or number...",

              contentPadding: EdgeInsets.all(0),
              border: InputBorder.none,
            ),
          ),
        ),
      ],
    ),
  );
}
