import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:itracker/src/core/app_colors.dart';
import 'package:flutter/material.dart';

import '../../core/app_icons.dart';
import '../../core/app_style.dart';
import '../../core/image_view.dart';

class ContactPopup extends StatefulWidget {
  const ContactPopup({super.key});

  @override
  State<ContactPopup> createState() => _ContactPopupState();
}

class _ContactPopupState extends State<ContactPopup> {
  final TextEditingController callSummaryController = TextEditingController();
  final TextEditingController followupReasonController =
      TextEditingController();

  String? selectedStatus = "Capsule";
  TimeOfDay? selectedTime;
  DateTime? selectedDate;

  final List<String> statuses = [
    "Capsule",
    "Interested",
    "Not Interested",
    "Callback",
  ];

  Future<void> pickTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() => selectedTime = picked);
    }
  }

  Future<void> pickDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() => selectedDate = picked);
    }
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return Dialog(
      child: SafeArea(
        child: Material(
          color: Colors.transparent,
          child: Container(
            width: width,
            height: 100,
            
            constraints:const BoxConstraints(maxHeight: 100),
            decoration: AppStyle.decoration.copyWith(
              border: Border.all(
                color: AppColors.primary,
                width: 1,
                style: BorderStyle.solid,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header Section
                Container(
                  decoration: BoxDecoration(
                    color: AppColors.primary,
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(12),
                    ),
                    border: Border.all(
                      color: AppColors.primary,
                      width: 2, // Sets the border width to 2.0 logical pixels
                      style: BorderStyle.solid, // Sets the border style to solid
                    ),
                  ),
                  padding: const EdgeInsets.symmetric(
                    vertical: 5,
                    horizontal: 16,
                  ),
                  child: Row(
                    children: [
                      InkWell(
                        onTap: () {
                          FlutterOverlayWindow.closeOverlay();
                        },
                        child: const CircleAvatar(
                          radius: 24,
                          backgroundColor: Colors.white24,
                          child: Text(
                            "DT",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "DEMO Rajesh Testington",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: Theme.of(context).textTheme.bodyMedium
                                  ?.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
      
                            Text(
                              "+91 9403890435",
                              style: Theme.of(context).textTheme.bodySmall
                                  ?.copyWith(color: Colors.white70),
                            ),
                            const SizedBox(height: 6),
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 15,
                                    vertical: 2,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.green.shade50,
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Text(
                                    "VIP",
                                    style: Theme.of(context).textTheme.bodySmall
                                        ?.copyWith(
                                          color: Colors.green,
                                          fontWeight: FontWeight.w600,
                                        ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Container(
                                  width: 22,
                                  height: 22,
                                  decoration: BoxDecoration(
                                    border: Border.all(color: Colors.white38),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: const Icon(
                                    Icons.add,
                                    size: 14,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: ImageView(
                          AppIcons.whatsapp,
                          width: AppStyle.iconSize,
                          height: AppStyle.iconSize,
                        ),
                        onPressed: () {},
                      ),
                      IconButton(
                        icon: const Icon(Icons.phone, color: Colors.white),
                        onPressed: () {},
                      ),
                    ],
                  ),
                ),
      
                // Lead and Assign info
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      color: const Color.fromARGB(255, 255, 255, 255),
                      padding: const EdgeInsets.symmetric(
                        vertical: 4,
                        horizontal: 16,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Lead stage: Demo",
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                          Text(
                            "Assigned to: Sales",
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "Followup Status",
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 3),
                    DropdownButtonFormField<String>(
                      initialValue: selectedStatus,
                      decoration: _inputDecoration(),
                      padding: const EdgeInsets.symmetric(vertical: 0),
                      items: statuses
                          .map(
                            (status) => DropdownMenuItem(
                              value: status,
                              child: Text(status),
                            ),
                          )
                          .toList(),
                      onChanged: (value) =>
                          setState(() => selectedStatus = value),
                    ),
      
                    const SizedBox(height: 8),
                    Text(
                      "Call Summary",
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 3),
                    _textBox(
                      controller: callSummaryController,
                      hint: "Enter call summary",
                    ),
                  ],
                ),
      
                const SizedBox(height: 24),
                Center(
                  child: SizedBox(
                    width: 120,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
      
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      onPressed: () {
                        FlutterOverlayWindow.closeOverlay();
                      },
                      child: Text(
                        "Saved",
                        style: Theme.of(
                          context,
                        ).textTheme.bodyMedium?.copyWith(color: Colors.white),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }

  InputDecoration _inputDecoration() => InputDecoration(
    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: const BorderSide(color: Colors.grey),
    ),
  );

  Widget _textBox({
    required TextEditingController controller,
    required String hint,
  }) => TextField(
    controller: controller,
    maxLines: 3,

    decoration: InputDecoration(
      hintText: hint,
      hintStyle: Theme.of(context).textTheme.bodySmall,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        // borderSide: const BorderSide(color: Colors.blueAccent),
      ),
    ),
  );
}
