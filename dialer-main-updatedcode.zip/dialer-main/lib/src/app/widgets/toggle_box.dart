import 'package:flutter/material.dart';

class ToggleBox extends StatelessWidget {
  const ToggleBox({
    super.key,
    required this.onTap,
    required this.lable,
    required this.activePageIndex,
    required this.index,
  });

  final void Function(int p1)? onTap;
  final int activePageIndex;
  final String lable;
  final int index;

  @override
  Widget build(BuildContext context) => Expanded(
    child: InkWell(
      borderRadius: const BorderRadius.all(Radius.circular(10)),
      onTap: () => onTap?.call(index),
      child: Container(
        alignment: Alignment.center,
        decoration: (activePageIndex == index)
            ? BoxDecoration(
                color: Theme.of(context).colorScheme.primary,
                borderRadius: const BorderRadius.all(Radius.circular(10)),
              )
            : BoxDecoration(
                color: Theme.of(context).colorScheme.secondaryContainer,
                borderRadius: const BorderRadius.all(Radius.circular(10)),
              ),
        child: Text(
          lable,
          style: Theme.of(context).textTheme.bodyMedium!.copyWith(
            color: (activePageIndex == index) ? Colors.white : Colors.black,
          ),
        ),
      ),
    ),
  );
}
