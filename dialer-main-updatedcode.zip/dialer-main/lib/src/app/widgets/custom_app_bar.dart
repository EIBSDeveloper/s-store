 

import 'package:flutter/material.dart';

import '../../../app.dart';
import '../utils/utils.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String? titleText;
  final Widget? title;
  final List<Widget>? actions;
  final bool showBackButton;

  const CustomAppBar({
    super.key,
    this.titleText,
    this.title,
    this.actions,
    this.showBackButton = false,
  });

  @override
  Widget build(BuildContext context) => AppBar(
    backgroundColor: Colors.transparent,
    elevation: 0,
    title: title ?? Text(capitalizeFirstLetter(titleText ?? '')),
    // centerTitle: true,
    actions: actions,
    leading: IconButton(
      icon: const Icon(Icons.arrow_back_ios_new),
      onPressed: () =>  navigatorKey.currentState!.pop(),
    ),
  );

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
