import 'package:flutter/material.dart';
import '../../core/app_style.dart';
import 'toggle_box.dart';

class ToggleBar extends StatelessWidget {
  const ToggleBar({
    super.key,
    required this.onTap,
    required this.activePageIndex,
    required this.buttonsList,
  });
  final void Function(int)? onTap;
  final int activePageIndex;
  final List<String> buttonsList;

  @override
  Widget build(BuildContext context) => Container(
    height: 40,
    decoration: AppStyle.decoration.copyWith(
      color: Theme.of(context).colorScheme.secondaryContainer,
    ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: <Widget>[
        ...List.generate(
          buttonsList.length,
          (index) => ToggleBox(
            onTap: onTap,
            activePageIndex: activePageIndex,
            lable: buttonsList[index],
            index: index,
          ),
        ),
      ],
    ),
  );
}
