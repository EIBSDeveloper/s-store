import 'package:flutter/material.dart';

class LableText extends StatelessWidget {
  const LableText(this.text, {super.key, this.isrequired = false});

  final String text;
  final bool isrequired;

  @override
  Widget build(BuildContext context) => RichText(
    text: TextSpan(
      text: text,
      style: const TextStyle(color: Colors.black),
      children: [
        if (isrequired)
          const TextSpan(
            text: " *",
            style: TextStyle(color: Colors.red, fontSize: 20),
          ),
      ],
    ),
  );
}
