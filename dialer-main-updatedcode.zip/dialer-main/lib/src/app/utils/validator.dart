class Validator {
  static String? validateName(String? value) {
    if (value == null || value.trim().isEmpty) {
      return "Lead name is required";
    }
    if (value.trim().length < 3) {
      return "Name must be at least 3 characters";
    }
    return null;
  }

  static String? validateMobile(String? value) {
    if (value == null || value.trim().isEmpty) {
      return "Mobile number is required";
    }
    if (!RegExp(r'^[0-9]{10}$').hasMatch(value.trim())) {
      return "Enter valid 10-digit mobile number";
    }
    return null;
  }

  static String? validateGender(String? value) {
    if (value == null || value.trim().isEmpty) {
      return "Gender is required";
    }
    return null;
  }

  static String? validateCountry(String? value) {
    if (value == null || value.trim().isEmpty) {
      return "Country required";
    }
    return null;
  }

  static String? validateState(String? value) {
    if (value == null || value.trim().isEmpty) {
      return "State required";
    }
    return null;
  }

  static String? validateCity(String? value) {
    if (value == null || value.trim().isEmpty) {
      return "City required";
    }
    return null;
  }

  static String? validateLeadSource(String? value) {
    if (value == null || value.trim().isEmpty) {
      return "Lead source required";
    }
    return null;
  }
}
