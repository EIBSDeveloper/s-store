import 'package:dio/dio.dart';
import 'package:get/get.dart' hide Response;

import '../../../../tt.dart';
import '../../controller/app_controller.dart';

final AppDataController appDeta = Get.find();

class ApiService {
  static Dio dio = Dio(
    BaseOptions(
      baseUrl: appDeta.baseUrl.string, // change
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 30),
      headers: {"Content-Type": "application/json"},
    ),
  );
  // GET
  /* static Future<Response> getData(
    String endpoint, {
    Map<String, dynamic>? query,
  }) async {
    try {
      return await dio.get(endpoint, queryParameters: query);
    } catch (e) {
      rethrow;
    }
  }*/
  static Future<Response> getData(
    String endpoint, {
    Map<String, dynamic>? query,
  }) async {
    try {
      final data = [
        {
          "name": "Alice",
          "time": "10:30 AM",
          "phone": "9874651230", // <- add this
          "duration": "5 min",
          "statusIcon": "incoming",
          "leadId": null,
          "tags": <Tag>[],
        },
        {
          "name": "",
          "time": "11:00 AM",
          "phone": "9784634565", // <- add this
          "duration": "2 min",
          "statusIcon": "missed",
          "leadId": 2,
          "tags": <Tag>[],
        },
        {
          "name": "Bob",
          "time": "12:15 PM",
          "phone": "8664511215", // <- add this
          "duration": "10 min",
          "statusIcon": "outgoing",
          "leadId": null,
          "tags": <Tag>[],
        },
        {
          "name": "Alice",
          "time": "10:30 AM",
          "phone": "9885622315", // <- add this
          "duration": "5 min",
          "statusIcon": "incoming",
          "leadId": 4,
          "tags": <Tag>[],
        },
        {
          "name": "",
          "time": "11:00 AM",
          "phone": "7878787878", // <- add this
          "duration": "2 min",
          "statusIcon": "missed",
          "leadId": null,
          "tags": <Tag>[],
        },
        {
          "name": "Bob",
          "time": "12:15 PM",
          "phone": "8446566231", // <- add this
          "duration": "10 min",
          "statusIcon": "outgoing",
          "leadId": 6,
          "tags": <Tag>[],
        },
        {
          "name": "",
          "time": "11:00 AM",
          "duration": "2 min",
          "phone": "9332154698", // <- add this
          "statusIcon": "missed",
          "leadId": null,
          "tags": <Tag>[],
        },
        {
          "name": "Bob",
          "time": "12:15 PM",
          "phone": "7456896532", // <- add this
          "duration": "10 min",
          "statusIcon": "outgoing",
          "leadId": 8,
          "tags": <Tag>[],
        },
      ];

      return Response(
        requestOptions: RequestOptions(path: endpoint),
        data: data,
        statusCode: 200,
      );
    } catch (e) {
      rethrow;
    }
  }

  // POST
  static Future<Response> postData(
    String endpoint,
    Map<String, dynamic> data, {
    Map<String, dynamic>? query,
  }) async {
    try {
      return await dio.post(endpoint, data: data, queryParameters: query);
    } catch (e) {
      rethrow;
    }
  }

  // PUT
  static Future<Response> putData(
    String endpoint,
    Map<String, dynamic> data, {
    Map<String, dynamic>? query,
  }) async {
    try {
      return await dio.put(endpoint, data: data, queryParameters: query);
    } catch (e) {
      rethrow;
    }
  }
}
