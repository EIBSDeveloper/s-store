class ApiConstants {
  //profile
  static const String profileDetails = "staff/details";

  //addressbook
  static const String calllist = "caller/list";
  static const String countryList = "CountryList";
  static const String stateList = "StateList"; // append /{Country}
  static const String cityList = "CityList"; // append /{State}

  //Calllog
  static const String editcaller = "caller/update";

  //Followups
  static const String reminderPopup = "followup/popup";
  static const String followuplist = "followup/list";
  static const String followUpAdd = "followup/add";
  static const String reminderclose = "followup/close";

  //Dashboard
  static const String todaySummary = "call/summary/today";
  static const String countByStatus = "call/count-by-status";
  static const String weeklySummary = "call/summary/weekly";

  //LeadDetails
  static String leadFollowUpslist = "lead/followups";
  static String leadCallLogslist = "lead/call-log";
}
