import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../app.dart';
import '../../../core/models/call_log_entry.dart';

class Utils {
  static Future<void> requestContactPermission() async {
    var status = await Permission.contacts.status;
    if (!status.isGranted) {
      await Permission.contacts.request();
    }
  }

  static String formatDuration(int totalSeconds) {
    final minutes = (totalSeconds ~/ 60).toString().padLeft(2, '0');
    final seconds = (totalSeconds % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  static String capitalizeFirstLetter(String input) {
    if (input.isEmpty) return input;
    return '${input[0].toUpperCase()}${input.substring(1)}';
  }
}

String capitalizeFirstLetter(final String input) =>
    input.isEmpty ? input : input[0].toUpperCase() + input.substring(1);

/// Open WhatsApp chat with a specific phone number
Future<void> openWhatsApp(String phoneNumber, {String message = ''}) async {
  final whatsappUrl = Uri.parse(
    "https://wa.me/$phoneNumber?text=${Uri.encodeComponent(message)}",
  );

  if (await canLaunchUrl(whatsappUrl)) {
    await launchUrl(whatsappUrl, mode: LaunchMode.externalApplication);
  } else {
    throw 'Could not launch WhatsApp';
  }
}

/// Open SMS app with a message
Future<void> openSMS(String phoneNumber, {String message = ''}) async {
  final smsUrl = Uri(
    scheme: 'sms',
    path: phoneNumber,
    queryParameters: <String, String>{'body': message},
  );

  if (await canLaunchUrl(smsUrl)) {
    await launchUrl(smsUrl);
  } else {
    throw 'Could not launch SMS';
  }
}

Color getLabelColor(String label) {
  switch (label.toLowerCase()) {
    case 'food':
      return Colors.green;
    case 'projects':
      return Colors.blue;
    case 'goals':
      return Colors.orange;
    case 'personal':
      return Colors.purple;
    case 'reminders':
      return Colors.red;
    case 'voices':
      return Colors.teal;
    default:
      return Theme.of(navigatorKey.currentContext!).colorScheme.primary;
  }
}

int typeToId(CallType type) {
  switch (type) {
    case CallType.incoming:
      return 1;
    case CallType.outgoing:
      return 2;
    case CallType.missed:
      return 3;
    case CallType.rejected:
      return 4;
    case CallType.all:
      throw 4;
    case CallType.voiceMail:
      throw 4;
    case CallType.blocked:
      throw 4;
    case CallType.answeredExternally:
      throw 4;
    case CallType.unknown:
      throw 4;
    case CallType.wifiIncoming:
      throw 4;
    case CallType.wifiOutgoing:
      throw 4;
  }
}
String formatDuration(int seconds) {
  final duration = Duration(seconds: seconds);

  String twoDigits(int n) => n.toString().padLeft(2, '0');

  String hours = twoDigits(duration.inHours);
  String minutes = twoDigits(duration.inMinutes.remainder(60));
  String secs = twoDigits(duration.inSeconds.remainder(60));

  // return "$hours:$minutes:$secs";
  return "$minutes:$secs";
}
