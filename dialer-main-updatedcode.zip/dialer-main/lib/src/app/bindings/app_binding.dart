import 'package:get/get.dart';
import 'package:itracker/src/app/modules/addressbook/controller/addressbookcontroller.dart';
import 'package:itracker/src/app/modules/followup/controller/followup_controller.dart';

import '../controller/app_controller.dart';
import '../modules/bottombar/contoller/bottombar_contoller.dart';
import '../modules/callLogs/controller/call_log_detailscontroller.dart';
import '../modules/callLogs/controller/call_logcontroller.dart';
import '../modules/callLogs/repository/client_repository.dart';
import '../modules/dashboard/controller/dashboard_controller.dart';
import '../modules/notification/notification_controller.dart';
import '../modules/payment_tracker/controller/customercontroller.dart';
import '../modules/payment_tracker/controller/paymentcontroller.dart';
import '../modules/payment_tracker/controller/schedulecontroller.dart';
import '../modules/splash/controller/splashcontroller.dart';
import '../modules/walkthrough/controller/onboarding_controller.dart';
import '../utils/http/http_service.dart';

class AppBinding implements Bindings {
  @override
  void dependencies() {
    Get.put(AppDataController(), permanent: true);
    Get.lazyPut(() => HttpService(), fenix: true);
    Get.lazyPut(() => SplashController(), fenix: true);
    Get.lazyPut(() => DashboardController(), fenix: true);
    Get.lazyPut(() => AddressbookController(), fenix: true);
    Get.lazyPut(() => FollowUpController(), fenix: true);

    Get.lazyPut(() => CallLogsController(), fenix: true);
    Get.lazyPut(() => OnboardingController(), fenix: true);
    Get.lazyPut(() => BottomBarContoller(), fenix: true);
    Get.lazyPut(() => CallDetailsController(), fenix: true);
    Get.lazyPut(() => CustomerController(), fenix: true);
    Get.lazyPut(() => SchedulesController(), fenix: true);
    Get.lazyPut(() => Paymentcontroller(), fenix: true);
    Get.lazyPut(() => NotificationController(), fenix: true);
    Get.lazyPut(() => ClientRepository(), fenix: true);
  }
}
