import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:itracker/src/app/utils/notificationservice.dart';
import 'package:itracker/src/core/app_text_theme.dart';

import 'app.dart';
import 'src/app/bindings/app_binding.dart';
import 'src/app/widgets/contect_popup.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await NotificationService.initialize();
  // Workmanager().initialize(callbackDispatcher);
  AppBinding().dependencies();
  await Hive.openBox('tagsBox');
  runApp(const MyApp());
}

@pragma("vm:entry-point")
void overlayMain() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    MaterialApp(
      theme: ThemeData(textTheme: AppTextTheme.style),
      debugShowCheckedModeBanner: false,
      home: const ContactPopup(),
    ),
  );
}
