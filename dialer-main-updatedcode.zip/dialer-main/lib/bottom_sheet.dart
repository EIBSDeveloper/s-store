import 'package:flutter/material.dart';
import 'package:itracker/src/core/app_colors.dart';

import 'app.dart';

Future<T?> showSideSlideBottomSheet<T>({
  required BuildContext context,
  required Widget child,
}) => showModalBottomSheet<T>(
  context: context,
  backgroundColor: Colors.transparent,
  isScrollControlled: true,
  builder: (_) => _SideSlideSheet(child: child),
);

class _SideSlideSheet extends StatefulWidget {
  final Widget child;
  const _SideSlideSheet({required this.child});

  @override
  State<_SideSlideSheet> createState() => _SideSlideSheetState();
}

class _SideSlideSheetState extends State<_SideSlideSheet>
    with SingleTickerProviderStateMixin {
  late AnimationController controller;
  late Animation<Offset> slideAnimation;

  @override
  void initState() {
    super.initState();

    controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    slideAnimation = Tween(
      begin: const Offset(1, 0), // start from RIGHT
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: controller, curve: Curves.easeOutCubic));

    controller.forward();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => SlideTransition(
    position: slideAnimation,
    child: DraggableScrollableSheet(
      initialChildSize: 0.4,
      minChildSize: 0.2,
      maxChildSize: 0.9,
      builder: (_, scrollController) => Container(
        decoration: const BoxDecoration(
          color: AppColors.background,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: SingleChildScrollView(
          controller: scrollController,
          child: widget.child,
        ),
      ),
    ),
  );
}

openButtomsheet(Widget child) => showSideSlideBottomSheet(
  context: navigatorKey.currentContext!,
  child: child,
);
