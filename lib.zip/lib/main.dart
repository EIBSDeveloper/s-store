import 'package:flutter/material.dart';

import 'package:get/get.dart';

import 'core/app_text_theme.dart';
import 'core/theme/theme_controller.dart';
import 'routes/app_pages.dart';
import 'routes/app_routes.dart';
import 'widgets/custom_transition.dart';

import 'core/controllers/lifecycle_controller.dart';
import 'core/utils/storage_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await StorageService.init();
  Get.put(LifecycleController());
  runApp(MyApp()); 
}

class MyApp extends StatelessWidget {
  final ThemeController themeController = Get.put(ThemeController());

  MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => GetMaterialApp(
        debugShowCheckedModeBanner: false,
        title: "Elysium",
        theme: ThemeData(
          textTheme: AppText.style,
          pageTransitionsTheme: const PageTransitionsTheme(
            builders: {
              TargetPlatform.android: SlideRightToLeftTransition(),
              TargetPlatform.iOS: SlideRightToLeftTransition(),
            },
          ),
        ),
        themeMode: themeController.themeMode.value,
        initialRoute:
            (StorageService.isPinEnabled() ||
                StorageService.isFingerprintEnabled())
            ? Routes.unlock
            : Routes.home,
        getPages: AppPages.routes,
      ),
    );
  }
}

// https://www.figma.com/design/CX9dZR9qODlva02Q8wFEWv/EGC-Super-App?node-id=88-14&t=KvHSOMqoG1tKq8wK-1
// https://stitch.withgoogle.com/projects/8747919702011136490


// https://huggingface.co/Ayodele01/gemma-4-E2B-Gemini-3.1-Pro-Reasoning-Distill-GGUF
// https://huggingface.co/mad-lab-ai/deepseek-coder-v2-lite-instruct-GGUF
