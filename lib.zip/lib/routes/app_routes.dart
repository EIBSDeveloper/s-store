abstract class Routes {
  static const home = "/home";
  static const login = "/login";
  static const confirmCheckIn = "/confirm-check-in";
  static const forgotPassword = "/forgot-password";
  static const otpVerification = "/otp-verification";
  static const newPassword = "/newPassword";
  static const notifications = "/notifications";
  static const securitySettings = "/security-settings";
  static const unlock = "/unlock";
  static const bot = "/bot";
    static const hrTicket = '/hr-ticket';
  static const raiseNewTicket = '/raise-new-ticket';
  static const submitTicket = '/submit-ticket';
  static const viewTicket = '/view-ticket';
  static const issueticket = '/issue-ticket';
  static const resolvedTicket = '/resolved-ticket';
  static const tasks = '/tasks';
  static const taskDetail = '/task-detail';

}
