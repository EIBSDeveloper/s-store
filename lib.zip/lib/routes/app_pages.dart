import 'package:elysium_employee/features/hr_ticket/bindings/hr_ticket_bindings.dart';
import 'package:elysium_employee/features/hr_ticket/view/screens/hr_ticket_screen.dart';
import 'package:elysium_employee/features/hr_ticket/view/screens/rise_new_ticket/issue_screen.dart';
import 'package:elysium_employee/features/hr_ticket/view/screens/rise_new_ticket/raise_new_ticket_screen.dart';
import 'package:elysium_employee/features/hr_ticket/view/screens/rise_new_ticket/ticket_submitted_screen.dart';
import 'package:elysium_employee/features/tasks/view/screens/task_detail_screen.dart'; 
import 'package:get/get.dart';
import '../features/attendance/bindings/attendance_binding.dart';
import '../features/attendance/bot/agri_bot.dart';
import '../features/attendance/bot/smart_farm_binding.dart';
import '../features/attendance/view/screen/attendance_screen.dart';
import '../features/attendance/view/screen/confirm.dart';

import '../features/tasks/view/screens/task_screen.dart';

import '../features/auth/bindings/forgot_password_binding.dart';
import '../features/auth/bindings/login_binding.dart';
import '../features/auth/screens/forgot_password_screen.dart';
import '../features/auth/screens/login_screen.dart';
import '../features/auth/screens/new_password_screen.dart';
import '../features/auth/screens/otp_verification_screen.dart';
import '../features/notifications/view/screens/notifications_screen.dart';
import '../features/security/bindings/security_binding.dart';
import '../features/security/view/screens/security_settings_screen.dart';
import '../features/security/view/screens/unlock_screen.dart';

import 'app_routes.dart';

class AppPages {
  static final routes = [
    GetPage(
      name: Routes.login,
      page: () => LoginScreen(),
      binding: LoginBinding(),
    ),
    GetPage(
      name: Routes.home,
      page: () => AttendanceScreen(),
      binding: AttendanceBinding(),
    ),
    GetPage(name: Routes.confirmCheckIn, page: () => Confirm()),
    GetPage(
      name: Routes.forgotPassword,
      page: () => const ForgotPasswordScreen(),
      binding: ForgotPasswordBinding(),
    ),
    GetPage(
      name: Routes.otpVerification,
      page: () => const OtpVerificationScreen(),
      binding: ForgotPasswordBinding(),
    ),
    GetPage(
      name: Routes.newPassword,
      page: () => const NewPasswordScreen(),
      binding: ForgotPasswordBinding(),
    ),
    GetPage(
      name: Routes.notifications,
      page: () => const NotificationsScreen(),
    ),
    GetPage(
      name: Routes.securitySettings,
      page: () => const SecuritySettingsScreen(),
      binding: SecurityBinding(),
    ),
    GetPage(
      name: Routes.unlock,
      page: () => const UnlockScreen(),
      binding: SecurityBinding(),
    ),
    GetPage(
      name: Routes.bot,
      page: () => const SmartFarmView(),
      binding: SmartFarmBinding(),
    ),
    GetPage(
      name: Routes.hrTicket,
      page: () => HrTicketScreen(),
      binding: HrTicketBindings(),
    ),

    GetPage(
      name: Routes.raiseNewTicket,
      page: () => RaiseTicketView(),
      binding: HrTicketBindings(),
    ),

    GetPage(name: Routes.submitTicket, page: () => TicketSubmittedScreen()),
    GetPage(name: Routes.issueticket, page: () => IssueScreen()),
    GetPage(name: Routes.tasks, page: () => TasksScreen()),
    GetPage(name: Routes.taskDetail, page: () => TaskDetailScreen()),
 

  ];
}
