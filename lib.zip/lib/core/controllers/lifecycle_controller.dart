import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/utils/storage_service.dart';
import '../../routes/app_routes.dart';

class LifecycleController extends GetxController with WidgetsBindingObserver {
  @override
  void onInit() {
    super.onInit();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void onClose() {
    WidgetsBinding.instance.removeObserver(this);
    super.onClose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _checkLock();
    } else if (state == AppLifecycleState.paused) {
      // Mark as locked when backgrounded if security is enabled
      if (StorageService.isPinEnabled() || StorageService.isFingerprintEnabled()) {
        StorageService.setLocked(true);
      }
    }
  }

  void _checkLock() {
    if ((StorageService.isPinEnabled() || StorageService.isFingerprintEnabled()) && 
        StorageService.isLocked()) {
      // Navigate to unlock screen if not already there
      if (Get.currentRoute != Routes.unlock) {
        Get.toNamed(Routes.unlock);
      }
    }
  }
}
