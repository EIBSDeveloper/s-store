import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static late SharedPreferences _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // Security Keys
  static const String _keyPin = 'security_pin';
  static const String _keyFingerprintEnabled = 'fingerprint_enabled';
  static const String _keyPinEnabled = 'pin_enabled';
  static const String _keyIsLocked = 'is_app_locked';

  // PIN
  static Future<void> setPin(String pin) async {
    await _prefs.setString(_keyPin, pin);
  }

  static String? getPin() {
    return _prefs.getString(_keyPin);
  }

  // Fingerprint Toggle
  static Future<void> setFingerprintEnabled(bool enabled) async {
    await _prefs.setBool(_keyFingerprintEnabled, enabled);
  }

  static bool isFingerprintEnabled() {
    return _prefs.getBool(_keyFingerprintEnabled) ?? false;
  }

  // PIN Toggle
  static Future<void> setPinEnabled(bool enabled) async {
    await _prefs.setBool(_keyPinEnabled, enabled);
  }

  static bool isPinEnabled() {
    return _prefs.getBool(_keyPinEnabled) ?? false;
  }

  // Lock State (useful for tracking app backgrounding)
  static Future<void> setLocked(bool locked) async {
    await _prefs.setBool(_keyIsLocked, locked);
  }

  static bool isLocked() {
    return _prefs.getBool(_keyIsLocked) ?? false;
  }

  static Future<void> clearSecurity() async {
    await _prefs.remove(_keyPin);
    await _prefs.remove(_keyFingerprintEnabled);
    await _prefs.remove(_keyPinEnabled);
    await _prefs.remove(_keyIsLocked);
  }

  // Generic Storage
  static Future<void> setString(String key, String value) async {
    await _prefs.setString(key, value);
  }

  static String? getString(String key) {
    return _prefs.getString(key);
  }
}
