import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppText {
  static TextStyle get titleLarge =>
      GoogleFonts.nunito(fontSize: 18, fontWeight: FontWeight.w600);

  static TextStyle get bodyLarge => GoogleFonts.nunito(
    fontSize: 15,
    fontWeight: FontWeight.w600,
    height: 1.4,
  );

  static TextStyle get bodyMedium =>
      GoogleFonts.nunito(fontSize: 14, fontWeight: FontWeight.w400);

  static TextStyle get bodySmall =>
      GoogleFonts.nunito(fontSize: 10, fontWeight: FontWeight.w400);

  static TextTheme get style => GoogleFonts.nunitoTextTheme().copyWith(
    titleLarge: titleLarge,
    bodyLarge: bodyLarge,
    bodyMedium: bodyMedium,
    bodySmall: bodySmall,
  );
}
