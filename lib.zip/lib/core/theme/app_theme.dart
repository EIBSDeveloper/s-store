import 'package:flutter/material.dart';

class AppTheme {
  static final lightTheme = ThemeData(
    brightness: Brightness.light,
    scaffoldBackgroundColor: Color(0xFFF9F9F9),
    primaryColor: Color(0xFF735B1D),
    fontFamily: "Manrope",
  );

  static final darkTheme = ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: Color(0xFF231A0E),
    primaryColor: Color(0xFFAF934F),
    fontFamily: "Manrope",
  );
}