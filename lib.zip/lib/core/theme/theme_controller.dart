import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../utils/storage_service.dart';

class ThemeController extends GetxController {
  Rx<ThemeMode> themeMode = ThemeMode.light.obs;

  // Observable Colors
  final Rx<Color> primaryColor = const Color(0xffab2b22).obs;
  final Rx<Color> secondaryColor = const Color(0xfffba919).obs;
  final Rx<Color> backgroundColor = const Color(0xfff0f7ff).obs;

  @override
  void onInit() {
    super.onInit();
    _loadStoredColors();
  }

  void _loadStoredColors() {
    final primary = StorageService.getString('primary_color');
    final secondary = StorageService.getString('secondary_color');
    final background = StorageService.getString('background_color');

    if (primary != null) primaryColor.value = Color(int.parse(primary));
    if (secondary != null) secondaryColor.value = Color(int.parse(secondary));
    if (background != null) backgroundColor.value = Color(int.parse(background));
  }

  void updateColors({Color? primary, Color? secondary, Color? background}) {
    if (primary != null) {
      primaryColor.value = primary;
      StorageService.setString('primary_color', primary.value.toString());
    }
    if (secondary != null) {
      secondaryColor.value = secondary;
      StorageService.setString('secondary_color', secondary.value.toString());
    }
    if (background != null) {
      backgroundColor.value = background;
      StorageService.setString('background_color', background.value.toString());
    }
  }

  void resetToDefault() {
    updateColors(
      primary: const Color(0xffab2b22),
      secondary: const Color(0xfffba919),
      background: const Color(0xfff0f7ff),
    );
  }

  void toggleTheme() {
    themeMode.value =
        themeMode.value == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
  }
}