class AppIcons {
  //  icon
  static String logo = "logo";
}
