import 'package:flutter/material.dart'; 
import '../features/attendance/model/attendance_model.dart';

class AppColors {
  static Color primary = Color.fromARGB(255, 47, 66, 161);
  static Color primarylight = Color.fromARGB(255, 206, 210, 229);
  static Color secondary = Color.fromARGB(255, 255,179,27);

  static const Color slate800 = Color(0xFF1E293B);
  static const Color slate400 = Color(0xFF94A3B8);
  static const Color slate300 = Color(0xFFCBD5E1);

  static Color background = Color.fromARGB(255,  245,247,252);

  static const tertiary = Color(0xFFFBBF24);
  static const danger = Colors.red;
  static const green = Color.fromARGB(255, 1, 180, 115);
  static const blue = Colors.cyan;
  static const whiteText = Color.fromARGB(255, 255, 255, 255);
  static LinearGradient gradient = LinearGradient(
    colors: [AppColors.secondary, AppColors.primary],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const navBg = Color(0xFF2D3A8C);
  static const textPrimary = Color(0xFF1F2937);
  static const textSecondary = Color(0xFF6B7280);
  static const borderLight = Color(0xFFE5E7EB);
  static const surfaceLight = Color(0xFFF8F9FA);

  static const accentYellow = Color(0xFFFEF3C7);
  static const accentYellowText = Color(0xFFD97706);
  static const accentBlue = Color(0xFFE0E7FF);
  static const accentBlueText = Color(0xFF4F46E5);
  static const accentGreen = Color(0xFFDCFCE7);
  static const accentGreenText = Color(0xFF16A34A);

  static const cardYellow = Color(0xFFFFFBEB);
  static const cardBlue = Color(0xFFF0F9FF);
  static const cardGreen = Color(0xFFF0FDF4);
  static const cardPurple = Color(0xFFF5F3FF);
  static const disable = Colors.grey;
  static const card = Color.fromARGB(255, 255, 254, 254);
  static const appBar = Color.fromARGB(255, 25, 25, 25);
  static const border = Color.fromARGB(255, 226, 226, 226);

  //Lead profile screen

  static const Color backgroundDark = Color(0xFF101C22);
  static const Color textDark = Color(0xFF111618);
  static const Color textLight = Colors.white;
  static const Color accent = Color(0xFF607c8a);

  // Standard Material Design colors (500-700 range for better visibility)
  static const Color error = Colors.red; // Red 700
  static const Color success = Color(0xFF388E3C); // Green 700
  static const Color warning = Color(0xFFF57C00); // Orange 700
  static const Color info = Color(0xFF1976D2); // Blue 700
  // static const Color primary = Color(0xFF6200EE);     // Deep Purple 500

  // Extended palette for specific use cases
  static const Color converted = Color(0xFF7B1FA2); // Purple 700
  static const Color lost = Color(0xFF616161); // Gray 700
  static const Color scheduled = Color(0xFFAB47BC); // Purple 400
  static const Color pending = Color(0xFFFFA000); // Amber 600
  static const Color active = Color(0xFF43A047); // Green 600
  static const Color draft = Color(0xFF757575); // Gray 600

  static Color attendance(AttendanceStatus status) {
    switch (status) {
      case AttendanceStatus.present:
        return Color(0xFF2E7D32);
      case AttendanceStatus.late:
        return Color(0xFFED6C02);
      case AttendanceStatus.absent:
        return Color(0xFFD32F2F);
      case AttendanceStatus.leave:
        return Color(0xFF1976D2);
      case AttendanceStatus.holiday:
        return Color(0xFF7B1FA2); // Purple
      case AttendanceStatus.none:
        return Color.fromARGB(255, 15, 129, 21); // Neutral / default
    }
  }

  static Color attendanceTxt(AttendanceStatus status) {
    switch (status) {
      case AttendanceStatus.present:
        return AppColors.active;
      case AttendanceStatus.late:
        return AppColors.warning;
      case AttendanceStatus.absent:
        return AppColors.danger;
      case AttendanceStatus.leave:
        return AppColors.danger;
      case AttendanceStatus.holiday:
        return AppColors.info;
      default:
        return Colors.black;
    }
  }

  //Hr Ticket

  static const Color openCount = Color(0XFFC88C15);
  static const Color bottomText = Color(0XFF393D50);
  static const Color inReview = Color(0XFF7186EE);
  static const Color resolved = Color(0XFF72A242);

  static const Color cardBg = Color(0XFFEBE7FF);

  static const Color openIconBg = Color(0XFFFBF1DB);
  static const Color inReviewIconBg = Color(0XFFEBE7FF);

  static const Color myTicSub = Color(0XFF7F8592);

  static const Color myTicOpeniconBg = Color(0XFFFBF1DB);
  static const Color myTicopenIcon = Color(0XFFFFB31B);
  static const Color myTicOpen = Color(0XFFFFEDC9);
  static const Color myTicOpenText = Color(0XFFE1A224);

  static const Color myTicInReviewIconBg = Color(0XFFEBE7FF);
  static const Color myTicInReviewIcon = Color(0XFF7186EE);
  static const Color myTicInReviewBg = Color(0XFFDAE0FF);
  static const Color myTicInReviewText = Color(0XFF7186EE);

  static const Color myTicResolvedIconBg = Color(0XFFE5F5D8);
  static const Color myTicResolvedIcon = Color(0XFF72A242);
  static const Color myTicResolvedBg = Color(0XFFE5F5D8);
  static const Color myTicResolvedText = Color(0XFF6DA13B);

  static const Color buttonTop = Color(0XFF273A96);
  static const Color buttonBottom = Color(0XFF4D62CB);

  //Raise New Ticket

  static const Color infoBar = Color(0XFFFFF8E7);
  static const Color infoBarBorder = Color(0XFFFFB31B);
  static const Color payroll = Color(0XFFE5F8D8);
  static const Color promotion = Color(0XFFDCE8FF);
  static const Color grievance = Color(0XFFFFF2D8);
  static const Color policy = Color(0XFFEBE7FF);

  //Issue Screen

  static const Color category = Color(0XFFDCE8FF);
  static const Color issueText = Color(0XFF7F8592);
  static const Color subjectTextArea = Color.fromARGB(18, 39, 57, 150);
  static const Color priorityBorder = Color(0XFF273A96);
  static const Color priorityFill = Color(0XFFB5C2FF);
  static const Color priorityText = Color(0XFF273A96);
  static const Color uploadFill = Color(0XFFD9D9D9);
  static const Color uploadBorder = Color(0XFF7F8592);
  static const Color uploadContent = Color(0XFF394063);

  static const Color viewTicketBtn = Color(0XFFFFB31B);

  //rating
  static const Color rating = Color(0XFFF5BF03);
  static const Color starBorder = Color(0XFFB5993A);

  //Tasks
  static const Color states = Color(0XFFB5C2FF);

  static const Color overDue = Color(0XFFEE4B4B);
  static const Color overDueBorder = Color(0XFFFFD1D1);
  static const Color dueToday = Color(0XFFC88C15);
  static const Color dueTodayBorder = Color(0XFFFFEECB);
  static const Color onTrack = Color(0XFF72A242);
  static const Color deadLine = Color(0XFF7F8592);
  static const Color mediumTag = Color(0XFFDAE0FF);
}
