import 'package:flutter/material.dart';

class AppStyle {
  static const double iconSizeLarge = 25;
  static const double iconSize = 20;
  static const double iconSize2 = 15;
  static const double iconSize3 = 10;

  static const double boxPadding = 8;

  static const double listGap = 6;
  static const double widgetsGap = 8;
  static const double borderRadiusBox = 8;
  static const double borderRadiusClip = 5;
  static const double borderRadiusBottom = 50;
  static const BoxDecoration inputDecoration = BoxDecoration(
    borderRadius: BorderRadius.all(Radius.circular(borderRadiusBox)),
  );
  static BoxDecoration decoration = BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(borderRadiusBox),
    boxShadow: [
      BoxShadow(
        color: Color.fromRGBO(0, 0, 0, 0.1),
        blurRadius: 2,
        spreadRadius: 0,
        offset: Offset(0, 1),
      ),
    ],
  );
  static BoxDecoration decorationDark = BoxDecoration(
    color: Colors.grey[850],
    borderRadius: BorderRadius.circular(10),
    border: Border.all(color: Colors.grey[800]!),
  );
  static const List<BoxShadow> boxShadow = [
    BoxShadow(
      color: Color.fromRGBO(0, 0, 0, 0.05),
      blurRadius: 2,
      spreadRadius: 0,
      offset: Offset(0, 1),
    ),
  ];
}
