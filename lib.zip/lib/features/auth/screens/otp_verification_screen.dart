import 'dart:ui';
import 'package:elysium_employee/core/app_colors.dart';
import 'package:elysium_employee/core/app_text_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import '../controllers/forgot_password_controller.dart';
import '../widgets/background_shapes.dart';

class OtpVerificationScreen extends GetView<ForgotPasswordController> {
  const OtpVerificationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final empId = Get.arguments as String? ?? '';

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          const BackgroundShapes(),

          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  /// LOGO
                  Column(
                    children: [
                      Image.network(
                        "https://erp.elysium.community/assets/common/logo_small.png",
                        height: 80,
                      ),
                      const SizedBox(height: 6),
                      Container(
                        height: 3,
                        width: 50,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: AppColors.primary,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  /// CARD
                  Container(
                    width: 400,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          blurRadius: 32,
                          color: Colors.black.withOpacity(.04),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(24),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                        child: Container(
                          padding: const EdgeInsets.all(28),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Colors.white.withOpacity(0.4),
                                Colors.white.withOpacity(0.1),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.6),
                              width: 1.5,
                            ),
                          ),
                          child: Column(
                            children: [
                        /// BACK BUTTON
                        Align(
                          alignment: Alignment.centerLeft,
                          child: GestureDetector(
                            onTap: () => Get.back(),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.arrow_back_ios_new_rounded,
                                  size: 14,
                                  color: AppColors.primary,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  'Back',
                                  style: AppText.bodySmall.copyWith(
                                    color: AppColors.primary,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        // const SizedBox(height: 16),

                        // /// SHIELD ICON
                        // Container(
                        //   width: 64,
                        //   height: 64,
                        //   decoration: BoxDecoration(
                        //     gradient: AppColors.gradient,
                        //     shape: BoxShape.circle,
                        //     boxShadow: [
                        //       BoxShadow(
                        //         color: AppColors.primary.withOpacity(0.3),
                        //         blurRadius: 16,
                        //         offset: const Offset(0, 6),
                        //       ),
                        //     ],
                        //   ),
                        //   child: const Icon(
                        //     Icons.shield_outlined,
                        //     color: Colors.white,
                        //     size: 30,
                        //   ),
                        // ),
                        const SizedBox(height: 16),

                        /// HEADER
                        Text(
                          "OTP Verification",
                          style: AppText.titleLarge.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 6),
                        RichText(
                          textAlign: TextAlign.center,
                          text: TextSpan(
                            style: AppText.bodySmall.copyWith(
                              color: Colors.grey,
                              fontWeight: FontWeight.w500,
                            ),
                            children: [
                              const TextSpan(
                                text:
                                    "We've sent a 6-digit OTP to the\nregistered contact for ",
                              ),
                              TextSpan(
                                text: empId,
                                style: AppText.bodySmall.copyWith(
                                  color: AppColors.primary,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 24),

                        /// OTP INPUT BOXES
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: List.generate(6, (index) {
                            return _OtpBox(
                              controller: controller.otpControllers[index],
                              focusNode: controller.otpFocusNodes[index],
                              onChanged: (val) =>
                                  controller.onOtpChanged(val, index),
                            );
                          }),
                        ),

                        const SizedBox(height: 12),

                        /// TIMER / RESEND
                        Obx(() {
                          final secs = controller.resendSeconds.value;
                          return Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                "Didn't receive OTP? ",
                                style: AppText.bodySmall.copyWith(
                                  color: Colors.grey.shade600,
                                ),
                              ),
                              GestureDetector(
                                onTap: secs == 0 ? controller.resendOtp : null,
                                child: Text(
                                  secs == 0
                                      ? "Resend OTP"
                                      : "Resend in ${secs}s",
                                  style: AppText.bodySmall.copyWith(
                                    color: secs == 0
                                        ? AppColors.primary
                                        : Colors.grey,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          );
                        }),

                        const SizedBox(height: 24),

                        /// VERIFY BUTTON
                        Obx(
                          () => _GradientButton(
                            label: "VERIFY OTP",
                            isLoading: controller.isLoading.value,
                            onTap: controller.verifyOtp,
                          ),
                        ),

                        const SizedBox(height: 16),

                        /// FOOTER
                        Column(
                          children: [
                            const Divider(),
                            const SizedBox(height: 5),
                            Text(
                              "Technical issues? Contact the IT Concierge",
                              style: AppText.bodySmall,
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "+91 0123456789",
                              style: AppText.bodyMedium.copyWith(
                                fontWeight: FontWeight.bold,
                                color: AppColors.primary,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 10),
                  Text(
                    "Innovation starts here – log in and drive progress.",
                    style: AppText.bodySmall,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Individual OTP digit box
class _OtpBox extends StatelessWidget {
  final TextEditingController controller;
  final FocusNode focusNode;
  final ValueChanged<String> onChanged;

  const _OtpBox({
    required this.controller,
    required this.focusNode,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 44,
      height: 52,
      child: TextField(
        controller: controller,
        focusNode: focusNode,
        onChanged: onChanged,
        textAlign: TextAlign.center,
        maxLength: 1,
        keyboardType: TextInputType.number,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        style: AppText.titleLarge.copyWith(
          fontWeight: FontWeight.bold,
          color: AppColors.primary,
        ),
        decoration: InputDecoration(
          counterText: '',
          filled: true,
          fillColor: const Color(0xFFF3F3F3),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: AppColors.primary, width: 2),
          ),
          contentPadding: EdgeInsets.zero,
        ),
      ),
    );
  }
}

/// Reusable gradient button
class _GradientButton extends StatelessWidget {
  final String label;
  final bool isLoading;
  final VoidCallback onTap;

  const _GradientButton({
    required this.label,
    required this.isLoading,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [AppColors.secondary, AppColors.primary],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.withAlpha(100),
              blurRadius: 12,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Center(
          child: isLoading
              ? const CircularProgressIndicator(color: Colors.white)
              : Text(
                  label,
                  style: AppText.bodyLarge.copyWith(
                    color: Colors.white,
                    letterSpacing: 2,
                    fontWeight: FontWeight.bold,
                  ),
                ),
        ),
      ),
    );
  }
}
