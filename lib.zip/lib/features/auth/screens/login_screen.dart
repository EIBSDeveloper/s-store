import 'package:elysium_employee/core/app_colors.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  // Design Tokens
  static const Color primary = Color(0xFF3F51B5);
  static const Color textSlate = Color(0xFF334155);
  static const Color iconColor = Color(0xFF7E8CA0);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primarylight,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    const SizedBox(height: 150),
                    Container(
                      width: double.infinity,
                      padding: EdgeInsets.fromLTRB(16, 10, 16, 50),
                      decoration: BoxDecoration(
                        color: AppColors.background,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20),
                        ),
                      ),
                      child: Column(
                        children: [
                          // Header Section
                          Text(
                            "Welcome",
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                              color: textSlate,
                            ),
                          ),
                          const SizedBox(height: 5),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 20),
                            child: Text(
                              "Login to access your attendance, tasks, salary and more.",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 14,
                              ),
                            ),
                          ),

                          // Illustration Placeholder
                          const LoginIllustration(),

                          // Input Fields
                          _buildInputField(
                            hint: "Employee ID",
                            icon: Icons.badge_outlined,
                          ),
                          const SizedBox(height: 16),
                          _buildInputField(
                            hint: "Enter your password",
                            icon: Icons.lock_outline,
                            isPassword: true,
                          ),

                          // Forgot Password
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton(
                              onPressed: () {},
                              child: const Text(
                                "Forgot Password?",
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Color(0xFF64748B),
                                  decoration: TextDecoration.underline,
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(height: 16),

                          // Login Button
                          SizedBox(
                            width: double.infinity,
                            height: 56,
                            child: ElevatedButton(
                              onPressed: () {},
                              style: ElevatedButton.styleFrom(
                                backgroundColor: primary,
                                foregroundColor: Colors.white,
                                elevation: 4,
                                shadowColor: primary.withOpacity(0.4),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child: const Text(
                                "LOGIN",
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.5,
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(height: 60),

                          // Footer
                          Column(
                            children: [
                              Container(
                                padding: const EdgeInsets.only(bottom: 4),
                                decoration: const BoxDecoration(
                                  border: Border(
                                    bottom: BorderSide(
                                      color: Color(0xFFE2E8F0),
                                      width: 1,
                                    ),
                                  ),
                                ),
                                child: const Text(
                                  "© 2026 ELYSIUM GROUPS",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 10,
                                    letterSpacing: 2,
                                    fontWeight: FontWeight.w600,
                                    color: Color(0xFF94A3B8),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 20),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputField({
    required String hint,
    required IconData icon,
    bool isPassword = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 15,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: TextField(
        obscureText: isPassword,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: Colors.grey, fontSize: 14),
          prefixIcon: Icon(icon, color: iconColor, size: 22),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            vertical: 18,
            horizontal: 16,
          ),
        ),
      ),
    );
  }
}

// Custom Painter for the SVG-style desk illustration
class LoginIllustration extends StatelessWidget {
  const LoginIllustration({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 240,
      height: 120,
      child: Image.asset("assets/gif/login.gif", fit: BoxFit.fitHeight),
    );
  }
}

// Gradient Mask for top and bottom waves
class WaveMask extends StatelessWidget {
  final bool isTop;
  const WaveMask({super.key, required this.isTop});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: isTop ? 200 : 150,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: isTop ? Alignment.topLeft : Alignment.bottomRight,
          end: isTop ? Alignment.bottomRight : Alignment.topLeft,
          colors: [
            const Color(0xFF3F51B5).withOpacity(isTop ? 0.1 : 0.08),
            const Color(0xFF3F51B5).withOpacity(isTop ? 0.05 : 0.03),
          ],
        ),
      ),
    );
  }
}
