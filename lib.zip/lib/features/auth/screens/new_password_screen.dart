import 'dart:ui';
import 'package:elysium_employee/core/app_colors.dart';
import 'package:elysium_employee/core/app_text_theme.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/forgot_password_controller.dart';
import '../widgets/background_shapes.dart';

class NewPasswordScreen extends GetView<ForgotPasswordController> {
  const NewPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          const BackgroundShapes(),

          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  /// LOGO
                  Column(
                    children: [
                      Image.network(
                        "https://erp.elysium.community/assets/common/logo_small.png",
                        height: 80,
                      ),
                      const SizedBox(height: 6),
                      Container(
                        height: 3,
                        width: 50,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: AppColors.primary,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  /// CARD
                  Container(
                    width: 400,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          blurRadius: 32,
                          color: Colors.black.withOpacity(.04),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(24),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                        child: Container(
                          padding: const EdgeInsets.all(28),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Colors.white.withOpacity(0.4),
                                Colors.white.withOpacity(0.1),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.6),
                              width: 1.5,
                            ),
                          ),
                          child: Column(
                            children: [
                        // /// KEY ICON
                        // Container(
                        //   width: 64,
                        //   height: 64,
                        //   decoration: BoxDecoration(
                        //     gradient: AppColors.gradient,
                        //     shape: BoxShape.circle,
                        //     boxShadow: [
                        //       BoxShadow(
                        //         color: AppColors.primary.withOpacity(0.3),
                        //         blurRadius: 16,
                        //         offset: const Offset(0, 6),
                        //       ),
                        //     ],
                        //   ),
                        //   child: const Icon(
                        //     Icons.key_rounded,
                        //     color: Colors.white,
                        //     size: 30,
                        //   ),
                        // ),
                        const SizedBox(height: 16),

                        /// HEADER
                        Text(
                          "Create New Password",
                          style: AppText.titleLarge.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          "Your new password must be at least 8 characters long",
                          style: AppText.bodySmall.copyWith(
                            color: Colors.grey,
                            fontWeight: FontWeight.w500,
                          ),
                          textAlign: TextAlign.center,
                        ),

                        const SizedBox(height: 24),

                        /// NEW PASSWORD FIELD
                        _PasswordLabel(label: "NEW PASSWORD"),
                        const SizedBox(height: 6),
                        Obx(
                          () => _PasswordField(
                            controller: controller.newPasswordController,
                            hint: "Enter new password",
                            isVisible: controller.isPasswordVisible.value,
                            onToggle: controller.togglePasswordVisibility,
                          ),
                        ),

                        const SizedBox(height: 18),

                        /// CONFIRM PASSWORD FIELD
                        _PasswordLabel(label: "CONFIRM PASSWORD"),
                        const SizedBox(height: 6),
                        Obx(
                          () => _PasswordField(
                            controller: controller.confirmPasswordController,
                            hint: "Re-enter new password",
                            isVisible:
                                controller.isConfirmPasswordVisible.value,
                            onToggle:
                                controller.toggleConfirmPasswordVisibility,
                          ),
                        ),

                        const SizedBox(height: 8),

                        /// PASSWORD HINTS
                        _PasswordHint(
                          text: "At least 8 characters",
                          controller: controller.newPasswordController,
                          checkFn: (val) => val.length >= 8,
                        ),
                        const SizedBox(height: 4),
                        _PasswordHint(
                          text: "Contains a number",
                          controller: controller.newPasswordController,
                          checkFn: (val) => val.contains(RegExp(r'[0-9]')),
                        ),
                        const SizedBox(height: 4),
                        _PasswordMatchHint(
                          newController: controller.newPasswordController,
                          confirmController:
                              controller.confirmPasswordController,
                        ),

                        const SizedBox(height: 24),

                        /// RESET BUTTON
                        Obx(
                          () => _GradientButton(
                            label: "RESET PASSWORD",
                            isLoading: controller.isLoading.value,
                            onTap: controller.resetPassword,
                          ),
                        ),

                        const SizedBox(height: 16),

                        /// FOOTER
                        Column(
                          children: [
                            const Divider(),
                            const SizedBox(height: 5),
                            Text(
                              "Technical issues? Contact the IT Concierge",
                              style: AppText.bodySmall,
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "+91 0123456789",
                              style: AppText.bodyMedium.copyWith(
                                fontWeight: FontWeight.bold,
                                color: AppColors.primary,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 10),
                  Text(
                    "Innovation starts here – log in and drive progress.",
                    style: AppText.bodySmall,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PasswordLabel extends StatelessWidget {
  final String label;

  const _PasswordLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Text(
        label,
        style: AppText.bodySmall.copyWith(fontWeight: FontWeight.w600),
      ),
    );
  }
}

class _PasswordField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final bool isVisible;
  final VoidCallback onToggle;

  const _PasswordField({
    required this.controller,
    required this.hint,
    required this.isVisible,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      obscureText: !isVisible,
      decoration: InputDecoration(
        hintText: hint,
        prefixIcon: const Icon(Icons.lock_outline),
        suffixIcon: IconButton(
          onPressed: onToggle,
          icon: Icon(
            isVisible
                ? Icons.visibility_off_outlined
                : Icons.visibility_outlined,
            color: Colors.grey,
          ),
        ),
        filled: true,
        fillColor: const Color(0xFFF3F3F3),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: AppColors.primary, width: 1.5),
        ),
      ),
    );
  }
}

/// Live password requirement hint
class _PasswordHint extends StatefulWidget {
  final String text;
  final TextEditingController controller;
  final bool Function(String) checkFn;

  const _PasswordHint({
    required this.text,
    required this.controller,
    required this.checkFn,
  });

  @override
  State<_PasswordHint> createState() => _PasswordHintState();
}

class _PasswordHintState extends State<_PasswordHint> {
  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_rebuild);
  }

  void _rebuild() => setState(() {});

  @override
  void dispose() {
    widget.controller.removeListener(_rebuild);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final passed = widget.checkFn(widget.controller.text);
    return Row(
      children: [
        Icon(
          passed ? Icons.check_circle_rounded : Icons.radio_button_unchecked,
          size: 14,
          color: passed ? AppColors.green : Colors.grey,
        ),
        const SizedBox(width: 6),
        Text(
          widget.text,
          style: AppText.bodySmall.copyWith(
            color: passed ? AppColors.green : Colors.grey,
          ),
        ),
      ],
    );
  }
}

/// Password match hint
class _PasswordMatchHint extends StatefulWidget {
  final TextEditingController newController;
  final TextEditingController confirmController;

  const _PasswordMatchHint({
    required this.newController,
    required this.confirmController,
  });

  @override
  State<_PasswordMatchHint> createState() => _PasswordMatchHintState();
}

class _PasswordMatchHintState extends State<_PasswordMatchHint> {
  @override
  void initState() {
    super.initState();
    widget.newController.addListener(_rebuild);
    widget.confirmController.addListener(_rebuild);
  }

  void _rebuild() => setState(() {});

  @override
  void dispose() {
    widget.newController.removeListener(_rebuild);
    widget.confirmController.removeListener(_rebuild);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final match =
        widget.newController.text.isNotEmpty &&
        widget.newController.text == widget.confirmController.text;
    return Row(
      children: [
        Icon(
          match ? Icons.check_circle_rounded : Icons.radio_button_unchecked,
          size: 14,
          color: match ? AppColors.green : Colors.grey,
        ),
        const SizedBox(width: 6),
        Text(
          "Passwords match",
          style: AppText.bodySmall.copyWith(
            color: match ? AppColors.green : Colors.grey,
          ),
        ),
      ],
    );
  }
}

class _GradientButton extends StatelessWidget {
  final String label;
  final bool isLoading;
  final VoidCallback onTap;

  const _GradientButton({
    required this.label,
    required this.isLoading,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [AppColors.secondary, AppColors.primary],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.withAlpha(100),
              blurRadius: 12,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Center(
          child: isLoading
              ? const CircularProgressIndicator(color: Colors.white)
              : Text(
                  label,
                  style: AppText.bodyLarge.copyWith(
                    color: Colors.white,
                    letterSpacing: 2,
                    fontWeight: FontWeight.bold,
                  ),
                ),
        ),
      ),
    );
  }
}
