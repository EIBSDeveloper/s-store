import 'dart:ui';
import 'package:elysium_employee/core/app_colors.dart';
import 'package:elysium_employee/core/app_text_theme.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/forgot_password_controller.dart';
import '../widgets/background_shapes.dart';
import '../widgets/login_input_field.dart';

class ForgotPasswordScreen extends GetView<ForgotPasswordController> {
  const ForgotPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          const BackgroundShapes(),

          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  /// LOGO
                  // Column(
                  //   children: [
                  //     Image.network(
                  //       "https://erp.elysium.community/assets/common/logo_small.png",
                  //       height: 80,
                  //     ),
                  //     const SizedBox(height: 6),
                  //     Container(
                  //       height: 3,
                  //       width: 50,
                  //       decoration: BoxDecoration(
                  //         borderRadius: BorderRadius.circular(5),
                  //         color: AppColors.primary,
                  //       ),
                  //     ),
                  //   ],
                  // ),

                  // const SizedBox(height: 20),

                  /// CARD
                  Container(
                    width: 400,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          blurRadius: 32,
                          color: Colors.black.withOpacity(.04),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(24),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                        child: Container(
                          padding: const EdgeInsets.all(28),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Colors.white.withOpacity(0.4),
                                Colors.white.withOpacity(0.1),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.6),
                              width: 1.5,
                            ),
                          ),
                          child: Column(
                            children: [
                              /// BACK BUTTON
                              Align(
                                alignment: Alignment.centerLeft,
                                child: GestureDetector(
                                  onTap: () => Get.back(),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        Icons.arrow_back_ios_new_rounded,
                                        size: 14,
                                        color: AppColors.primary,
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        'Back to Login',
                                        style: AppText.bodySmall.copyWith(
                                          color: AppColors.primary,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),

                              // const SizedBox(height: 20),

                              // /// LOCK ICON
                              // Container(
                              //   width: 64,
                              //   height: 64,
                              //   decoration: BoxDecoration(
                              //     gradient: AppColors.gradient,
                              //     shape: BoxShape.circle,
                              //     boxShadow: [
                              //       BoxShadow(
                              //         color: AppColors.primary.withOpacity(0.3),
                              //         blurRadius: 16,
                              //         offset: const Offset(0, 6),
                              //       ),
                              //     ],
                              //   ),
                              //   child: const Icon(
                              //     Icons.lock_reset_rounded,
                              //     color: Colors.white,
                              //     size: 30,
                              //   ),
                              // ),
                              const SizedBox(height: 16),

                              /// HEADER
                              Text(
                                "Forgot Password?",
                                style: AppText.titleLarge.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                "Enter your Employee ID and we'll send an OTP to your registered contact",
                                style: AppText.bodySmall.copyWith(
                                  color: Colors.grey,
                                  fontWeight: FontWeight.w500,
                                ),
                                textAlign: TextAlign.center,
                              ),

                              const SizedBox(height: 24),

                              /// EMPLOYEE ID FIELD
                              LoginInputField(
                                label: "Employee ID",
                                hint: "E-000000",
                                icon: Icons.badge_outlined,
                                controller: controller.empIdController,
                              ),

                              const SizedBox(height: 24),

                              /// SEND OTP BUTTON
                              Obx(
                                () => _GradientButton(
                                  label: "SEND OTP",
                                  isLoading: controller.isLoading.value,
                                  onTap: controller.sendOtp,
                                ),
                              ),

                              const SizedBox(height: 16),

                              /// FOOTER
                              // Column(
                              //   children: [
                              //     const Divider(),
                              //     const SizedBox(height: 5),
                              //     Text(
                              //       "Technical issues? Contact the IT Concierge",
                              //       style: AppText.bodySmall,
                              //       textAlign: TextAlign.center,
                              //     ),
                              //     const SizedBox(height: 4),
                              //     Text(
                              //       "+91 0123456789",
                              //       style: AppText.bodyMedium.copyWith(
                              //         fontWeight: FontWeight.bold,
                              //         color: AppColors.primary,
                              //       ),
                              //     ),
                              //   ],
                              // ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 10),
                  Text(
                    "Innovation starts here – log in and drive progress.",
                    style: AppText.bodySmall,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Reusable gradient button
class _GradientButton extends StatelessWidget {
  final String label;
  final bool isLoading;
  final VoidCallback onTap;

  const _GradientButton({
    required this.label,
    required this.isLoading,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          gradient:   LinearGradient(
            colors: [AppColors.secondary, AppColors.primary],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.withAlpha(100),
              blurRadius: 12,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Center(
          child: isLoading
              ? const CircularProgressIndicator(color: Colors.white)
              : Text(
                  label,
                  style: AppText.bodyLarge.copyWith(
                    color: Colors.white,
                    letterSpacing: 2,
                    fontWeight: FontWeight.bold,
                  ),
                ),
        ),
      ),
    );
  }
}
