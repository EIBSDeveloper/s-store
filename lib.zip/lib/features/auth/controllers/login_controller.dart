import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../routes/app_routes.dart';
import '../models/login_response_model.dart';

class LoginController extends GetxController {
  final repo = AuthRepository();

  final empIdController = TextEditingController();
  final passwordController = TextEditingController();

  var isLoading = false.obs;

  void login() async {
    isLoading.value = true;

    final res = await repo.login(empIdController.text, passwordController.text);

    isLoading.value = false;

    if (res != null) {
      Get.toNamed(Routes.home);
      Get.snackbar("Success", "Welcome ${res.userName}");
    } else {
      Get.snackbar("Error", "Invalid Credentials");
    }
  }
}
