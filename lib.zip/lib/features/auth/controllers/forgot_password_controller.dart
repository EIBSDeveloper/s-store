import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../routes/app_routes.dart';

class ForgotPasswordController extends GetxController {
  // Step 1: Employee ID entry
  final empIdController = TextEditingController();

  // Step 2: OTP verification
  final List<TextEditingController> otpControllers =
      List.generate(6, (_) => TextEditingController());
  final List<FocusNode> otpFocusNodes =
      List.generate(6, (_) => FocusNode());

  // Step 3: New password
  final newPasswordController = TextEditingController();
  final confirmPasswordController = TextEditingController();

  var isLoading = false.obs;
  var isPasswordVisible = false.obs;
  var isConfirmPasswordVisible = false.obs;

  // Resend OTP timer
  var resendSeconds = 30.obs;
  bool _timerRunning = false;

  @override
  void onClose() {
    empIdController.dispose();
    for (var c in otpControllers) {
      c.dispose();
    }
    for (var f in otpFocusNodes) {
      f.dispose();
    }
    newPasswordController.dispose();
    confirmPasswordController.dispose();
    super.onClose();
  }

  String get otp => otpControllers.map((c) => c.text).join();

  void togglePasswordVisibility() {
    isPasswordVisible.value = !isPasswordVisible.value;
  }

  void toggleConfirmPasswordVisibility() {
    isConfirmPasswordVisible.value = !isConfirmPasswordVisible.value;
  }

  /// Send OTP to the employee's registered email/phone
  void sendOtp() async {
    final empId = empIdController.text.trim();
    if (empId.isEmpty) {
      Get.snackbar(
        'Missing Info',
        'Please enter your Employee ID',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.orange.shade100,
        colorText: Colors.orange.shade900,
      );
      return;
    }

    isLoading.value = true;

    // TODO: Replace with actual API call
    await Future.delayed(const Duration(seconds: 2));

    isLoading.value = false;

    // Navigate to OTP screen
    Get.toNamed(Routes.otpVerification, arguments: empId);
    _startResendTimer();

    Get.snackbar(
      'OTP Sent',
      'A 6-digit OTP has been sent to your registered contact',
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: Colors.green.shade100,
      colorText: Colors.green.shade900,
    );
  }

  /// Verify the entered OTP
  void verifyOtp() async {
    if (otp.length < 6) {
      Get.snackbar(
        'Invalid OTP',
        'Please enter all 6 digits',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.orange.shade100,
        colorText: Colors.orange.shade900,
      );
      return;
    }

    isLoading.value = true;

    // TODO: Replace with actual API call
    await Future.delayed(const Duration(seconds: 2));

    isLoading.value = false;

    // Navigate to reset password screen
    Get.toNamed(Routes.newPassword);
  }

  /// Handle OTP field navigation
  void onOtpChanged(String value, int index) {
    if (value.isNotEmpty && index < 5) {
      otpFocusNodes[index + 1].requestFocus();
    } else if (value.isEmpty && index > 0) {
      otpFocusNodes[index - 1].requestFocus();
    }
  }

  /// Resend OTP
  void resendOtp() {
    if (resendSeconds.value > 0) return;
    for (var c in otpControllers) {
      c.clear();
    }
    otpFocusNodes[0].requestFocus();
    _startResendTimer();
    Get.snackbar(
      'OTP Resent',
      'A new OTP has been sent',
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: Colors.green.shade100,
      colorText: Colors.green.shade900,
    );
  }

  void _startResendTimer() {
    if (_timerRunning) return;
    resendSeconds.value = 30;
    _timerRunning = true;
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (resendSeconds.value > 0) {
        resendSeconds.value--;
        return true;
      }
      _timerRunning = false;
      return false;
    });
  }

  /// Reset password
  void resetPassword() async {
    final newPass = newPasswordController.text;
    final confirmPass = confirmPasswordController.text;

    if (newPass.isEmpty || confirmPass.isEmpty) {
      Get.snackbar(
        'Missing Info',
        'Please fill in all fields',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.orange.shade100,
        colorText: Colors.orange.shade900,
      );
      return;
    }

    if (newPass.length < 8) {
      Get.snackbar(
        'Weak Password',
        'Password must be at least 8 characters',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.orange.shade100,
        colorText: Colors.orange.shade900,
      );
      return;
    }

    if (newPass != confirmPass) {
      Get.snackbar(
        'Mismatch',
        'Passwords do not match',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red.shade100,
        colorText: Colors.red.shade900,
      );
      return;
    }

    isLoading.value = true;

    // TODO: Replace with actual API call
    await Future.delayed(const Duration(seconds: 2));

    isLoading.value = false;

    Get.snackbar(
      'Success',
      'Password reset successfully. Please log in.',
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: Colors.green.shade100,
      colorText: Colors.green.shade900,
    );

    // Go back to login
    Get.offAllNamed(Routes.login);
  }
}
