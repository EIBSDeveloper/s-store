import 'package:elysium_employee/core/app_colors.dart';
import 'package:flutter/material.dart';

class BackgroundShapes extends StatelessWidget {
  const BackgroundShapes({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        /// Top Right Blob
        Positioned(
          top: -80,
          right: -80,
          child: Container(
            width: 200,
            height: 230,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [
                  AppColors.secondary.withAlpha(200),
                  AppColors.primary.withAlpha(200),
                ],
              ),
            ),
          ),
        ),

        /// Center Behind Blob 1
        Align(
          alignment: Alignment.center,
          child: Transform.translate(
            offset: const Offset(-100, -80),
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    AppColors.secondary.withAlpha(200),
                    AppColors.primary.withAlpha(200),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
            ),
          ),
        ),

        /// Center Behind Blob 2
        Align(
          alignment: Alignment.center,
          child: Transform.translate(
            offset: const Offset(120, 150),
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    AppColors.primary.withAlpha(200),
                    AppColors.secondary.withAlpha(200),
                  ],
                  begin: Alignment.bottomLeft,
                  end: Alignment.topRight,
                ),
              ),
            ),
          ),
        ),

        /// Top Left
        // Positioned(
        //   top: 40,
        //   left: 20,
        //   child: Container(
        //     width: 80,
        //     height: 80,
        //     decoration: const BoxDecoration(
        //       shape: BoxShape.circle,
        //       gradient: LinearGradient(
        //         colors: [AppColors.secondary, AppColors.primary],
        //       ),
        //     ),
        //   ),
        // ),
        Positioned(
          top: 40,
          left: 35,
          child: Container(
            // width: 80,
            // height: 90,
            // decoration: const BoxDecoration(
            //   shape: BoxShape.circle,
            //   gradient: LinearGradient(
            //     colors: [AppColors.secondary, AppColors.primary],
            //   ),
            // ),
            child: Column(
              children: [
                Image.network(
                  "https://erp.elysium.community/assets/common/logo_small.png",
                  height: 80,
                ),
                const SizedBox(height: 3),
                Container(
                  height: 3,
                  width: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: AppColors.primary,
                    gradient: LinearGradient(
                      colors: [AppColors.primary, AppColors.secondary],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),

        /// Bottom Cluster
        Positioned(
          bottom: 30,
          left: 20,
          child: Row(
            children: [
              _circle(50, [
                AppColors.secondary.withAlpha(200),
                AppColors.primary.withAlpha(200),
              ]),
              const SizedBox(width: 6),
              _circle(30, [
                AppColors.primary.withAlpha(200),
                AppColors.secondary.withAlpha(200),
              ]),
              const SizedBox(width: 6),
              _circle(20, [
                AppColors.secondary.withAlpha(200),
                AppColors.primary.withAlpha(200),
              ]),
            ],
          ),
        ),
      ],
    );
  }

  Widget _circle(double size, List<Color> colors) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: colors),
        shape: BoxShape.circle,
      ),
    );
  }
}
