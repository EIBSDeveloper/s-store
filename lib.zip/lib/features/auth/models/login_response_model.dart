import '../repository/auth_repository.dart';

class AuthRepository {
  Future<LoginResponse?> login(String empId, String password) async {
    await Future.delayed(const Duration(seconds: 2));

    /// MOCK RESPONSE
    final json = {
      "status": true,
      "token": "abc123token",
      "user_name": "John Doe",
    };

    if (empId == "E001" && password == "123456") {
      return LoginResponse.fromJson(json);
    }

    return null;
  }
}
