import 'package:flutter/material.dart'; 

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  // Design Tokens
  static const Color primary = Color(0xFF3F51B5);
  static const Color backgroundLight = Color(0xFFF8FAFC);
  static const Color textSlate = Color(0xFF334155);
  static const Color iconColor = Color(0xFF7E8CA0);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundLight,
      body: Stack(
        children: [
          // Background Gradient Waves (CSS wave-top/bottom)
          const Positioned(top: 0, left: 0, right: 0, child: WaveMask(isTop: true)),
          const Positioned(bottom: 0, left: 0, right: 0, child: WaveMask(isTop: false)),

          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Column(
                children: [
                  const SizedBox(height: 60),
                  
                  // Header Section
                  Text(
                    "Welcome",
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w800,
                      color: textSlate,
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Text(
                      "Login to access your attendance, tasks, salary and more.",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 14,
                        height: 1.5,
                      ),
                    ),
                  ),

                  const SizedBox(height: 48),

                  // Illustration Placeholder
                  const LoginIllustration(),

                  const SizedBox(height: 48),

                  // Input Fields
                  _buildInputField(
                    hint: "Employee ID",
                    icon: Icons.badge_outlined,
                  ),
                  const SizedBox(height: 16),
                  _buildInputField(
                    hint: "Enter your password",
                    icon: Icons.lock_outline,
                    isPassword: true,
                  ),

                  // Forgot Password
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: () {},
                      child: const Text(
                        "Forgot Password?",
                        style: TextStyle(
                          fontSize: 12,
                          color: Color(0xFF64748B),
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Login Button
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primary,
                        foregroundColor: Colors.white,
                        elevation: 4,
                        shadowColor: primary.withOpacity(0.4),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        "LOGIN",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 60),

                  // Footer
                  Column(
                    children: [
                      Container(
                        width: 140,
                        padding: const EdgeInsets.only(bottom: 4),
                        decoration: const BoxDecoration(
                          border: Border(
                            bottom: BorderSide(color: Color(0xFFE2E8F0), width: 1),
                          ),
                        ),
                        child: const Text(
                          "© 2026 ELYSIUM GROUPS",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 10,
                            letterSpacing: 2,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF94A3B8),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputField({
    required String hint,
    required IconData icon,
    bool isPassword = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 15,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: TextField(
        obscureText: isPassword,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: Colors.grey, fontSize: 14),
          prefixIcon: Icon(icon, color: iconColor, size: 22),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
        ),
      ),
    );
  }
}



// Custom Painter for the SVG-style desk illustration
class LoginIllustration extends StatelessWidget {
  const LoginIllustration({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 240,
      height: 100,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          // Base line
          Container(
            height: 2,
            width: 240,
            color: const Color(0xFFE2E8F0),
          ),
          // Simple geometric shapes to represent the SVG assets
          Positioned(
            bottom: 2,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFA726),
                    borderRadius: const BorderRadius.only(topLeft: Radius.circular(20)),
                    border: Border.all(color: const Color(0xFF475569), width: 1.5),
                  ),
                ),
                Container(
                  width: 60,
                  height: 70,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF1F5F9),
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: const Color(0xFF475569), width: 1.5),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Gradient Mask for top and bottom waves
class WaveMask extends StatelessWidget {
  final bool isTop;
  const WaveMask({super.key, required this.isTop});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: isTop ? 200 : 150,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: isTop ? Alignment.topLeft : Alignment.bottomRight,
          end: isTop ? Alignment.bottomRight : Alignment.topLeft,
          colors: [
            const Color(0xFF3F51B5).withOpacity(isTop ? 0.1 : 0.08),
            const Color(0xFF3F51B5).withOpacity(isTop ? 0.05 : 0.03),
          ],
        ),
      ),
    );
  }
}


