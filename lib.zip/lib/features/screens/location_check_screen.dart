import 'package:flutter/material.dart'; 

class LocationCheckScreen extends StatelessWidget {
  const LocationCheckScreen({super.key});

  // Design Tokens
  static const Color primary = Color(0xFF4F63D1);
  static const Color backgroundLight = Color(0xFFF8FAFF);
  static const Color emerald50 = Color(0xFFECFDF5);
  static const Color emerald500 = Color(0xFF10B981);
  static const Color emerald700 = Color(0xFF047857);
  static const Color slate500 = Color(0xFF64748B);
  static const Color slate900 = Color(0xFF0F172A);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundLight,
      body: Column(
        children: [
          // Mock System Status Bar
          _buildStatusBar(),
          
          // App Header
          _buildHeader(),

          Expanded(
            child: Stack(
              children: [
                
                SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Map View
                      _buildMapCard(),
                      const SizedBox(height: 24),
                      
                      // Status Banner
                      _buildStatusBanner(),
                      const SizedBox(height: 24),
                      
                      // Location Details Section
                      const Padding(
                        padding: EdgeInsets.only(left: 4, bottom: 12),
                        child: Text(
                          "LOCATION DETAILS",
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.2,
                            color: slate500,
                          ),
                        ),
                      ),
                      _buildDetailsCard(),
                      const SizedBox(height: 24),
                      
                      // Info Warning
                      _buildWarningCard(),
                      const SizedBox(height: 80), // Space for button
                    ],
                  ),
                ),
              ],
            ),
          ),
          
          // Fixed Bottom Section
          _buildBottomAction(),
        ],
      ),
    );
  }

  Widget _buildStatusBar() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(24, 12, 24, 8),
      child: SafeArea(
        bottom: false,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text("9:41", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            Row(
              children: const [
                Icon(Icons.signal_cellular_alt, size: 16),
                SizedBox(width: 4),
                Icon(Icons.wifi, size: 16),
                SizedBox(width: 4),
                Icon(Icons.battery_full, size: 16),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: Colors.grey.shade100)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              IconButton(onPressed: () {}, icon: const Icon(Icons.chevron_left, size: 28)),
              const Text("Location Check", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            ],
          ),
          Stack(
            children: [
              IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_outlined, size: 26)),
              Positioned(
                right: 12,
                top: 12,
                child: Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: Colors.red,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 2),
                  ),
                ),
              )
            ],
          )
        ],
      ),
    );
  }

  Widget _buildMapCard() {
    return Container(
      height: 224,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Map Placeholder
            Image.network(
              "https://placehold.co/600x400/e2e8f0/64748b?text=Map+View",
              fit: BoxFit.cover,
              width: double.infinity,
              height: double.infinity,
            ),
            // Pin
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.location_on, color: primary, size: 48),
                Container(
                  width: 16,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusBanner() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: emerald50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFD1FAE5)),
      ),
      child: Row(
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(
              color: emerald500,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(color: emerald500.withOpacity(0.3), spreadRadius: 4),
              ],
            ),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Text(
              "Inside office zone — Elysium HQ Madurai",
              style: TextStyle(color: emerald700, fontWeight: FontWeight.w600, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailsCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.grey.shade100),
      ),
      child: Column(
        children: [
          _buildDetailRow("Detected location", "9.9252° N, 78.1198° E", "VERIFIED", Colors.cyan),
          const Divider(height: 32, color: Color(0xFFF1F5F9)),
          _buildDetailRow("Office zone", "Elysium HQ (100m Radius)", "WITHIN", Colors.cyan),
          const Divider(height: 32, color: Color(0xFFF1F5F9)),
          _buildDetailRow("GPS accuracy", "+/- 8 meters", "HIGH", Colors.indigo),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String title, String subtitle, String tag, MaterialColor color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 2),
            Text(subtitle, style: const TextStyle(color: slate500, fontSize: 13)),
          ],
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: color.shade50,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            tag,
            style: TextStyle(color: color.shade700, fontWeight: FontWeight.bold, fontSize: 10),
          ),
        ),
      ],
    );
  }

  Widget _buildWarningCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFBEB),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFFEF3C7)),
      ),
      child: Column(
        children: const [
          Text("Not at office?", style: TextStyle(color: Color(0xFFB45309), fontWeight: FontWeight.bold)),
          SizedBox(height: 4),
          Text(
            "Enable WFH mode on the previous screen before checking in. Late or outside-zone check ins are flagged for HR review.",
            textAlign: TextAlign.center,
            style: TextStyle(color: Color(0xFFD97706), fontSize: 13, height: 1.5),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomAction() {
    return Container(
      padding: const EdgeInsets.all(16),
      color: Colors.white,
      child: ElevatedButton(
        onPressed: () {},
        style: ElevatedButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 56),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          elevation: 4,
          shadowColor: primary.withOpacity(0.4),
        ),
        child: const Text("Confirm Check In", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
      ),
    );
  }


}
