import 'package:flutter/material.dart';

class RadialBackground extends StatelessWidget {
  const RadialBackground({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(1.0, -1.0),
          radius: 1.0,
          colors: [Color(0x0D3F51B5), Colors.transparent],
        ),
      ),
    );
  }
}
