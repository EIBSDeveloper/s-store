import 'package:elysium_employee/core/app_colors.dart';
import 'package:flutter/material.dart';

// class AttendanceDashboard extends StatelessWidget {
//   const AttendanceDashboard({super.key});

//   // Color Palette from HTML
// }
