import 'package:flutter/material.dart'; 
import './donut_chart_painter.dart'; 

class PayslipDetailScreen extends StatelessWidget {
  const PayslipDetailScreen({super.key});

  // Design Tokens
  static const Color primary = Color(0xFF273A96);
  static const Color accentOrange = Color(0xFFFFB31B);
  static const Color backgroundLight = Color(0xFFF8F9FE);
  static const Color cardLight = Colors.white;
  static const Color textSlate600 = Color(0xFF475569);
  static const Color textSlate900 = Color(0xFF0F172A);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundLight,
      body: Stack(
        children: [
          // Radial/Wavy Background Effect

          Column(
            children: [
              _buildStatusBar(),
              _buildHeader(),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildEmployeeCard(),
                      const SizedBox(height: 24),
                      _buildSectionTitle("EARNINGS"),
                      _buildEarningsCard(),
                      const SizedBox(height: 24),
                      _buildSectionTitle("DEDUCTIONS"),
                      _buildDeductionsCard(),
                      const SizedBox(height: 16),
                      _buildNetPayableBanner(),
                      const SizedBox(height: 120), // Bottom padding for fixed button
                    ],
                  ),
                ),
              ),
            ],
          ),

          // Floating Download Button
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: _buildDownloadButton(),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(32, 12, 32, 8),
      child: SafeArea(
        bottom: false,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text("9:41", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            Row(
              children: const [
                Icon(Icons.signal_cellular_alt, size: 18),
                SizedBox(width: 6),
                Icon(Icons.wifi, size: 18),
                SizedBox(width: 6),
                Icon(Icons.battery_full, size: 22),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              IconButton(onPressed: () {}, icon: const Icon(Icons.chevron_left, size: 28)),
              Text(
                "Payslip Detail",
                style:TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: textSlate900),
              ),
            ],
          ),
          IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_outlined, size: 26)),
        ],
      ),
    );
  }

  Widget _buildEmployeeCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF9EE),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFFFE7B2)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10)],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Elysium Groups", style:TextStyle(color: accentOrange, fontWeight: FontWeight.bold, fontSize: 18)),
              const SizedBox(height: 4),
              const Text("Salary Slip — March 2026", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 4),
              const Text("Aditya • L3 • EMP0142", style: TextStyle(color: textSlate600, fontSize: 14)),
            ],
          ),
          SizedBox(
            width: 60,
            height: 60,
            child: CustomPaint(painter: DonutChartPainter()),
          )
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 12),
      child: Text(
        title,
        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: textSlate600, letterSpacing: 1.1),
      ),
    );
  }

  Widget _buildEarningsCard() {
    return _buildDetailsCard([
      _rowItem("Basic salary", "₹25,000"),
      _rowItem("HRA", "₹12,500"),
      _rowItem("PA", "₹7,100"),
      _rowItem("Incentive", "₹4,200", valueColor: Colors.green.shade600),
      _rowItem("Transport Allowance", "₹3,000"),
    ], "Gross", "₹51,800", accentOrange);
  }

  Widget _buildDeductionsCard() {
    return _buildDetailsCard([
      _rowItem("PF", "₹6,216"),
      _rowItem("ESI", "0"),
      _rowItem("PT", "₹200"),
      _rowItem("LOP", "₹1,456"),
    ], "Total Deduction", "₹7,872", Colors.red);
  }

  Widget _buildDetailsCard(List<Widget> rows, String totalLabel, String totalValue, Color totalColor) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 20, offset: const Offset(0, 4))],
      ),
      child: Column(
        children: [
          ...rows,
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Divider(height: 1, color: Color(0xFFF1F5F9)),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(totalLabel, style:TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              Text(totalValue, style:TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: totalColor)),
            ],
          )
        ],
      ),
    );
  }

  Widget _rowItem(String label, String value, {Color? valueColor}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: textSlate600, fontSize: 14)),
          Text(value, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: valueColor ?? textSlate900)),
        ],
      ),
    );
  }

  Widget _buildNetPayableBanner() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFFEEF2FF),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFD1DBFF)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text("Net Payable", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          Text(
            "₹48,128",
            style:TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: primary),
          ),
        ],
      ),
    );
  }

  Widget _buildDownloadButton() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [backgroundLight.withOpacity(0), backgroundLight],
        ),
      ),
      child: ElevatedButton.icon(
        onPressed: () {},
        icon: const Icon(Icons.download_rounded, color: Colors.white),
        label: const Text("Download"),
        style: ElevatedButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 56),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          elevation: 8,
          shadowColor: primary.withOpacity(0.4),
          textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
