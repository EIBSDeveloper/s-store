import 'dart:math' as math;
import 'package:flutter/material.dart';

import 'payslip_detail_screen.dart'; 

class DonutChartPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;
    final rect = Rect.fromCircle(center: center, radius: radius);

    final paintPrimary = Paint()..style = PaintingStyle.fill;
    final paintAccent = Paint()..style = PaintingStyle.fill;

    // Draw Conic Gradient (Primary for Earnings, Accent for Deductions)
    // 280deg for Primary, remaining for Accent
    canvas.drawArc(rect, -math.pi / 2, (280 / 360) * 2 * math.pi, true, paintPrimary..color = PayslipDetailScreen.primary);
    canvas.drawArc(rect, (280 / 360) * 2 * math.pi - math.pi / 2, (80 / 360) * 2 * math.pi, true, paintAccent..color = PayslipDetailScreen.accentOrange);

    // Draw White center to create Donut effect
    canvas.drawCircle(center, radius * 0.6, Paint()..color = Colors.white);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}
