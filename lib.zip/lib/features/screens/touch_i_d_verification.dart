import 'package:flutter/material.dart';
 

class TouchIDVerification extends StatefulWidget {
  const TouchIDVerification({super.key});

  // Color Palette from Tailwind Config
  static const Color primaryColor = Color(0xFF4459C5);
  static const Color secondaryColor = Color(0xFFFFB321);
  static const Color backgroundLight = Colors.white;
  static const Color cardLight = Color(0xFFF8FAFC);
  static const Color textSlate900 = Color(0xFF0F172A);
  static const Color textSlate500 = Color(0xFF64748B);
  static const Color textSlate400 = Color(0xFF94A3B8);

  @override
  State<TouchIDVerification> createState() => _TouchIDVerificationState();
}

class _TouchIDVerificationState extends State<TouchIDVerification> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TouchIDVerification.backgroundLight,
      body: Stack(
        children: [
          // --- Background Wave Pattern Mockup ---
          Positioned.fill(
            child: CustomPaint(
              painter: WavePainter(),
            ),
          ),
          
          SafeArea(
            bottom: false,
            child: Column(
              children: [
                // --- Mock System Status Bar ---
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text("9:41", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                      Row(
                        children: const [
                          Icon(Icons.signal_cellular_alt, size: 14),
                          SizedBox(width: 6),
                          Icon(Icons.wifi, size: 14),
                          SizedBox(width: 6),
                          RotationTransition(
                            turns: AlwaysStoppedAnimation(90 / 360),
                            child: Icon(Icons.battery_full, size: 14),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // --- Header ---
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.arrow_back_ios, size: 20, color: TouchIDVerification.textSlate500),
                          const SizedBox(width: 8),
                          Text(
                            "Check In",
                            style:TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: TouchIDVerification.textSlate900,
                            ),
                          ),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: const BoxDecoration(shape: BoxShape.circle),
                        child: const Icon(Icons.notifications_none, color: TouchIDVerification.textSlate500),
                      ),
                    ],
                  ),
                ),

                // --- Main Content ---
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(horizontal: 32),
                    child: Column(
                      children: [
                        const SizedBox(height: 32),
                        // Biometric Illustration
                        _buildScannerIllustration(),
                        const SizedBox(height: 40),
                        
                        Text(
                          "Touch ID verification",
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: TouchIDVerification.textSlate900,
                          ),
                        ),
                        const SizedBox(height: 12),
                        const Text(
                          "Place your finger on the sensor or use Face ID to confirm your identity",
                          textAlign: TextAlign.center,
                          style: TextStyle(color: TouchIDVerification.textSlate500, height: 1.5),
                        ),
                        const SizedBox(height: 40),

                        // Action Buttons
                        _buildButton(
                          text: "Use Face ID",
                          bgColor: TouchIDVerification.primaryColor,
                          textColor: Colors.white,
                          hasShadow: true,
                        ),
                        const SizedBox(height: 16),
                        _buildButton(
                          text: "Use PIN Instead",
                          bgColor: TouchIDVerification.secondaryColor,
                          textColor: TouchIDVerification.textSlate900,
                          hasShadow: false,
                        ),
                      ],
                    ),
                  ),
                ),

                // --- Bottom Info Section ---
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.fromLTRB(32, 40, 32, 24),
                  decoration: const BoxDecoration(
                    color: TouchIDVerification.cardLight,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(40)),
                  ),
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            )
                          ],
                        ),
                        child: Column(
                          children: const [
                            Text(
                              "Why we verify",
                              style: TextStyle(
                                color: TouchIDVerification.primaryColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              "Biometric verification prevents proxy check-ins and ensures accurate attendance records.",
                              textAlign: TextAlign.center,
                              style: TextStyle(color: TouchIDVerification.textSlate500, fontSize: 14, height: 1.5),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 48),
                      const Divider(color: Color(0xFFE2E8F0)),
                      const SizedBox(height: 24),
                      const Text(
                        "Biometric data is processed on-device and\nnever stored on servers",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: TouchIDVerification.textSlate400, fontSize: 12, height: 1.2),
                      ),
                      const SizedBox(height: 32),
                      // Home Indicator
                      Container(
                        width: 128,
                        height: 6,
                        decoration: BoxDecoration(
                          color: const Color(0xFFE2E8F0),
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScannerIllustration() {
    return Container(
      width: 192,
      height: 192,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: TouchIDVerification.primaryColor.withOpacity(0.2), width: 2),
      ),
      child: Center(
        child: Container(
          width: 128,
          height: 160,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: TouchIDVerification.primaryColor, width: 2),
          ),
          child: Stack(
            children: [
              // Top Bar
              Container(
                height: 32,
                decoration: BoxDecoration(
                  border: Border(bottom: BorderSide(color: TouchIDVerification.primaryColor.withOpacity(0.4), width: 2)),
                ),
                child: Row(
                  children: [
                    const SizedBox(width: 8),
                    CircleAvatar(radius: 3, backgroundColor: TouchIDVerification.primaryColor.withOpacity(0.4)),
                    const SizedBox(width: 4),
                    CircleAvatar(radius: 3, backgroundColor: TouchIDVerification.primaryColor.withOpacity(0.4)),
                  ],
                ),
              ),
              // Scanning Corners
              Center(
                child: SizedBox(
                  width: 80,
                  height: 96,
                  child: Stack(
                    children: [
                      _corner(top: 0, left: 0, isTop: true, isLeft: true),
                      _corner(top: 0, right: 0, isTop: true, isLeft: false),
                      _corner(bottom: 0, left: 0, isTop: false, isLeft: true),
                      _corner(bottom: 0, right: 0, isTop: false, isLeft: false),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _corner({double? top, double? left, double? right, double? bottom, required bool isTop, required bool isLeft}) {
    return Positioned(
      top: top, left: left, right: right, bottom: bottom,
      child: Container(
        width: 16,
        height: 16,
        decoration: BoxDecoration(
          border: Border(
            top: isTop ? const BorderSide(color: TouchIDVerification.primaryColor, width: 2) : BorderSide.none,
            bottom: !isTop ? const BorderSide(color: TouchIDVerification.primaryColor, width: 2) : BorderSide.none,
            left: isLeft ? const BorderSide(color: TouchIDVerification.primaryColor, width: 2) : BorderSide.none,
            right: !isLeft ? const BorderSide(color: TouchIDVerification.primaryColor, width: 2) : BorderSide.none,
          ),
        ),
      ),
    );
  }

  Widget _buildButton({required String text, required Color bgColor, required Color textColor, required bool hasShadow}) {
    return Container(
      width: double.infinity,
      height: 60,
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: hasShadow ? [
          BoxShadow(
            color: TouchIDVerification.primaryColor.withOpacity(0.2),
            blurRadius: 15,
            offset: const Offset(0, 8),
          )
        ] : null,
      ),
      child: Center(
        child: Text(
          text,
          style: TextStyle(color: textColor, fontSize: 18, fontWeight: FontWeight.w600),
        ),
      ),
    );
  }
}

// Custom Painter to replicate the SVG Wave Pattern
class WavePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    final path1 = Path();
    paint.color = const Color(0xFF4459C5).withOpacity(0.08);
    path1.moveTo(-50, size.height * 0.2);
    path1.quadraticBezierTo(size.width * 0.25, size.height * 0.15, size.width * 0.5, size.height * 0.2);
    path1.quadraticBezierTo(size.width * 0.75, size.height * 0.25, size.width + 50, size.height * 0.2);
    canvas.drawPath(path1, paint);

    final path2 = Path();
    paint.color = const Color(0xFF4459C5).withOpacity(0.05);
    path2.moveTo(-50, size.height * 0.25);
    path2.quadraticBezierTo(size.width * 0.25, size.height * 0.2, size.width * 0.5, size.height * 0.25);
    path2.quadraticBezierTo(size.width * 0.75, size.height * 0.3, size.width + 50, size.height * 0.25);
    canvas.drawPath(path2, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}