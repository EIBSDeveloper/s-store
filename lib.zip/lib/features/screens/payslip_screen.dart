import 'package:flutter/material.dart'; 

class PayslipScreen extends StatelessWidget {
  const PayslipScreen({super.key});

  // --- Design Tokens ---
  static const Color primary = Color(0xFF3F51B5);
  static const Color secondary = Color(0xFFFFB300);
  static const Color background = Color(0xFFF8F9FD);
  static const Color slate900 = Color(0xFF0F172A);
  static const Color slate500 = Color(0xFF64748B);
  static const Color slate400 = Color(0xFF94A3B8);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 10),
              _buildLatestPayslipCard(),
              const SizedBox(height: 10),
              _buildRecentSectionHeader(),
              const SizedBox(height: 10),
              _buildRecentList(),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLatestPayslipCard() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.grey.shade100),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Latest Payslip",
                  style: TextStyle(
                    color: slate500,
                    fontWeight: FontWeight.w500,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "₹48,128",
                  style: TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                    color: primary,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  "March 2026 • Net payable • Credited Mar 31",
                  style: TextStyle(color: slate500, fontSize: 11),
                ),
                const SizedBox(height: 24),

                // Stats Grid
                Container(
                  padding: const EdgeInsets.only(top: 20),
                  decoration: BoxDecoration(
                    border: Border(
                      top: BorderSide(color: Colors.grey.shade100),
                    ),
                  ),
                  child: Row(
                    children: [
                      _buildStat("₹51,800", "GROSS"),
                      _buildDivider(),
                      _buildStat(
                        "-₹7,872",
                        "DEDUCTIONS",
                        valueColor: Colors.red,
                      ),
                      _buildDivider(),
                      _buildStat(
                        "₹4,200",
                        "INCENTIVE",
                        valueColor: Colors.green.shade600,
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // Action Buttons
                Row(
                  children: [
                    Expanded(
                      child: _buildButton(
                        "View Payslip",
                        Icons.payments,
                        primary,
                        Colors.white,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildButton(
                        "Download",
                        Icons.file_download,
                        secondary,
                        slate900,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStat(String val, String label, {Color? valueColor}) {
    return Expanded(
      child: Column(
        children: [
          Text(
            val,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: valueColor ?? Colors.amber.shade700,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: const TextStyle(
              fontSize: 9,
              color: slate500,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDivider() =>
      Container(height: 30, width: 1, color: Colors.grey.shade100);

  Widget _buildButton(String text, IconData icon, Color bg, Color textCol) {
    return Container(
      height: 50,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          if (bg == primary)
            BoxShadow(
              color: primary.withOpacity(0.2),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: textCol, size: 20),
          const SizedBox(width: 8),
          Text(
            text,
            style: TextStyle(
              color: textCol,
              fontWeight: FontWeight.bold,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentSectionHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Text(
          "Recent Payslips",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        TextButton.icon(
          onPressed: () {},
          icon: const Text(
            "View all",
            style: TextStyle(color: primary, fontWeight: FontWeight.bold),
          ),
          label: const Icon(Icons.arrow_forward, size: 14, color: primary),
        ),
      ],
    );
  }

  Widget _buildRecentList() {
    return Column(
      children: [
        _buildListItem(
          "March 2026",
          "Net ₹48,128",
          "Yesterday",
          Colors.amber.shade50,
          Colors.amber.shade700,
        ),
        const SizedBox(height: 12),
        _buildListItem(
          "February 2026",
          "Net ₹45,340",
          "Mar 04",
          Colors.indigo.shade50,
          primary,
        ),
        const SizedBox(height: 12),
        _buildListItem(
          "January 2026",
          "Net ₹47,550",
          "Feb 04",
          Colors.indigo.shade50,
          primary,
        ),
        const SizedBox(height: 12),
        _buildListItem(
          "December 2025",
          "Net ₹47,550",
          "Jan 04",
          Colors.indigo.shade50,
          primary,
        ),
      ],
    );
  }

  Widget _buildListItem(
    String title,
    String sub,
    String date,
    Color iconBg,
    Color iconCol,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.grey.shade50),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: iconBg,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(Icons.payments_outlined, color: iconCol),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),
                ),
                Text(
                  sub,
                  style: const TextStyle(color: slate500, fontSize: 12),
                ),
              ],
            ),
          ),
          Text(
            date,
            style: const TextStyle(
              color: slate400,
              fontSize: 11,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}
