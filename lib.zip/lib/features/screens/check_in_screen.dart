import 'package:flutter/material.dart'; 
class CheckInScreen extends StatefulWidget {
  const CheckInScreen({super.key});

  @override
  State<CheckInScreen> createState() => _CheckInScreenState();
}

class _CheckInScreenState extends State<CheckInScreen> {
  bool isWfhToggled = true; // Match initial state in your HTML

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFB), // bg-gray-50
      body: SafeArea(
        child: Center(
          // Constrains to a mobile view width on wider screens, just like your HTML
          child: Container(
            constraints: const BoxConstraints(maxWidth: 375),
            color: Colors.white,
            child: Column(
              children: [
                // --- BEGIN: Top Status Bar (System Style Mock) ---
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24.0,
                    vertical: 12.0,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        '9:41',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                      Row(
                        children: const [
                          Icon(
                            Icons.signal_cellular_alt,
                            size: 16,
                            color: Color(0xFF1E293B),
                          ),
                          SizedBox(width: 4),
                          Icon(Icons.wifi, size: 16, color: Color(0xFF1E293B)),
                          SizedBox(width: 4),
                          Icon(
                            Icons.battery_full,
                            size: 16,
                            color: Color(0xFF1E293B),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // --- END: Top Status Bar ---

                // --- BEGIN: Header ---
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16.0,
                    vertical: 8.0,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          IconButton(
                            onPressed: () {},
                            icon: const Icon(
                              Icons.arrow_back_ios_new,
                              size: 20,
                              color: Color(0xFF334155),
                            ),
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(),
                          ),
                          const SizedBox(width: 8),
                          const Text(
                            'Check In',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF1E293B),
                            ),
                          ),
                        ],
                      ),
                      Stack(
                        children: [
                          IconButton(
                            onPressed: () {},
                            icon: const Icon(
                              Icons.notifications_none_outlined,
                              size: 24,
                              color: Color(0xFF334155),
                            ),
                          ),
                          Positioned(
                            right: 12,
                            top: 12,
                            child: Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: Colors.red,
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: Colors.white,
                                  width: 1.5,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // --- END: Header ---
                Expanded(
                  child: Container(
                    // Mimicking the wavy radial gradients from the HTML
                    decoration: const BoxDecoration(
                      gradient: RadialGradient(
                        center: Alignment(-0.6, -0.8),
                        radius: 0.4,
                        colors: [Color(0x66E2E8F0), Colors.transparent],
                      ),
                    ),
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16.0,
                        vertical: 16.0,
                      ),
                      child: Column(
                        children: [
                          // --- BEGIN: Central Illustration (Door Handle) ---
                          Center(
                            child: SizedBox(
                              width: 128,
                              height: 160,
                              child: Stack(
                                children: [
                                  // Base Door plate
                                  Positioned.fill(
                                    left: 8,
                                    right: 20,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        border: Border.all(
                                          color: const Color(0xFF334155),
                                          width: 4,
                                        ),
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                      child: Center(
                                        child: Container(
                                          width: 16,
                                          height: 24,
                                          decoration: BoxDecoration(
                                            color: const Color(0xFF334155),
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  // Left side blue accent
                                  Positioned(
                                    left: 0,
                                    top: 0,
                                    bottom: 0,
                                    width: 8,
                                    child: Container(
                                      decoration: const BoxDecoration(
                                        color: Color(0xFF2563EB),
                                        borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(6),
                                          bottomLeft: Radius.circular(6),
                                        ),
                                      ),
                                    ),
                                  ),
                                  // Right side door handle
                                  Positioned(
                                    top: 16,
                                    right: 0,
                                    width: 80,
                                    height: 16,
                                    child: Container(
                                      decoration: const BoxDecoration(
                                        border: Border(
                                          top: BorderSide(
                                            color: Color(0xFF334155),
                                            width: 4,
                                          ),
                                          right: BorderSide(
                                            color: Color(0xFF334155),
                                            width: 4,
                                          ),
                                          bottom: BorderSide(
                                            color: Color(0xFF334155),
                                            width: 4,
                                          ),
                                        ),
                                        borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(6),
                                          bottomRight: Radius.circular(6),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 24),
                          // --- END: Central Illustration ---

                          // --- BEGIN: Status Card ---
                          Container(
                            padding: const EdgeInsets.all(24),
                            decoration: BoxDecoration(
                              color: const Color(
                                0xFFEFF6FF,
                              ).withOpacity(0.5), // bg-blue-50/50
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: const Color(0xFFDBEAFE),
                              ),
                            ),
                            child: Column(
                              children: [
                                const Text(
                                  'Monday • April 06 • 2026',
                                  style: TextStyle(
                                    color: Color(0xFF94A3B8), // slate-400
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                const Text(
                                  'Not Checked In',
                                  style: TextStyle(
                                    color: Color(0xFF1E293B), // slate-800
                                    fontSize: 30,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                                const SizedBox(height: 24),
                                Container(
                                  padding: const EdgeInsets.only(top: 16),
                                  // border: const Border(
                                  //   top: BorderSide(color: Color(0xFFDBEAFE)),
                                  // ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Text(
                                        'Shift starts at 9:00AM',
                                        style: TextStyle(
                                          color: Color(0xFF64748B),
                                          fontSize: 14,
                                        ),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 12,
                                          vertical: 4,
                                        ),
                                        decoration: BoxDecoration(
                                          color: const Color(
                                            0xFFFFEDD5,
                                          ), // orange-100
                                          borderRadius: BorderRadius.circular(
                                            999,
                                          ),
                                        ),
                                        child: const Text(
                                          'Late',
                                          style: TextStyle(
                                            color: Color(
                                              0xFFF97316,
                                            ), // orange-500
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                          // --- END: Status Card ---

                          // --- BEGIN: Statistics Row ---
                          Container(
                            padding: const EdgeInsets.symmetric(
                              vertical: 16,
                              horizontal: 8,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(
                                0xFFF3E8FF,
                              ).withOpacity(0.3), // purple-50/30
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: const Color(0xFFE9D5FF),
                              ),
                            ),
                            child: Row(
                              children: [
                                _buildStatColumn(
                                  '96%',
                                  'This Month',
                                  const Color(0xFF22C55E),
                                  true,
                                ),
                                _buildStatColumn(
                                  '18',
                                  'Days Present',
                                  const Color(0xFF334155),
                                  true,
                                ),
                                _buildStatColumn(
                                  '2',
                                  'Late Arrivals',
                                  const Color(0xFFF59E0B),
                                  false,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 24),
                          // --- END: Statistics Row ---

                          // --- BEGIN: Main Action Button ---
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: () {},
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF5266CB),
                                padding: const EdgeInsets.symmetric(
                                  vertical: 16,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                elevation: 4,
                                shadowColor: const Color(
                                  0xFF5266CB,
                                ).withOpacity(0.3),
                              ),
                              child: const Text(
                                'Check-In Now',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 24),
                          // --- END: Main Action Button ---

                          // --- BEGIN: Toggle Section ---
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 4.0,
                            ),
                            child: Row(
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      isWfhToggled = !isWfhToggled;
                                    });
                                  },
                                  child: Container(
                                    width: 44,
                                    height: 24,
                                    decoration: BoxDecoration(
                                      color: isWfhToggled
                                          ? const Color(0xFFCBD5E1)
                                          : const Color(0xFF3B82F6),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 2.0,
                                    ),
                                    child: AnimatedAlign(
                                      duration: const Duration(
                                        milliseconds: 200,
                                      ),
                                      alignment: isWfhToggled
                                          ? Alignment.centerRight
                                          : Alignment.centerLeft,
                                      child: Container(
                                        width: 18,
                                        height: 18,
                                        decoration: BoxDecoration(
                                          color: isWfhToggled
                                              ? const Color(0xFF64748B)
                                              : Colors.white,
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                const Text(
                                  'Working from home today',
                                  style: TextStyle(
                                    color: Color(0xFF334155),
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 32),
                          // --- END: Toggle Section ---

                          // --- BEGIN: Recent Activity ---
                          Container(
                            margin: const EdgeInsets.symmetric(horizontal: 16),
                            padding: const EdgeInsets.fromLTRB(16, 24, 16, 80),
                            decoration: const BoxDecoration(
                              color: Color(0xFFF9FAFB),
                              borderRadius: BorderRadius.vertical(
                                top: Radius.circular(24),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Recent Activity',
                                  style: TextStyle(
                                    color: Color(0xFF334155),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                  ),
                                ),
                                const SizedBox(height: 16),
                                _buildActivityItem(
                                  icon: Icons.check,
                                  iconColor: const Color(0xFFF97316),
                                  bgColor: const Color(0xFFFFEDD5),
                                  title: 'Leave Approved',
                                  date: 'Yesterday',
                                  description:
                                      'Casual Leave • Mar 18 - 19 • 2 days',
                                ),
                                const SizedBox(height: 16),
                                _buildActivityItem(
                                  icon: Icons.star_rate_rounded,
                                  iconColor: const Color(0xFFA855F7),
                                  bgColor: const Color(0xFFF3E8FF),
                                  title: 'Full Attendance - Feb 2026',
                                  date: 'Mar 1',
                                  description: '+100 Points Credited',
                                ),
                              ],
                            ),
                          ),
                          // --- END: Recent Activity ---
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Helper widget to construct the statistics columns
  Widget _buildStatColumn(
    String value,
    String label,
    Color valueColor,
    bool hasRightBorder,
  ) {
    return Expanded(
      child: Container(
        decoration: BoxDecoration(
          border: hasRightBorder
              ? const Border(right: BorderSide(color: Color(0xFFCBD5E1)))
              : null,
        ),
        child: Column(
          children: [
            Text(
              value,
              style: TextStyle(
                color: valueColor,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label.toUpperCase(),
              style: const TextStyle(
                color: Color(0xFF64748B),
                fontSize: 10,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper widget to construct activity items
  Widget _buildActivityItem({
    required IconData icon,
    required Color iconColor,
    required Color bgColor,
    required String title,
    required String date,
    required String description,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: bgColor,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: iconColor, size: 24),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF1E293B),
                      fontSize: 14,
                    ),
                  ),
                  Text(
                    date,
                    style: const TextStyle(
                      color: Color(0xFF94A3B8),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 2),
              Text(
                description,
                style: const TextStyle(color: Color(0xFF64748B), fontSize: 12),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
