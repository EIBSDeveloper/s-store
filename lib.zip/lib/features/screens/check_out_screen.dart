import 'package:flutter/material.dart'; 
class CheckOutScreen extends StatelessWidget {
  const CheckOutScreen({super.key});

  // --- Design Tokens from HTML ---
  static const Color primary = Color(0xFFFFB321);
  static const Color backgroundLight = Color(0xFFF8F9FD);
  static const Color cardBlue = Color(0xFFEEF4FF);
  static const Color textMain = Color(0xFF334155);
  static const Color successBg = Color(0xFFECF7ED);
  static const Color successText = Color(0xFF4CAF50);
  static const Color accentBlue = Color(0xFFE8EFFF);
  static const Color accentBlueText = Color(0xFF5C7CFA);
  static const Color slate500 = Color(0xFF64748B);
  static const Color slate800 = Color(0xFF1E293B);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundLight,
      body: Stack(
        children: [
       
          SafeArea(
            child: Column(
              children: [
                // --- Mock Status Bar ---
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("9:41", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                      Row(
                        children: [
                          Icon(Icons.signal_cellular_alt, size: 16),
                          SizedBox(width: 6),
                          Icon(Icons.wifi, size: 16),
                          SizedBox(width: 6),
                          Icon(Icons.battery_full, size: 16),
                        ],
                      ),
                    ],
                  ),
                ),

                // --- Header ---
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.chevron_left, color: slate800),
                          const SizedBox(width: 8),
                          Text(
                            "Check in",
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: slate800,
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          _buildStatusPill(),
                          const SizedBox(width: 12),
                          const Stack(
                            children: [
                              Icon(Icons.notifications_none_outlined, color: slate500),
                              Positioned(
                                right: 0,
                                top: 0,
                                child: CircleAvatar(
                                  radius: 4.5,
                                  backgroundColor: Colors.white,
                                  child: CircleAvatar(radius: 3, backgroundColor: Colors.red),
                                ),
                              )
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // --- Main Scrollable Content ---
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Main Blue Card
                        _buildDurationCard(),
                        
                        const SizedBox(height: 32),
                        const Text(
                          "Session Summary",
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: slate800),
                        ),
                        const SizedBox(height: 16),
                        _buildSummaryItem("Check-in time", "09:02 AM"),
                        _buildSummaryItem("Check-out time", "06:08 PM"),
                        _buildSummaryItem("Location", "Elysium HQ"),
                        _buildSummaryStatusItem("Status", "On Time"),

                        const SizedBox(height: 16),
                        const Text(
                          "Add a note",
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: slate800),
                        ),
                        const SizedBox(height: 12),
                        _buildNoteArea(),

                        const SizedBox(height: 32),
                        _buildCheckOutButton(),
                      ],
                    ),
                  ),
                ),

                // --- Bottom Indicator ---
                Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  width: 128,
                  height: 5,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusPill() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: successBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFD1EBD5)),
      ),
      child: const Row(
        children: [
          CircleAvatar(radius: 4, backgroundColor: Color(0xFF4CAF50)),
          SizedBox(width: 8),
          Text(
            "Checked In",
            style: TextStyle(color: Color(0xFF4CAF50), fontSize: 11, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildDurationCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: cardBlue,
        borderRadius: BorderRadius.circular(32),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 10,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Column(
        children: [
          // Illustration Placeholder
          Container(
            height: 160,
            width: 200,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.4),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Icon(Icons.work_outline, size: 80, color: textMain),
          ),
          const SizedBox(height: 16),
          const Text(
            "Monday • April 06 • 2026",
            style: TextStyle(color: slate500, fontSize: 14, fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 4),
          Text(
            "09h 06m",
            style: TextStyle(
              fontSize: 40,
              fontWeight: FontWeight.bold,
              color: slate800,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Text("09:02 AM", style: TextStyle(color: slate500, fontSize: 12)),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 8),
                child: Icon(Icons.arrow_forward, size: 14, color: Colors.grey),
              ),
              Text("06:08 PM", style: TextStyle(color: slate500, fontSize: 12)),
            ],
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildSmallTag("Full Day", const Color(0xFFF1F8F1), const Color(0xFF8BC34A), hasCircle: true),
              const SizedBox(width: 8),
              _buildSmallTag("+5 pts earned", accentBlue, accentBlueText, hasCircle: false),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSmallTag(String text, Color bg, Color textCol, {required bool hasCircle}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Row(
        children: [
          if (hasCircle) ...[
            CircleAvatar(radius: 3, backgroundColor: textCol),
            const SizedBox(width: 8),
          ],
          Text(text, style: TextStyle(color: textCol, fontWeight: FontWeight.bold, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildSummaryItem(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Color(0xFFF1F5F9))),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: slate500, fontSize: 14)),
          Text(value, style: const TextStyle(color: slate800, fontWeight: FontWeight.bold, fontSize: 14)),
        ],
      ),
    );
  }

  Widget _buildSummaryStatusItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: slate500, fontSize: 14)),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFFF1F8F1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFFE6F4EA)),
            ),
            child: Row(
              children: [
                const CircleAvatar(radius: 3, backgroundColor: Color(0xFF8BC34A)),
                const SizedBox(width: 6),
                Text(value, style: const TextStyle(color: Color(0xFF8BC34A), fontWeight: FontWeight.bold, fontSize: 11)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNoteArea() {
    return TextField(
      maxLines: 4,
      decoration: InputDecoration(
        hintText: "eg : Day was interesting and productive",
        hintStyle: const TextStyle(color: Colors.grey, fontSize: 14),
        fillColor: const Color(0xFFF3F4F6),
        filled: true,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.all(16),
      ),
    );
  }

  Widget _buildCheckOutButton() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: primary.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 10),
          )
        ],
      ),
      child: ElevatedButton(
        onPressed: () {},
        style: ElevatedButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: slate800,
          padding: const EdgeInsets.symmetric(vertical: 18),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          elevation: 0,
        ),
        child: const Text("Confirm Check Out", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
      ),
    );
  }
}
 