import 'package:flutter/material.dart'; 
class CheckedInScreen extends StatelessWidget {
  const CheckedInScreen({super.key});

  // --- Theme Colors ---
  static const Color primary = Color(0xFFFFB321);
  static const Color backgroundLight = Color(0xFFF8F9FE);
  static const Color success = Color(0xFF4CAF50);
  static const Color textGrey = Color(0xFF64748B);
  static const Color accentBlue = Color(0xFFE8F0FF);
  static const Color slate800 = Color(0xFF1E293B);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundLight,
      body: Center(
        child: Container(
          constraints: const BoxConstraints(maxWidth: 450), // max-w-md
          child: Stack(
            children: [ 

              Column(
                children: [
                  const SizedBox(height: 12),
                  _buildMockStatusBar(),
                  _buildHeader(),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.fromLTRB(24, 16, 24, 100),
                      child: Column(
                        children: [
                          _buildMainStatusCard(),
                          const SizedBox(height: 16),
                          _buildStatsRow(),
                          const SizedBox(height: 24),
                          _buildTodaySession(),
                          const SizedBox(height: 24),
                          _buildCheckOutButton(),
                          const SizedBox(height: 16),
                          _buildReminderCard(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),

              // --- Bottom Navigation ---
              _buildBottomNav(),
            ],
          ),
        ),
      ),
    );
  }

  // --- UI Components ---

  Widget _buildMockStatusBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text("9:41", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
          Row(
            children: const [
              Icon(Icons.signal_cellular_4_bar, size: 16),
              SizedBox(width: 4),
              Icon(Icons.wifi, size: 16),
              SizedBox(width: 4),
              Icon(Icons.battery_full, size: 16),
            ],
          )
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              const Icon(Icons.chevron_left, color: slate800),
              const SizedBox(width: 4),
              Text("Check in", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: slate800)),
            ],
          ),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: success.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    Container(width: 6, height: 6, decoration: const BoxDecoration(color: success, shape: BoxShape.circle)),
                    const SizedBox(width: 6),
                    const Text("Checked In", style: TextStyle(color: success, fontSize: 12, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Stack(
                children: [
                  const Icon(Icons.notifications_none, color: slate800),
                  Positioned(
                    right: 0,
                    top: 0,
                    child: Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 1.5),
                      ),
                    ),
                  )
                ],
              )
            ],
          )
        ],
      ),
    );
  }

  Widget _buildMainStatusCard() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: accentBlue.withOpacity(0.4),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withOpacity(0.5)),
      ),
      child: Column(
        children: [
          const Icon(Icons.person_outline, size: 100, color: Colors.blueGrey), // Placeholder for illustration
          const SizedBox(height: 16),
          const Text("Monday • April 06 • 2026", style: TextStyle(color: textGrey, fontSize: 14, fontWeight: FontWeight.w500)),
          const SizedBox(height: 4),
          Text("02 : 45 : 26", style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold, letterSpacing: 2, color: slate800)),
          const Text("Checked in at 09:02 AM • Elysium HQ", style: TextStyle(color: textGrey, fontSize: 11)),
          const SizedBox(height: 24),
          // Timeline Slider
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(color: primary.withOpacity(0.15), borderRadius: BorderRadius.circular(4)),
                child: const Text("LATE", style: TextStyle(color: primary, fontSize: 10, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 8),
              Stack(
                alignment: Alignment.centerLeft,
                children: [
                  Container(height: 6, width: double.infinity, decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(10))),
                  FractionallySizedBox(widthFactor: 0.65, child: Container(height: 6, decoration: BoxDecoration(color: primary, borderRadius: BorderRadius.circular(10)))),
                  const Positioned(
                    left: 200, // Matching 65% visually
                    child: CircleAvatar(radius: 8, backgroundColor: primary, child: CircleAvatar(radius: 4, backgroundColor: Colors.white)),
                  )
                ],
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  Text("9:00AM", style: TextStyle(fontSize: 10, color: textGrey)),
                  Text("Expected • 8Hrs", style: TextStyle(fontSize: 10, color: textGrey)),
                  Text("6:00PM", style: TextStyle(fontSize: 10, color: textGrey)),
                ],
              )
            ],
          )
        ],
      ),
    );
  }

  Widget _buildStatsRow() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFEEF2FF).withOpacity(0.5),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE0E7FF).withOpacity(0.5)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildStatItem("96%", "This Month", success),
          _buildVerticalDivider(),
          _buildStatItem("18", "Days Present", slate800),
          _buildVerticalDivider(),
          _buildStatItem("2", "Late Arrivals", primary),
        ],
      ),
    );
  }

  Widget _buildStatItem(String val, String label, Color color) {
    return Column(
      children: [
        Text(val, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
        Text(label, style: const TextStyle(fontSize: 10, color: textGrey)),
      ],
    );
  }

  Widget _buildVerticalDivider() => Container(width: 1, height: 32, color: Colors.grey[300]);

  Widget _buildTodaySession() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Today's Session", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 16),
        _buildTimelineItem("Check-in", "Elysium HQ • Biometric", "09-02 AM", success, true),
        _buildTimelineItem("Check Out", "Pending", "-", Colors.grey[300]!, false),
      ],
    );
  }

  Widget _buildTimelineItem(String title, String sub, String time, Color color, bool isFirst) {
    return IntrinsicHeight(
      child: Row(
        children: [
          Column(
            children: [
              Container(
                width: 12, height: 12,
                decoration: BoxDecoration(color: color, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)),
              ),
              if (!isFirst == false) Expanded(child: Container(width: 2, color: Colors.grey[200])),
            ],
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: isFirst ? slate800 : textGrey)),
                Text(sub, style: const TextStyle(fontSize: 12, color: textGrey)),
                const SizedBox(height: 16),
              ],
            ),
          ),
          Text(time, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        ],
      ),
    );
  }

  Widget _buildCheckOutButton() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        boxShadow: [BoxShadow(color: primary.withOpacity(0.2), blurRadius: 20, offset: const Offset(0, 10))],
      ),
      child: ElevatedButton(
        onPressed: () {},
        style: ElevatedButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: slate800,
          padding: const EdgeInsets.symmetric(vertical: 18),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          elevation: 0,
        ),
        child: const Text("Check Out", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
      ),
    );
  }

  Widget _buildReminderCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFBEB),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFEF3C7)),
      ),
      child: Column(
        children: const [
          Text("Upcoming reminder", style: TextStyle(color: primary, fontWeight: FontWeight.bold, fontSize: 13)),
          SizedBox(height: 4),
          Text("Check-out reminder at 6:15 PM if not logged out", textAlign: TextAlign.center, style: TextStyle(color: textGrey, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _buildBottomNav() {
    return Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: Container(
        padding: const EdgeInsets.only(top: 12, bottom: 20),
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: Color(0xFFF1F5F9))),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildNavItem(Icons.home_outlined, "Home", false),
            _buildNavItem(Icons.calendar_today, "Attendance", true),
            _buildNavItem(Icons.description_outlined, "Reports", false),
            _buildNavItem(Icons.person_outline, "Profile", false),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, bool active) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: active ? primary : Colors.grey[400]),
        const SizedBox(height: 4),
        Text(label, style: TextStyle(fontSize: 10, color: active ? primary : Colors.grey[400], fontWeight: active ? FontWeight.bold : FontWeight.normal)),
      ],
    );
  }
}
