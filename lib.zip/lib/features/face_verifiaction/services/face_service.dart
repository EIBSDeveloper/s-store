import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;
 
import '../../../utils/utils/embedding_matcher.dart';
import '../../../utils/utils/exceptions.dart';
import '../../../utils/utils/face_embedder.dart';
import '../data/datasources/face_local_datasource.dart';
import '../models/face_user.dart';
import '../models/attendance.dart'; 

class FaceService {
  final FaceLocalDatasource local;

  FaceService(this.local);

  Future<void> registerFace({
    required String name,
    required String faceImagePath,
  }) async {
    final image = img.decodeImage(File(faceImagePath).readAsBytesSync());
    if (image == null) throw Exception('Failed to decode face image');

    final embedding = FaceEmbedder.getEmbedding(image);

    await local.insertUser(
      name,
      faceImagePath,
      embedding,
    );
  }

  Future<FaceUser?> verifyFace(String capturedImagePath) async {
    final users = await local.getAllUsers();
    final image = img.decodeImage(File(capturedImagePath).readAsBytesSync());
    if (image == null) return null;

    final capturedEmbedding = FaceEmbedder.getEmbedding(image);

    const double threshold = 0.80;
    FaceUser? bestMatch;
    double highestScore = -1.0;

    for (final user in users) {
      final result = EmbeddingMatcher.match(
        capturedEmbedding,
        user.embedding,
        threshold: threshold,
      );

      debugPrint('Face match score for ${user.name}: ${result.score}');

      if (result.isMatch && result.score > highestScore) {
        highestScore = result.score;
        bestMatch = user;
      }
    }

    if (bestMatch != null) {
      debugPrint('Best match confirmed: ${bestMatch.name} with score $highestScore');
    }

    return bestMatch;
  }

  Future<void> markAttendance(int userId) async {
    final now = DateTime.now();
    final todayStart = DateTime(now.year, now.month, now.day);
    final todayEnd = todayStart.add(const Duration(days: 1));

    final existing = await local.getAttendanceForUserBetween(
      userId,
      todayStart,
      todayEnd,
    );

    if (existing.isNotEmpty) {
      throw const AttendanceAlreadyMarkedException();
    }

    await local.insertAttendance(userId);
  }

  Future<List<Attendance>> getAttendance() async {
    return await local.getAttendance();
  }
}
