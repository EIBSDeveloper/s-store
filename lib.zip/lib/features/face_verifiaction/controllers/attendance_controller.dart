import 'package:get/get.dart';
import '../services/face_service.dart';
import '../models/attendance.dart';

class AttendanceController extends GetxController {
  final FaceService _faceService = Get.find<FaceService>();
  
  var attendances = <Attendance>[].obs;
  var isLoading = false.obs;

  @override
  void onInit() {
    super.onInit();
    loadAttendance();
  }

  Future<void> loadAttendance() async {
    isLoading.value = true;
    try {
      final data = await _faceService.getAttendance();
      attendances.assignAll(data);
    } finally {
      isLoading.value = false;
    }
  }
}
