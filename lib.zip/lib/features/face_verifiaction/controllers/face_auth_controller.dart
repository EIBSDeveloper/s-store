import 'package:get/get.dart';
import '../../../utils/utils/exceptions.dart';
import '../services/face_service.dart';
import '../models/face_user.dart'; 

class FaceAuthController extends GetxController {
  final FaceService _faceService = Get.find<FaceService>();

  var isLoading = false.obs;
  var errorMessage = ''.obs;
  var isRegistered = false.obs;
  var verifiedUser = Rx<FaceUser?>(null);

  Future<void> registerFace({
    required String name,
    required String faceImagePath,
  }) async {
    isLoading.value = true;
    errorMessage.value = '';
    isRegistered.value = false;

    try {
      await _faceService.registerFace(name: name, faceImagePath: faceImagePath);
      isRegistered.value = true;
    } catch (_) {
      errorMessage.value = 'Failed to register face';
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> verifyFace(String capturedImagePath) async {
    isLoading.value = true;
    errorMessage.value = '';
    verifiedUser.value = null;
    FaceUser? user;
    try {
        user = await _faceService.verifyFace(capturedImagePath);

      if (user == null) {
        errorMessage.value = 'Face not recognized';
        isLoading.value = false;
        return;
      }

      await _faceService.markAttendance(user.id);
      verifiedUser.value = user;
    } on AttendanceAlreadyMarkedException {
      errorMessage.value = '${user!.name}Attendance already marked today';
    } catch (e) {
      errorMessage.value = 'Verification failed: ${e.toString()}';
    } finally {
      isLoading.value = false;
    }
  }

  void resetState() {
    isLoading.value = false;
    errorMessage.value = '';
    isRegistered.value = false;
    verifiedUser.value = null;
  }
}
