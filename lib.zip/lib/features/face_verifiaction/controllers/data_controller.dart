import 'package:get/get.dart';
import '../models/face_user.dart';
import '../models/attendance.dart';

class DataController extends GetxController {
  final RxList<FaceUser> _users = <FaceUser>[].obs;
  final RxList<Attendance> _attendance = <Attendance>[].obs;

  List<FaceUser> get users => _users;
  List<Attendance> get attendanceList =>
      _attendance; // Renamed to avoid name conflict if any

  void addUser(FaceUser user) {
    _users.add(user);
    update();
  }

  FaceUser? getUserById(int id) {
    return _users.firstWhereOrNull((user) => user.id == id);
  }

  void addAttendance(Attendance entry) {
    _attendance.add(entry);
    update();
  }

  List<Attendance> getAttendanceForUserBetween(
    int userId,
    DateTime from,
    DateTime to,
  ) {
    return _attendance.where((a) {
      return a.userId == userId &&
          a.timestamp.isAfter(from.subtract(const Duration(seconds: 1))) &&
          a.timestamp.isBefore(to);
    }).toList();
  }
}
