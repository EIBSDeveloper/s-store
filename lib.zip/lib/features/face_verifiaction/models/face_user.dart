class FaceUser {
  final int id;
  final String name;
  final String faceImagePath;
  final List<double> embedding;
  final DateTime createdAt;

  FaceUser({
    required this.id,
    required this.name,
    required this.faceImagePath,
    required this.embedding,
    required this.createdAt,
  });

  factory FaceUser.fromJson(Map<String, dynamic> json) {
    return FaceUser(
      id: json['id'],
      name: json['name'],
      faceImagePath: json['faceImagePath'],
      embedding: List<double>.from(json['embedding']),
      createdAt: DateTime.parse(json['createdAt']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'faceImagePath': faceImagePath,
      'embedding': embedding,
      'createdAt': createdAt.toIso8601String(),
    };
  }
}
