class Attendance {
  final int id;
  final int userId;
  final DateTime timestamp;

  Attendance({
    required this.id,
    required this.userId,
    required this.timestamp,
  });

  factory Attendance.fromJson(Map<String, dynamic> json) {
    return Attendance(
      id: json['id'],
      userId: json['userId'],
      timestamp: DateTime.parse(json['timestamp']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'timestamp': timestamp.toIso8601String(),
    };
  }
}
