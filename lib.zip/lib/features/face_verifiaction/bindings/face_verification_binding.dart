import 'package:get/get.dart';

import '../controllers/data_controller.dart';
import '../controllers/attendance_controller.dart';
import '../controllers/face_auth_controller.dart';
import '../data/datasources/face_local_datasource.dart';
import '../services/face_service.dart'; 

class FaceVerificationBinding extends Bindings {
  @override
  void dependencies() {
    // ✅ Database & Datasources
    final dataController = Get.find<DataController>();
    Get.lazyPut(() => FaceLocalDatasource(dataController));
    
    // ✅ Services
    Get.lazyPut(() => FaceService(Get.find<FaceLocalDatasource>()));
    
    // ✅ Controllers
    Get.lazyPut(() => FaceAuthController());
    Get.lazyPut(() => AttendanceController());
  }
}
