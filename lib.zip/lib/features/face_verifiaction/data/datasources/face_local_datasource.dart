import '../../controllers/data_controller.dart';
import '../../models/face_user.dart';
import '../../models/attendance.dart';

class FaceLocalDatasource {
  final DataController dataController;

  FaceLocalDatasource(this.dataController);

  // ---------- Face User ----------

  Future<int> insertUser(
    String name,
    String faceImagePath,
    List<double> embedding,
  ) async {
    final id = dataController.users.length + 1;
    final newUser = FaceUser(
      id: id,
      name: name,
      faceImagePath: faceImagePath,
      embedding: embedding,
      createdAt: DateTime.now(),
    );
    dataController.addUser(newUser);
    return id;
  }

  Future<List<FaceUser>> getAllUsers() async {
    return dataController.users;
  }

  Future<FaceUser?> getUserById(int id) async {
    return dataController.getUserById(id);
  }

  // ---------- Attendance ----------

  Future<void> insertAttendance(int userId) async {
    final id = dataController.attendanceList.length + 1;
    final newAttendance = Attendance(
      id: id,
      userId: userId,
      timestamp: DateTime.now(),
    );
    dataController.addAttendance(newAttendance);
  }

  Future<List<Attendance>> getAttendance() async {
    return dataController.attendanceList;
  }

  Future<List<Attendance>> getAttendanceForUserBetween(
    int userId,
    DateTime from,
    DateTime to,
  ) async {
    return dataController.getAttendanceForUserBetween(userId, from, to);
  }
}
