import 'package:elysium_employee/core/app_colors.dart';
import 'package:elysium_employee/features/home/view/screens/test.dart';
import 'package:elysium_employee/features/home/view/widget/mini_bar.dart';
import 'package:flutter/material.dart';

class PointsCard extends StatelessWidget {
  const PointsCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 90,
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.cardYellow,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.08),
                      blurRadius: 4,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.stars_outlined,
                  color: AppColors.accentYellowText,
                  size: 16,
                ),
              ),
              const Text(
                '2,840',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              const Text(
                'Points',
                style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                MiniBar(height: 12, color: const Color(0xFFFBBF24)),
                  const SizedBox(width: 3),
                  MiniBar(height: 20, color: const Color(0xFFFBBF24)),
                  const SizedBox(width: 3),
                  MiniBar(height: 16, color: const Color(0xFFFBBF24)),
                  const SizedBox(width: 3),
                  MiniBar(height: 32, color: const Color(0xFFFBBF24)),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
