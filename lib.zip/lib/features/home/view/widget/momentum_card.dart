import 'package:elysium_employee/core/app_colors.dart';
import 'package:flutter/material.dart';

class MomentumCard extends StatelessWidget {
  const MomentumCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 70,
      // ❌ REMOVE width: double.infinity
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.cardBlue,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Stack(
        clipBehavior: Clip.none, // ✅ allow overflow safely
        children: [
          Align(
            alignment: Alignment.bottomLeft,
            child: SizedBox(
              width: 100,
              child: Text(
                'Keep your momentum going',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: AppColors.textPrimary,
                  height: 1.4,
                ),
              ),
            ),
          ),

          // ✅ Use Positioned instead of Transform
          Positioned(
            top: -40, // safer than -80
            right: -10,
            child: Image.network(
              'https://raw.githubusercontent.com/EIBSDeveloper/animation/refs/heads/main/progress.gif',
              width: 70,
              height: 70,
              fit: BoxFit.contain,
              errorBuilder: (_, __, ___) =>
                  const SizedBox(width: 64, height: 64),
            ),
          ),
        ],
      ),
    );
  }
}
