import 'package:elysium_employee/core/app_colors.dart';
import 'package:elysium_employee/features/home/view/screens/test.dart';
import 'package:elysium_employee/features/home/view/widget/quick_action_item.dart';
import 'package:flutter/material.dart';

class QuickActions extends StatelessWidget {
  const QuickActions({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Quick Actions',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: const [
              QuickActionItem(
                icon: Icons.check_box_outlined,
                label: 'Check In',
                iconColor: Color(0xFF6B7280),
                bgColor: Colors.white,
              ),
              QuickActionItem(
                icon: Icons.warning_amber_rounded,
                label: 'Leave',
                iconColor: Color(0xFF6366F1),
                bgColor: Color(0xFFE0E7FF),
              ),
              QuickActionItem(
                icon: Icons.receipt_long_outlined,
                label: 'Payslip',
                iconColor: Color(0xFFA855F7),
                bgColor: Color(0xFFF5F3FF),
              ),
              QuickActionItem(
                icon: Icons.assignment_outlined,
                label: 'Tasks',
                iconColor: Color(0xFF3B82F6),
                bgColor: Color(0xFFEFF6FF),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
