import 'package:elysium_employee/features/home/view/screens/test.dart';
import 'package:elysium_employee/features/home/view/widget/attendance_card.dart';
import 'package:elysium_employee/features/home/view/widget/level_card.dart';
import 'package:elysium_employee/features/home/view/widget/momentum_card.dart';
import 'package:elysium_employee/features/home/view/widget/points_card.dart';
import 'package:flutter/material.dart';

class StatsGrid extends StatelessWidget {
  const StatsGrid({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 170,
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: Column(
              children: [PointsCard(), SizedBox(height: 8), LevelCard()],
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              children: [
                MomentumCard(),
                SizedBox(height: 8),
                AttendanceCard(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
