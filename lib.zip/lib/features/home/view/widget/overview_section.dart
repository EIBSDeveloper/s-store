import 'package:elysium_employee/core/app_colors.dart';
import 'package:elysium_employee/features/home/view/screens/test.dart';
import 'package:elysium_employee/features/home/view/widget/activity_feed.dart';
import 'package:flutter/material.dart';

class OverviewSection extends StatelessWidget {
  const OverviewSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      decoration: const BoxDecoration(
        color: AppColors.surfaceLight,
        borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Overview',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 8),
          const Row(
            children: [
              Expanded(child: HRTicketCard()),
              SizedBox(width: 10),
              Expanded(child: IncentiveCard()),
            ],
          ),
          const SizedBox(height: 8),
          const Row(
            children: [
              Expanded(child: LeaveTakenCard()),
              SizedBox(width: 10),
              Expanded(child: NextTrainingCard()),
            ],
          ),
          const SizedBox(height: 8),
          const ActivityFeed(),
        ],
      ),
    );
  }
}
