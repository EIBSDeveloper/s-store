import 'package:flutter/material.dart';

class MiniBar extends StatelessWidget {
  final double height;
  final Color color;
  const MiniBar({super.key, required this.height, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 6,
      height: height,
      decoration: BoxDecoration(
        color: color,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(2)),
      ),
    );
  }
}
