import 'dart:math';
import 'package:elysium_employee/core/app_colors.dart';
import 'package:flutter/material.dart';

class CircularChartPainter extends CustomPainter {
  final double progress;
  const CircularChartPainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 4;
    final strokeWidth = 5.5;

    // Background
    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..color = const Color(0xFFE6E6E6)
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth,
    );

    // Foreground arc
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      -pi / 2,
      2 * pi * progress,
      false,
      Paint()
        ..color = const Color(0xFF22C55E)
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth
        ..strokeCap = StrokeCap.round,
    );

    // Text
    final tp = TextPainter(
      text: const TextSpan(
        text: '6%',
        style: TextStyle(
          fontSize: 8,
          fontWeight: FontWeight.w700,
          color: AppColors.textPrimary,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(
      canvas,
      Offset(center.dx - tp.width / 2, center.dy - tp.height / 2),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
