import 'package:get/get.dart';
import 'package:flutter/material.dart';

import '../../../../core/app_colors.dart';
import '../screens/test.dart';

class BottomNavController1 extends GetxController {
  var selectedIndex = 0.obs;

  void changeIndex(int index) {
    selectedIndex.value = index;
  }
}

class BottomNav extends StatelessWidget {
  BottomNav({super.key});

  final BottomNavController1 controller = Get.put(BottomNavController1());

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: AppColors.navBg,
          borderRadius: BorderRadius.circular(40),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _navItem(index: 0, icon: Icons.home_outlined, label: "Home"),
            _navItem(
              index: 1,
              icon: Icons.calendar_today_outlined,
              label: "Home",
            ),
            _navItem(
              index: 2,
              icon: Icons.local_activity_outlined,
              label: "Home",
            ),
            _navItem(index: 3, icon: Icons.person_outline, label: "Home"),
          ],
        ),
      ),
    );
  }

  /// 🔹 Selected Item (with label)
  Widget _navItem({
    required int index,
    required IconData icon,
    required String label,
  }) {
    return GestureDetector(
      onTap: () => controller.changeIndex(index),
      child: Obx(() {
        bool isSelected = controller.selectedIndex.value == index;

        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: isSelected
                ? Colors.white.withOpacity(0.2)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(30),
          ),
          child: Row(
            children: [
              Icon(
                icon,
                color: isSelected ? Colors.white : const Color(0xFFA5B4FC),
                size: 22,
              ),
              if (isSelected) ...[
                const SizedBox(width: 8),
                Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ],
          ),
        );
      }),
    );
  }
}
