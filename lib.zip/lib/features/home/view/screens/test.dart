import 'dart:math';
import 'package:elysium_employee/features/home/view/widget/activity_feed.dart';
import 'package:elysium_employee/features/home/view/widget/mini_bar.dart';
import 'package:flutter/material.dart';

import '../../../../core/app_colors.dart';

class HRTicketCard extends StatelessWidget {
  const HRTicketCard();

  @override
  Widget build(BuildContext context) {
    return OverviewCard(
      child: Stack(
        children: [
          Positioned(
            top: 0,
            right: 0,
            child: Container(
              width: 6,
              height: 6,
              decoration: const BoxDecoration(
                color: Color(0xFFFBBF24),
                shape: BoxShape.circle,
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  MiniIconBox(
                    icon: Icons.confirmation_number_outlined,
                    iconColor: const Color(0xFF22C55E),
                    bgColor: const Color(0xFFF0FDF4),
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'HR Ticket',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  RichText(
                    text: const TextSpan(
                      children: [
                        TextSpan(
                          text: '5 ',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF16A34A),
                            fontFamily: 'PlusJakartaSans',
                          ),
                        ),
                        TextSpan(
                          text: '/ 8',
                          style: TextStyle(
                            fontSize: 20,
                            color: AppColors.textSecondary,
                            fontFamily: 'PlusJakartaSans',
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Text(
                    '3 Due Today',
                    style: TextStyle(
                      fontSize: 10,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: 0.625,
                  backgroundColor: const Color(0xFFF3F4F6),
                  valueColor: const AlwaysStoppedAnimation<Color>(
                    Color(0xFFFBBF24),
                  ),
                  minHeight: 4,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class IncentiveCard extends StatelessWidget {
  const IncentiveCard();

  @override
  Widget build(BuildContext context) {
    return OverviewCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              MiniIconBox(
                icon: Icons.monetization_on_outlined,
                iconColor: const Color(0xFFA855F7),
                bgColor: const Color(0xFFF5F3FF),
              ),
              const SizedBox(width: 8),
              const Text(
                'Incentive',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: AppColors.textPrimary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              const Text(
                '₹18k',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  MiniBar(height: 12, color: const Color(0xFFFBBF24)),
                  const SizedBox(width: 3),
                  MiniBar(height: 16, color: const Color(0xFFFBBF24)),
                  const SizedBox(width: 3),
                  MiniBar(height: 20, color: const Color(0xFFFBBF24)),
                  const SizedBox(width: 3),
                  MiniBar(height: 24, color: const Color(0xFFFBBF24)),
                ],
              ),
            ],
          ),
          // const SizedBox(height: 4),
          const Align(
            alignment: Alignment.centerRight,
            child: Text(
              'Current Month',
              style: TextStyle(fontSize: 10, color: AppColors.textSecondary),
            ),
          ),
        ],
      ),
    );
  }
}

class LeaveTakenCard extends StatelessWidget {
  const LeaveTakenCard();

  @override
  Widget build(BuildContext context) {
    return OverviewCard(
      child: Stack(
        children: [
          Positioned(
            top: 0,
            right: 0,
            child: Container(
              width: 6,
              height: 6,
              decoration: const BoxDecoration(
                color: Color(0xFF3B82F6),
                shape: BoxShape.circle,
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                MiniIconBox(
                    icon: Icons.event_busy_outlined,
                    iconColor: const Color(0xFF3B82F6),
                    bgColor: const Color(0xFFEFF6FF),
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'Leave Taken',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: const [
                  Text(
                    '3',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFFEAB308),
                    ),
                  ),
                  Text(
                    'Current Month',
                    style: TextStyle(
                      fontSize: 10,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: Container(
                      height: 4,
                      margin: const EdgeInsets.only(right: 3),
                      decoration: BoxDecoration(
                        color: const Color(0xFF22C55E),
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      height: 4,
                      margin: const EdgeInsets.only(right: 3),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFBBF24),
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Container(
                      height: 4,
                      decoration: BoxDecoration(
                        color: const Color(0xFFFECACA),
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class NextTrainingCard extends StatelessWidget {
  const NextTrainingCard();

  @override
  Widget build(BuildContext context) {
    return OverviewCard(
      child: Stack(
        children: [
          Positioned(
            top: 0,
            right: 0,
            child: Container(
              width: 6,
              height: 6,
              decoration: const BoxDecoration(
                color: Color(0xFFFBBF24),
                shape: BoxShape.circle,
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  MiniIconBox(
                    icon: Icons.school_outlined,
                    iconColor: const Color(0xFF6366F1),
                    bgColor: const Color(0xFFEEF2FF),
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'Next Training',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            'Mar 24',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          Text(
                            ' 3 Days to go',
                            style: TextStyle(
                              fontSize: 8,
                              color: AppColors.textSecondary,
                            ),
                          ),
                        ],
                      ),
                      Text(
                        'React Advanced',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w500,
                          color: Color(0xFF4F46E5),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: const LinearProgressIndicator(
                  value: 0.5,
                  backgroundColor: Color(0xFFF3F4F6),
                  valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFFBBF24)),
                  minHeight: 4,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class OverviewCard extends StatelessWidget {
  final Widget child;
  const OverviewCard({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.borderLight),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 4,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: child,
    );
  }
}

class MiniIconBox extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final Color bgColor;
  const MiniIconBox({
    required this.icon,
    required this.iconColor,
    required this.bgColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Icon(icon, color: iconColor, size: 14),
    );
  }
}
// ─── Wavy Pattern Painter ──────────────────────────────────────────────────
class WavyPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    void drawWave(double yOffset, Color color) {
      paint.color = color;
      final path = Path();
      path.moveTo(0, yOffset);
      path.cubicTo(
        size.width * 0.125,
        yOffset + 50,
        size.width * 0.375,
        yOffset - 50,
        size.width * 0.5,
        yOffset,
      );
      path.cubicTo(
        size.width * 0.625,
        yOffset + 50,
        size.width * 0.875,
        yOffset - 50,
        size.width,
        yOffset,
      );
      canvas.drawPath(path, paint);
    }

    drawWave(size.height * 0.5, const Color(0xFFE0E7FF).withOpacity(0.5));
    drawWave(size.height * 0.6, const Color(0xFFE0E7FF).withOpacity(0.3));
    drawWave(size.height * 0.4, const Color(0xFFE0E7FF).withOpacity(0.4));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
