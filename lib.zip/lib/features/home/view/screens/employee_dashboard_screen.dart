import 'package:elysium_employee/features/home/view/screens/test.dart';
import 'package:elysium_employee/features/home/view/widget/buttom.dart';
import 'package:elysium_employee/features/home/view/widget/header.dart';
import 'package:elysium_employee/features/home/view/widget/overview_section.dart';
import 'package:elysium_employee/features/home/view/widget/quick_actions.dart';
import 'package:elysium_employee/features/home/view/widget/stats_grid.dart';
import 'package:flutter/material.dart';

class EmployeeDashboardScreen extends StatelessWidget {
  const EmployeeDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            Header(),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    SizedBox(height: 15),
                    StatsGrid(),
                    SizedBox(height: 8),
                    QuickActions(),
                    SizedBox(height: 8),
                    OverviewSection(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),

      bottomNavigationBar: BottomNav(),
    );
  }
}
