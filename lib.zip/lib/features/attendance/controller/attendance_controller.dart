import 'package:get/get.dart';

import '../model/attendance_model.dart';
import '../repositories/attendance_repository.dart';

class AttendanceController extends GetxController {
  final AttendanceRepository repo = AttendanceRepository();

  AttendanceController();
  List<AttendanceRecord> get filteredRecords {
    final selected = selectedDate.value;
    if (selected == null) return data.value?.records ?? [];

    return data.value!.records.where((e) {
      return e.date.contains(selected.day.toString());
    }).toList();
  }

  var currentMonth = DateTime.now().obs;
  var data = Rxn<AttendanceModel>();
  var isLoading = false.obs;
  var selectedDate = Rxn<DateTime>();

  @override
  void onInit() {
    selectedDate.value = DateTime.now(); // default = today
    loadMonth();
    super.onInit();
  }

  void selectDate(int day) {
    selectedDate.value = DateTime(
      currentMonth.value.year,
      currentMonth.value.month,
      day,
    );
  }

  void loadMonth() async {
    isLoading.value = true;

    final year = currentMonth.value.year;
    final month = currentMonth.value.month;

    data.value = await repo.fetchAttendance(year, month);

    isLoading.value = false;
  }

  void nextMonth() {
    currentMonth.value = DateTime(
      currentMonth.value.year,
      currentMonth.value.month + 1,
    );
    loadMonth();
  }

  void prevMonth() {
    currentMonth.value = DateTime(
      currentMonth.value.year,
      currentMonth.value.month - 1,
    );
    loadMonth();
  }
}
