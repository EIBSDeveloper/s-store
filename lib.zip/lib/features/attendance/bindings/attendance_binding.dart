import 'package:get/get.dart';

import '../controller/attendance_controller.dart';
import '../repositories/attendance_repository.dart';

class AttendanceBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => AttendanceRepository());
    Get.lazyPut(() => AttendanceController( ));
  }
}