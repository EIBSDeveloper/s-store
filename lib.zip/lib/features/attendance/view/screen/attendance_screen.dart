import 'package:elysium_employee/core/app_colors.dart';
import 'package:elysium_employee/widgets/widget_gap.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../utils/utils.dart';
import '../../../dashboard/view/widgets/glass_card.dart';
import '../../controller/attendance_controller.dart';
import '../widget/calendar_widget.dart';
import '../widget/check_out_popup.dart';
import '../widget/record_item.dart';

class AttendanceScreen extends GetView<AttendanceController> {
  const AttendanceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.only(bottom: 40),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildStatsRow(),
              Obx(() {
                final data = controller.data.value;

                if (data == null) {
                  return const Center(child: CircularProgressIndicator());
                }
                return GlassCard(
                  padding: const EdgeInsets.all(10),
                  margin: EdgeInsets.zero,
                  gradientColors: [
                    Colors.white.withOpacity(0.5),
                    Colors.white.withOpacity(0.1),
                  ],
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: CalendarWidget(
                      key: ValueKey(controller.currentMonth.value),
                      days: data.calendar,
                      month: controller.currentMonth.value,
                    ),
                  ),
                );
              }),
              _buildRequestsSection(),
              _buildActionButtons(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatsRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _buildStatItem("18", "Present", Colors.green),
          _buildStatItem("2", "Late", AppColors.secondary),
          _buildStatItem("1", "Permission", const Color(0xFF5C6BC0)),
          _buildStatItem("2", "Leave", Color(0xFF9E9E9E)),
          _buildStatItem("1", "Absent", Colors.red),
        ],
      ),
    );
  }

  Widget _buildStatItem(String val, String label, Color color) {
    return Column(
      children: [
        Container(
          width: 58,
          height: 58,
          decoration: BoxDecoration(
            color: color.withAlpha(80),
            shape: BoxShape.circle,
          ),
          alignment: Alignment.center,
          child: Text(
            val,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ),
        const SizedBox(height: 3),
        Text(
          label,
          style: const TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w500,
            color: Colors.grey,
          ),
        ),
      ],
    );
  }

  Widget _buildRequestsSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Requests",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _filterChip("All", true),
                _filterChip("Recent Requests", false),
                _filterChip("Pending Approvals", false),
              ],
            ),
          ),
          const SizedBox(height: 10),
          _requestItem(
            "Leave • Apr 4-5",
            "Travelling Out of Sta.. • Submitted Mar 25",
            "Pending",
            AppColors.primary,
          ),
          _requestItem(
            "Leave • March 18-19",
            "Payroll Query • Submitted Mar 14",
            "Approved",
            Colors.green,
          ),
          _requestItem(
            "Permission • Feb 15 • 1Hr",
            "10.00am - 11.00am • Submitted Feb 13",
            "Approved",
            Colors.green,
          ),
        ],
      ),
    );
  }

  Widget _filterChip(String label, bool active) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
      decoration: BoxDecoration(
        color: active ? AppColors.primarylight : Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.primary),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: AppColors.primary,
          fontSize: 13,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _requestItem(String title, String sub, String status, Color color) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: color.withAlpha(80),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              status == "Pending" ? Icons.access_time : Icons.check,
              color: color,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,

                          fontSize: 15,
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: color.withAlpha(80),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        status.toUpperCase(),
                        style: TextStyle(
                          color: color,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  sub,
                  style: const TextStyle(color: Colors.grey, fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          _primaryButton(
            "Apply Leave",
            Icons.calendar_today,
            AppColors.primary,
          ),
          const SizedBox(width: 10),
          _primaryButton("Permission", Icons.access_time, AppColors.secondary),
        ],
      ),
    );
  }

  Widget _primaryButton(String label, IconData icon, Color color) {
    return Expanded(
      child: Container(
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.2),
              blurRadius: 15,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white),
            const SizedBox(width: 10),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,

                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
