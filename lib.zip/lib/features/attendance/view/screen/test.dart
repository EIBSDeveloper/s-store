import 'dart:math';
import 'package:elysium_employee/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:hugeicons/hugeicons.dart';

import '../../../../core/app_style.dart';

class TestScreen extends StatelessWidget {
  const TestScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [const SizedBox(height: 20), const SizedBox(height: 30)],
          ),
        ),
      ),
    );
  }

  Widget floatingCard({
    required String title,
    required String value,
    required String subtitle,
    required Color color,
  }) {
    return Container(
      width: 90,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: const [BoxShadow(blurRadius: 10, color: Colors.black12)],
      ),
      child: Column(
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 8,
              fontWeight: FontWeight.bold,
              color: Colors.black54,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w900,
              color: color,
            ),
          ),
          Text(
            subtitle,
            style: const TextStyle(fontSize: 8, color: Colors.black45),
          ),
        ],
      ),
    );
  }
}

/// CUSTOM CIRCLE PAINTER
class CirclePainter extends CustomPainter {
  final double progress;

  CirclePainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final base = Paint()
      ..color = Colors.grey.withOpacity(0.2)
      ..strokeWidth = 12
      ..style = PaintingStyle.stroke;

    final progressPaint = Paint()
      ..shader =
            SweepGradient(
            colors: [AppColors.secondary, AppColors.primary],
          ).createShader(
            Rect.fromCircle(
              center: size.center(Offset.zero),
              radius: size.width / 2,
            ),
          )
      ..strokeWidth = 12
      ..style = PaintingStyle.stroke;

    final rect = Offset.zero & size;

    canvas.drawArc(rect, 0, 2 * pi, false, base);
    canvas.drawArc(rect, -pi / 2, 2 * pi * progress, false, progressPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

/// WORK ITEM
class WorkItem extends StatelessWidget {
  final List<List<dynamic>> icon;
  final String title;
  final String time;
  final String status;
  final bool isGreen;

  const WorkItem({
    super.key,
    required this.icon,
    required this.title,
    required this.time,
    required this.status,
    required this.isGreen,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Container(
              height: 40,
              width: 40,
              decoration: BoxDecoration(
                color: AppColors.primary.withAlpha(40),
                borderRadius: BorderRadius.circular(8),
              ),
              padding: EdgeInsets.all(8),
              child: HugeIcon(
                icon: icon,
                color: AppColors.primary,
                size: AppStyle.iconSize2,
              ),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
                Text(
                  time,
                  style: const TextStyle(fontSize: 10, color: Colors.black54),
                ),
              ],
            ),
          ],
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: isGreen
                ? Colors.green.withAlpha(30)
                : Colors.black.withAlpha(30),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Text(
            status,
            style: TextStyle(
              fontSize: 10,
              color: isGreen ? Colors.green : Colors.black45,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ],
    );
  }
}
