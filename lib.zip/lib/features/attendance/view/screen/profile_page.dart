import 'package:elysium_employee/core/app_colors.dart';
import 'package:elysium_employee/features/dashboard/view/widgets/glass_card.dart';
import 'package:flutter/material.dart';
import 'package:hugeicons/hugeicons.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  static const Color sapphire900 = Color(0xFF0D1B2A);
  static const Color sapphireDefault = Color(0xFF1C2541);
  static const Color sapphireLight = Color(0xFF3A506B);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            children: [
              const SizedBox(height: 10),
              _buildExecutiveCard(),
              const SizedBox(height: 10),
              _buildBentoGrid(),
              const SizedBox(height: 10),
              _buildAchievementTip(),

              const SizedBox(height: 10),
              _buildActionButtons(),
              const SizedBox(height: 100),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildExecutiveCard() {
    return GlassCard(
      gradientColors: [
        AppColors.primary.withOpacity(0.9),
        AppColors.primary.withOpacity(0.9),
      ],
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildProfileImage(),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Aditya',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: -0.5,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        Text(
                          'EMP0142',
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.white.withOpacity(0.9),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Container(width: 1, height: 10, color: Colors.white24),
                        const SizedBox(width: 6),
                        Text(
                          'SOFTWARE DEV LEAD',
                          style: TextStyle(
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                            color: Colors.white.withOpacity(0.8),
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              _buildLevelTag(),
            ],
          ),
          const SizedBox(height: 10),
          _buildProgressSection(),
        ],
      ),
    );
  }

  Widget _buildProfileImage() {
    return Column(
      children: [
        const CircleAvatar(
          radius: 25,
          backgroundColor: Colors.white,
          backgroundImage: NetworkImage('https://via.placeholder.com/150'),
        ),
      ],
    );
  }

  Widget _buildLevelTag() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.3)),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          HugeIcon(
            icon: HugeIcons.strokeRoundedStars,
            color: AppColors.pending,
            size: 17,
          ),
          SizedBox(width: 4),
          Text(
            'L3',
            style: TextStyle(
              fontSize: 12,
              color: Colors.white,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressSection() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'QUARTERLY MILESTONE',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.9),
                  fontSize: 9,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.5,
                ),
              ),
              const Text(
                '80%',
                style: TextStyle(
                  color: AppColors.pending,
                  fontWeight: FontWeight.w900,
                  fontSize: 14,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Stack(
            children: [
              Container(
                height: 6,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
              Container(
                height: 6,
                width: 250, // Approximation or use LayoutBuilder
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Colors.amber, AppColors.warning],
                  ),
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBentoGrid() {
    return Column(
      children: [
        Row(
          children: [
            _cardWrapper(
              color: const Color(0xFFEEF2FF),
              child: _bentoStat(
                HugeIcons.strokeRoundedTickDouble03,
                '4',
                'VERIFIED',
                Colors.indigo,
              ),
            ),
            const SizedBox(width: 12),
            _cardWrapper(
              color: const Color(0xFFFFFBEB),
              child: _bentoStat(
                HugeIcons.strokeRoundedHourglass,
                '1',
                'PENDING',
                Colors.amber,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        GlassCard(
          padding: const EdgeInsets.symmetric(vertical: 0),
          gradientColors: [
            Colors.white.withOpacity(0.6),
            Colors.white.withOpacity(0.2),
          ],
          child: Column(
            children: [
              _infoRow(
                HugeIcons.strokeRoundedOffice,
                'Department',
                'Engineering',
              ),
              const Divider(height: 1, color: Colors.white24),
              _infoRow(
                HugeIcons.strokeRoundedUserSquare,
                'Reports to',
                'Kannan V.',
              ),
              const Divider(height: 1, color: Colors.white24),
              _infoRow(
                HugeIcons.strokeRoundedCalendar03,
                'Joined',
                'March 2023',
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _cardWrapper({required Widget child, Color color = Colors.white}) {
    return Expanded(
      child: GlassCard(
        padding: const EdgeInsets.all(12),
        gradientColors: [color.withOpacity(0.7), color.withOpacity(0.3)],
        child: child,
      ),
    );
  }

  Widget _bentoStat(
    List<List<dynamic>> icon,
    String value,
    String label,
    Color color,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              value,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Color(0xFF1E293B),
              ),
            ),
            HugeIcon(icon: icon, color: color, size: 24),
          ],
        ),
        Text(
          label,
          style: const TextStyle(
            fontSize: 9,
            fontWeight: FontWeight.w900,
            color: Color(0xFF94A3B8),
            letterSpacing: 0.5,
          ),
        ),
      ],
    );
  }

  Widget _infoRow(List<List<dynamic>> icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(200),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.white),
            ),
            child: HugeIcon(icon: icon, size: 16, color: AppColors.primary),
          ),
          const SizedBox(width: 12),
          Text(
            label,
            style: const TextStyle(
              color: Color(0xFF64748B),
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
          const Spacer(),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.w800,
              color: Color(0xFF1E293B),
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Row(
      children: [
        Expanded(
          child: _btn(
            HugeIcons.strokeRoundedShare01,
            'SHARE PROFILE',
            Colors.white,
            AppColors.slate800,
            false,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _btn(
            HugeIcons.strokeRoundedPencilEdit01,
            'EDIT DETAILS',
            AppColors.primary,
            Colors.white,
            true,
          ),
        ),
      ],
    );
  }

  Widget _btn(
    List<List<dynamic>> icon,
    String label,
    Color bg,
    Color text,
    bool shadow,
  ) {
    return GlassCard(
      padding: EdgeInsets.zero,
      gradientColors: [
        shadow ? bg : Colors.white.withOpacity(0.6),
        shadow ? bg : Colors.white.withOpacity(0.2),
      ],
      child: InkWell(
        onTap: () {},
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              HugeIcon(
                icon: icon,
                size: 18,
                color: shadow ? Colors.white : AppColors.primary,
              ),
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  color: shadow ? Colors.white : AppColors.slate800,
                  fontWeight: FontWeight.w900,
                  fontSize: 11,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAchievementTip() {
    return GlassCard(
      gradientColors: [
        Colors.amber.withOpacity(0.2),
        Colors.amber.withOpacity(0.05),
      ],
      borderColor: Colors.amber.withOpacity(0.3),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          const HugeIcon(
            icon: HugeIcons.strokeRoundedStars,
            color: Colors.amber,
            size: 20,
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Text(
              'Top 5% performer this month. Keep it up!',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: Color(0xFF92400E),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
