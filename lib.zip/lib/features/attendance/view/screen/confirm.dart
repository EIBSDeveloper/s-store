import 'package:elysium_employee/core/app_style.dart';
import 'package:elysium_employee/widgets/primary_button.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';

import '../../../../core/app_colors.dart';
import '../../../dashboard/view/widgets/glass_card.dart';

class Confirm extends StatefulWidget {
  const Confirm({super.key});

  @override
  State<Confirm> createState() => _ConfirmState();
}

class _ConfirmState extends State<Confirm> with TickerProviderStateMixin {
  late AnimationController pulseController;
  late AnimationController fadeController;

  @override
  void initState() {
    super.initState();

    pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();
  }

  @override
  void dispose() {
    pulseController.dispose();
    fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      backgroundColor: AppColors.background,
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            _mapCard(),
            const SizedBox(height: 10),
            _locationDetails(),
            const SizedBox(height: 10),
            _warningBox(),
            const SizedBox(height: 10),
            PrimaryButton(
              name: "CONFIRM CHECK-IN",
              onTap: () {
                Get.back();
              },
            ),
            const SizedBox(height: 100),
          ],
        ),
      ),
    );
  }

  // ================= MAP CARD =================
  Widget _mapCard() {
    return Container(
      height: 260,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 20),
        ],
      ),
      child: Container(
        decoration: AppStyle.decoration.copyWith(
          borderRadius: BorderRadius.circular(20),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Stack(
            children: [
              // Overlay
              Container(color: Colors.black.withOpacity(0.2)),

              // Geofence Circle
              Center(
                child: AnimatedBuilder(
                  animation: pulseController,
                  builder: (_, __) {
                    return Transform.scale(
                      scale: 1 + (pulseController.value * 0.1),
                      child: Container(
                        width: 160,
                        height: 160,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: AppColors.primary.withOpacity(0.4),
                            width: 2,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),

              // User Pin
              Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.primary,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Text(
                        "You're here",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(height: 6),
                    AnimatedBuilder(
                      animation: pulseController,
                      builder: (_, __) {
                        return Container(
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                            color: AppColors.primary,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.primary.withOpacity(0.6),
                                blurRadius: 10 * pulseController.value,
                                spreadRadius: 3,
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),

              // Bottom Status
              Positioned(
                bottom: 0,
                child: Container(
                  width: MediaQuery.of(context).size.width - 32,
                  padding: const EdgeInsets.all(12),
                  color: const Color(0xFF2D2417),
                  child: Row(
                    children: const [
                      CircleAvatar(
                        radius: 4,
                        backgroundColor: Color(0xFFAF934F),
                      ),
                      SizedBox(width: 8),
                      Text(
                        "Inside office zone — Elysium HQ",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ================= DETAILS =================
  Widget _locationDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "LOCATION DETAILS",
          style: TextStyle(fontSize: 12, letterSpacing: 2),
        ),
        const SizedBox(height: 10),
        _tile(
          HugeIcons.strokeRoundedLocation03,
          "Detected location",
          "9.9252° N, 78.1198° E",
          "Verified",
          AppColors.primary,
        ),
        _tile(
          HugeIcons.strokeRoundedOffice,
          "Office zone",
          "Elysium — 150m",
          "Within",
          AppColors.primary,
        ),
        _tile(
          HugeIcons.strokeRoundedLocationUser04,
          "GPS Accuracy",
          "±8 meters",
          "High",
          Colors.green,
        ),
      ],
    );
  }

  Widget _tile(
    List<List<dynamic>> icon,
    String title,
    String sub,
    String badge,
    Color color,
  ) {
    return GlassCard(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      gradientColors: [
        const Color(0xFFEFF6FF).withOpacity(0.8),
        const Color(0xFFEFF6FF).withOpacity(0.3),
      ],
      child: Row(
        children: [
          // Icon(icon, color: color),
          HugeIcon(icon: icon, color: color, size: AppStyle.iconSizeLarge),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 10)),
                Text(sub, style: const TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(badge, style: TextStyle(color: color, fontSize: 10)),
          ),
        ],
      ),
    );
  }

  // ================= WARNING =================
  Widget _warningBox() {
    return GlassCard(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      gradientColors: [
        AppColors.warning.withAlpha(50),
        AppColors.warning.withAlpha(50),
      ],

      child: const Text(
        "If you are working from home, switch to WFH mode. Late check-ins will be flagged.",
      ),
    );
  }
}
