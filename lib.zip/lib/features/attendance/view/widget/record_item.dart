import 'package:flutter/material.dart';

import '../../../../core/app_colors.dart';
import '../../../dashboard/view/widgets/glass_card.dart';

/// RECORD ITEM
class RecordItem extends StatelessWidget {
  final String day;
  final String date;
  final String title;
  final String time;
  final String status;
  final Color color;
  final bool isDim;
  final void Function()? onTap;
  const RecordItem({
    super.key,
    required this.day,
    required this.date,
    required this.title,
    required this.time,
    required this.status,
    required this.color,
    required this.onTap,
    this.isDim = false,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(8),
      gradientColors: [
        const Color.fromARGB(255, 255, 255, 255).withOpacity(0.5),
        const Color.fromARGB(255, 255, 255, 255).withOpacity(0.2),
      ],
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              // color: AppColors.secondary.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.primary.withOpacity(0.5)),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  day.toUpperCase(),
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    color: AppColors.primary.withOpacity(0.6),
                  ),
                ),
                Text(
                  date,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    color: AppColors.primary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),

          /// CONTENT
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    color: isDim ? AppColors.slate400 : AppColors.slate800,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  time,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    color: isDim
                        ? Colors.red.withOpacity(0.7)
                        : AppColors.slate800,
                  ),
                ),
              ],
            ),
          ),

          /// STATUS
          InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(12),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(width: 1, color: color.withOpacity(0.2)),
              ),
              child: Text(
                status.toUpperCase(),
                style: TextStyle(
                  fontSize: 9,
                  color: color,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
