import 'package:elysium_employee/core/app_colors.dart';
import 'package:flutter/material.dart';

import '../../model/attendance_model.dart';

class LegendWidget extends StatelessWidget {
  const LegendWidget({super.key});

  Widget item(AttendanceStatus status) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(
            color: AppColors.attendance(status),
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        const SizedBox(width: 4),
        Text(
          status.name,
          style: const TextStyle(fontSize: 10, color: Colors.black),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 10,
      runSpacing: 6,
      alignment: WrapAlignment.center,
      children: [...AttendanceStatus.values.map((status) => item(status))],
    );
  }
}
