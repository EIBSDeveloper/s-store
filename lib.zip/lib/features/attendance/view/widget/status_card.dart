import 'package:flutter/material.dart';

class StatusCard extends StatelessWidget {
  final String title;
  final int count;
  final Color bgColor;
  final Color textColor;

  const StatusCard({
    super.key,
    required this.title,
    required this.count,
    required this.bgColor,
    required this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Text("$count",
              style: TextStyle(
                  fontWeight: FontWeight.bold, color: textColor)),
          const SizedBox(width: 6),
          Text(title,
              style: TextStyle(fontSize: 10, color: textColor)),
        ],
      ),
    );
  }
}