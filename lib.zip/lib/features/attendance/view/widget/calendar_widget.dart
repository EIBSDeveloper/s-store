import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../core/app_colors.dart';
import '../../controller/attendance_controller.dart';
import '../../model/attendance_model.dart';
import 'legend_widget.dart';

class CalendarWidget extends StatelessWidget {
  final List<CalendarDay> days;
  final DateTime month;

  const CalendarWidget({super.key, required this.days, required this.month});

  /// First weekday (Mon = 1 → convert to 0 index)
  int getStartOffset() {
    final firstDay = DateTime(month.year, month.month, 1);
    return firstDay.weekday - 1;
  }

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<AttendanceController>();

    final offset = getStartOffset();
    final totalCells = offset + days.length;

    return Column(
      children: [
        /// WEEK LABELS
        Row(
          children: const ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"]
              .map(
                (e) => Expanded(
                  child: Center(
                    child: Text(
                      e,
                      style: TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
              )
              .toList(),
        ),

        const SizedBox(height: 6),

        /// CALENDAR GRID (Reactive)
        Obx(() {
          final selected = controller.selectedDate.value;
          final today = DateTime.now();

          return GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: totalCells,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 7,
              mainAxisSpacing: 4,
              crossAxisSpacing: 4,
            ),
            itemBuilder: (_, index) {
              /// EMPTY CELL (before month start)
              if (index < offset) {
                return const SizedBox();
              }

              final day = days[index - offset];

              final currentDate = DateTime(month.year, month.month, day.day);

              final isToday =
                  currentDate.year == today.year &&
                  currentDate.month == today.month &&
                  currentDate.day == today.day;

              final isSelected =
                  selected != null &&
                  currentDate.year == selected.year &&
                  currentDate.month == selected.month &&
                  currentDate.day == selected.day;

              return GestureDetector(
                onTap: () => controller.selectDate(day.day),

                /// ANIMATION
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  curve: Curves.easeInOut,
                  alignment: Alignment.center,

                  decoration: BoxDecoration(
                    /// PRIORITY → Selected > Today > Status
                    color: isSelected
                        ? AppColors.primary.withOpacity(0.1)
                        : isToday
                        ? AppColors.primary
                        : AppColors.attendance(day.status).withAlpha(180),

                    borderRadius: BorderRadius.circular(10),

                    border: isSelected
                        ? Border.all(color: AppColors.primary, width: 1.5)
                        : Border.all(color: Colors.white, width: 1.5),
                  ),

                  child: AnimatedScale(
                    duration: const Duration(milliseconds: 200),
                    scale: isSelected ? 1.1 : 1,
                    child: Text(
                      "${day.day}",
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: isSelected
                            ? FontWeight.w900
                            : FontWeight.bold,
                        color: isSelected
                            ? AppColors.primary
                            : isToday
                            ? Colors.white
                            : Colors.white,
                      ),
                    ),
                  ),
                ),
              );
            },
          );
        }),

        const SizedBox(height: 8),

        /// LEGEND
        /// LEGEND
        const LegendWidget(),
      ],
    );
  }
}
