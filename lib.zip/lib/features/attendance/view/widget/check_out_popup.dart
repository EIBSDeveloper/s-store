import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';

import '../../../../core/app_colors.dart';
import '../../../../core/app_text_theme.dart';
import '../../../../widgets/primary_button.dart';
import '../screen/test.dart';

class CheckOutPopup extends StatefulWidget {
  const CheckOutPopup({super.key});

  @override
  State<CheckOutPopup> createState() => _CheckOutPopupState();
}

class _CheckOutPopupState extends State<CheckOutPopup>
    with TickerProviderStateMixin {
  late AnimationController controller;

  @override
  void initState() {
    super.initState();
    controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    )..forward();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final gold = AppColors.secondary;
    final dark = AppColors.primary;

    return Material(
      color: Colors.transparent,
      child: Stack(
        children: [
          AnimatedBuilder(
            animation: controller,
            builder: (_, __) {
              return Opacity(
                opacity: controller.value,
                child: BackdropFilter(
                  filter: ImageFilter.blur(
                    sigmaX: 8 * controller.value,
                    sigmaY: 8 * controller.value,
                  ),
                  child: Container(color: Colors.black.withOpacity(0.3)),
                ),
              );
            },
          ),

          /// 🔥 Popup animation
          Center(
            child: ScaleTransition(
              scale: CurvedAnimation(
                parent: controller,
                curve: Curves.easeOutBack,
              ),
              child: FadeTransition(
                opacity: controller,
                child: _modal(gold, dark),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _modal(Color gold, Color dark) {
    return Container(
      width: 340,
      padding: const EdgeInsets.all(0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 30),
        ],
      ),
      child: Stack(
        children: [
          // Glow
          Positioned(
            top: 0,
            right: 0,
            child: InkWell(
              onTap: () {
                Get.back();
              },
              child: Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: AppColors.secondary.withAlpha(40),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(40),
                    topRight: Radius.circular(24),
                  ),
                ),
                child: Icon(Icons.close, color: AppColors.primary),
              ),
            ),
          ),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 30),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                /// PROGRESS CIRCLE
                Stack(
                  alignment: Alignment.center,
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 40),
                      width: 280,
                      height: 190,
                      child: CustomPaint(painter: CirclePainter(0.75)),
                    ),

                    /// INNER CARD
                    Container(
                      width: 160,
                      height: 160,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.grey.shade200),
                        boxShadow: const [
                          BoxShadow(blurRadius: 25, color: Colors.black12),
                        ],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "TIME LOGGED",
                            style: AppText.bodySmall.copyWith(letterSpacing: 2),
                          ),
                          SizedBox(height: 5),
                          Text(
                            "8h 52m",
                            style: AppText.titleLarge.copyWith(
                              fontSize: 25,
                              fontWeight: FontWeight.w900,
                              color: AppColors.primary,
                            ),
                          ),
                          SizedBox(height: 10),
                          Text(
                            "LATE ARRIVAL",
                            style: AppText.bodySmall.copyWith(
                              color: Colors.red,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Text(
                            "18m past 09:00 AM",
                            style: AppText.bodySmall.copyWith(
                              color: Colors.black54,
                            ),
                          ),
                        ],
                      ),
                    ),

                    /// LEFT FLOAT CARD
                    Positioned(
                      left: 0,
                      top: 20,
                      child: floatingCard(
                        title: "IMPACT",
                        value: "-10",
                        subtitle: "DEDUCTED",
                        color: Colors.red,
                      ),
                    ),

                    /// RIGHT FLOAT CARD
                    Positioned(
                      right: 0,
                      bottom: 20,
                      child: Container(
                        width: 90,
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: const [
                            BoxShadow(blurRadius: 10, color: Colors.black12),
                          ],
                        ),
                        child: Column(
                          children: [
                            const Text(
                              "LATES",
                              style: TextStyle(
                                fontSize: 8,
                                letterSpacing: 1.5,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: const [
                                Text(
                                  "2",
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 18,
                                  ),
                                ),
                                Text(
                                  "/3",
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: Colors.black54,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 5),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: LinearProgressIndicator(
                                value: 0.66,
                                backgroundColor: Colors.grey.shade300,
                                color: AppColors.danger,
                                minHeight: 4,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 10),

                /// WORK LOG
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          const Text(
                            "WORK LOG",
                            style: TextStyle(
                              fontSize: 10,
                              letterSpacing: 2,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Container(height: 1, color: Colors.grey),
                          ),
                        ],
                      ),
                      const SizedBox(height: 15),

                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.grey.shade300,
                            style: BorderStyle.solid,
                          ),
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.white,
                        ),
                        child: Column(
                          children: [
                            WorkItem(
                              icon: HugeIcons.strokeRoundedLogin02,
                              title: "Check-in",
                              time: "09:18 AM",
                              status: "Verified",
                              isGreen: true,
                            ),
                            SizedBox(height: 10),
                            WorkItem(
                              icon: HugeIcons.strokeRoundedLogout02,
                              title: "Check-out",
                              time: " - - : - -",
                              status: "none",
                              isGreen: false,
                            ),
                            SizedBox(height: 10),
                            WorkItem(
                              icon: HugeIcons.strokeRoundedOffice,
                              title: "Location",
                              time: "Elysium — 150m",
                              status: "Verified",
                              isGreen: true,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 10,
                  ),
                  child: PrimaryButton(
                    name: "CONFIRM CHECK-OUT",
                    onTap: () {
                      Get.back();
                    },
                  ),
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget floatingCard({
    required String title,
    required String value,
    required String subtitle,
    required Color color,
  }) {
    return Container(
      width: 90,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: const [BoxShadow(blurRadius: 10, color: Colors.black12)],
      ),
      child: Column(
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 8,
              fontWeight: FontWeight.bold,
              color: Colors.black54,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w900,
              color: color,
            ),
          ),
          Text(
            subtitle,
            style: const TextStyle(fontSize: 8, color: Colors.black45),
          ),
        ],
      ),
    );
  }
}
