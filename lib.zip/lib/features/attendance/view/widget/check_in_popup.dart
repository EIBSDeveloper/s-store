import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../core/app_colors.dart';
import '../../../../routes/app_routes.dart';

class CheckInPopup extends StatefulWidget {
  const CheckInPopup({super.key});

  @override
  State<CheckInPopup> createState() => _CheckInPopupState();
}

class _CheckInPopupState extends State<CheckInPopup>
    with TickerProviderStateMixin {
  late AnimationController controller;

  @override
  void initState() {
    super.initState();
    controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    )..forward();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final gold = AppColors.secondary;
    final dark = AppColors.primary;

    return Material(
      color: Colors.transparent,
      child: Stack(
        children: [
          /// 🔥 Blur background
          AnimatedBuilder(
            animation: controller,
            builder: (_, __) {
              return Opacity(
                opacity: controller.value,
                child: BackdropFilter(
                  filter: ImageFilter.blur(
                    sigmaX: 8 * controller.value,
                    sigmaY: 8 * controller.value,
                  ),
                  child: Container(color: Colors.black.withOpacity(0.3)),
                ),
              );
            },
          ),

          /// 🔥 Popup animation
          Center(
            child: ScaleTransition(
              scale: CurvedAnimation(
                parent: controller,
                curve: Curves.easeOutBack,
              ),
              child: FadeTransition(
                opacity: controller,
                child: _modal(gold, dark),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _modal(Color gold, Color dark) {
    return Container(
      width: 340,
      padding: const EdgeInsets.all(0),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 30),
        ],
      ),
      child: Stack(
        children: [
          // Glow
          Positioned(
            top: 0,
            right: 0,
            child: InkWell(
              onTap: () {
                Get.back();
              },
              child: Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: AppColors.secondary.withAlpha(40),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(40),
                    topRight: Radius.circular(24),
                  ),
                ),
                child: Icon(Icons.close, color: AppColors.primary),
              ),
            ),
          ),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 30),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Icon
                // Container(
                //   width: 70,
                //   height: 70,
                //   decoration: BoxDecoration(
                //     color: AppColors.secondary,
                //     shape: BoxShape.circle,
                //   ),
                //   child: const Icon(Icons.lock, size: 32),
                // ),

                // const SizedBox(height: 20),
                const Text(
                  "Security Verification",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),

                const SizedBox(height: 10),

                const Text(
                  "Place your finger or use Face ID to confirm your identity.",
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: Colors.black54),
                ),

                const SizedBox(height: 24),

                // Buttons
                _btn("Use Face ID", Icons.face, dark, Colors.white, () {
                  Get.back();
                  Get.toNamed(Routes.confirmCheckIn);
                }),
                const SizedBox(height: 10),
                _btn(
                  "Use PIN instead",
                  Icons.pin,
                  Colors.grey.shade200,
                  dark,
                  () {},
                ),

                const SizedBox(height: 20),

                // Info box
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.warning.withAlpha(30),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.info, size: 16, color: AppColors.warning),
                          SizedBox(width: 6),
                          Text(
                            "WHY WE VERIFY",
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 6),
                      Text(
                        "Biometric verification prevents proxy check-ins.",
                        style: TextStyle(fontSize: 11),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.verified_user,
                      size: 14,
                      color: AppColors.warning,
                    ),
                    SizedBox(width: 6),
                    Text(
                      "Processed on-device only",
                      style: TextStyle(fontSize: 10),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _btn(
    String text,
    IconData icon,
    Color bg,
    Color fg,
    Function()? onTap,
  ) {
    return InkWell(
      onTap: onTap,
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: fg),
            const SizedBox(width: 8),
            Text(
              text,
              style: TextStyle(color: fg, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
