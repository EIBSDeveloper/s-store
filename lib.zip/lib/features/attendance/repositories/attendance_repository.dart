import '../model/attendance_model.dart';
class AttendanceRepository {
  Future<AttendanceModel> fetchAttendance(int year, int month) async {
    await Future.delayed(const Duration(milliseconds: 500));

    /// 🔹 API response (only marked days)
    final apiResponse = {
      "attendance_dates": [
        {"date": "2026-03-01", "status": "present"},
        {"date": "2026-03-04", "status": "late"},
        {"date": "2026-03-06", "status": "late"},
        {"date": "2026-03-11", "status": "absent"},
        {"date": "2026-03-16", "status": "leave"},
        {"date": "2026-03-17", "status": "leave"},
      ]
    };

    /// 🔹 Convert API list → Map for fast lookup
    final Map<int, String> statusMap = {};

    for (var item in apiResponse['attendance_dates']!) {
      final date = DateTime.parse(item['date']!);
      if (date.year == year && date.month == month) {
        statusMap[date.day] = item['status']!;
      }
    }

    /// 🔹 Get total days in month
    final totalDays = DateTime(year, month + 1, 0).day;

    /// 🔹 Build full calendar
    final calendar = List.generate(totalDays, (index) {
      final day = index + 1;

      return {
        "day": day,
        "status": statusMap[day] ?? "none", // 🔥 key logic
      };
    });

    /// 🔹 Final JSON
    final json = {
      "present": 18,
      "late": 2,
      "absent": 1,
      "leave": 2,
      "calendar": calendar,
      "records": []
    };

    return AttendanceModel.fromJson(json);
  }
}