 
import 'package:get/get.dart';

import 'chat_repository.dart';
import 'smart_farm_controller.dart';
//HugeIcons.strokeroundedArtificialIntelligence06
//HugeIcons.strokeroundedAward04
class SmartFarmBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ChatRepository>(() => ChatRepository());

    Get.lazyPut<SmartFarmController>(
      () => SmartFarmController(repository: Get.find<ChatRepository>()),
    );
  }
}
