import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:get/get.dart';

import 'chart.dart';

class FormattedMessageContent extends StatelessWidget {
  final MessageModel message;
  final Color? textColor;

  const FormattedMessageContent({
    super.key,
    required this.message,
    this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    if (message.isUser) {
      return Padding(
        padding: const EdgeInsets.all(0),
        child: Text(
          message.text,
          style: Get.textTheme.bodyMedium?.copyWith(
            color: textColor ?? Colors.white,
          ),
        ),
      );
    }

    final effectiveTextColor =
        textColor ?? (Get.isDarkMode ? Colors.white : Colors.black87);

    return Padding(
      padding: const EdgeInsets.all(0),
      child: MarkdownBody(
        data: message.text,
        styleSheet: MarkdownStyleSheet(
          p: Get.textTheme.bodyMedium?.copyWith(color: effectiveTextColor),
          strong: Get.textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: effectiveTextColor,
          ),
          em: Get.textTheme.bodyMedium?.copyWith(
            fontStyle: FontStyle.italic,
            color: effectiveTextColor,
          ),
          code: Get.textTheme.bodyMedium?.copyWith(
            fontFamily: 'monospace',
            backgroundColor: Get.isDarkMode
                ? Colors.grey[800]
                : Colors.grey[200],
            color: effectiveTextColor,
          ),
          codeblockDecoration: BoxDecoration(
            color: Get.isDarkMode ? Colors.grey[800] : Colors.grey[200],
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        selectable: true,
      ),
    );
  }
}
