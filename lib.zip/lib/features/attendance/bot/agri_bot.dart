import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

import '../../../core/app_colors.dart';
import '../../../widgets/custom_app_bar.dart';
import '../../dashboard/view/widgets/glass_card.dart';
import 'chart.dart';
import 'formatt_message.dart';
import 'smart_farm_controller.dart';

class SmartFarmView extends GetView<SmartFarmController> {
  const SmartFarmView({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.background,
    extendBodyBehindAppBar: true,
    appBar: CustomAppBar(
      title: Text('Bot Title'),

      actions: [
        IconButton(
          icon: const Icon(Icons.photo_library_outlined),
          onPressed: () => controller.pickImage(ImageSource.gallery),
          tooltip: 'tooltip.gallery'.tr,
        ),
        IconButton(
          icon: const Icon(Icons.info_outline),
          onPressed: _showAboutDialog,
        ),
      ],
    ),
    body: SafeArea(
      child: Column(
        children: [
          // Analysis indicator
          Obx(
            () => controller.isAnalyzing.value
                ? _buildAnalysisIndicator()
                : const SizedBox.shrink(),
          ),

          // Messages list
          Expanded(
            child: Obx(
              () => controller.messages.isEmpty
                  ? _buildEmptyState()
                  : _buildMessagesList(),
            ),
          ),

          // Input area
          _buildInputArea(),
        ],
      ),
    ),
  );

  Widget _buildAnalysisIndicator() => GlassCard(
    borderRadius: 0,
    blur: 10,
    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
    gradientColors: [
      AppColors.primary.withOpacity(0.2),
      AppColors.primary.withOpacity(0.1),
    ],
    child: Row(
      children: [
          SizedBox(
          width: 18,
          height: 18,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            valueColor: AlwaysStoppedAnimation(AppColors.primary),
          ),
        ),
        const SizedBox(width: 12),
        Text(
          'analyzing'.tr,
          style: Get.textTheme.bodyMedium?.copyWith(
            color: AppColors.primary,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    ),
  );

  Widget _buildEmptyState() => Center(
    child: GlassCard(
      margin: const EdgeInsets.symmetric(horizontal: 40),
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child:   Center(
              child: HugeIcon(
                icon: HugeIcons.strokeRoundedChatBot,
                color: AppColors.primary,
                size: 40,
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'emptyTitle'.tr,
            style: Get.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: AppColors.slate800,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'emptySubtitle'.tr,
            textAlign: TextAlign.center,
            style: Get.textTheme.bodyMedium?.copyWith(
              color: AppColors.slate400,
            ),
          ),
        ],
      ),
    ),
  );

  Widget _buildMessagesList() => ListView.builder(
    controller: controller.scrollController,
    padding: const EdgeInsets.only(top: 16, bottom: 16),
    itemCount: controller.messages.length,
    itemBuilder: (context, index) {
      final message = controller.messages[index];
      return MessageWidget(
        message: message,
        index: index,
        messages: controller.messages,
        onLongPress: () => _showMessageOptions(message),
      );
    },
  );

  Widget _buildInputArea() => GlassCard(
    borderRadius: 0,
    blur: 15,
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
    gradientColors: [
      Colors.white.withOpacity(0.9),
      Colors.white.withOpacity(0.8),
    ],
    borderColor: Colors.white.withAlpha(200),
    child: Row(
      children: [
        // Camera button
        InkWell(
          onTap: () => controller.pickImage(ImageSource.camera),
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child:   HugeIcon(
              icon: HugeIcons.strokeRoundedCamera01,
              color: AppColors.primary,
              size: 22,
            ),
          ),
        ),
        const SizedBox(width: 12),

        // Text input
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.5),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                color: AppColors.primary.withOpacity(0.2),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: TextField(
                      controller: controller.textController,
                      focusNode: controller.focusNode,
                      decoration: InputDecoration(
                        hintText: 'hintText'.tr,
                        hintStyle: TextStyle(
                          color: AppColors.slate400,
                          fontSize: 14,
                        ),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                          vertical: 12,
                        ),
                      ),
                      style: Get.textTheme.bodyMedium?.copyWith(
                        color: AppColors.slate800,
                      ),
                      onSubmitted: (text) {
                        if (text.trim().isNotEmpty) {
                          controller.addUserMessage(text.trim());
                        }
                      },
                      maxLines: 4,
                      minLines: 1,
                      textCapitalization: TextCapitalization.sentences,
                    ),
                  ),
                ),

                // Send button
                Padding(
                  padding: const EdgeInsets.only(right: 4),
                  child: Material(
                    color: AppColors.primary,
                    borderRadius: BorderRadius.circular(20),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(20),
                      onTap: () {
                        final text = controller.textController.text.trim();
                        if (text.isNotEmpty) {
                          controller.addUserMessage(text);
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        child: const HugeIcon(
                          icon: HugeIcons.strokeRoundedSent,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  );

  void _showAboutDialog() {
    Get.dialog(
      AlertDialog(
        title: Text('aboutTitle'.tr),
        content: Text('aboutContent'.tr),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: Text('dialog.close'.tr),
          ),
        ],
      ),
    );
  }

  void _showMessageOptions(MessageModel message) {
    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.copy, color: Get.theme.primaryColor),
              title: Text('copy'.tr),
              onTap: () {
                Get.back();
                controller.copyToClipboard(message.text);
              },
            ),
            if (message.isUser)
              ListTile(
                leading: Icon(Icons.edit, color: Get.theme.primaryColor),
                title: Text('edit'.tr),
                onTap: () {
                  Get.back();
                  _showEditMessageDialog(message);
                },
              ),
          ],
        ),
      ),
      backgroundColor: Get.theme.cardTheme.color,
    );
  }

  void _showEditMessageDialog(MessageModel message) {
    final editController = TextEditingController(text: message.text);

    Get.dialog(
      AlertDialog(
        title: Text('editMessage'.tr),
        content: TextField(
          controller: editController,
          decoration: const InputDecoration(border: OutlineInputBorder()),
          maxLines: 5,
          minLines: 1,
        ),
        actions: [
          TextButton(onPressed: () => Get.back(), child: Text('cancel'.tr)),
          FilledButton(
            onPressed: () {
              final updatedText = editController.text.trim();
              if (updatedText.isNotEmpty) {
                controller.updateMessage(message.id, updatedText);
                Get.back();
              }
            },
            child: Text('save'.tr),
          ),
        ],
      ),
    );
  }
}

class MessageWidget extends StatelessWidget {
  final MessageModel message;
  final int index;
  final List<MessageModel> messages;
  final VoidCallback onLongPress;

  const MessageWidget({
    super.key,
    required this.message,
    required this.index,
    required this.messages,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final isFirstMessage =
        index == 0 || messages[index - 1].isUser != message.isUser;
    final showAvatar = isFirstMessage;

    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        bottom: 8,
        top: isFirstMessage ? 12 : 0,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!message.isUser && showAvatar) _buildBotAvatar(),
          if (!message.isUser && !showAvatar) const SizedBox(width: 48),

          Expanded(
            child: Column(
              crossAxisAlignment: message.isUser
                  ? CrossAxisAlignment.end
                  : CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onLongPress: onLongPress,
                  child: GlassCard(
                    borderRadius: 10,
                    padding: EdgeInsets.zero,
                    gradientColors: message.isUser
                        ? [
                            AppColors.primary,
                            AppColors.primary.withOpacity(0.8),
                          ]
                        : [
                            Colors.white.withOpacity(0.6),
                            Colors.white.withOpacity(0.3),
                          ],
                    borderColor: message.isUser
                        ? AppColors.primary.withAlpha(100)
                        : Colors.white.withAlpha(150),
                    child: Container(
                      constraints: BoxConstraints(
                        maxWidth: MediaQuery.of(context).size.width * 0.7,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (message.imagePath != null) _buildImagePreview(),
                          if (message.text.isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 10,
                              ),
                              child: FormattedMessageContent(
                                message: message,
                                textColor: message.isUser
                                    ? Colors.white
                                    : AppColors.slate800,
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
                _buildTimestamp(),
              ],
            ),
          ),

          if (message.isUser && showAvatar) _buildUserAvatar(),
          if (message.isUser && !showAvatar) const SizedBox(width: 48),
        ],
      ),
    );
  }

  Widget _buildBotAvatar() => Container(
    width: 36,
    height: 36,
    margin: const EdgeInsets.only(right: 12, top: 4),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.5),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Colors.white.withAlpha(180)),
    ),
    child:   Center(
      child: HugeIcon(
        icon: HugeIcons.strokeRoundedChatBot,
        color: AppColors.primary,
        size: 20,
      ),
    ),
  );

  Widget _buildUserAvatar() => Container(
    width: 36,
    height: 36,
    margin: const EdgeInsets.only(left: 12, top: 4),
    decoration: BoxDecoration(
      gradient: AppColors.gradient,
      borderRadius: BorderRadius.circular(12),
      boxShadow: [
        BoxShadow(
          color: AppColors.primary.withOpacity(0.3),
          blurRadius: 8,
          offset: const Offset(0, 2),
        ),
      ],
    ),
    child: const Icon(Icons.person, color: Colors.white, size: 20),
  );

  Widget _buildImagePreview() => ClipRRect(
    borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
    child: Stack(
      children: [
        Image.file(
          File(message.imagePath!),
          width: double.infinity,
          height: 200,
          fit: BoxFit.cover,
        ),
        Positioned(
          top: 8,
          right: 8,
          child: GlassCard(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            borderRadius: 8,
            blur: 5,
            child: Text(
              'analyzingImage'.tr,
              style: const TextStyle(
                color: AppColors.slate800,
                fontSize: 10,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ],
    ),
  );

  Widget _buildTimestamp() => Padding(
    padding: const EdgeInsets.only(top: 4, left: 4, right: 4),
    child: Text(
      DateFormat.jm().format(message.timestamp),
      style: TextStyle(
        color: AppColors.slate400,
        fontSize: 10,
        fontWeight: FontWeight.w500,
      ),
    ),
  );
}
