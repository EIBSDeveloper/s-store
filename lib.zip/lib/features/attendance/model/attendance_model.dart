enum AttendanceStatus { present, late, absent, leave, holiday, none }

class CalendarDay {
  final int day;
  final AttendanceStatus status;

  CalendarDay({
    required this.day,
    required this.status,
  });

  factory CalendarDay.fromJson(Map<String, dynamic> json) {
    return CalendarDay(
      day: json['day'],
      status: AttendanceStatus.values.firstWhere(
        (e) => e.name == json['status'],
        orElse: () => AttendanceStatus.none,
      ),
    );
  }
}
class AttendanceDayApi {
  final DateTime date;
  final String status;

  AttendanceDayApi({
    required this.date,
    required this.status,
  });

  factory AttendanceDayApi.fromJson(Map<String, dynamic> json) {
    return AttendanceDayApi(
      date: DateTime.parse(json['date']),
      status: json['status'],
    );
  }
}
class AttendanceModel {
  final int present;
  final int late;
  final int absent;
  final int leave;
  final List<CalendarDay> calendar;
  final List<AttendanceRecord> records;

  AttendanceModel({
    required this.present,
    required this.late,
    required this.absent,
    required this.leave,
    required this.calendar,
    required this.records,
  });

  factory AttendanceModel.fromJson(Map<String, dynamic> json) {
    return AttendanceModel(
      present: json['present'],
      late: json['late'],
      absent: json['absent'],
      leave: json['leave'],
      calendar: (json['calendar'] as List)
          .map((e) => CalendarDay.fromJson(e))
          .toList(),
      records: (json['records'] as List)
          .map((e) => AttendanceRecord.fromJson(e))
          .toList(),
    );
  }
}
class AttendanceRecord {
  final String date;
  final String day;
  final String checkIn;
  final String checkOut;
  final String status;

  AttendanceRecord({
    required this.date,
    required this.day,
    required this.checkIn,
    required this.checkOut,
    required this.status,
  });

  factory AttendanceRecord.fromJson(Map<String, dynamic> json) {
    return AttendanceRecord(
      date: json['date'],
      day: json['day'],
      checkIn: json['check_in'] ?? '',
      checkOut: json['check_out'] ?? '',
      status: json['status'],
    );
  }
}