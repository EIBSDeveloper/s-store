import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'dart:ui';
import '../../../../core/app_colors.dart';
import '../../../../core/app_style.dart';
import '../../../../routes/app_routes.dart';
import '../../../attendance/view/widget/check_in_popup.dart';

import 'dart:math' as math;

import '../../../bottom_bar/controller/bottombar_controller.dart';
import '../widgets/glass_card.dart';
import '../widgets/color_editor_bottom_sheet.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  static const Color slate800 = Color(0xFF1E293B);
  static const Color slate400 = Color.fromARGB(255, 0, 0, 0);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            children: [
              const SizedBox(height: 8),

              _buildQuickActions()
                  .animate()
                  .fadeIn(duration: 400.ms)
                  .slideY(begin: 0.1, end: 0, duration: 400.ms),

              const SizedBox(height: 8),

              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      children: [
                        _buildAttendanceCard()
                            .animate()
                            .fadeIn(delay: 12.ms, duration: 400.ms)
                            .slideX(begin: -0.1, end: 0, duration: 400.ms),

                        const SizedBox(height: 8),

                        _buildTaskCard()
                            .animate()
                            .fadeIn(delay: 30.ms, duration: 400.ms)
                            .slideX(begin: -0.1, end: 0, duration: 400.ms),

                        const SizedBox(height: 8),

                        _buildIncentiveCard()
                            .animate()
                            .fadeIn(delay: 50.ms, duration: 400.ms)
                            .slideX(begin: -0.1, end: 0, duration: 400.ms),
                      ],
                    ),
                  ),

                  const SizedBox(width: 8),

                  Expanded(
                    child: Column(
                      children: [
                        _buildPointsCard()
                            .animate()
                            .fadeIn(delay: 15.ms, duration: 400.ms)
                            .slideX(begin: 0.1, end: 0, duration: 400.ms),

                        const SizedBox(height: 8),

                        _buildLevelCard()
                            .animate()
                            .fadeIn(delay: 30.ms, duration: 400.ms)
                            .slideX(begin: 0.1, end: 0, duration: 400.ms),

                        const SizedBox(height: 8),

                        _buildActivityCard()
                            .animate()
                            .fadeIn(delay: 50.ms, duration: 400.ms)
                            .slideX(begin: 0.1, end: 0, duration: 400.ms),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 8),

              _buildMomentumCard()
                  .animate()
                  .fadeIn(delay: 60.ms, duration: 500.ms)
                  .slideY(begin: 0.2, end: 0, duration: 500.ms),

              const SizedBox(height: 8),

              Row(
                children: [
                  Expanded(
                    child: _buildLeaveBalanceCard()
                        .animate()
                        .fadeIn(delay: 70.ms, duration: 500.ms)
                        .slideY(begin: 0.2, end: 0, duration: 500.ms),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildTrainingCard()
                        .animate()
                        .fadeIn(delay: 75.ms, duration: 800.ms)
                        .slideY(begin: 0.2, end: 0, duration: 800.ms),
                  ),
                ],
              ),

              const SizedBox(height: 100),
            ],
          ),
        ),
      ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          FloatingActionButton(
            mini: true,
            heroTag: 'themeButton',
            onPressed: () {
              showModalBottomSheet(
                context: context,
                backgroundColor: Colors.transparent,
                isScrollControlled: true,
                builder: (_) => const ColorEditorBottomSheet(),
              ).then((result) {
                Get.find<BottomBarController>().screenNavigation(
                  module: ScreenModule.attendance,
                );
                Get.find<BottomBarController>().screenNavigation(
                  module: ScreenModule.dashboard,
                );
              });
            },
            backgroundColor: Colors.white,
            elevation: 2,
            child: HugeIcon(
              icon: HugeIcons.strokeRoundedColorPicker,
              color: AppColors.primary,
              size: 20,
            ),
          ).animate().fadeIn(delay: 100.ms).slideX(begin: 1),
          const SizedBox(height: 12),
          FloatingActionButton(
            heroTag: 'chatButton',
            onPressed: () {
              Get.toNamed(Routes.bot);
            },
            backgroundColor: Colors.white,
            elevation: 2,
            child: HugeIcon(
              icon: HugeIcons.strokeRoundedChatBot,
              color: AppColors.primary,
              size: AppStyle.iconSizeLarge,
            ),
          ).animate().fadeIn(delay: 330.ms).slideX(begin: 1),
        ],
      ),
    );
  }

  Widget _buildQuickActions() {
    return GlassCard(
      gradientColors: [AppColors.primary, AppColors.primary],
      padding: const EdgeInsets.all(10),
      child: Row(
        children: [
          _actionBtn(HugeIcons.strokeRoundedFingerPrintCheck, "CHECK IN", () {
            showDialog(
              context: Get.context!,
              barrierDismissible: true,
              barrierColor: Colors.transparent,
              builder: (_) => const CheckInPopup(),
            );
          }),
          _divider(),
          _actionBtn(HugeIcons.strokeRoundedCalendarRemove02, "LEAVE", () {}),
          _divider(),
          _actionBtn(HugeIcons.strokeRoundedInvoice01, "PAYSLIP", () {}),
          _divider(),
          _actionBtn(HugeIcons.strokeRoundedTicket03, "HR TICKET", () {}),
        ],
      ),
    );
  }

  Widget _actionBtn(List<List<dynamic>> icon, String label, Function()? onTap) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withAlpha(85),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  width: 0.4,
                  color: Colors.white.withAlpha(150),
                ),
              ),
              child: HugeIcon(
                icon: icon,
                color: Colors.white,
                size: AppStyle.iconSize,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 9,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _divider() => Container(height: 30, width: 1, color: Colors.white24);

  Widget _buildAttendanceCard() {
    return GlassCard(
      padding: const EdgeInsets.all(10),
      gradientColors: [
        const Color.fromARGB(255, 243, 253, 236).withOpacity(0.10),
        const Color.fromARGB(255, 243, 253, 236).withOpacity(0.3),
      ],
      child: Column(
        children: [
          const Text(
            "ATTENDANCE",
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.bold,
              color: slate400,
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 100, // Increased size for better shadow visibility
            width: 100,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // The Painter
                CustomPaint(
                  size: const Size(110, 110),
                  painter: Modern3DCircularProgressPainter(progress: 0.50),
                ),

                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.baseline,
                      textBaseline: TextBaseline.alphabetic,
                      children: [
                        Text(
                          '50',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                            color: Colors.blueGrey[800],
                            letterSpacing: -1,
                          ),
                        ),
                        Text(
                          '%',
                          style: TextStyle(
                            fontSize: 8,
                            fontWeight: FontWeight.bold,
                            color: Colors.blueGrey[400],
                          ),
                        ),
                      ],
                    ),
                    Text(
                      'DONE',
                      style: TextStyle(
                        fontSize: 6,
                        fontWeight: FontWeight.w800,
                        color: Colors.black,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: Color(0xFF059669).withAlpha(50),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Text(
              "EXCELLENT",
              style: TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.bold,
                color: Color(0xFF059669),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPointsCard() {
    return _gridWidget(
      color: const Color(0xFFFFFBEB),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(Icons.stars, color: Colors.amber, size: 20),
              Text(
                "POINTS",
                style: TextStyle(
                  fontSize: 8,
                  fontWeight: FontWeight.bold,
                  color: slate400,
                ),
              ),
            ],
          ),
          Row(
            children: [
              const Expanded(
                child: Text(
                  "2,840",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    color: slate800,
                  ),
                ),
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [2.0, 4.0, 8.0, 12.0]
                    .map(
                      (h) =>
                          Container(
                                margin: const EdgeInsets.only(right: 2),
                                width: 4,
                                height: h,
                                decoration: BoxDecoration(
                                  color: Colors.amber.withOpacity(h / 12),
                                  borderRadius: BorderRadius.circular(2),
                                ),
                              )
                              .animate()
                              .scaleY(
                                begin: 0,
                                end: 1,
                                duration: 900.ms,
                                curve: Curves.easeOutBack,
                                alignment: Alignment.bottomCenter,
                              )
                              .fadeIn(duration: 400.ms),
                    )
                    .toList(),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLevelCard() {
    return _gridWidget(
      color: const Color(0xFFEEF2FF),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "L3",
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.w900,
                  color: AppColors.primary,
                ),
              ),
              Column(
                children: [
                  Icon(Icons.leaderboard, color: AppColors.primary, size: 20),
                  Text(
                    "LEVEL",
                    style: TextStyle(
                      fontSize: 8,
                      fontWeight: FontWeight.bold,
                      color: slate400,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMomentumCard() {
    return GlassCard(
      padding: const EdgeInsets.all(10),
      gradientColors: [
        const Color.fromARGB(255, 255, 255, 255).withOpacity(0.6),
        const Color.fromARGB(255, 255, 255, 255).withOpacity(0.3),
      ],
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Momentum",
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: slate800,
                ),
              ),
              Text(
                "12 DAY STREAK",
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  color: slate400,
                ),
              ),
            ],
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [16.0, 10.0, 24.0, 14.0, 20.0]
                .map(
                  (h) =>
                      Container(
                            margin: const EdgeInsets.only(left: 4),
                            width: 6,
                            height: h,
                            decoration: BoxDecoration(
                              color: h == 24.0 ? Colors.amber : Colors.blue,
                              borderRadius: BorderRadius.circular(4),
                            ),
                          )
                          .animate()
                          .scaleY(
                            begin: 0,
                            end: 1,
                            duration: 1100.ms,
                            curve: Curves.elasticOut,
                            alignment: Alignment.bottomCenter,
                          )
                          .fadeIn(duration: 800.ms),
                )
                .toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildActivityCard() {
    return GlassCard(
      padding: EdgeInsets.zero,
      gradientColors: [
        Colors.white.withOpacity(0.6),
        Colors.white.withOpacity(0.2),
      ],
      child: SizedBox(
        height: 190,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "ACTIVITY",
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      color: slate800,
                      letterSpacing: 1,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 255, 255, 255),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text(
                      "All",
                      style: TextStyle(
                        fontSize: 8,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const Divider(height: 1, color: Color.fromARGB(255, 255, 255, 255)),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(10),
                children: [
                  _activityItem("Leave Approved", "Mar 18-19 • 2d", Colors.cyan)
                      .animate()
                      .fadeIn(delay: 500.ms, duration: 400.ms)
                      .slideX(begin: 0.1, end: 0, duration: 400.ms),

                  _activityItem(
                        "Task assigned",
                        "QI Client Report",
                        Colors.amber,
                      )
                      .animate()
                      .fadeIn(delay: 600.ms, duration: 400.ms)
                      .slideX(begin: 0.1, end: 0, duration: 400.ms),

                  _activityItem(
                        "Quarterly Townhall",
                        "3:00 PM today",
                        Colors.indigo,
                      )
                      .animate()
                      .fadeIn(delay: 400.ms, duration: 400.ms)
                      .slideX(begin: 0.1, end: 0, duration: 400.ms),

                  _activityItem("Appraisal Started", "Due Mar 30", Colors.blue)
                      .animate()
                      .fadeIn(delay: 800.ms, duration: 400.ms)
                      .slideX(begin: 0.1, end: 0, duration: 400.ms),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _activityItem(String title, String sub, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.only(left: 8),
      decoration: BoxDecoration(
        border: Border(left: BorderSide(color: color, width: 2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.bold,
              color: slate800,
            ),
            overflow: TextOverflow.ellipsis,
          ),
          Text(
            sub,
            style: const TextStyle(
              fontSize: 10,
              color: slate400,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTaskCard() {
    return _gridWidget(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // const Icon(Icons.check_circle, color: Colors.cyan, size: 20),
              HugeIcon(
                icon: HugeIcons.strokeRoundedTaskDone02,
                color: AppColors.primary,
                size: AppStyle.iconSize,
              ),
              Container(
                width: 6,
                height: 6,
                decoration: const BoxDecoration(
                  color: Colors.amber,
                  shape: BoxShape.circle,
                ),
              ),
            ],
          ),
          const SizedBox(height: 3),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                "7",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  color: slate800,
                ),
              ),
              const Align(
                alignment: AlignmentGeometry.centerRight,
                child: Column(
                  children: [
                    Text(
                      "TASKS",
                      style: TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                        color: slate400,
                      ),
                    ),
                    Text(
                      "3 Today",
                      style: TextStyle(
                        fontSize: 8,
                        fontWeight: FontWeight.bold,
                        color: Colors.amber,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildIncentiveCard() {
    return _gridWidget(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              HugeIcon(
                icon: HugeIcons.strokeRoundedWallet02,
                color: AppColors.primary,
                size: AppStyle.iconSize,
              ),
              CircleAvatar(radius: 3, backgroundColor: AppColors.primary),
            ],
          ),
          SizedBox(height: 5),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "₹18k",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  color: slate800,
                ),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    "INCENTIVE",
                    style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                      color: slate400,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLeaveBalanceCard() {
    return _gridWidget(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "8",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  color: slate800,
                ),
              ),
              HugeIcon(
                icon: HugeIcons.strokeRoundedCalendar03,
                color: AppColors.primary,
                size: AppStyle.iconSizeLarge,
              ),
              // Icon(Icons.calendar_month, color: Colors.indigo, size: 20),
            ],
          ),
          Text(
            "LEAVE BALANCE",
            style: TextStyle(
              fontSize: 8,
              fontWeight: FontWeight.bold,
              color: slate400,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTrainingCard() {
    return _gridWidget(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                children: [
                  Text(
                    "Mar 24",
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      color: slate800,
                    ),
                  ),
                  Text(
                    "TRAINING",
                    style: TextStyle(
                      fontSize: 8,
                      fontWeight: FontWeight.bold,
                      color: slate400,
                    ),
                  ),
                ],
              ),
              HugeIcon(
                icon: HugeIcons.strokeRoundedCourse,
                color: AppColors.primary,
                size: AppStyle.iconSizeLarge,
              ),
              // Icon(Icons.school, color: Colors.indigo, size: 20),
            ],
          ),

          Text(
            "React Advanced",
            style: TextStyle(
              fontSize: 8,
              fontWeight: FontWeight.bold,
              color: Colors.indigo,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  Widget _gridWidget({required Widget child, Color color = Colors.white}) {
    return GlassCard(
      gradientColors: [color.withOpacity(0.7), color.withOpacity(0.3)],
      child: child,
    );
  }
}

class Modern3DCircularProgressPainter extends CustomPainter {
  final double progress; // 0.0 to 1.0

  Modern3DCircularProgressPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = (size.width / 2) - 10; // Padding for shadows
    final rect = Rect.fromCircle(center: center, radius: radius);
    const strokeWidth = 12.0;

    // 1. 🔹 Background Track (Inner Shadow Effect)
    final bgPaint = Paint()
      ..color = const Color.fromARGB(255, 216, 216, 216)
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth;

    canvas.drawCircle(center, radius, bgPaint);

    // 2. 🔹 Dark Inner Bevel (Neumorphic touch)
    final bevelPaint = Paint()
      ..color = const Color.fromARGB(255, 255, 255, 255).withOpacity(0.05)
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth / 2
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2);

    canvas.drawArc(rect, 0, math.pi * 2, false, bevelPaint);

    // 3. 🔹 The Progress Arc (Main Gradient)
    final sweepGradient = SweepGradient(
      startAngle: -math.pi / 2,
      endAngle: 3 * math.pi / 2,
      tileMode: TileMode.clamp,
      colors: [AppColors.primary, AppColors.primary, AppColors.primary],
      stops: const [0.0, 0.5, 1.0],
    );

    final progressPaint = Paint()
      ..shader = sweepGradient.createShader(rect)
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth;

    // Rotate the canvas to start gradient at top (-90 degrees)
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(-math.pi / 2);
    canvas.translate(-center.dx, -center.dy);

    canvas.drawArc(rect, 0, math.pi * 2 * progress, false, progressPaint);
    canvas.restore();

    // 4. 🔹 Floating Head Glow (The 3D "Pop")
    if (progress > 0) {
      final endAngle = (2 * math.pi * progress) - (math.pi / 2);
      final headX = center.dx + radius * math.cos(endAngle);
      final headY = center.dy + radius * math.sin(endAngle);

      // final headShadow = Paint()
      //   ..color = AppColors.primary
      //   ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);

      // canvas.drawCircle(Offset(headX, headY), strokeWidth / 1.5, headShadow);

      final headLight = Paint()..color = Colors.white;
      canvas.drawCircle(Offset(headX, headY), strokeWidth / 3, headLight);
    }
  }

  @override
  bool shouldRepaint(covariant Modern3DCircularProgressPainter oldDelegate) {
    return oldDelegate.progress != progress;
  }
}
