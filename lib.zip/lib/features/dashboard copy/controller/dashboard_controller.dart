import 'package:get/get.dart';

import '../model/dashboard_model.dart';
import '../repository/dashboard_repository.dart';

class DashboardController extends GetxController {
  final DashboardRepository repo = DashboardRepository();

  DashboardController();

  var isLoading = true.obs;
  var dashboard = Rxn<DashboardModel>();

  @override
  void onInit() {
    fetchData();
    super.onInit();
  }

  void fetchData() async {
    isLoading.value = true;
    dashboard.value = await repo.fetchDashboard();
    isLoading.value = false;
  }
}
