class DashboardModel {
  String name;
  int points;
  String level;
  int attendance;

  DashboardModel({
    required this.name,
    required this.points,
    required this.level,
    required this.attendance,
  });

  factory DashboardModel.fromJson(Map<String, dynamic> json) {
    return DashboardModel(
      name: json['name'],
      points: json['points'],
      level: json['level'],
      attendance: json['attendance'],
    );
  }
}