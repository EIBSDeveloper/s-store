import '../model/dashboard_model.dart';

class DashboardRepository {
  Future<DashboardModel> fetchDashboard() async {
    await Future.delayed(const Duration(seconds: 1));

    final response = {
      "name": "Rajesh Kumar",
      "points": 2840,
      "level": "L3",
      "attendance": 96,
    };

    return DashboardModel.fromJson(response);
  }
}
