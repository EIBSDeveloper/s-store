import 'package:elysium_employee/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:hugeicons/hugeicons.dart';

import '../../../../core/app_text_theme.dart';

class IconBox extends StatelessWidget {
  const IconBox({
    super.key,
    required this.icon,
    required this.title,
    required this.onTap,
    this.color,
  });
  final Function()? onTap;
  final List<List<dynamic>> icon;
  final String title;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          InkWell(
            onTap: onTap,
            child: Container(
              decoration: BoxDecoration(
                color: color?.withAlpha(40) ?? AppColors.primary.withAlpha(40),
                // gradient: LinearGradient(
                //   colors: [
                //     AppColors.secondary.withAlpha(50),
                //     AppColors.primary.withAlpha(50),
                //   ],
                // ),
                borderRadius: BorderRadius.circular(10),
              ),
              padding: const EdgeInsets.all(14),
              child: HugeIcon(icon: icon, color: color ?? AppColors.primary),
            ),
          ),
          const SizedBox(height: 5),
          Text(
            title,
            style: AppText.bodySmall.copyWith(fontSize: 10),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
