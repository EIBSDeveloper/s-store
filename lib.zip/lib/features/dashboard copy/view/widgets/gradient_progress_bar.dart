import 'package:flutter/material.dart';

import '../../../../core/app_colors.dart';

class GradientProgressBar extends StatelessWidget {
  final double progress; // 0.0 → 1.0

  const GradientProgressBar({super.key, required this.progress});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 8,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final width = constraints.maxWidth;
          final progressWidth = width * progress;

          return Stack(
            children: [
              // 🔘 Remaining (gray)
              Container(
                width: width,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(20),
                ),
              ),

              // ✅ Static Gradient Progress
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  width: progressWidth,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [AppColors.secondary, AppColors.primary],
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
