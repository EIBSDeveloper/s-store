import 'package:flutter/material.dart';
import 'package:get/get.dart'; 
import '../../../../core/app_colors.dart'; 
import '../../../../core/theme/theme_controller.dart'; 

class ColorEditorBottomSheet extends StatelessWidget {
  const ColorEditorBottomSheet({super.key});

  @override
  Widget build(BuildContext context) {
    final themeController = Get.find<ThemeController>();

    return Obx(
      () => Container(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
        decoration: BoxDecoration(
          color: AppColors.background.withOpacity(0.9),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 20,
              spreadRadius: 5,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Theme Customizer",
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    letterSpacing: -0.5,
                  ),
                ),
                IconButton(
                  onPressed: () => Get.back(),
                  icon: const Icon(Icons.close_rounded),
                  style: IconButton.styleFrom(
                    backgroundColor: Colors.white.withOpacity(0.5),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            _buildSectionTitle("Primary Color"),
            const SizedBox(height: 12),
            _buildColorGrid(
              current: themeController.primaryColor.value,
              onSelect: (color) => themeController.updateColors(primary: color),
              options: [
                const Color(0xffab2b22), // Default
                const Color(0xFF06B6D4), // Blue
                const Color(0xff1976d2), // Blue
                const Color(0xff2e7d32), // Green
                const Color(0xff7b1fa2), // Purple
                const Color(0xfff57c00), // Orange
                const Color(0xff000000), // Black
              ],
            ),

            const SizedBox(height: 24),
            _buildSectionTitle("Secondary Color"),
            const SizedBox(height: 12),
            _buildColorGrid(
              current: themeController.secondaryColor.value,
              onSelect: (color) =>
                  themeController.updateColors(secondary: color),
              options: [
                const Color(0xfffba919), // Default
                const Color(0xff0288d1), // Sky Blue
                const Color(0xff8bc34a), // Lime
                const Color(0xffe91e63), // Pink
                const Color(0xfffbbf24), // Amber
                const Color(0xff607c8a), // Slate
              ],
            ),

            const SizedBox(height: 24),
            _buildSectionTitle("Background Surface"),
            const SizedBox(height: 12),
            _buildColorGrid(
              current: themeController.backgroundColor.value,
              onSelect: (color) =>
                  themeController.updateColors(background: color),
              options: [
                const Color(0xfff0f7ff), // Default
                const Color(0xfffffbf0), // Cream
                const Color(0xfff0fff4), // Mint
                const Color(0xffffffff), // White
                const Color(0xfff5f5f5), // Grey
                const Color(0xff101c22), // Dark
              ],
            ),

            const SizedBox(height: 32),
            Row(
              children: [
                Expanded(
                  child: TextButton.icon(
                    onPressed: () => themeController.resetToDefault(),
                    icon: const Icon(Icons.refresh_rounded, size: 18),
                    label: const Text("Reset to Default"),
                    style: TextButton.styleFrom(
                      foregroundColor: Colors.grey[700],
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                        side: BorderSide(color: Colors.grey[300]!),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title.toUpperCase(),
      style: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w900,
        color: Colors.grey[600],
        letterSpacing: 1.2,
      ),
    );
  }

  Widget _buildColorGrid({
    required Color current,
    required List<Color> options,
    required Function(Color) onSelect,
  }) {
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: options.map((color) {
        // ignore: deprecated_member_use
        final isSelected = current.value == color.value;
        return GestureDetector(
          onTap: () => onSelect(color),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              border: Border.all(
                color: isSelected ? Colors.white : Colors.transparent,
                width: 3,
              ),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.4),
                  blurRadius: isSelected ? 12 : 4,
                  spreadRadius: isSelected ? 2 : 0,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: isSelected
                ? const Icon(Icons.check_rounded, color: Colors.white, size: 20)
                : null,
          ),
        );
      }).toList(),
    );
  }
}
