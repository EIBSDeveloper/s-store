import 'package:elysium_employee/core/app_colors.dart';
import 'package:elysium_employee/core/app_text_theme.dart';
import 'package:elysium_employee/features/dashboard/view/widgets/gradient_progress_bar.dart';
import 'package:elysium_employee/features/dashboard/view/widgets/icon_box.dart';
import 'package:elysium_employee/features/dashboard/view/widgets/glass_card.dart';
import 'package:elysium_employee/widgets/widget_gap.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';

import '../../../attendance/view/widget/check_in_popup.dart';
import '../../../../routes/app_routes.dart';
import '../../controller/dashboard_controller.dart';
import '../../model/dashboard_model.dart';

class DashboardScreen extends GetView<DashboardController> {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Obx(() {
          if (controller.isLoading.value) {
            return const Center(child: CircularProgressIndicator());
          }

          final data = controller.dashboard.value!;

          return SingleChildScrollView(
            padding: const EdgeInsets.only(bottom: 100),
            child: Column(
              children: [
                _HeroCard(data: data),
                const WidgetGap(),
                const _QuickActions(),
                const WidgetGap(),
                const _OverviewSection(),
                const WidgetGap(),
                const _ActivitySection(), const WidgetGap(),
                // const _LeaderboardSection(),
              ],
            ),
          );
        }),
      ),
    );
  }
}

// ============= Hero Card =============

class _HeroCard extends StatelessWidget {
  final DashboardModel data;

  const _HeroCard({required this.data});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      margin: const EdgeInsets.symmetric(horizontal: 10),
      padding: const EdgeInsets.all(10),
      gradientColors: [
        AppColors.secondary.withOpacity(0.3),
        AppColors.primary.withOpacity(0.1),
      ],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                children: [
                  CircleAvatar(
                    radius: 22,
                    backgroundColor: AppColors.primary.withAlpha(40),
                    child: Text(
                      data.name.isNotEmpty ? data.name[0] : "U",
                      style: TextStyle(
                        color: AppColors.primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),

                  // Online indicator
                  Positioned(
                    bottom: 2,
                    right: 2,
                    child: Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        color: Colors.green,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Good Morning", style: TextStyle(fontSize: 10)),
                  Text(
                    data.name,
                    style: TextStyle(
                      color: AppColors.primary,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              Spacer(),
              Container(
                decoration: BoxDecoration(
                  // color: Colors.white,
                  // borderRadius: BorderRadius.circular(6),
                ),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withAlpha(40),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    "MAR",
                    style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                      letterSpacing: .5,
                      color: AppColors.primary,
                    ),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 8),

          // 🔹 Stats Row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(child: _stat("Points", data.points.toString())),
              const SizedBox(width: 10),
              Expanded(child: _stat("Level", data.level)),
              const SizedBox(width: 10),
              Expanded(child: _stat("Attendance", "${data.attendance}%")),
            ],
          ),
        ],
      ),
    );
  }

  Widget _stat(String title, String value) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 5),
        decoration: BoxDecoration(
          color: AppColors.primary.withAlpha(40),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.white12),
        ),
        child: Column(
          children: [
            Text(title, style: const TextStyle(fontSize: 10)),
            const SizedBox(height: 2),
            Text(
              value,
              style: TextStyle(
                color: AppColors.primary,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============= Quick Actions =============
class _QuickActions extends StatelessWidget {
  const _QuickActions();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconBox(
            icon: HugeIcons.strokeRoundedSun01,
            title: "Check In",
            color: Colors.green,
            onTap: () {
              showDialog(
                context: context,
                barrierDismissible: true,
                barrierColor: Colors.transparent,
                builder: (_) => const CheckInPopup(),
              );
            },
          ),
          IconBox(
            icon: HugeIcons.strokeRoundedCalendar02,
            title: "Leave",
            color: Colors.orange,
            onTap: () {},
          ),
          IconBox(
            icon: HugeIcons.strokeRoundedWallet02,
            title: "Payslip",
            color: Colors.blue,
            onTap: () {},
          ),
          IconBox(
            icon: HugeIcons.strokeRoundedMessage02,
            title: "HR Ticket",
            color: Colors.deepPurple,
            onTap: () {},
          ),
          IconBox(
            icon: HugeIcons.strokeRoundedSettings02,
            title: "Security",
            color: Colors.blueGrey,
            onTap: () => Get.toNamed(Routes.securitySettings),
          ),
        ],
      ),
    );
  }
}

// ============= Overview Section =============
class _OverviewSection extends StatelessWidget {
  const _OverviewSection();

  final List<Map<String, dynamic>> _items = const [
    {"title": "Tasks", "value": "7", "sub": "3 due today", "progress": 0.6},
    {
      "title": "This Month",
      "value": "₹48K",
      "sub": "+₹4.2K incentive",
      "progress": 0.85,
    },
    {
      "title": "Leave Balance",
      "value": "8",
      "sub": "days remaining",
      "progress": 0.4,
    },
    {
      "title": "Next Training",
      "value": "Mar 24",
      "sub": "React Advanced",
      "progress": 0.2,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          _header("Overview"),
          const SizedBox(height: 10),
          LayoutBuilder(
            builder: (context, constraints) {
              int crossAxisCount = 2;
              if (constraints.maxWidth >= 1200) {
                crossAxisCount = 5;
              } else if (constraints.maxWidth >= 600) {
                crossAxisCount = 4;
              } else {
                crossAxisCount = 2;
              }
              return GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: 4,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: crossAxisCount,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 1.7,
                ),
                itemBuilder: (context, index) {
                  final data = _items[index];
                  return _OverviewCard(
                    title: data['title'],
                    value: data['value'],
                    sub: data['sub'],
                    progress: data['progress'],
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _header(String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title.toUpperCase(),
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
        ),
        Text(
          "View All",
          style: TextStyle(
            fontSize: 11,
            color: AppColors.primary,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

// ============= Overview Card =============
class _OverviewCard extends StatelessWidget {
  final String title;
  final String value;
  final String sub;
  final double progress;

  const _OverviewCard({
    required this.title,
    required this.value,
    required this.sub,
    required this.progress,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(8),
      margin: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Text(title.toUpperCase(), style: AppText.bodySmall),
          Text(
            value,
            style: AppText.titleLarge.copyWith(fontWeight: FontWeight.bold),
          ),
          Align(
            alignment: AlignmentGeometry.centerRight,
            child: Text(
              sub,
              style: AppText.bodySmall.copyWith(
                color: AppColors.secondary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(height: 8),
          GradientProgressBar(progress: progress),
        ],
      ),
    );
  }
}

// ============= Activity Section =============
class _ActivitySection extends StatelessWidget {
  const _ActivitySection();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          _header("Activity Feed"),
          const SizedBox(height: 10),
          SizedBox(
            height: 30,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                _chip("All", true),
                _chip("Tasks", false),
                _chip("Approvals", false),
                _chip("Announcements", false),
              ],
            ),
          ),
          const SizedBox(height: 10),
          _ActivityItem(
            title: "Leave approved",
            subtitle: "Casual Leave, Mar 18-19 • 2 days",
            status: "Approved",
            icon: HugeIcons.strokeRoundedCalendar02,
            color: Colors.green,
          ),
          _ActivityItem(
            title: "Task assigned",
            subtitle: "Q1 Client Report, by Priya S.",
            status: "Due Today",
            icon: HugeIcons.strokeRoundedStickyNote02,
            color: Colors.orange,
          ),
          _ActivityItem(
            title: "+120 points earned",
            subtitle: "Performance bonus, Mar 15",
            status: "Reward",
            icon: HugeIcons.strokeRoundedQuiz01,
            color: AppColors.primary,
          ),
          const _ActivityItem(
            title: "HR Ticket updated",
            subtitle: "Laptop replacement, #HR-0041",
            status: "In Review",
            icon: HugeIcons.strokeRoundedQuiz02,
            color: Colors.blue,
          ),
        ],
      ),
    );
  }

  Widget _chip(String text, bool selected) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: selected ? AppColors.primary : AppColors.whiteText,

        borderRadius: BorderRadius.circular(8),
      ),
      alignment: Alignment.center,
      child: Text(
        text,
        style: AppText.bodySmall.copyWith(
          color: selected ? Colors.white : AppColors.textDark,
          fontWeight: selected ? FontWeight.bold : FontWeight.normal,
        ),
      ),
    );
  }

  Widget _header(String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title.toUpperCase(),
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
        ),
        Text(
          "View All",
          style: TextStyle(
            fontSize: 11,
            color: AppColors.primary,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

// ============= Activity Item =============
class _ActivityItem extends StatelessWidget {
  final String title;
  final String subtitle;
  final String status;
  final List<List<dynamic>> icon;
  final Color color;

  const _ActivityItem({
    required this.title,
    required this.subtitle,
    required this.status,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 40,
            width: 40,
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withAlpha(40),
              // border: Border.all(width: .4, color: color),
              borderRadius: BorderRadius.circular(10),
            ),

            child: HugeIcon(icon: icon, color: color),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                Text(
                  subtitle,
                  style: const TextStyle(fontSize: 11, color: Colors.grey),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: color.withAlpha(30),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              status,
              style: TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
