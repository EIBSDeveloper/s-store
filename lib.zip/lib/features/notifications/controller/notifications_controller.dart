import 'package:get/get.dart';
import '../model/notification_model.dart';

class NotificationsController extends GetxController {
  var notifications = <NotificationModel>[].obs;
  var isLoading = false.obs;

  @override
  void onInit() {
    super.onInit();
    loadDemoNotifications();
  }

  void loadDemoNotifications() {
    isLoading.value = true;
    
    // Simulate loading/demo data
    final demoData = [
      NotificationModel(
        id: '1',
        title: 'Check-in Successful',
        message: 'You have successfully checked in at 09:00 AM.',
        timestamp: DateTime.now().subtract(const Duration(hours: 5)),
        type: 'attendance',
        isRead: true,
      ),
      NotificationModel(
        id: '2',
        title: 'Meeting Reminder',
        message: 'Team stand-up meeting starts in 15 minutes.',
        timestamp: DateTime.now().subtract(const Duration(hours: 2)),
        type: 'reminder',
      ),
      NotificationModel(
        id: '3',
        title: 'Salary Credited',
        message: 'Your salary for the month of March has been credited.',
        timestamp: DateTime.now().subtract(const Duration(days: 1)),
        type: 'system',
      ),
      NotificationModel(
        id: '4',
        title: 'Upcoming Holiday',
        message: 'Friday is a public holiday celebrating the Spring Festival.',
        timestamp: DateTime.now().subtract(const Duration(days: 2)),
        type: 'system',
        isRead: true,
      ),
      NotificationModel(
        id: '5',
        title: 'Profile Updated',
        message: 'Your profile information was updated successfully.',
        timestamp: DateTime.now().subtract(const Duration(days: 3)),
        type: 'system',
      ),
    ];

    notifications.assignAll(demoData);
    isLoading.value = false;
  }

  void markAsRead(String id) {
    final index = notifications.indexWhere((n) => n.id == id);
    if (index != -1) {
      notifications[index].isRead.value = true;
    }
  }

  void deleteNotification(String id) {
    notifications.removeWhere((n) => n.id == id);
  }

  void markAllAsRead() {
    for (var notification in notifications) {
      notification.isRead.value = true;
    }
  }

  int get unreadCount => notifications.where((n) => !n.isRead.value).length;
}
