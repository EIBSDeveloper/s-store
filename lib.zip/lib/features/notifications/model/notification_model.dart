import 'package:get/get.dart';

class NotificationModel {
  final String id;
  final String title;
  final String message;
  final DateTime timestamp;
  final RxBool isRead;
  final String? type; // e.g., 'attendance', 'system', 'reminder'

  NotificationModel({
    required this.id,
    required this.title,
    required this.message,
    required this.timestamp,
    bool isRead = false,
    this.type,
  }) : isRead = isRead.obs;

  factory NotificationModel.fromJson(Map<String, dynamic> json) {
    return NotificationModel(
      id: json['id'],
      title: json['title'],
      message: json['message'],
      timestamp: DateTime.parse(json['timestamp']),
      isRead: json['isRead'] ?? false,
      type: json['type'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'message': message,
      'timestamp': timestamp.toIso8601String(),
      'isRead': isRead.value,
      'type': type,
    };
  }
}
