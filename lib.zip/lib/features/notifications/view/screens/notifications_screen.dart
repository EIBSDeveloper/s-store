import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:hugeicons/hugeicons.dart';
import '../../../../core/app_colors.dart';
import '../../../../core/app_text_theme.dart';
import '../../../dashboard/view/widgets/glass_card.dart';
import '../../controller/notifications_controller.dart';
import '../../model/notification_model.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(NotificationsController());

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: _buildAppBar(controller),
      body: Column(
        children: [
          _buildFilterChips(controller),

          /// LIST AREA
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return Center(
                  child: CircularProgressIndicator(color: AppColors.primary),
                );
              }

              if (controller.notifications.isEmpty) {
                return _buildEmptyState();
              }

              return ListView.builder(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
                itemCount: controller.notifications.length,
                itemBuilder: (context, index) {
                  final notification = controller.notifications[index];
                  return _buildModernNotificationItem(
                    context,
                    controller,
                    notification,
                  );
                },
              );
            }),
          ),
        ],
      ),
    );
  }

  /// ✅ NORMAL APP BAR (instead of SliverAppBar)
  PreferredSizeWidget _buildAppBar(NotificationsController controller) {
    return AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      leading: IconButton(
        icon: const Icon(
          Icons.arrow_back_ios_new,
          color: Colors.black,
          size: 20,
        ),
        onPressed: () => Get.back(),
      ),
      title: Text(
        'Notifications',
        style: AppText.titleLarge.copyWith(
          color: Colors.black,
          fontWeight: FontWeight.w800,
          fontSize: 20,
        ),
      ),
      actions: [
        IconButton(
          icon: HugeIcon(
            color: AppColors.primary,
            icon: HugeIcons.strokeRoundedTickDouble03,
          ),
          onPressed: () => controller.markAllAsRead(),
        ),
        const SizedBox(width: 8),
      ],
    );
  }

  Widget _buildFilterChips(NotificationsController controller) {
    return Container(
      height: 60,
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        children: [
          _filterChip('All', true),
          _filterChip('Unread', false),
          _filterChip('Attendance', false),
          _filterChip('System', false),
        ],
      ),
    );
  }

  Widget _filterChip(String label, bool isSelected) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: isSelected ? AppColors.primary : Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isSelected ? AppColors.primary : Colors.grey.withOpacity(0.2),
        ),
        boxShadow: isSelected
            ? [
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ]
            : [],
      ),
      alignment: Alignment.center,
      child: Text(
        label,
        style: AppText.bodyMedium.copyWith(
          color: isSelected ? Colors.white : Colors.black87,
          fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildModernNotificationItem(
    BuildContext context,
    NotificationsController controller,
    NotificationModel notification,
  ) {
    return Obx(() {
      final bool isRead = notification.isRead.value;

      return Dismissible(
        key: Key(notification.id),
        direction: DismissDirection.endToStart,
        background: _buildDismissBackground(),
        onDismissed: (direction) =>
            controller.deleteNotification(notification.id),
        child: InkWell(
          onTap: () => controller.markAsRead(notification.id),
          borderRadius: BorderRadius.circular(10),
          child: GlassCard(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(8),
            gradientColors: [
              const Color.fromARGB(255, 255, 255, 255).withOpacity(0.8),
              const Color.fromARGB(255, 255, 255, 255).withOpacity(0.3),
            ],
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildModernIcon(notification.type),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              notification.title,
                              style: AppText.bodyLarge.copyWith(
                                fontWeight: isRead
                                    ? FontWeight.w600
                                    : FontWeight.w800,
                                fontSize: 14,
                                color: Colors.black,
                              ),
                            ),
                          ),
                          if (!isRead)
                            Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: AppColors.primary,
                                shape: BoxShape.circle,
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 3),
                      Text(
                        notification.message,
                        style: AppText.bodySmall.copyWith(
                          color: Colors.black54,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Row(
                        children: [
                          HugeIcon(
                            icon: HugeIcons.strokeRoundedClock01,
                            size: 14,
                            color: Colors.grey,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            _formatTimestamp(notification.timestamp),
                            style: AppText.bodySmall.copyWith(
                              color: Colors.grey[500],
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const Spacer(),
                          Text(
                            'View Details',
                            style: AppText.bodySmall.copyWith(
                              color: AppColors.primary,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          Icon(
                            Icons.arrow_forward_ios,
                            size: 10,
                            color: AppColors.primary,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    });
  }

  Widget _buildModernIcon(String? type) {
    IconData iconData;
    Color iconColor;
    Color bgColor;

    switch (type) {
      case 'attendance':
        iconData = Icons.fingerprint_rounded;
        iconColor = AppColors.green;
        bgColor = AppColors.green.withOpacity(0.12);
        break;
      case 'reminder':
        iconData = Icons.alarm_rounded;
        iconColor = AppColors.tertiary;
        bgColor = AppColors.tertiary.withOpacity(0.12);
        break;
      case 'system':
        iconData = Icons.auto_awesome_rounded;
        iconColor = AppColors.primary;
        bgColor = AppColors.primary.withOpacity(0.12);
        break;
      default:
        iconData = Icons.notifications_active_rounded;
        iconColor = Colors.blue;
        bgColor = Colors.blue.withOpacity(0.12);
    }

    return Container(
      height: 48,
      width: 48,
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Center(child: Icon(iconData, color: iconColor, size: 22)),
    );
  }

  Widget _buildDismissBackground() {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.red[400],
        borderRadius: BorderRadius.circular(16),
      ),
      alignment: Alignment.centerRight,
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: HugeIcon(
        icon: HugeIcons.strokeRoundedDelete02,
        color: Colors.white,
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.05),
              shape: BoxShape.circle,
            ),
            child: HugeIcon(
              icon: HugeIcons.strokeRoundedNotification01,
              size: 80,
              color: AppColors.primary.withOpacity(0.3),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'All caught up!',
            style: AppText.titleLarge.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Text(
            'No notifications to show right now.',
            style: AppText.bodyMedium.copyWith(color: Colors.grey[500]),
          ),
        ],
      ),
    );
  }

  String _formatTimestamp(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else if (difference.inDays < 7) {
      return '${difference.inDays}d ago';
    } else {
      return DateFormat('MMM dd, yyyy').format(timestamp);
    }
  }
}
