import 'package:elysium_employee/routes/app_routes.dart';
import 'package:get/get.dart';
import '../model/task_model.dart';

class TasksController extends GetxController {
  var selectedTab = "All".obs;
  var selectedTask = Rxn<TaskModel>();

  final tasks = <TaskModel>[
    TaskModel(
      title: "QI Client Onboarding Report",
      priority: "• Critical",
      status: "Overdue • ",
      dueDate: "Due March 19 • ",
      tag: "Overdue",
      progressText: "1 day overdue",
      description:
          "Compile and format onboarding report including metrics, blockers & plan.",
      assignedBy: "Rahul",
    ),
    TaskModel(
      title: "API integration - auth module",
      priority: "• High",
      status: "In Progress • ",
      dueDate: "Due today 6:00 PM • ",
      tag: "Today",
      progressText: "In Progress",
      description:
          "Compile and format onboarding report including metrics, blockers & plan.",
      assignedBy: "Rahul",
    ),
    TaskModel(
      title: "Unit tests payment gateway",
      priority: "• Medium",
      status: "In Review • ",
      dueDate: "",
      tag: "Apr 08",
      progressText: "2 Days Left",
      description:
          "Compile and format onboarding report including metrics, blockers & plan.",
      assignedBy: "Rahul",
    ),
    TaskModel(
      title: "Update Design Documentation",
      priority: "• Medium",
      status: "In Review • ",
      dueDate: "",
      tag: "Apr 08",
      progressText: "2 Days Left",
      description:
          "Compile and format onboarding report including metrics, blockers & plan.",
      assignedBy: "Rahul",
    ),
  ].obs;

  void openTask(TaskModel task) {
    selectedTask.value = task;
    Get.toNamed(Routes.taskDetail);
  }
}
