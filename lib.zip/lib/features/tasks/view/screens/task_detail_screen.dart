import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:path/path.dart';
import '../../controller/task_controller.dart';
import '../../../../core/app_colors.dart';

class TaskDetailScreen extends StatelessWidget {
  TaskDetailScreen({super.key});

  final controller = Get.find<TasksController>();

  @override
  Widget build(BuildContext context) {
    final task = controller.selectedTask.value;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(task?.title ?? ""),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),

      body: task == null
          ? const Center(child: Text("No Task Selected"))
          : Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _bgColor(task.tag),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: _borderColor(task.tag),
                        width: 1,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                task.title,
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            _chip(task.status, _statusColor(task.status)),
                          ],
                        ),

                        SizedBox(height: 10),

                        Row(
                          children: [
                            _chip(task.tag, _tagColor(task.tag)),
                            SizedBox(width: 10),
                            _chip(task.priority, _priorityColor(task.priority)),
                          ],
                        ),

                        SizedBox(height: 10),

                        Text(
                          task.description,
                          style: TextStyle(
                            color: AppColors.bottomText,
                            fontWeight: FontWeight.w400,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: 20),

                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.whiteText,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.grey.shade300, width: 1),
                    ),
                    child: Column(
                      children: [
                        _infoRow("Assigned by", task.assignedBy),
                        _infoRow("Due date", task.dueDate, task.status),
                        _infoRow("Priority", task.priority),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  /// ATTACHMENTS TITLE
                  const Text(
                    "Attachments",
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),

                  const SizedBox(height: 10),

                  /// SAMPLE ATTACHMENTS
                  // Row(
                  //   children: [
                  //     _attachment("PDF"),
                  //     const SizedBox(width: 10),
                  //     _attachment("IMG"),
                  //   ],
                  // ),
                  const Spacer(),

                  /// BUTTON
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Colors.indigo, Colors.blue],
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Center(
                      child: Text(
                        "Update Status",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  /// ---------------- COLORS ----------------

  Color _borderColor(String tag) {
    switch (tag) {
      case "Overdue":
        return AppColors.overDue;
      case "Today":
        return AppColors.dueToday;
      default:
        return AppColors.bottomText;
    }
  }

  Color _tagColor(String tag) {
    switch (tag) {
      case "Overdue":
        return AppColors.overDue;
      case "Today":
        return AppColors.dueToday;
      default:
        return AppColors.uploadContent;
    }
  }

  Color _priorityColor(String priority) {
    switch (priority) {
      case "• Critical":
        return AppColors.overDue;
      case "• High":
        return AppColors.dueToday;
      default:
        return AppColors.bottomText;
    }
  }

  Color _statusColor(String status) {
    if (status.contains("Overdue")) {
      return AppColors.overDue;
    } else if (status.contains("In Progress")) {
      return AppColors.dueToday;
    } else {
      return AppColors.bottomText;
    }
  }

  Widget _chip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color),
      ),
      child: Text(text, style: TextStyle(color: color, fontSize: 10)),
    );
  }

  Widget _infoRow(String label, String value, [String? status]) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              color: AppColors.bottomText,
              fontWeight: FontWeight.w400,
              fontSize: 11,
            ),
          ),

          Flexible(
            child: Text(
              _formatValue(value, status),
              textAlign: TextAlign.right,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }

  String _formatValue(String value, String? status) {
    final cleanStatus = status?.replaceAll("•", "").trim() ?? "";

    if (value.isEmpty) return cleanStatus;
    if (cleanStatus.isEmpty) return value;

    return "$value • $cleanStatus";
  }

  Color _bgColor(String tag) {
    switch (tag) {
      case "Overdue":
        return AppColors.overDue.withOpacity(0.08);
      case "Today":
        return AppColors.dueToday.withOpacity(0.08);
      default:
        return AppColors.bottomText.withOpacity(0.08);
    }
  }

  Widget _attachment(String type) {
    return Container(
      width: 50,
      height: 50,
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Center(child: Text(type)),
    );
  }
}
