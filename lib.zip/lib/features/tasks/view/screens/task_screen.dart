import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/app_colors.dart';
import '../../controller/task_controller.dart';

class TasksScreen extends StatelessWidget {
  TasksScreen({super.key});

  final controller = Get.put(TasksController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.whiteText,
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _tab("All"),
                _tab("Tasks"),
                _tab("Approvals"),
                _tab("Announcements"),
              ],
            ),
            SizedBox(height: 15),

            Container(
              margin: EdgeInsets.only(top: 10),
              height: 85,
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.cardBg,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _card(1, "Over Due", AppColors.overDue),
                  VerticalDivider(
                    indent: 15,
                    endIndent: 15,
                    color: AppColors.bottomText,
                  ),
                  _card(2, "Due Today", AppColors.dueToday),
                  VerticalDivider(
                    indent: 15,
                    endIndent: 15,
                    color: AppColors.bottomText,
                  ),
                  _card(5, "On Track", AppColors.onTrack),
                ],
              ),
            ),
            SizedBox(height: 15),

            Expanded(
              child: Obx(() {
                return ListView.builder(
                  itemCount: controller.tasks.length,
                  itemBuilder: (context, index) {
                    final task = controller.tasks[index];

                    return _taskCard(task);
                  },
                );
              }),
            ),
          ],
        ),
      ),
    );
  }

  // TAB
  Widget _tab(String title) {
    return Obx(() {
      final isSelected = controller.selectedTab.value == title;

      return GestureDetector(
        onTap: () => controller.selectedTab.value = title,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
          decoration: BoxDecoration(
            color: isSelected ? AppColors.states : Colors.transparent,
            borderRadius: BorderRadius.circular(20),

            border: Border.all(color: AppColors.priorityText, width: 1),
          ),
          child: Text(
            title,
            style: TextStyle(
              color: AppColors.priorityText,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      );
    });
  }

  Widget _card(int value, String title, Color color) {
    return Column(
      children: [
        Text(
          value.toString(),
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w600,
            color: color,
          ),
        ),
        SizedBox(height: 4),

        Text(
          title,
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w500,
            color: AppColors.bottomText,
          ),
        ),
      ],
    );
  }

  Widget _taskCard(task) {
    return InkWell(
      onTap: () => controller.openTask(task),
      child: Container(
        margin: EdgeInsets.only(bottom: 12),
        padding: EdgeInsets.all(12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _borderColor(task.tag), width: 1),
          color: Colors.white,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    task.title,
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),

                if (task.tag.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: _tagColor(task.tag),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      task.tag,
                      style: TextStyle(
                        fontSize: 10,
                        color: _tagTextColor(task.tag),
                      ),
                    ),
                  ),
              ],
            ),

            SizedBox(height: 5),

            Row(
              children: [
                Text(
                  task.priority,
                  style: TextStyle(
                    color: _priorityColor(task.priority),
                    fontSize: 12,
                  ),
                ),
                Spacer(),

                Text(
                  task.tag == "Overdue" || task.tag == "Today"
                      ? task.dueDate
                      : task.status,
                  style: TextStyle(fontSize: 11, color: AppColors.deadLine),
                ),

                Text(
                  task.progressText,
                  style: TextStyle(fontSize: 11, color: AppColors.deadLine),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Color _borderColor(String tag) {
    switch (tag) {
      case "Overdue":
        return AppColors.overDue;
      case "Today":
        return AppColors.dueToday;
      default:
        return AppColors.bottomText;
    }
  }

  static Color _priorityColor(String priority) {
    switch (priority) {
      case "• Critical":
        return AppColors.overDue;
      case "• High":
        return AppColors.dueToday;
      default:
        return AppColors.bottomText;
    }
  }

  Color _tagTextColor(String tag) {
    switch (tag) {
      case "Overdue":
        return AppColors.overDue;
      case "Today":
        return AppColors.dueToday;
      default:
        return AppColors.uploadContent;
    }
  }

  static Color _tagColor(String tag) {
    switch (tag) {
      case "Overdue":
        return AppColors.overDueBorder;
      case "Today":
        return AppColors.dueTodayBorder;
      default:
        return AppColors.mediumTag;
    }
  }
}
