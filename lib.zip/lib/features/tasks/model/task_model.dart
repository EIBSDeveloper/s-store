class TaskModel {
  final String title;
  final String priority;
  final String status;
  final String dueDate;
  final String tag;
  final String progressText;
  final String description;
  final String assignedBy;

  TaskModel({
    required this.title,
    required this.priority,
    required this.status,
    required this.dueDate,
    required this.tag,
    required this.progressText,
    required this.description,
    required this.assignedBy,
  });
}
