import 'package:elysium_employee/features/hr_ticket/model/raise_new_ticket_model.dart';
import 'package:get/get.dart';

import '../../../core/app_colors.dart';

class RaiseNewTicketController extends GetxController {
  var selectedCategory = Rxn<RaiseNewTicketModel>();

  var subject = ''.obs;
  var description = ''.obs;
  var priority = 'High'.obs;

  void selectPriority(String value) {
    priority.value = value;
  }

  final categories = <RaiseNewTicketModel>[
    RaiseNewTicketModel(
      id: "1",
      title: "Payroll query",
      image: "assets/icons/payroll.png",
      color: AppColors.payroll,

      iconBg: AppColors.whiteText,
    ),
    RaiseNewTicketModel(
      id: "2",
      title: "Promotion /\nRole change",
      image: "assets/icons/Promotion.png",
      color: AppColors.promotion,
      iconBg: AppColors.whiteText,
    ),
    RaiseNewTicketModel(
      id: "3",
      title: "Policy query",
      image: "assets/icons/policy.png",
      color: AppColors.policy,
      iconBg: AppColors.whiteText,
    ),
    RaiseNewTicketModel(
      id: "4",
      title: "Grievance",
      color: AppColors.grievance,
      image: "assets/icons/grievance.png",
      iconBg: AppColors.whiteText,
    ),
    RaiseNewTicketModel(
      id: "5",
      title: "Document request",
      color: AppColors.payroll,
      image: "assets/icons/document.png",
      iconBg: AppColors.whiteText,
    ),
    RaiseNewTicketModel(
      id: "6",
      title: "Asset request",
      color: AppColors.promotion,
      image: "assets/icons/asset.png",
      iconBg: AppColors.whiteText,
    ),
  ];

  void selectCategory(RaiseNewTicketModel category) {
    selectedCategory.value = category;
  }
}
