import 'package:elysium_employee/features/hr_ticket/model/view_ticket_model.dart';
import 'package:elysium_employee/features/hr_ticket/view/screens/view_tickets/rating_ticket.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../core/app_colors.dart';

class ViewTicketController extends GetxController {
  var ticketStatus = "submitted".obs;

  final expandedIndex = (-1).obs;

  void toggleExpand(int index) {
    expandedIndex.value = expandedIndex.value == index ? -1 : index;
  }

  Color getResolutionColor() {
    final time = resolutionTime.value;

    int hours = 0;
    int minutes = 0;

    final hourMatch = RegExp(r'(\d+)h').firstMatch(time);
    final minMatch = RegExp(r'(\d+)m').firstMatch(time);

    if (hourMatch != null) {
      hours = int.parse(hourMatch.group(1)!);
    }

    if (minMatch != null) {
      minutes = int.parse(minMatch.group(1)!);
    }

    final totalHours = hours + (minutes / 60);

    if (totalHours <= 24) {
      return AppColors.active;
    } else {
      return AppColors.danger;
    }
  }

  final ticketId = "#HR-0041".obs;
  final title = "March payslip discrepancy".obs;
  final category = "Payroll Query".obs;
  final assignedTeam = "Payroll".obs;
  final sla = "24 Hrs".obs;
  final resolutionTime = "5h 53m • Within SLA".obs;
  final isResolved = true.obs;

  final List<ViewTicketModel> step = [
    ViewTicketModel(
      id: "submitted",
      title: "Ticket submitted",
      time: "Mar 20 • 9:05 AM",
      isDone: true,
      messages: [
        "My Q4 incentive of ₹4,200 was approved on March 15, but is missing from my March payslip net amount. Please check..",
      ],
    ),
    ViewTicketModel(
      id: "respond",
      title: "HR Responds",
      time: "Mar 20 • 9:42 AM",
      isDone: true,
      messages: [
        "Rajesh, I’ve received your ticket Let check the payroll run for March with the finance team. Will update you within 4 hours.",
      ],
    ),
    ViewTicketModel(
      id: "resolved",
      title: "Ticket Resolved",
      time: "Mar 20 • 2:28 PM",
      isDone: true,
      messages: [
        "Update: I found the issue — the incentive was approved after the payroll cut-off date of Mar 14. It will be credited in April payslip I'll attach the confirmation note",
      ],
    ),
  ];

  final steps = <ViewTicketModel>[].obs;

  void loadStepsByStatus(String status) {
    ticketStatus.value = status;
    expandedIndex.value = -1;

    int doneCount = status == "submitted"
        ? 1
        : status == "in_review"
        ? 2
        : step.length;

    steps.assignAll(
      step.asMap().entries.map((entry) {
        final index = entry.key;
        final item = entry.value;

        return item.copyWith(isDone: index < doneCount);
      }).toList(),
    );
  }

  void changeStatus(String status) {
    loadStepsByStatus(status);
  }

  @override
  void onInit() {
    super.onInit();
    loadStepsByStatus("submitted");
  }

  final rating = 0.obs;
  final commentController = TextEditingController();

  void openRatingSheet(BuildContext context) {
    Get.bottomSheet(
      RatingTicketScreen(controller: .new()),
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
    );
  }
}
