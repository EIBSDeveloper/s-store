import 'package:get/get.dart';

class HrTicketController extends GetxController{
  
}