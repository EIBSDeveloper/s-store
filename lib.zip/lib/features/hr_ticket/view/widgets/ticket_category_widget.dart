import 'package:elysium_employee/features/hr_ticket/view/screens/rise_new_ticket/issue_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../controller/raise_new_ticket_controller.dart';
import '../../model/raise_new_ticket_model.dart';

class TicketCategoryWidget extends StatelessWidget {
  final RaiseNewTicketModel category;

  const TicketCategoryWidget({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<RaiseNewTicketController>();

    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () {
        controller.selectCategory(category);
        Get.to(() => IssueScreen());
      },

      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: category.color,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: category.iconBg,
              child: Padding(
                padding: const EdgeInsets.all(6),
                child: Image.asset(category.image),
              ),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  category.title,
                  textAlign: TextAlign.right,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
