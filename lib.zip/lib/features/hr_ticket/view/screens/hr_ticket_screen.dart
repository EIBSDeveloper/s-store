import 'package:elysium_employee/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../core/app_colors.dart';
import '../../controller/view_ticket_controller.dart';
import 'view_tickets/ticket_detail_screen.dart';

class HrTicketScreen extends StatelessWidget {
  HrTicketScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(ViewTicketController());
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.only(top: 10),
                height: 100,
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.cardBg,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _card(1, "Submitted", AppColors.openCount),
                    VerticalDivider(
                      indent: 15,
                      endIndent: 15,
                      color: AppColors.bottomText,
                    ),
                    _card(2, "In Review", AppColors.inReview),
                    VerticalDivider(
                      indent: 15,
                      endIndent: 15,
                      color: AppColors.bottomText,
                    ),
                    _card(5, "Resolved", AppColors.resolved),
                  ],
                ),
              ),
              SizedBox(height: 10),

              Text(
                "My Tickets",
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: AppColors.bottomText,
                ),
              ),
              SizedBox(height: 20),

              Column(
                children: [
                  ticketItem(
                    onTap: () {
                      controller.loadStepsByStatus("submitted");
                      Get.to(() => TicketDetailsScreen());
                    },
                    title: "Laptop Replacement",
                    subtitle: "IT Support • Submitted Mar 18",
                    statusText: "Submitted",
                    icon: Icons.schedule,
                    iconColor: AppColors.myTicopenIcon,
                    iconBg: AppColors.myTicOpeniconBg,
                    statusBg: AppColors.myTicOpen,
                    statusTextColor: AppColors.myTicOpenText,
                  ),
                  SizedBox(height: 15),
                  ticketItem(
                    onTap: () {
                      controller.loadStepsByStatus("in_review");
                      Get.to(() => TicketDetailsScreen());
                    },
                    title: "March payslip",
                    subtitle: "Payroll Query • Submitted Mar 25",
                    statusText: "In Review",
                    icon: Icons.assignment_late_outlined,
                    iconColor: AppColors.myTicInReviewIcon,
                    iconBg: AppColors.myTicInReviewIconBg,
                    statusBg: AppColors.myTicInReviewBg,
                    statusTextColor: AppColors.myTicInReviewText,
                  ),

                  SizedBox(height: 15),
                  ticketItem(
                    onTap: () {
                      controller.loadStepsByStatus("in_review");
                      Get.to(() => TicketDetailsScreen());
                    },
                    title: "March payslip",
                    subtitle: "Payroll Query • Submitted Mar 25",
                    statusText: "In Review",
                    icon: Icons.assignment_late_outlined,
                    iconColor: AppColors.myTicInReviewIcon,
                    iconBg: AppColors.myTicInReviewIconBg,
                    statusBg: AppColors.myTicInReviewBg,
                    statusTextColor: AppColors.myTicInReviewText,
                  ),

                  SizedBox(height: 15),

                  ticketItem(
                    onTap: () {
                      controller.loadStepsByStatus("submitted");
                      Get.to(() => TicketDetailsScreen());
                    },
                    title: "Laptop Replacement",
                    subtitle: "IT Support • Submitted Mar 18",
                    statusText: "Submitted",
                    icon: Icons.schedule,
                    iconColor: AppColors.myTicopenIcon,
                    iconBg: AppColors.myTicOpeniconBg,
                    statusBg: AppColors.myTicOpen,
                    statusTextColor: AppColors.myTicOpenText,
                  ),

                  SizedBox(height: 15),
                  ticketItem(
                    onTap: () {
                      controller.loadStepsByStatus("in_review");
                      Get.to(() => TicketDetailsScreen());
                    },
                    title: "March payslip",
                    subtitle: "Payroll Query • Submitted Mar 25",
                    statusText: "In Review",
                    icon: Icons.assignment_late_outlined,
                    iconColor: AppColors.myTicInReviewIcon,
                    iconBg: AppColors.myTicInReviewIconBg,
                    statusBg: AppColors.myTicInReviewBg,
                    statusTextColor: AppColors.myTicInReviewText,
                  ),
                  SizedBox(height: 15),

                  ticketItem(
                    onTap: () {
                      controller.loadStepsByStatus("resolved");
                      Get.to(() => TicketDetailsScreen());
                    },
                    title: "Work from Home Req...",
                    subtitle: "Payroll Query • Submitted Mar 25",
                    statusText: "Resolved",
                    icon: Icons.check,
                    iconColor: AppColors.myTicResolvedIcon,
                    iconBg: AppColors.myTicResolvedIconBg,
                    statusBg: AppColors.myTicResolvedBg,
                    statusTextColor: AppColors.myTicResolvedText,
                  ),

                  SizedBox(height: 15),

                  ticketItem(
                    onTap: () {
                      controller.loadStepsByStatus("resolved");
                      Get.to(() => TicketDetailsScreen());
                    },
                    title: "Work from Home Req...",
                    subtitle: "Payroll Query • Submitted Mar 25",
                    statusText: "Resolved",
                    icon: Icons.check,
                    iconColor: AppColors.myTicResolvedIcon,
                    iconBg: AppColors.myTicResolvedIconBg,
                    statusBg: AppColors.myTicResolvedBg,
                    statusTextColor: AppColors.myTicResolvedText,
                  ),

                  SizedBox(height: 15),

                  ticketItem(
                    onTap: () {
                      controller.loadStepsByStatus("resolved");
                      Get.to(() => TicketDetailsScreen());
                    },
                    title: "Work from Home Req...",
                    subtitle: "Payroll Query • Submitted Mar 25",
                    statusText: "Resolved",
                    icon: Icons.check,
                    iconColor: AppColors.myTicResolvedIcon,
                    iconBg: AppColors.myTicResolvedIconBg,
                    statusBg: AppColors.myTicResolvedBg,
                    statusTextColor: AppColors.myTicResolvedText,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(right: 5, bottom: 55),
        child: GestureDetector(
          onTap: () => Get.toNamed(Routes.raiseNewTicket),
          child: Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [AppColors.buttonTop, AppColors.buttonBottom],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Icon(Icons.add, color: Colors.white, size: 30),
          ),
        ),
      ),
    );
  }
}

Widget _card(int value, String title, Color color) {
  return Column(
    children: [
      Text(
        value.toString(),
        style: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.w600,
          color: color,
        ),
      ),
      SizedBox(height: 4),

      Text(
        title,
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w500,
          color: AppColors.bottomText,
        ),
      ),
    ],
  );
}

Widget ticketItem({
  required VoidCallback onTap,
  required String title,
  required String subtitle,
  required String statusText,
  required IconData icon,
  required Color iconColor,
  required Color iconBg,
  required Color statusBg,
  required Color statusTextColor,
}) {
  return InkWell(
    onTap: onTap,
    child: Row(
      children: [
        Container(
          padding: const EdgeInsets.all(5),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            color: iconBg,
          ),
          child: Icon(icon, color: iconColor),
        ),

        const SizedBox(width: 15),

        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 5),
            Text(
              subtitle,
              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500),
            ),
          ],
        ),

        const Spacer(),

        Container(
          padding: const EdgeInsets.all(5),
          decoration: BoxDecoration(
            color: statusBg,
            borderRadius: BorderRadius.circular(5),
          ),
          child: Text(
            statusText,
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w500,
              color: statusTextColor,
            ),
          ),
        ),
      ],
    ),
  );
}
