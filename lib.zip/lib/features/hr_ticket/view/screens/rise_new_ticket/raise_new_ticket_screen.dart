import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../../core/app_colors.dart';
import '../../../controller/raise_new_ticket_controller.dart';
import '../../widgets/ticket_category_widget.dart';

class RaiseTicketView extends StatelessWidget {
  const RaiseTicketView({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(RaiseNewTicketController());

    return Scaffold(
      backgroundColor: AppColors.whiteText,
      appBar: AppBar(
        title: Text(
          "Raise New Ticket",
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: AppColors.bottomText,
          ),
        ),
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Icon(Icons.notifications_none),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.infoBar,
                border: BoxBorder.all(color: AppColors.infoBarBorder),
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Row(
                children: [
                  Expanded(
                    child: Text(
                      "Choose the category that best describes your issue. It \ndetermines which HR team handles your ticket.",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        color: AppColors.bottomText,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            Expanded(
              child: GridView.builder(
                itemCount: controller.categories.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 14,
                  mainAxisSpacing: 14,
                  childAspectRatio: 1.7,
                ),
                itemBuilder: (_, index) {
                  return TicketCategoryWidget(
                    category: controller.categories[index],
                  );
                },
              ),
            ),
            // Spacer(),
            // Padding(
            //   padding: const EdgeInsets.all(15.0),
            //   child: SizedBox(
            //     width: double.infinity,
            //     child: Container(
            //       decoration: BoxDecoration(
            //         gradient: LinearGradient(
            //           colors: [AppColors.buttonTop, AppColors.buttonBottom],
            //           begin: Alignment.topLeft,
            //           end: Alignment.bottomRight,
            //         ),
            //         borderRadius: BorderRadius.circular(10),
            //       ),
            //       child: ElevatedButton(
            //         onPressed: () {},
            //         style: ElevatedButton.styleFrom(
            //           backgroundColor: Colors.transparent,
            //           shadowColor: Colors.transparent,
            //           padding: const EdgeInsets.symmetric(vertical: 14),
            //           shape: RoundedRectangleBorder(
            //             borderRadius: BorderRadius.circular(10),
            //           ),
            //         ),
            //         child: Text(
            //           "Next",
            //           style: TextStyle(
            //             fontSize: 16,
            //             fontWeight: FontWeight.bold,
            //             color: Colors.white,
            //           ),
            //         ),
            //       ),
            //     ),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }
}
