import 'package:dotted_border/dotted_border.dart';
import 'package:elysium_employee/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../../core/app_colors.dart';
import '../../../controller/raise_new_ticket_controller.dart';

class IssueScreen extends StatelessWidget {
  const IssueScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<RaiseNewTicketController>();

    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Describe your issue",
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: AppColors.bottomText,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.category,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Obx(() {
                final category = controller.selectedCategory.value;

                return Column(
                  children: [
                    _row("Category", category?.title ?? ""),
                    Divider(),
                    _row("Assigned Team", "Payroll"),
                    Divider(),
                    _row("Response SLA", "24 Hrs"),
                  ],
                );
              }),
            ),

            SizedBox(height: 16),

            Text(
              "Subject",
              style: TextStyle(
                color: AppColors.issueText,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(height: 6),
            TextField(
              onChanged: (val) => controller.subject.value = val,
              decoration: _inputDecoration(
                "March payslip — Incentive not Reflected",
              ),
            ),

            SizedBox(height: 16),

            Text(
              "Description",
              style: TextStyle(
                color: AppColors.issueText,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(height: 6),
            TextField(
              maxLines: 4,
              onChanged: (val) => controller.description.value = val,
              decoration: _inputDecoration("Describe your issue"),
            ),

            SizedBox(height: 16),

            Text(
              "Priority",
              style: TextStyle(
                color: AppColors.issueText,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(height: 8),

            Obx(
              () => Row(
                children: [
                  "Urgent",
                  "High",
                  "Normal",
                ].map((p) => _priorityButton(controller, p)).toList(),
              ),
            ),

            SizedBox(height: 20),

            DottedBorder(
              // borderType: BorderType.RRect,
              // radius: Radius.circular(10),
              // dashPattern: [6, 6],
              // color: AppColors.uploadBorder,
              // strokeWidth: 2,
              options: RectDottedBorderOptions(
                dashPattern: [10, 5],
                color: AppColors.uploadBorder,
                strokeWidth: 2,
                padding: EdgeInsets.all(10),
              ),
              child: InkWell(
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  height: 60,
                  padding: EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(color: AppColors.uploadFill),
                  alignment: Alignment.center,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.upload_file_outlined,
                        color: AppColors.uploadContent,
                      ),
                      SizedBox(width: 8),
                      Text(
                        "Upload Screenshot or Document",
                        style: TextStyle(
                          color: AppColors.uploadContent,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: 35),
            Padding(
              padding: const EdgeInsets.all(25.0),
              child: SizedBox(
                width: double.infinity,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [AppColors.buttonTop, AppColors.buttonBottom],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ElevatedButton(
                    onPressed: () => Get.toNamed(Routes.submitTicket),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      shadowColor: Colors.transparent,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: Text(
                      "Submit Ticket",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _row(String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: TextStyle(
              color: AppColors.issueText,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              color: AppColors.bottomText,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  InputDecoration _inputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      filled: true,
      fillColor: AppColors.subjectTextArea,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide.none,
      ),
    );
  }

  Widget _priorityButton(RaiseNewTicketController controller, String label) {
    final isSelected = controller.priority.value == label;

    return Expanded(
      child: GestureDetector(
        onTap: () => controller.selectPriority(label),
        child: Container(
          margin: EdgeInsets.only(right: 8),
          padding: EdgeInsets.symmetric(vertical: 20),
          decoration: BoxDecoration(
            color: isSelected ? AppColors.priorityFill : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: AppColors.priorityBorder),
          ),
          child: Center(
            child: Text(
              label,
              style: TextStyle(
                color: AppColors.priorityText,
                fontWeight: FontWeight.w500,
                fontSize: 12,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
