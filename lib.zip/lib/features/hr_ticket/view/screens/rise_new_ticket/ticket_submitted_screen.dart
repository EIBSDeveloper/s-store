import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../../core/app_colors.dart';
import '../../../../../routes/app_routes.dart';

class TicketSubmittedScreen extends StatelessWidget {
  const TicketSubmittedScreen({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(title: Text("Ticket Submission")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.category,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  Image.asset(
                    "assets/gif/ticket_submitted.gif",
                    height: 100,
                    width: 100,
                    alignment: AlignmentGeometry.topCenter,
                  ),

                  SizedBox(height: 10),

                  Text(
                    "Monday • April 06 • 2026",
                    style: TextStyle(
                      fontSize: 11,
                      color: AppColors.issueText,
                      fontWeight: FontWeight.w500,
                    ),
                  ),

                  const SizedBox(height: 6),

                  const Text(
                    "Ticket submitted!",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                      color: AppColors.bottomText,
                    ),
                  ),

                  const SizedBox(height: 4),

                  const Text(
                    "#HR-0041",
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: AppColors.bottomText,
                    ),
                  ),

                  SizedBox(height: 6),

                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.myTicOpen,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      "Submitted",
                      style: TextStyle(
                        fontSize: 12,
                        color: AppColors.myTicOpenText,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            SizedBox(height: 20),

            // Align(
            //   alignment: Alignment.centerLeft,
            //   child: Text(
            //     "Resolution Steps",
            //     style: TextStyle(
            //       fontSize: 12,
            //       color: AppColors.bottomText,
            //       fontWeight: FontWeight.w500,
            //     ),
            //   ),
            // ),

            // SizedBox(height: 10),

            // Obx(
            //   () => Column(
            //     children: controller.ticketStatus.map((step) {
            //       return _timelineItem(
            //         title: step["title"].toString(),
            //         time: step["time"].toString(),
            //         isDone: step["done"] as bool,
            //       );
            //     }).toList(),
            //   ),
            // ),
            Spacer(),

            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  Expanded(
                    child: _gradientButton(
                      text: "Back to HR",
                      textcolor: AppColors.whiteText,
                      onTap: () {
                        Get.back();
                        Get.back();
                        Get.back();
                      },
                      colors: [AppColors.buttonTop, AppColors.buttonBottom],
                    ),
                  ),

                  const SizedBox(width: 12),
                  Expanded(
                    child: _gradientButton(
                      text: "View Ticket",
                      textcolor: AppColors.bottomText,
                      onTap: () {
                        Get.back();
                        Get.back();
                        Get.back();
                        Get.toNamed(Routes.viewTicket);
                      },
                      colors: [
                        AppColors.viewTicketBtn,
                        AppColors.viewTicketBtn,
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Widget _timelineItem({
  //   required String title,
  //   required String time,
  //   required bool isDone,
  // }) {
  //   return Row(
  //     crossAxisAlignment: CrossAxisAlignment.start,
  //     children: [
  //       Column(
  //         children: [
  //           Icon(
  //             Icons.circle,
  //             size: 14,
  //             color: isDone ? AppColors.active : AppColors.uploadBorder,
  //           ),
  //           Container(width: 1, height: 40, color: AppColors.uploadBorder),
  //         ],
  //       ),
  //       const SizedBox(width: 10),
  //       Expanded(
  //         child: Padding(
  //           padding: const EdgeInsets.only(bottom: 16),
  //           child: Column(
  //             crossAxisAlignment: CrossAxisAlignment.start,
  //             children: [
  //               Text(
  //                 title,
  //                 style: TextStyle(
  //                   fontWeight: FontWeight.w600,
  //                   fontSize: 15,
  //                   color: AppColors.bottomText,
  //                 ),
  //               ),
  //               SizedBox(height: 2),
  //               Text(
  //                 time,
  //                 style: const TextStyle(
  //                   fontSize: 11,
  //                   color: AppColors.uploadBorder,
  //                   fontWeight: FontWeight.w500,
  //                 ),
  //               ),
  //             ],
  //           ),
  //         ),
  //       ),
  //     ],
  //   );
  // }

  Widget _gradientButton({
    required String text,
    required VoidCallback onTap,
    required List<Color> colors,
    required Color textcolor,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: colors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(10),
      ),
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: textcolor,
          ),
        ),
      ),
    );
  }
}
