import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../controller/view_ticket_controller.dart';
import '../../../../../core/app_colors.dart';

class TicketDetailsScreen extends StatelessWidget {
  const TicketDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(ViewTicketController());

    return Scaffold(
      appBar: AppBar(
        title: Obx(
          () => Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    controller.ticketId.value,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: AppColors.bottomText,
                    ),
                  ),
                  Text(
                    controller.title.value,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: AppColors.issueText,
                    ),
                  ),
                ],
              ),
              Spacer(),
              _statusChip(controller.ticketStatus.value),
            ],
          ),
        ),
      ),

      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.category,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  _row("Category", controller.category.value),
                  Divider(),
                  _row("Assigned Team", controller.assignedTeam.value),
                  Divider(),
                  _row("Response SLA", controller.sla.value),
                  Divider(),
                  Obx(
                    () => Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Resolution time",
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            color: AppColors.issueText,
                          ),
                        ),
                        Text(
                          controller.resolutionTime.value,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: controller.getResolutionColor(),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            SizedBox(height: 20),

            Obx(() {
              return Column(
                children: List.generate(controller.steps.length, (index) {
                  final step = controller.steps[index];

                  return _timelineItem(
                    key: GlobalKey(),
                    index: index,
                    title: step.title,
                    time: step.time,
                    isDone: step.isDone,
                    messages: step.messages,
                    isLast: index == controller.steps.length - 1,
                    controller: controller,
                  );
                }),
              );
            }),

            SizedBox(height: 30),

            Obx(() {
              if (controller.ticketStatus.value != "resolved") {
                return SizedBox();
              }

              return Row(
                children: [
                  Expanded(
                    child: _gradientButton(
                      text: "Rate & Close",
                      textcolor: AppColors.whiteText,
                      onTap: () {
                        controller.openRatingSheet(context);
                      },
                      colors: [AppColors.buttonTop, AppColors.buttonBottom],
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: _gradientButton(
                      text: "Reopen Ticket",
                      textcolor: AppColors.bottomText,
                      onTap: () {},
                      colors: [
                        AppColors.viewTicketBtn,
                        AppColors.viewTicketBtn,
                      ],
                    ),
                  ),
                ],
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _row(String text, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            text,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w500,
              color: AppColors.issueText,
            ),
          ),
          Text(
            value.isEmpty ? "-" : value,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: AppColors.bottomText,
            ),
          ),
        ],
      ),
    );
  }

  Widget _statusChip(String status) {
    Color bgColor;
    Color textColor;

    if (status == "submitted") {
      bgColor = AppColors.myTicOpen;
      textColor = AppColors.myTicOpenText;
    } else if (status == "in_review") {
      bgColor = AppColors.myTicInReviewBg;
      textColor = AppColors.myTicInReviewText;
    } else {
      bgColor = AppColors.myTicResolvedBg;
      textColor = AppColors.myTicResolvedText;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        status.replaceAll("_", " ").toUpperCase(),
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w600,
          color: textColor,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  Widget _timelineItem({
    required GlobalKey key,
    required int index,
    required String title,
    required String time,
    required bool isDone,
    required List<String> messages,
    required bool isLast,
    required ViewTicketController controller,
  }) {
    return Obx(() {
      final isExpanded = controller.expandedIndex.value == index;

      return IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Column(
              children: [
                Icon(
                  Icons.circle,
                  size: 14,
                  color: isDone ? AppColors.active : AppColors.uploadBorder,
                ),
                if (!isLast)
                  Expanded(
                    child: Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                        width: 1,
                        height: double.infinity,
                        color: AppColors.uploadBorder,
                      ),
                    ),
                  ),
              ],
            ),

            SizedBox(width: 10),

            Expanded(
              child: Padding(
                padding: EdgeInsets.only(bottom: 16),
                child: Column(
                  children: [
                    InkWell(
                      onTap: () => controller.toggleExpand(index),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                title,
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 15,
                                  color: AppColors.bottomText,
                                ),
                              ),
                              SizedBox(width: 8),

                              Expanded(
                                child: Divider(
                                  color: AppColors.uploadBorder,
                                  thickness: 1,
                                ),
                              ),

                              Icon(
                                isExpanded
                                    ? Icons.keyboard_arrow_up
                                    : Icons.keyboard_arrow_down,
                              ),
                            ],
                          ),

                          Text(
                            time,
                            style: TextStyle(
                              fontSize: 11,
                              color: AppColors.uploadBorder,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),

                    if (isExpanded && isDone && messages.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          constraints: const BoxConstraints(maxWidth: 300),
                          decoration: BoxDecoration(
                            color: Colors.grey.shade200,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: messages.map((msg) {
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 6),
                                child: Text(
                                  msg,
                                  style: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w400,
                                    color: AppColors.bottomText,
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    });
  }

  Widget _gradientButton({
    required String text,
    required VoidCallback onTap,
    required List<Color> colors,
    required Color textcolor,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: colors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(10),
      ),
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: textcolor,
          ),
        ),
      ),
    );
  }
}
