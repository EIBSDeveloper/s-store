class ViewTicketModel {
  final String id;
  final String title;
  final String time;
  final bool isDone;
  final List<String> messages;

  ViewTicketModel({
    required this.id,
    required this.title,
    required this.time,
    required this.isDone,
    required this.messages,
  });

  ViewTicketModel copyWith({
    String? id,
    String? title,
    String? time,
    bool? isDone,
   List<String>? messages,
  }) {
    return ViewTicketModel(
      id: id ?? this.id,
      title: title ?? this.title,
      time: time ?? this.time,
      isDone: isDone ?? this.isDone,
      messages: messages ?? this.messages,
    );
  }
}
class TicketMessage {
  final String text;
  final bool isSender; 

  TicketMessage({
    required this.text,
    required this.isSender,
  });
}
