import 'package:flutter/material.dart';

class RaiseNewTicketModel {
  final String id;
  final String title;
  final String image;
  final Color color;
  final Color iconBg;

  RaiseNewTicketModel({
    required this.id,
    required this.title,
    required this.image,
    required this.color,
    required this.iconBg,
  });
}