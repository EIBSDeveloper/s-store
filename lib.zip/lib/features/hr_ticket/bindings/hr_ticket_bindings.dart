import 'package:elysium_employee/features/hr_ticket/controller/hr_ticket_controller.dart';
import 'package:get/get.dart';

class HrTicketBindings extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => HrTicketController());
  }
}
