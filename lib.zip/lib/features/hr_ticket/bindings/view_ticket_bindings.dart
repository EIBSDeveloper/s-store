import 'package:get/get.dart';

import '../controller/view_ticket_controller.dart';

class ViewTicketBindings extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ViewTicketController>(() => ViewTicketController());
  }
}