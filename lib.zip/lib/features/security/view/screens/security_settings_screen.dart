import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/app_colors.dart';
import '../../../../core/app_style.dart';
import '../../../../core/app_text_theme.dart';
import '../../controllers/security_controller.dart';

class SecuritySettingsScreen extends GetView<SecurityController> {
  const SecuritySettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F6F8),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: AppColors.primary, size: 20),
          onPressed: () => Get.back(),
        ),
        title: Text(
          "Security Settings",
          style: AppText.titleLarge.copyWith(fontWeight: FontWeight.bold, color: AppColors.primary),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            const SizedBox(height: 30),
            _buildSecurityOptions(),
            const SizedBox(height: 30),
            _buildPinSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: AppStyle.decoration.copyWith(
        gradient: LinearGradient(
          colors: [AppColors.primary.withOpacity(0.8), AppColors.secondary.withOpacity(0.8)],
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.shield_outlined,
              color: Colors.white,
              size: 30,
            ),
          ),
          const SizedBox(width: 15),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "App Protection",
                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                ),
                Text(
                  "Secure your data with PIN and Biometrics",
                  style: TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSecurityOptions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 5, bottom: 10),
          child: Text("AUTHENTICATION", style: AppText.bodySmall.copyWith(letterSpacing: 1.2, fontWeight: FontWeight.bold, color: Colors.grey)),
        ),
        Container(
          decoration: AppStyle.decoration,
          child: Column(
            children: [
              Obx(() => _buildToggleItem(
                icon: Icons.fingerprint,
                title: "Touch ID / Face ID",
                subtitle: "Unlock app using biometrics",
                value: controller.isFingerprintEnabled.value,
                onChanged: controller.canCheckBiometrics.value 
                  ? (val) => controller.toggleFingerprint(val)
                  : null,
                enabled: controller.canCheckBiometrics.value,
              )),
              const Divider(height: 1, indent: 60),
              Obx(() => _buildToggleItem(
                icon: Icons.lock_outline,
                title: "PIN Lock",
                subtitle: "Requires PIN to unlock app",
                value: controller.isPinEnabled.value,
                onChanged: (val) => controller.togglePin(val),
              )),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPinSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 5, bottom: 10),
          child: Text("PIN MANAGEMENT", style: AppText.bodySmall.copyWith(letterSpacing: 1.2, fontWeight: FontWeight.bold, color: Colors.grey)),
        ),
        Container(
          decoration: AppStyle.decoration,
          child: ListTile(
            onTap: () => _showSetPinDialog(),
            leading: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
              child: Icon(Icons.lock_person_outlined, color: AppColors.primary, size: 20),
            ),
            title: const Text("Change / Set PIN", style: TextStyle(fontWeight: FontWeight.w600)),
            trailing: const Icon(Icons.chevron_right, color: Colors.grey),
          ),
        ),
      ],
    );
  }

  Widget _buildToggleItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required Function(bool)? onChanged,
    bool enabled = true,
  }) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: enabled ? AppColors.primary.withOpacity(0.1) : Colors.grey.withOpacity(0.1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(
          icon, 
          color: enabled ? AppColors.primary : Colors.grey, 
          size: 20,
        ),
      ),
      title: Text(title, style: TextStyle(fontWeight: FontWeight.w600, color: enabled ? Colors.black : Colors.grey)),
      subtitle: Text(subtitle, style: const TextStyle(fontSize: 11, color: Colors.grey)),
      trailing: Switch(
        value: value,
        onChanged: onChanged,
        activeColor: AppColors.primary,
      ),
    );
  }

  void _showSetPinDialog() {
    final TextEditingController pinController = TextEditingController();
    Get.dialog(
      AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text("Set Security PIN", textAlign: TextAlign.center),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text("Enter a 4-digit PIN to secure your app", textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 20),
            TextField(
              controller: pinController,
              keyboardType: TextInputType.number,
              maxLength: 4,
              obscureText: true,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 24, letterSpacing: 10, fontWeight: FontWeight.bold),
              decoration: const InputDecoration(
                counterText: "",
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(vertical: 10),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Get.back(), child: const Text("Cancel")),
          ElevatedButton(
            onPressed: () {
              if (pinController.text.length == 4) {
                controller.savePin(pinController.text);
                Get.back();
                Get.snackbar("Success", "PIN set successfully", snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.green, colorText: Colors.white);
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            child: const Text("Save PIN", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}
