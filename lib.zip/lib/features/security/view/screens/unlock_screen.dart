import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/app_colors.dart';
import '../../../../core/utils/storage_service.dart';
import '../../controllers/security_controller.dart';

class UnlockScreen extends StatefulWidget {
  const UnlockScreen({super.key});

  @override
  State<UnlockScreen> createState() => _UnlockScreenState();
}

class _UnlockScreenState extends State<UnlockScreen> {
  final controller = Get.find<SecurityController>();
  final List<String> _pin = [];
  bool _isError = false;

  void _onNumberPress(String number) {
    if (_pin.length < 4) {
      setState(() {
        _pin.add(number);
        _isError = false;
      });
      if (_pin.length == 4) {
        _verifyFingerprint();
      }
    }
  }

  void _onBackspace() {
    if (_pin.isNotEmpty) {
      setState(() {
        _pin.removeLast();
        _isError = false;
      });
    }
  }

  Future<void> _verifyFingerprint() async {
    final enteredPin = _pin.join();
    if (controller.verifyPin(enteredPin)) {
      await StorageService.setLocked(false);
      Get.offAllNamed('/home');
    } else {
      setState(() {
        _pin.clear();
        _isError = true;
      });
      Get.snackbar("Incorrect PIN", "Please try again", snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.red, colorText: Colors.white);
    }
  }

  Future<void> _authenticateBiometrics() async {
    bool authenticated = await controller.authenticateWithBiometrics();
    if (authenticated) {
      await StorageService.setLocked(false);
      Get.offAllNamed('/home');
    }
  }

  @override
  void initState() {
    super.initState();
    if (controller.isFingerprintEnabled.value) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _authenticateBiometrics();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false, // Cannot go back from unlock screen
      child: Scaffold(
        body: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AppColors.primary, AppColors.secondary.withOpacity(0.8)],
            ),
          ),
          child: SafeArea(
            child: Column(
              children: [
                const Spacer(flex: 1),
                _buildLogo(),
                const Spacer(flex: 1),
                _buildPinIndicator(),
                const SizedBox(height: 40),
                _buildNumberPad(),
                const Spacer(flex: 2),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLogo() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.15),
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white.withOpacity(0.3)),
          ),
          child: const Icon(Icons.lock_outline, color: Colors.white, size: 40),
        ),
        const SizedBox(height: 20),
        const Text(
          "ELYSIUM",
          style: TextStyle(
            color: Colors.white,
            fontSize: 28,
            fontWeight: FontWeight.bold,
            letterSpacing: 8,
          ),
        ),
        const SizedBox(height: 10),
        const Text(
          "Secure Access Only",
          style: TextStyle(color: Colors.white70, fontSize: 14),
        ),
      ],
    );
  }

  Widget _buildPinIndicator() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(4, (index) {
        bool isFilled = index < _pin.length;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          margin: const EdgeInsets.symmetric(horizontal: 12),
          width: 16,
          height: 16,
          decoration: BoxDecoration(
            color: _isError 
                ? Colors.red 
                : (isFilled ? Colors.white : Colors.white.withOpacity(0.2)),
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white.withOpacity(0.5)),
            boxShadow: isFilled ? [BoxShadow(color: Colors.white.withOpacity(0.5), blurRadius: 10)] : [],
          ),
        );
      }),
    );
  }

  Widget _buildNumberPad() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: Column(
        children: [
          for (var i = 0; i < 3; i++)
            _buildNumberRow(i * 3 + 1, (i * 3 + 1) + 2),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildBiometricButton(),
              _buildNumberButton("0"),
              _buildBackspaceButton(),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildNumberRow(int start, int end) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          for (var i = start; i <= end; i++)
            _buildNumberButton(i.toString()),
        ],
      ),
    );
  }

  Widget _buildNumberButton(String number) {
    return GestureDetector(
      onTap: () => _onNumberPress(number),
      child: Container(
        width: 70,
        height: 70,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.1),
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white.withOpacity(0.2)),
        ),
        alignment: Alignment.center,
        child: Text(
          number,
          style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w600),
        ),
      ),
    );
  }

  Widget _buildBackspaceButton() {
    return GestureDetector(
      onTap: _onBackspace,
      onLongPress: () => setState(() => _pin.clear()),
      child: Container(
        width: 70,
        height: 70,
        alignment: Alignment.center,
        child: const Icon(Icons.backspace_outlined, color: Colors.white70, size: 28),
      ),
    );
  }

  Widget _buildBiometricButton() {
    if (!controller.isFingerprintEnabled.value) {
      return const SizedBox(width: 70);
    }
    return GestureDetector(
      onTap: _authenticateBiometrics,
      child: Container(
        width: 70,
        height: 70,
        decoration: BoxDecoration(
          color: AppColors.primary.withOpacity(0.3),
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white.withOpacity(0.3)),
        ),
        child: const Center(
          child: Icon(Icons.fingerprint, color: Colors.white, size: 32),
        ),
      ),
    );
  }
}
