import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:local_auth/local_auth.dart';
import '../../../core/utils/storage_service.dart';

class SecurityController extends GetxController {
  final LocalAuthentication _auth = LocalAuthentication();

  var isPinEnabled = false.obs;
  var isFingerprintEnabled = false.obs;
  var canCheckBiometrics = false.obs;

  @override
  void onInit() {
    super.onInit();
    _loadSettings();
    _checkBiometrics();
  }

  void _loadSettings() {
    isPinEnabled.value = StorageService.isPinEnabled();
    isFingerprintEnabled.value = StorageService.isFingerprintEnabled();
  }

  Future<void> _checkBiometrics() async {
    try {
      canCheckBiometrics.value = await _auth.canCheckBiometrics || await _auth.isDeviceSupported();
    } on PlatformException catch (e) {
      print("Biometrics error: $e");
      canCheckBiometrics.value = false;
    }
  }

  Future<void> togglePin(bool value) async {
    if (value && StorageService.getPin() == null) {
      // Need to set PIN first
      Get.toNamed('/security-settings/set-pin');
      return;
    }
    isPinEnabled.value = value;
    await StorageService.setPinEnabled(value);
  }

  Future<void> toggleFingerprint(bool value) async {
    if (value) {
      bool authenticated = await authenticateWithBiometrics();
      if (!authenticated) return;
    }
    isFingerprintEnabled.value = value;
    await StorageService.setFingerprintEnabled(value);
  }

  Future<bool> authenticateWithBiometrics() async {
    try {
      return await _auth.authenticate(
        localizedReason: 'Please authenticate to unlock Elysium',
      );
    } on PlatformException catch (e) {
      print("Auth error: $e");
      return false;
    }
  }

  Future<void> savePin(String pin) async {
    await StorageService.setPin(pin);
    await StorageService.setPinEnabled(true);
    isPinEnabled.value = true;
    _loadSettings();
  }

  bool verifyPin(String pin) {
    return StorageService.getPin() == pin;
  }
}
