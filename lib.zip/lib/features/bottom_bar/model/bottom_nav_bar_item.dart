import 'package:flutter/material.dart';

import '../controller/bottombar_controller.dart';

class BottomNavBarItem {
  final String title;
  final Widget screen;
  final ScreenModule screenModule;
  final List<List<dynamic>> icon;
  final Color color;
  const BottomNavBarItem({
    required this.screen,
    required this.title,
    required this.icon,
    required this.screenModule,
    required this.color,
  });
}
