import 'package:elysium_employee/features/attendance/view/screen/profile_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';

import '../../../../core/app_colors.dart';
import '../../attendance/view/screen/attendance_screen.dart';
import '../../attendance/view/screen/test.dart'; 
import '../../dashboard/view/screens/dashboard_screen.dart';
import '../model/bottom_nav_bar_item.dart';

enum ScreenModule { dashboard, attendance, task, profile }

class BottomBarController extends GetxController {
  final RxInt selectedIndex = 0.obs;
  dynamic screenSetting;
  late final PageController pageController;
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  RxList<BottomNavBarItem> get pages => <BottomNavBarItem>[
    const BottomNavBarItem(
      screen: DashboardScreen(),
      title: 'Dashboard',
      icon: HugeIcons.strokeRoundedHome04,
      screenModule: ScreenModule.dashboard,
      color: AppColors.converted,
    ),
      BottomNavBarItem(
      screen: AttendanceScreen(),
      title: 'Attendance',
      icon: HugeIcons.strokeRoundedCalendar02,
      color: AppColors.primary,
      screenModule: ScreenModule.attendance,
    ),
      BottomNavBarItem(
      screen: TestScreen(),
      title: 'Task',
      icon: HugeIcons.strokeRoundedDocumentValidation,
      color: AppColors.primary,
      screenModule: ScreenModule.task,
    ),

    const BottomNavBarItem(
      screen: ProfilePage(),
      title: 'Profile',
      icon: HugeIcons.strokeRoundedUserSquare,
      color: Colors.pink,
      screenModule: ScreenModule.profile,
    ),
  ].obs;

  @override
  void onInit() {
    super.onInit();

    pageController = PageController(initialPage: selectedIndex.value);
  }

  @override
  void onClose() {
    pageController.dispose();

    super.onClose();
  }

  int getIndex(ScreenModule module) => pages
      .indexWhere((page) => page.screenModule == module)
      .clamp(0, pages.length - 1);

  void screenNavigation({int? index, ScreenModule? module}) {
    if (module != null) {
      index = getIndex(module);
    }
    selectedIndex.value = index!;
    pageController.jumpToPage(index);
  }

  void openDrawer() {
    scaffoldKey.currentState?.openDrawer();
  }

  void closeDrawer() {
    scaffoldKey.currentState?.openEndDrawer();
  }
}
