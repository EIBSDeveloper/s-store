import 'package:get/get.dart';

import '../../attendance/controller/attendance_controller.dart';
import '../../dashboard/controller/dashboard_controller.dart';
import '../controller/bottombar_controller.dart';
 

class BottombarBinding extends Bindings {
  @override
  void dependencies() { 
    Get.lazyPut(() => BottomBarController( ));
    Get.lazyPut(() => DashboardController( ));
    Get.lazyPut(() => AttendanceController( ));
  }
}