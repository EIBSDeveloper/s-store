import 'package:flutter/material.dart';

class CheckInOutSwitch extends StatefulWidget {
  final bool initialValue;
  final Function(bool)? onChanged;

  const CheckInOutSwitch({
    super.key,
    this.initialValue = false,
    this.onChanged,
  });

  @override
  State<CheckInOutSwitch> createState() => _CheckInOutSwitchState();
}

class _CheckInOutSwitchState extends State<CheckInOutSwitch> {
  late bool isCheckedIn;

  @override
  void initState() {
    super.initState();
    isCheckedIn = widget.initialValue;
  }

  @override
  Widget build(BuildContext context) => Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      Switch(
        value: isCheckedIn,
        onChanged: (value) {
          setState(() => isCheckedIn = value);
          if (widget.onChanged != null) widget.onChanged!(value);
        },
        activeThumbColor: Colors.white,
        activeTrackColor: Colors.green,
        inactiveThumbColor: Colors.white,
        inactiveTrackColor: Colors.red,
      ),
    ],
  );
}
