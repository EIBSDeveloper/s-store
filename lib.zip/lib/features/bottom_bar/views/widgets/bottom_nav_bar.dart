import 'dart:ui';
import 'package:flutter/material.dart';
import '../../model/bottom_nav_bar_item.dart';
import 'nav_bar_item.dart';

class BottomNavBar extends StatefulWidget {
  final List<BottomNavBarItem> children;
  final int currentIndex;
  final Color? backgroundColor;
  final Color? selectColor;
  final Function(int)? onTap;

  const BottomNavBar({
    super.key,
    required this.children,
    required this.selectColor,
    required this.currentIndex,
    this.backgroundColor,
    required this.onTap,
  });

  @override
  State<BottomNavBar> createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          width: screenWidth,
          height: 55,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.white.withOpacity(0.8),
                Colors.white.withOpacity(0.4),
              ],
              begin: Alignment.bottomCenter,
              end: Alignment.topCenter,
            ),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
            border: Border(
              top: BorderSide(color: Colors.white.withOpacity(0.6), width: 1.2),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 15,
                offset: const Offset(0, -2),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: List.generate(
              widget.children.length,
              (index) => NavBarItem(
                index: index,
                item: widget.children[index],
                selected: widget.currentIndex == index,
                onTap: () {
                  widget.onTap?.call(index);
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}
