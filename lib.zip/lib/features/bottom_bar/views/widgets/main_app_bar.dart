import 'dart:ui';
import 'package:flutter/material.dart';

import '../../../../core/app_colors.dart';
import '../../../../core/app_style.dart';
import '../../../../widgets/notification_icon_with_ripples.dart';

class MainAppBar extends StatelessWidget {
  const MainAppBar({super.key, required this.title, this.openMenu});
  final void Function()? openMenu;
  final Text title;

  @override
  Widget build(BuildContext context) => ClipRRect(
    child: BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
      child: Container(
        padding: const EdgeInsets.only(right: 16, left: 16, bottom: 8, top: 8),
        height: 60,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.white.withOpacity(0.8),
              Colors.white.withOpacity(0.4),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
          border: Border(
            bottom: BorderSide(
              color: Colors.white.withOpacity(0.6),
              width: 1.2,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            InkWell(
              onTap: openMenu,
              child: Container(
                height: 40,
                width: 40,
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                alignment: Alignment.center,
                child:   Icon(
                  Icons.notes_outlined,
                  color: AppColors.primary,
                  size: AppStyle.iconSizeLarge,
                ),
              ),
            ),
            const SizedBox(width: 12),
            title,
            const Spacer(),
            const NotificationIconWithRipples(),
          ],
        ),
      ),
    ),
  );
}
