import 'package:flutter/material.dart';
import 'package:hugeicons/hugeicons.dart';

import '../../../../../core/app_style.dart';
import '../../../../core/app_colors.dart';
import '../../model/bottom_nav_bar_item.dart';

class NavBarItem extends StatefulWidget {
  final BottomNavBarItem item;
  final int index;
  final bool selected;
  final Function onTap;
  final Color? backgroundColor;
  const NavBarItem({
    super.key,
    required this.item,
    this.selected = false,
    required this.onTap,
    this.backgroundColor,
    required this.index,
  });

  @override
  State<NavBarItem> createState() => _NavBarItemState();
}

class _NavBarItemState extends State<NavBarItem> {
  @override
  Widget build(BuildContext context) => Expanded(
    child: InkWell(
      onTap: () {
        widget.onTap();
      },
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 5),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(AppStyle.borderRadiusBox),
          gradient: widget.selected
              ? LinearGradient(
                  colors: [
                    AppColors.secondary.withOpacity(0.15),
                    AppColors.primary.withOpacity(0.10),
                  ],
                )
              : null,
          border: widget.selected
              ? Border.all(color: Colors.white.withOpacity(0.4), width: 1)
              : null,
        ),
        child: Column(
          children: [
            AnimatedContainer(
              padding: const EdgeInsets.all(8),

              duration: const Duration(milliseconds: 300),
              constraints: BoxConstraints(minWidth: widget.selected ? 70 : 50),
              height: 7,
              alignment: Alignment.center,
              width: 10,
              decoration: BoxDecoration(
                color: widget.selected ? AppColors.primary : Colors.transparent,
                borderRadius: const BorderRadius.vertical(
                  bottom: Radius.circular(8),
                ),
                boxShadow: widget.selected
                    ? [
                        // BoxShadow(
                        //   color: AppColors.primary.withOpacity(0.3),
                        //   blurRadius: 8,
                        //   offset: const Offset(0, 2),
                        // ),
                      ]
                    : null,
              ),
            ),

            Expanded(
              child: HugeIcon(
                icon: widget.item.icon,
                color: AppColors.primary,
                size: AppStyle.iconSizeLarge,
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
