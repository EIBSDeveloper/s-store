import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../../core/app_colors.dart'; 
import '../../controller/bottombar_controller.dart';
import '../widgets/bottom_nav_bar.dart';
import '../widgets/exit_pup_up.dart';
import '../widgets/main_app_bar.dart';
import 'menu.dart';

class Home extends GetView<BottomBarController> {
  const Home({super.key});

  @override
  Widget build(BuildContext context) => WillPopScope(
    onWillPop: () async => await showConfirmExitPopup(context),
    child: Scaffold(
      key: controller.scaffoldKey,
      drawer: AppMenu(),
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            Obx(
              () => MainAppBar(
                openMenu: () {
                  controller.scaffoldKey.currentState?.openDrawer();
                },
                title: Text(
                  controller.pages[controller.selectedIndex.value].title,

                  style: Theme.of(
                    context,
                  ).textTheme.titleLarge!.copyWith(color: AppColors.primary),
                ),
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: controller.pageController,
                itemCount: controller.pages.length,
                itemBuilder: (context, index) => controller.pages[index].screen,
                onPageChanged: (index) {
                  controller.selectedIndex.value = index;
                },
              ),
            ),
          ],
        ),
      ),

      bottomNavigationBar: SafeArea(
        child: Obx(
          () => BottomNavBar(
            key: const ValueKey("BottomBar"),
            currentIndex: controller.selectedIndex.value,
            backgroundColor: AppColors.card,

            selectColor: Theme.of(context).colorScheme.secondaryContainer,
            onTap: (index) => controller.screenNavigation(index: index),
            children: controller.pages,
          ),
        ),
      ),
    ),
  );
}
