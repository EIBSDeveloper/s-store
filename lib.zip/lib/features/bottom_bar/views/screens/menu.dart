import 'package:elysium_employee/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';

import '../../../../routes/app_routes.dart';

class AppMenu extends StatelessWidget {
  const AppMenu({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: AppColors.background,
      child: SizedBox(
        width: 300,
        child: Column(
          children: [
            _header(),
            Expanded(child: _menuList()),
            _logout(),
          ],
        ),
      ),
    );
  }

  /// ---------------- HEADER ----------------
  Widget _header() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.secondary, AppColors.primary],
        ),
      ),
      padding: const EdgeInsets.fromLTRB(20, 60, 20, 20),
      child: Row(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                // ignore: deprecated_member_use
                color: Colors.white.withOpacity(0.5),
                width: 2,
              ),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(28),
              child: Container(
                color: Colors.white,
                padding: EdgeInsets.all(8),
                child: Image.network(
                  "https://erp.elysium.community/assets/common/logo_small.png",
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text(
                "Elysium Groups",
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              SizedBox(height: 4),
              Text(
                "EIBS",
                style: TextStyle(color: Colors.white70, fontSize: 12),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// ---------------- MENU ----------------
  Widget _menuList() {
    return ListView(
      padding: const EdgeInsets.symmetric(vertical: 10),
      children: [
        // _menuItem(Icons.person_outline, "Profile", active: true),
        _menuItem(HugeIcons.strokeRoundedSun01, "Today Check - in"),
        _menuItem(HugeIcons.strokeRoundedCalendar02, "Leave"),
        _menuItem(HugeIcons.strokeRoundedWallet02, "Payslip"),
        _menuItem(HugeIcons.strokeRoundedMessage02, "HR Ticket"),
        _menuItem(HugeIcons.strokeRoundedNotification01, "Notifications"),
        _menuItem(HugeIcons.strokeRoundedSettings02, "Settings"),
      ],
    );
  }

  Widget _menuItem(List<List<dynamic>> icon, String text) {
    return Column(
      children: [
        // if (active)
        // Positioned(
        //   left: 0,
        //   top: 8,
        //   bottom: 8,
        //   child: Container(
        //     width: 8,
        //     decoration: BoxDecoration(
        //       color: AppColors.primary,
        //       borderRadius: BorderRadius.circular(4),
        //     ),
        //   ),
        // ),
        Container(
          // margin: EdgeInsets.only(right: 8, bottom: 8),
          decoration:
              // active
              //     ?
              BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(10)),
                // gradient: LinearGradient(
                //   colors: [
                //     AppColors.secondary.withAlpha(80),
                //     AppColors.primary.withAlpha(150),
                //   ],
                // ),
              ),
          // : null,
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 20,
              vertical: 4,
            ),
            leading: HugeIcon(icon: icon, color: AppColors.primary),
            title: Text(
              text,
              style: TextStyle(
                color: Colors.black87,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ),

        // Divider(height: 5, thickness: .5),
      ],
    );
  }

  /// ---------------- LOGOUT ----------------
  Widget _logout() {
    return InkWell(
      onTap: () {
        Get.toNamed(Routes.login);
      },
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          // gradient: LinearGradient(
          //   colors: [AppColors.secondary, AppColors.primary],
          // ),
          border: Border(top: BorderSide(color: Colors.grey.shade300)),
        ),
        child: Row(
          children:   [
            SizedBox(width: 10),
            Icon(Icons.logout, color: AppColors.primary),
            SizedBox(width: 10),
            Text(
              "Log Out",
              style: TextStyle(
                color: AppColors.primary,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
