import 'package:flutter/material.dart';
import 'package:get/get.dart';
 

class FlagClipCard extends StatelessWidget {
  const FlagClipCard({
    super.key,
    required this.lable,
    required this.statusColor,
  });

  final String lable;

  final Color statusColor;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(
      color: statusColor.withAlpha(30),
      borderRadius: BorderRadius.circular(5),
    ),
    child: Text(
      lable,
      style: Get.theme.textTheme.bodySmall
          ?.copyWith(color: statusColor, fontWeight: FontWeight.w600),
    ),
  );
}
