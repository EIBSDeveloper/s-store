import 'package:flutter/material.dart';

import '../core/app_colors.dart'; 

class LabelText extends StatelessWidget {
  const LabelText(this.text, {super.key, this.isRequired = false});

  final String text;
  final bool isRequired;

  @override
  Widget build(BuildContext context) => RichText(
    text: TextSpan(
      text: text,
      style: const TextStyle(color: AppColors.textPrimary, fontSize: 14),
      children: [
        if (isRequired)
          const TextSpan(
            text: " *",
            style: TextStyle(color: AppColors.danger, fontSize: 18),
          ),
      ],
    ),
  );
}
