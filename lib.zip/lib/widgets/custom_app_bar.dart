import 'package:flutter/material.dart';
import 'package:get/get.dart'; 
 
import '../../core/app_colors.dart';
import '../core/app_style.dart';
import '../utils/utils.dart'; 

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String? titleText;
  final Text? title;
  final List<Widget>? actions;
  final bool showBackButton;

  const CustomAppBar({
    super.key,
    this.titleText,
    this.title,
    this.actions,
    this.showBackButton = false,
  });

  @override
  Widget build(BuildContext context) => AppBar(
    backgroundColor: AppColors.whiteText,

    elevation: 0,
    title: Row(
      children: [
        InkWell(
          onTap: () => Get.back(),
          child: Container(
            width: 40,
            height: 40,

            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.arrow_back_ios_new,
              color: AppColors.primary,
              size: AppStyle.iconSize2,
            ),
          ),
        ),
        const SizedBox(width: 10),
        title ??
            Text(
              capitalizeFirstLetter(titleText ?? ''),
              style: TextStyle(color: AppColors.primary),
            ),
      ],
    ),
    // centerTitle: true,
    actions: actions != null ? [...actions!, const SizedBox(width: 8)] : null,
    automaticallyImplyLeading: false,

    // leading: InkWell(
    //   onTap: () => navigatorKey.currentState!.pop(),
    //   child: Container(
    //     width: 30,
    //     height: 30,

    //     decoration: BoxDecoration(
    //       color: Colors.grey.shade200,
    //       shape: BoxShape.circle,
    //     ),
    //     child: const Icon(
    //       Icons.arrow_back_ios_new,
    //       color: AppColors.primary,
    //       size: AppStyle.iconSize2,
    //     ),
    //   ),
    // ),
  );

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
