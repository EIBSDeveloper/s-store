// import 'package:flutter/material.dart'; 

// class AppSearchBar extends StatelessWidget {
//   final void Function(String)? onChanged;
//   const AppSearchBar({super.key, this.onChanged});

//   @override
//   Widget build(BuildContext context) => Container(
//     margin: const EdgeInsets.symmetric(horizontal: 10),
//     padding: const EdgeInsets.symmetric(horizontal: 8),
//     decoration: AppStyle.decoration,
//     child: Row(
//       children: [
//         Container(
//           width: 40,
//           height: 40,
//           padding: const EdgeInsets.all(10),

//           child: const HugeIcon(
//             icon: HugeIcons.strokeRoundedSearch01,
//             color: AppColors.textPrimary,
//           ),
//         ),
//         const SizedBox(width: 10),
//         Expanded(
//           child: TextField(
//             onChanged: onChanged,
//             decoration: const InputDecoration(
//               hintText: "Search by name or number...",
//               hintStyle: TextStyle(color: Colors.white),
//               contentPadding: EdgeInsets.all(0),

//               border: InputBorder.none,
//             ),
//           ),
//         ),
//       ],
//     ),
//   );
// }
