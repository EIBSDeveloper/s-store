import 'package:flutter/material.dart'; 

import '../../core/app_colors.dart';

class EmptyScreen extends StatelessWidget {
  final IconData? icon;

  final String title;
  final String body;
  final String? actionText;
  final void Function()? onPressed;
  const EmptyScreen({
    super.key,
    required this.icon,
    required this.title,
    required this.body,
    this.actionText,
    this.onPressed,
  });

  @override
  Widget build(BuildContext context) => Center(
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 24),

      constraints: const BoxConstraints(maxWidth: 400),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            height: 140,
            width: 140,
            decoration: BoxDecoration(
              color: AppColors.primary.withAlpha(50),
              shape: BoxShape.circle,
            ),
            padding: const EdgeInsets.all(20),
            child: Icon(icon),
          ),

          const SizedBox(height: 30),
          Text(
            title,
            style: Theme.of(
              context,
            ).textTheme.titleLarge!.copyWith(color: AppColors.primary),
          ),

          const SizedBox(height: 10),

          Text(
            body,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium,
          ),

          const SizedBox(height: 40),
          if (actionText != null)
            SizedBox(
              width: 300,
              height: 55,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                onPressed: onPressed,
                child: Text(
                  actionText!,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ),
            ),

          const SizedBox(height: 20),

          // TextButton(
          //   onPressed: () {},
          //   child: const Text(
          //     "Learn more about this feature",
          //     style: TextStyle(color: Colors.grey),
          //   ),
          // ),
        ],
      ),
    ),
  );
}
