import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../core/app_colors.dart';
import '../core/app_style.dart';
 

class FilterChipWidget extends StatelessWidget {
  final String label;
  final bool selected;
  final bool isDark;
  final Function()? onSelected;
  const FilterChipWidget({
    super.key,
    required this.label,
    this.selected = false,
    this.isDark = false,
    this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Get.theme.textTheme;
    return InkWell(
      onTap: onSelected,

      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        margin: const EdgeInsets.only(right: 10),
        decoration: AppStyle.decoration.copyWith(
          color: !selected ? AppColors.card : null,
          gradient: selected ? AppColors.gradient : null,
          borderRadius: BorderRadius.circular(AppStyle.borderRadiusClip),
        ),
        child: Center(
          child: Text(
            label,
            style: theme.bodyMedium?.copyWith(
              color: selected ? AppColors.card : AppColors.textPrimary,
            ),
          ),
        ),
      ),
    );
  }
}
