import 'package:flutter/material.dart';

class Background extends StatelessWidget {
  final Widget? child;
  const Background({super.key, this.child});

  @override
  Widget build(BuildContext context) => Container(
    color: Colors.white,
    child: Container(child: child),
  );
}
