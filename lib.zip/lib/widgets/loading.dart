import 'package:flutter/material.dart';

import 'package:loading_animation_widget/loading_animation_widget.dart';

import '../../core/app_colors.dart';

class Loading extends StatelessWidget {
  final double? size;
  const Loading({super.key, this.size});

  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(10.0),
      child: LoadingAnimationWidget.threeArchedCircle(
        color: AppColors.primary,
        size: size ?? 50,
      ),
    ),
  );
}
