import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';

import '../../../../../core/app_colors.dart';
import '../../../../../core/app_style.dart';
import '../core/theme/theme_controller.dart';
import '../features/notifications/controller/notifications_controller.dart';
import '../routes/app_routes.dart';

class NotificationIconWithRipples extends StatefulWidget {
  const NotificationIconWithRipples({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _NotificationIcon createState() => _NotificationIcon();
}

class _NotificationIcon extends State<NotificationIconWithRipples>
    with TickerProviderStateMixin {
  late NotificationsController notificationsController;
  @override
  void initState() {
    notificationsController = Get.put(NotificationsController());
    super.initState();
  }

  @override
  void dispose() {
    notificationsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Stack(
    clipBehavior: Clip.none,
    children: [
      Obx(() {
        final unreadCount = notificationsController.unreadCount;
        if (unreadCount == 0) return const SizedBox.shrink();

        return Positioned(
          right: 2,
          top: 2,
          child: Container(
            padding: const EdgeInsets.all(4),
            decoration: const BoxDecoration(
              color: Colors.red,
              shape: BoxShape.circle,
            ),
            constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
            child: Center(
              child: Text(
                unreadCount > 9 ? '9+' : unreadCount.toString(),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 8,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        );
      }),

      // Notification icon
      IconButton(
        onPressed: () async {
          Get.toNamed(Routes.notifications);
        },
        icon: HugeIcon(
          icon: HugeIcons.strokeRoundedNotification01,
          color: Get.find<ThemeController>().primaryColor.value,
          size: AppStyle.iconSizeLarge,
        ),
      ),
    ],
  );
}
