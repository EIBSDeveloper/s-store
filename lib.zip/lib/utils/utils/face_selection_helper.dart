import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';

class FaceSelectionResult {
  final Face? face;
  final String? error;

  FaceSelectionResult({
    this.face,
    this.error,
  });

  bool get isValid => face != null;
}

class FaceSelectionHelper {
  static FaceSelectionResult selectSingleFace(
      List<Face> faces,
      ) {
    if (faces.isEmpty) {
      return FaceSelectionResult(
        error: 'No face detected',
      );
    }

    if (faces.length > 1) {
      return FaceSelectionResult(
        error: 'Multiple faces detected. Please be alone.',
      );
    }

    final face = faces.first;
    
    // 🔍 Ensure face is large enough (at least 100px wide)
    // Most front cameras are at least 480p or 720p. 100px is a safe minimum.
    if (face.boundingBox.width < 120) {
      return FaceSelectionResult(
        error: 'Please move closer to the camera',
      );
    }

    return FaceSelectionResult(face: face);
  }
}
