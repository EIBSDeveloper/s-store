import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';

class Utils {
  static Future<void> requestContactPermission() async {
    var status = await Permission.contacts.status;
    if (!status.isGranted) {
      await Permission.contacts.request();
    }
  }

  static String formatDuration(int totalSeconds) {
    final minutes = (totalSeconds ~/ 60).toString().padLeft(2, '0');
    final seconds = (totalSeconds % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  static String capitalizeFirstLetter(String input) {
    if (input.isEmpty) return input;
    return '${input[0].toUpperCase()}${input.substring(1)}';
  }
}

String capitalizeFirstLetter(final String input) =>
    input.isEmpty ? input : input[0].toUpperCase() + input.substring(1);

/// Open WhatsApp chat with a specific phone number
Future<void> openWhatsApp(String phoneNumber, {String message = ''}) async {
  final whatsappUrl = Uri.parse(
    "https://wa.me/$phoneNumber?text=${Uri.encodeComponent(message)}",
  );

  if (await canLaunchUrl(whatsappUrl)) {
    await launchUrl(whatsappUrl, mode: LaunchMode.externalApplication);
  } else {
    throw 'Could not launch WhatsApp';
  }
}

/// Open SMS app with a message
Future<void> openSMS(String phoneNumber, {String message = ''}) async {
  final smsUrl = Uri(
    scheme: 'sms',
    path: phoneNumber,
    queryParameters: <String, String>{'body': message},
  );

  if (await canLaunchUrl(smsUrl)) {
    await launchUrl(smsUrl);
  } else {
    throw 'Could not launch SMS';
  }
}

Color getColorFromHex(String hexColor) {
  hexColor = hexColor.replaceAll('#', '');
  if (hexColor.length == 6) hexColor = 'ff$hexColor';
  return Color(int.parse(hexColor, radix: 16));
}

String formatDuration(int seconds) {
  final duration = Duration(seconds: seconds);

  String twoDigits(int n) => n.toString().padLeft(2, '0');

  // String hours = twoDigits(duration.inHours);
  String minutes = twoDigits(duration.inMinutes.remainder(60));
  String secs = twoDigits(duration.inSeconds.remainder(60));

  // return "$hours:$minutes:$secs";
  return "$minutes:$secs";
}

String getCurrentDateFormatted(DateTime? now) {
  now ??= DateTime.now();
  return DateFormat('MMM - yyyy').format(now);
}

String removeCountryCode(String number) {
  // Remove spaces, dashes, brackets
  String cleaned = number.replaceAll(RegExp(r'[^\d+]'), '');

  // If starts with +, remove country code (keep last 10 digits)
  if (cleaned.startsWith('+')) {
    cleaned = cleaned.replaceAll('+', '');
  }

  // Keep only last 10 digits (Indian mobile standard)
  if (cleaned.length > 10) {
    cleaned = cleaned.substring(cleaned.length - 10);
  }

  return cleaned;
}
