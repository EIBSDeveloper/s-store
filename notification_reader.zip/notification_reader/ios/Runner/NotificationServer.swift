import Foundation
import GCDWebServer
import SQLite3

// MARK: - Notification Model
struct NotificationPayload: Codable {
    let app_name: String
    let title: String
    let body: String
    let timestamp: String?
    let bundle_id: String?
    
    var resolvedTimestamp: String {
        if let ts = timestamp, !ts.isEmpty {
            return ts
        }
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter.string(from: Date())
    }
}

// MARK: - NotificationServer
@objc class NotificationServer: NSObject {
    
    static let shared = NotificationServer()
    
    private var webServer: GCDWebServer?
    private let port: UInt = 8765
    
    // AppGroup identifier — must match entitlements
    private let appGroupID = "group.com.yourname.notificationreader"
    private let userDefaultsKey = "stored_notifications"
    
    // SQLite database path inside AppGroup shared container
    private var dbPath: String {
        guard let container = FileManager.default.containerURL(
            forSecurityApplicationGroupIdentifier: appGroupID
        ) else {
            // Fallback to documents
            let docs = FileManager.default.urls(
                for: .documentDirectory, in: .userDomainMask
            ).first!
            return docs.appendingPathComponent("notifications.db").path
        }
        return container.appendingPathComponent("notifications.db").path
    }
    
    private var db: OpaquePointer?
    
    // MARK: - Lifecycle
    private override init() {
        super.init()
        setupDatabase()
    }
    
    // MARK: - Server Start/Stop
    @objc func startServer() {
        guard webServer == nil else {
            print("[NotificationServer] Server already running on port \(port)")
            return
        }
        
        let server = GCDWebServer()
        
        // ── Health check endpoint ──────────────────────────────────────
        server.addHandler(
            forMethod: "GET",
            path: "/ping",
            request: GCDWebServerRequest.self
        ) { _ -> GCDWebServerResponse? in
            let response = GCDWebServerDataResponse(
                jsonObject: ["status": "ok", "port": self.port]
            )
            response?.statusCode = 200
            return response
        }
        
        // ── Receive notification POST ──────────────────────────────────
        server.addHandler(
            forMethod: "POST",
            path: "/notification",
            request: GCDWebServerDataRequest.self
        ) { [weak self] request -> GCDWebServerResponse? in
            guard
                let self = self,
                let dataRequest = request as? GCDWebServerDataRequest,
                !dataRequest.data.isEmpty
            else {
                return GCDWebServerDataResponse(
                    jsonObject: ["error": "Empty body"]
                )
            }
            
            do {
                let payload = try JSONDecoder().decode(
                    NotificationPayload.self,
                    from: dataRequest.data
                )
                
                let saved = self.saveNotification(payload)
                
                let response = GCDWebServerDataResponse(
                    jsonObject: [
                        "success": saved,
                        "app": payload.app_name,
                        "ts": payload.resolvedTimestamp
                    ]
                )
                response?.statusCode = saved ? 200 : 500
                return response
                
            } catch {
                print("[NotificationServer] JSON decode error: \(error)")
                let response = GCDWebServerDataResponse(
                    jsonObject: ["error": "Invalid JSON: \(error.localizedDescription)"]
                )
                response?.statusCode = 400
                return response
            }
        }
        
        // ── Get all notifications (for debugging) ─────────────────────
        server.addHandler(
            forMethod: "GET",
            path: "/notifications",
            request: GCDWebServerRequest.self
        ) { [weak self] _ -> GCDWebServerResponse? in
            guard let self = self else { return nil }
            let notifications = self.fetchAllNotificationsAsJSON()
            return GCDWebServerDataResponse(jsonObject: ["data": notifications])
        }
        
        // ── Clear all ─────────────────────────────────────────────────
        server.addHandler(
            forMethod: "DELETE",
            path: "/notifications",
            request: GCDWebServerRequest.self
        ) { [weak self] _ -> GCDWebServerResponse? in
            guard let self = self else { return nil }
            let cleared = self.clearAllNotifications()
            return GCDWebServerDataResponse(
                jsonObject: ["cleared": cleared]
            )
        }
        
        let options: [String: Any] = [
            GCDWebServerOption_Port: port,
            GCDWebServerOption_BindToLocalhost: true,
            GCDWebServerOption_AutomaticallySuspendInBackground: false,
            GCDWebServerOption_ConnectedStateCoalescingInterval: 5.0
        ]
        
        do {
            try server.start(options: options)
            self.webServer = server
            print("[NotificationServer] ✅ Server started on port \(port)")
            print("[NotificationServer] DB path: \(dbPath)")
        } catch {
            print("[NotificationServer] ❌ Failed to start: \(error)")
        }
    }
    
    @objc func stopServer() {
        webServer?.stop()
        webServer = nil
        print("[NotificationServer] Server stopped")
    }
    
    var isRunning: Bool {
        return webServer?.isRunning ?? false
    }
    
    // MARK: - SQLite Setup
    private func setupDatabase() {
        let flags = SQLITE_OPEN_CREATE | SQLITE_OPEN_READWRITE | SQLITE_OPEN_FULLMUTEX
        
        if sqlite3_open_v2(dbPath, &db, flags, nil) != SQLITE_OK {
            print("[NotificationServer] ❌ Cannot open database: \(dbPath)")
            return
        }
        
        // Enable WAL mode for better concurrent access
        sqlite3_exec(db, "PRAGMA journal_mode=WAL;", nil, nil, nil)
        sqlite3_exec(db, "PRAGMA synchronous=NORMAL;", nil, nil, nil)
        
        let createTable = """
        CREATE TABLE IF NOT EXISTS notifications (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            app_name    TEXT    NOT NULL DEFAULT '',
            bundle_id   TEXT             DEFAULT '',
            title       TEXT    NOT NULL DEFAULT '',
            body        TEXT    NOT NULL DEFAULT '',
            timestamp   TEXT    NOT NULL,
            is_read     INTEGER NOT NULL DEFAULT 0,
            created_at  INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
        );
        """
        
        let createIndex = """
        CREATE INDEX IF NOT EXISTS idx_notifications_app_name
        ON notifications(app_name);
        """
        
        let createIndexTS = """
        CREATE INDEX IF NOT EXISTS idx_notifications_timestamp
        ON notifications(timestamp DESC);
        """
        
        if sqlite3_exec(db, createTable, nil, nil, nil) != SQLITE_OK {
            let err = String(cString: sqlite3_errmsg(db))
            print("[NotificationServer] ❌ Create table error: \(err)")
        } else {
            sqlite3_exec(db, createIndex, nil, nil, nil)
            sqlite3_exec(db, createIndexTS, nil, nil, nil)
            print("[NotificationServer] ✅ Database ready at: \(dbPath)")
        }
    }
    
    // MARK: - Save Notification
    @discardableResult
    func saveNotification(_ payload: NotificationPayload) -> Bool {
        guard db != nil else { return false }
        
        let sql = """
        INSERT INTO notifications (app_name, bundle_id, title, body, timestamp, is_read)
        VALUES (?, ?, ?, ?, ?, 0);
        """
        
        var stmt: OpaquePointer?
        defer { sqlite3_finalize(stmt) }
        
        guard sqlite3_prepare_v2(db, sql, -1, &stmt, nil) == SQLITE_OK else {
            let err = String(cString: sqlite3_errmsg(db))
            print("[NotificationServer] ❌ Prepare error: \(err)")
            return false
        }
        
        sqlite3_bind_text(stmt, 1, (payload.app_name as NSString).utf8String, -1, nil)
        sqlite3_bind_text(stmt, 2, ((payload.bundle_id ?? "") as NSString).utf8String, -1, nil)
        sqlite3_bind_text(stmt, 3, (payload.title as NSString).utf8String, -1, nil)
        sqlite3_bind_text(stmt, 4, (payload.body as NSString).utf8String, -1, nil)
        sqlite3_bind_text(stmt, 5, (payload.resolvedTimestamp as NSString).utf8String, -1, nil)
        
        let result = sqlite3_step(stmt) == SQLITE_DONE
        
        if result {
            print("[NotificationServer] ✅ Saved: [\(payload.app_name)] \(payload.title)")
            // Also persist to UserDefaults for quick AppGroup access
            appendToUserDefaults(payload)
            // Post notification so Flutter can refresh
            notifyFlutter()
        } else {
            let err = String(cString: sqlite3_errmsg(db))
            print("[NotificationServer] ❌ Insert error: \(err)")
        }
        
        return result
    }
    
    // MARK: - Fetch All as JSON array (for HTTP debug endpoint)
    func fetchAllNotificationsAsJSON() -> [[String: Any]] {
        guard db != nil else { return [] }
        
        let sql = """
        SELECT id, app_name, bundle_id, title, body, timestamp, is_read
        FROM notifications
        ORDER BY timestamp DESC
        LIMIT 500;
        """
        
        var stmt: OpaquePointer?
        defer { sqlite3_finalize(stmt) }
        
        guard sqlite3_prepare_v2(db, sql, -1, &stmt, nil) == SQLITE_OK else {
            return []
        }
        
        var results: [[String: Any]] = []
        
        while sqlite3_step(stmt) == SQLITE_ROW {
            let row: [String: Any] = [
                "id":        Int(sqlite3_column_int(stmt, 0)),
                "app_name":  String(cString: sqlite3_column_text(stmt, 1)),
                "bundle_id": String(cString: sqlite3_column_text(stmt, 2)),
                "title":     String(cString: sqlite3_column_text(stmt, 3)),
                "body":      String(cString: sqlite3_column_text(stmt, 4)),
                "timestamp": String(cString: sqlite3_column_text(stmt, 5)),
                "is_read":   Int(sqlite3_column_int(stmt, 6))
            ]
            results.append(row)
        }
        
        return results
    }
    
    // MARK: - Clear All
    @discardableResult
    func clearAllNotifications() -> Bool {
        guard db != nil else { return false }
        let result = sqlite3_exec(db, "DELETE FROM notifications;", nil, nil, nil) == SQLITE_OK
        if result {
            clearUserDefaults()
        }
        return result
    }
    
    // MARK: - Delete by ID
    @discardableResult
    func deleteNotification(id: Int64) -> Bool {
        guard db != nil else { return false }
        let sql = "DELETE FROM notifications WHERE id = ?;"
        var stmt: OpaquePointer?
        defer { sqlite3_finalize(stmt) }
        guard sqlite3_prepare_v2(db, sql, -1, &stmt, nil) == SQLITE_OK else { return false }
        sqlite3_bind_int64(stmt, 1, id)
        return sqlite3_step(stmt) == SQLITE_DONE
    }
    
    // MARK: - Mark Read
    @discardableResult
    func markAsRead(id: Int64) -> Bool {
        guard db != nil else { return false }
        let sql = "UPDATE notifications SET is_read = 1 WHERE id = ?;"
        var stmt: OpaquePointer?
        defer { sqlite3_finalize(stmt) }
        guard sqlite3_prepare_v2(db, sql, -1, &stmt, nil) == SQLITE_OK else { return false }
        sqlite3_bind_int64(stmt, 1, id)
        return sqlite3_step(stmt) == SQLITE_DONE
    }
    
    // MARK: - Mark All Read
    func markAllAsRead() {
        guard db != nil else { return }
        sqlite3_exec(db, "UPDATE notifications SET is_read = 1;", nil, nil, nil)
    }
    
    // MARK: - Count unread
    func unreadCount() -> Int {
        guard db != nil else { return 0 }
        let sql = "SELECT COUNT(*) FROM notifications WHERE is_read = 0;"
        var stmt: OpaquePointer?
        defer { sqlite3_finalize(stmt) }
        guard sqlite3_prepare_v2(db, sql, -1, &stmt, nil) == SQLITE_OK else { return 0 }
        guard sqlite3_step(stmt) == SQLITE_ROW else { return 0 }
        return Int(sqlite3_column_int(stmt, 0))
    }
    
    // MARK: - AppGroup UserDefaults helpers
    private func appendToUserDefaults(_ payload: NotificationPayload) {
        guard let defaults = UserDefaults(suiteName: appGroupID) else { return }
        
        var existing = defaults.array(forKey: userDefaultsKey) as? [[String: String]] ?? []
        let entry: [String: String] = [
            "app_name":  payload.app_name,
            "bundle_id": payload.bundle_id ?? "",
            "title":     payload.title,
            "body":      payload.body,
            "timestamp": payload.resolvedTimestamp
        ]
        existing.append(entry)
        
        // Keep only last 100 in UserDefaults (full history is in SQLite)
        if existing.count > 100 {
            existing = Array(existing.suffix(100))
        }
        
        defaults.set(existing, forKey: userDefaultsKey)
        defaults.synchronize()
    }
    
    private func clearUserDefaults() {
        guard let defaults = UserDefaults(suiteName: appGroupID) else { return }
        defaults.removeObject(forKey: userDefaultsKey)
        defaults.synchronize()
    }
    
    // MARK: - Notify Flutter via Darwin notification
    private func notifyFlutter() {
        CFNotificationCenterPostNotification(
            CFNotificationCenterGetDarwinNotifyCenter(),
            CFNotificationName("com.yourname.notificationreader.new_notification" as CFString),
            nil, nil, true
        )
    }
    
    // MARK: - Cleanup
    deinit {
        sqlite3_close(db)
        stopServer()
    }
}