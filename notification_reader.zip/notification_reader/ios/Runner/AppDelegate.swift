import UIKit
import Flutter

@UIApplicationMain
@objc class AppDelegate: FlutterAppDelegate {
    
    // The single Flutter engine that drives our UI
    private var flutterEngine: FlutterEngine?
    
    // Method channel identifier — must match Dart side
    private let channelName = "com.yourname.notificationreader/notifications"
    
    // MARK: - App Launch
    override func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        
        // 1. Register Flutter plugins
        GeneratedPluginRegistrant.register(with: self)
        
        // 2. Start the HTTP server BEFORE setting up channels
        NotificationServer.shared.startServer()
        
        // 3. Set up MethodChannel after Flutter engine is ready
        if let controller = window?.rootViewController as? FlutterViewController {
            setupMethodChannel(controller: controller)
        }
        
        // 4. Listen for new-notification Darwin events and forward to Flutter
        registerDarwinObserver()
        
        // 5. Configure background fetch interval
        UIApplication.shared.setMinimumBackgroundFetchInterval(
            UIApplication.backgroundFetchIntervalMinimum
        )
        
        return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }
    
    // MARK: - MethodChannel Setup
    private func setupMethodChannel(controller: FlutterViewController) {
        let channel = FlutterMethodChannel(
            name: channelName,
            binaryMessenger: controller.binaryMessenger
        )
        
        channel.setMethodCallHandler { [weak self] call, result in
            guard let self = self else { return }
            
            switch call.method {
                
            // ── Server status ─────────────────────────────────────────
            case "isServerRunning":
                result(NotificationServer.shared.isRunning)
                
            case "restartServer":
                NotificationServer.shared.stopServer()
                NotificationServer.shared.startServer()
                result(NotificationServer.shared.isRunning)
                
            // ── Fetch notifications ───────────────────────────────────
            case "getAllNotifications":
                let notifications = NotificationServer.shared.fetchAllNotificationsAsJSON()
                // Convert to JSON string for Dart
                if let data = try? JSONSerialization.data(
                    withJSONObject: notifications, options: []
                ),
                   let jsonString = String(data: data, encoding: .utf8) {
                    result(jsonString)
                } else {
                    result("[]")
                }
                
            // ── Delete operations ─────────────────────────────────────
            case "deleteById":
                guard let args = call.arguments as? [String: Any],
                      let idValue = args["id"] else {
                    result(FlutterError(
                        code: "INVALID_ARGS",
                        message: "id required",
                        details: nil
                    ))
                    return
                }
                // Accept both Int and String id
                let id: Int64
                if let intId = idValue as? Int {
                    id = Int64(intId)
                } else if let strId = idValue as? String, let parsed = Int64(strId) {
                    id = parsed
                } else {
                    result(FlutterError(
                        code: "INVALID_ID",
                        message: "id must be numeric",
                        details: nil
                    ))
                    return
                }
                result(NotificationServer.shared.deleteNotification(id: id))
                
            case "clearAll":
                result(NotificationServer.shared.clearAllNotifications())
                
            // ── Read status ───────────────────────────────────────────
            case "markAsRead":
                guard let args = call.arguments as? [String: Any],
                      let idInt = args["id"] as? Int else {
                    result(FlutterError(code: "INVALID_ARGS", message: "id required", details: nil))
                    return
                }
                result(NotificationServer.shared.markAsRead(id: Int64(idInt)))
                
            case "markAllAsRead":
                NotificationServer.shared.markAllAsRead()
                result(true)
                
            case "getUnreadCount":
                result(NotificationServer.shared.unreadCount())
                
            // ── Server info ───────────────────────────────────────────
            case "getServerPort":
                result(8765)
                
            case "getDatabasePath":
                // Useful for debugging
                let appGroupID = "group.com.yourname.notificationreader"
                if let container = FileManager.default.containerURL(
                    forSecurityApplicationGroupIdentifier: appGroupID
                ) {
                    result(container.appendingPathComponent("notifications.db").path)
                } else {
                    result("unavailable")
                }
                
            default:
                result(FlutterMethodNotImplemented)
            }
        }
        
        print("[AppDelegate] ✅ MethodChannel registered: \(channelName)")
    }
    
    // MARK: - Darwin Notification Observer
    // When a new notification arrives via HTTP, we ping Flutter to refresh
    private func registerDarwinObserver() {
        CFNotificationCenterAddObserver(
            CFNotificationCenterGetDarwinNotifyCenter(),
            Unmanaged.passUnretained(self).toOpaque(),
            { _, observer, _, _, _ in
                guard let observer = observer else { return }
                let appDelegate = Unmanaged<AppDelegate>
                    .fromOpaque(observer)
                    .takeUnretainedValue()
                appDelegate.onNewNotificationArrived()
            },
            "com.yourname.notificationreader.new_notification" as CFString,
            nil,
            .deliverImmediately
        )
    }
    
    @objc private func onNewNotificationArrived() {
        DispatchQueue.main.async { [weak self] in
            guard self != nil else { return }
            if let controller = self?.window?.rootViewController as? FlutterViewController {
                let channel = FlutterMethodChannel(
                    name: self!.channelName,
                    binaryMessenger: controller.binaryMessenger
                )
                // Invoke a Flutter-side listener
                channel.invokeMethod("onNewNotification", arguments: nil)
            }
        }
    }
    
    // MARK: - Background Fetch
    override func application(
        _ application: UIApplication,
        performFetchWithCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void
    ) {
        // Keep server alive during background fetch
        if !NotificationServer.shared.isRunning {
            NotificationServer.shared.startServer()
            completionHandler(.newData)
        } else {
            completionHandler(.noData)
        }
    }
    
    // MARK: - Foreground / Background transitions
    override func applicationDidBecomeActive(_ application: UIApplication) {
        super.applicationDidBecomeActive(application)
        if !NotificationServer.shared.isRunning {
            print("[AppDelegate] Restarting server on foreground...")
            NotificationServer.shared.startServer()
        }
    }
    
    override func applicationWillResignActive(_ application: UIApplication) {
        super.applicationWillResignActive(application)
        // Server keeps running — GCDWebServer handles background automatically
        print("[AppDelegate] App backgrounding — server remains: \(NotificationServer.shared.isRunning)")
    }
    
    override func applicationWillTerminate(_ application: UIApplication) {
        super.applicationWillTerminate(application)
        NotificationServer.shared.stopServer()
    }
}
