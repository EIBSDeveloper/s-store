import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:collection/collection.dart';
import 'package:badges/badges.dart' as badges;
import 'package:flutter/services.dart';
import '../models/notification_item.dart';
import '../services/notification_bridge.dart';
import '../services/notification_db.dart';
import '../widgets/notification_card.dart';
import '../widgets/app_filter_chip.dart';
import '../screens/server_info_screen.dart';

class NotificationListScreen extends StatefulWidget {
  const NotificationListScreen({super.key});

  @override
  State<NotificationListScreen> createState() => _NotificationListScreenState();
}

class _NotificationListScreenState extends State<NotificationListScreen>
    with WidgetsBindingObserver {
  final _bridge = NotificationBridge();
  final _db = NotificationDb();

  List<NotificationItem> _allNotifications = [];
  List<NotificationItem> _filteredNotifications = [];
  List<String> _appNames = [];
  String? _selectedApp;
  bool _isLoading = true;
  bool _serverRunning = false;
  int _unreadCount = 0;

  // Grouped view
  Map<String, List<NotificationItem>> _grouped = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _bridge.setNewNotificationListener(_onNewNotification);
    _initialize();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _bridge.removeNewNotificationListener();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _loadNotifications();
      _checkServer();
    }
  }

  // ── Init ───────────────────────────────────────────────────────────────
  Future<void> _initialize() async {
    await _checkServer();
    await _loadNotifications();
  }

  Future<void> _checkServer() async {
    final running = await _bridge.isServerRunning();
    if (mounted) {
      setState(() => _serverRunning = running);
    }
  }

  // ── Load / Sync ────────────────────────────────────────────────────────
  Future<void> _loadNotifications() async {
    if (!mounted) return;
    setState(() => _isLoading = true);

    try {
      // Fetch from Swift SQLite (source of truth)
      final items = await _bridge.getAllNotifications();

      // Sync to Dart SQLite for fast local queries
      await _db.replaceAll(items);

      // Fetch grouped from local DB
      final grouped = await _db.getGroupedByApp(appFilter: _selectedApp);
      final apps = await _db.getDistinctApps();
      final unread = await _db.getUnreadCount();

      if (!mounted) return;
      setState(() {
        _allNotifications = items;
        _grouped = grouped;
        _appNames = apps;
        _unreadCount = unread;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      _showSnack('Error loading: $e', isError: true);
    }
  }

  void _onNewNotification() {
    _loadNotifications();
    // Haptic feedback for new notification
    HapticFeedback.lightImpact();
  }

  // ── Filter ─────────────────────────────────────────────────────────────
  Future<void> _applyFilter(String? appName) async {
    setState(() {
      _selectedApp = appName;
      _isLoading = true;
    });
    final grouped = await _db.getGroupedByApp(appFilter: appName);
    if (!mounted) return;
    setState(() {
      _grouped = grouped;
      _isLoading = false;
    });
  }

  // ── Actions ────────────────────────────────────────────────────────────
  Future<void> _deleteItem(int id) async {
    await _bridge.deleteById(id);
    await _db.deleteById(id);
    await _loadNotifications();
  }

  Future<void> _markRead(int id) async {
    await _bridge.markAsRead(id);
    await _db.markAsRead(id);
    final unread = await _db.getUnreadCount();
    if (!mounted) return;
    setState(() => _unreadCount = unread);
    // Refresh grouped to update card style
    final grouped = await _db.getGroupedByApp(appFilter: _selectedApp);
    if (!mounted) return;
    setState(() => _grouped = grouped);
  }

  Future<void> _markAllRead() async {
    await _bridge.markAllAsRead();
    await _db.markAllAsRead();
    await _loadNotifications();
  }

  Future<void> _clearAll() async {
    final confirmed = await showCupertinoDialog<bool>(
      context: context,
      builder: (_) => CupertinoAlertDialog(
        title: const Text('Clear All?'),
        content: const Text(
          'This will permanently delete all stored notifications.',
        ),
        actions: [
          CupertinoDialogAction(
            isDestructiveAction: true,
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Clear All'),
          ),
          CupertinoDialogAction(
            isDefaultAction: true,
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await _bridge.clearAll();
      await _db.deleteAll();
      await _loadNotifications();
      _showSnack('All notifications cleared');
    }
  }

  // ── UI Helpers ─────────────────────────────────────────────────────────
  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: isError
            ? Theme.of(context).colorScheme.error
            : Theme.of(context).colorScheme.primary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ── Build ──────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          _buildSliverAppBar(theme),
          _buildServerStatusBanner(theme),
          _buildFilterBar(theme),
          if (_isLoading)
            const SliverFillRemaining(
              child: Center(child: CircularProgressIndicator()),
            )
          else if (_grouped.isEmpty)
            _buildEmptyState(theme)
          else
            _buildNotificationList(theme),
        ],
      ),
    );
  }

  Widget _buildSliverAppBar(ThemeData theme) {
    return SliverAppBar(
      pinned: true,
      expandedHeight: 100,
      backgroundColor: theme.scaffoldBackgroundColor,
      flexibleSpace: FlexibleSpaceBar(
        titlePadding: const EdgeInsets.only(left: 20, bottom: 16),
        title: Row(
          children: [
            const Text(
              'Notifications',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.5,
              ),
            ),
            if (_unreadCount > 0) ...[
              const SizedBox(width: 10),
              badges.Badge(
                badgeContent: Text(
                  _unreadCount > 99 ? '99+' : '$_unreadCount',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                badgeStyle: badges.BadgeStyle(
                  badgeColor: theme.colorScheme.primary,
                  padding: const EdgeInsets.all(5),
                ),
                child: const SizedBox(width: 4),
              ),
            ],
          ],
        ),
      ),
      actions: [
        // Mark all read
        if (_unreadCount > 0)
          IconButton(
            icon: const Icon(Icons.done_all_rounded),
            tooltip: 'Mark all read',
            onPressed: _markAllRead,
          ),
        // Clear all
        IconButton(
          icon: const Icon(Icons.delete_sweep_rounded),
          tooltip: 'Clear all',
          onPressed: _clearAll,
        ),
        // Server info
        IconButton(
          icon: Icon(
            _serverRunning ? Icons.wifi_rounded : Icons.wifi_off_rounded,
            color: _serverRunning
                ? Colors.greenAccent
                : theme.colorScheme.error,
          ),
          tooltip: 'Server info',
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const ServerInfoScreen(),
              ),
            );
          },
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  Widget _buildServerStatusBanner(ThemeData theme) {
    if (_serverRunning) return const SliverToBoxAdapter(child: SizedBox.shrink());

    return SliverToBoxAdapter(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: theme.colorScheme.error.withOpacity(0.15),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: theme.colorScheme.error.withOpacity(0.3),
          ),
        ),
        child: Row(
          children: [
            Icon(
              Icons.warning_amber_rounded,
              color: theme.colorScheme.error,
              size: 18,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'HTTP server not running. Tap Wi-Fi icon to restart.',
                style: TextStyle(
                  color: theme.colorScheme.error,
                  fontSize: 13,
                ),
              ),
            ),
            TextButton(
              onPressed: () async {
                final ok = await _bridge.restartServer();
                setState(() => _serverRunning = ok);
              },
              child: const Text('Restart'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterBar(ThemeData theme) {
    if (_appNames.isEmpty) return const SliverToBoxAdapter(child: SizedBox.shrink());

    return SliverToBoxAdapter(
      child: SizedBox(
        height: 52,
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          scrollDirection: Axis.horizontal,
          children: [
            AppFilterChip(
              label: 'All',
              isSelected: _selectedApp == null,
              onTap: () => _applyFilter(null),
            ),
            ..._appNames.map(
              (app) => AppFilterChip(
                label: app,
                isSelected: _selectedApp == app,
                onTap: () => _applyFilter(app),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(ThemeData theme) {
    return SliverFillRemaining(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.notifications_off_outlined,
              size: 72,
              color: theme.colorScheme.onSurface.withOpacity(0.2),
            ),
            const SizedBox(height: 16),
            Text(
              'No notifications yet',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
                color: theme.colorScheme.onSurface.withOpacity(0.4),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Set up iOS Shortcuts to start\ncapturing notifications',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: theme.colorScheme.onSurface.withOpacity(0.3),
              ),
            ),
            const SizedBox(height: 24),
            OutlinedButton.icon(
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Refresh'),
              onPressed: _loadNotifications,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNotificationList(ThemeData theme) {
    final sortedApps = _grouped.keys.toList()..sort();

    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (context, index) {
          // Each "group" is: section header + notification cards
          int cursor = 0;
          for (final appName in sortedApps) {
            final items = _grouped[appName]!;
            // Section header
            if (cursor == index) {
              return _buildSectionHeader(appName, items.length, theme);
            }
            cursor++;
            // Cards
            for (int i = 0; i < items.length; i++) {
              if (cursor == index) {
                final isLast = i == items.length - 1;
                return NotificationCard(
                  item: items[i],
                  isLast: isLast,
                  onDelete: () => _deleteItem(items[i].id),
                  onTap: () {
                    if (!items[i].isRead) {
                      _markRead(items[i].id);
                    }
                  },
                );
              }
              cursor++;
            }
          }
          return null;
        },
        childCount: sortedApps.fold<int>(
          0,
          (sum, app) => sum + 1 + (_grouped[app]?.length ?? 0),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(
      String appName, int count, ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
      child: Row(
        children: [
          _buildAppIcon(appName, theme),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              appName,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.3,
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
            decoration: BoxDecoration(
              color: theme.colorScheme.primary.withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              '$count',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: theme.colorScheme.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppIcon(String appName, ThemeData theme) {
    final Map<String, String> emojiMap = {
      'YouTube':  '▶️',
      'Telegram': '✈️',
      'WhatsApp': '💬',
      'Gmail':    '📧',
      'SMS':      '💬',
      'Messages': '💬',
      'Twitter':  '🐦',
      'Instagram':'📸',
      'Slack':    '🎯',
      'Signal':   '🔐',
      'LinkedIn': '💼',
    };

    final emoji = emojiMap[appName] ?? '🔔';

    return Container(
      width: 32,
      height: 32,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Center(
        child: Text(emoji, style: const TextStyle(fontSize: 16)),
      ),
    );
  }
}