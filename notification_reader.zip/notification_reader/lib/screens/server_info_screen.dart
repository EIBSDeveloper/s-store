
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/notification_bridge.dart';

class ServerInfoScreen extends StatefulWidget {
  const ServerInfoScreen({super.key});

  @override
  State<ServerInfoScreen> createState() => _ServerInfoScreenState();
}

class _ServerInfoScreenState extends State<ServerInfoScreen> {
  final _bridge = NotificationBridge();
  bool _running = false;
  int _port = 8765;
  String _dbPath = '...';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final running = await _bridge.isServerRunning();
    final port = await _bridge.getServerPort();
    final path = await _bridge.getDatabasePath();
    if (!mounted) return;
    setState(() {
      _running = running;
      _port = port;
      _dbPath = path;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Server Info')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                _statusTile(theme),
                const SizedBox(height: 16),
                _infoTile(
                  theme,
                  icon: Icons.lan_rounded,
                  label: 'Endpoint URL',
                  value: 'http://localhost:$_port/notification',
                  copyable: true,
                ),
                const SizedBox(height: 12),
                _infoTile(
                  theme,
                  icon: Icons.health_and_safety_rounded,
                  label: 'Health Check',
                  value: 'http://localhost:$_port/ping',
                  copyable: true,
                ),
                const SizedBox(height: 12),
                _infoTile(
                  theme,
                  icon: Icons.storage_rounded,
                  label: 'Database Path',
                  value: _dbPath,
                  copyable: true,
                ),
                const SizedBox(height: 24),
                _curlExample(theme),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  icon: const Icon(Icons.restart_alt_rounded),
                  label: const Text('Restart Server'),
                  onPressed: () async {
                    final ok = await _bridge.restartServer();
                    setState(() => _running = ok);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: theme.colorScheme.primary,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.all(16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _statusTile(ThemeData theme) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _running
            ? Colors.green.withOpacity(0.15)
            : theme.colorScheme.error.withOpacity(0.15),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Icon(
            _running ? Icons.check_circle_rounded : Icons.cancel_rounded,
            color: _running ? Colors.greenAccent : theme.colorScheme.error,
            size: 28,
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _running ? 'Server Running' : 'Server Offline',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                _running ? 'Listening on port $_port' : 'Not accepting connections',
                style: TextStyle(
                  fontSize: 13,
                  color: theme.colorScheme.onSurface.withOpacity(0.6),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _infoTile(
    ThemeData theme, {
    required IconData icon,
    required String label,
    required String value,
    bool copyable = false,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: theme.colorScheme.primary),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 11,
                    color: theme.colorScheme.onSurface.withOpacity(0.5),
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 2),
                SelectableText(
                  value,
                  style: const TextStyle(
                    fontSize: 13,
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ),
          ),
          if (copyable)
            IconButton(
              icon: const Icon(Icons.copy_rounded, size: 16),
              onPressed: () {
                Clipboard.setData(ClipboardData(text: value));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Copied to clipboard'),
                    duration: Duration(seconds: 1),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  Widget _curlExample(ThemeData theme) {
    const curl = '''curl -X POST http://localhost:8765/notification \\
  -H "Content-Type: application/json" \\
  -d '{
    "app_name": "TestApp",
    "title": "Hello World",
    "body": "This is a test notification",
    "timestamp": "2024-01-15T10:30:00Z"
  }' ''';

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Test with cURL',
                style: TextStyle(
                  fontSize: 12,
                  color: theme.colorScheme.primary,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: () {
                  Clipboard.setData(const ClipboardData(text: curl));
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('cURL command copied'),
                      duration: Duration(seconds: 1),
                    ),
                  );
                },
                child: Icon(
                  Icons.copy_rounded,
                  size: 16,
                  color: theme.colorScheme.onSurface.withOpacity(0.5),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          SelectableText(
            curl,
            style: const TextStyle(
              fontFamily: 'monospace',
              fontSize: 11,
              height: 1.6,
            ),
          ),
        ],
      ),
    );
  }
}