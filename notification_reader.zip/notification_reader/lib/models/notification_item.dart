class NotificationItem {
  final int id;
  final String appName;
  final String bundleId;
  final String title;
  final String body;
  final String timestamp;
  final bool isRead;

  const NotificationItem({
    required this.id,
    required this.appName,
    required this.bundleId,
    required this.title,
    required this.body,
    required this.timestamp,
    required this.isRead,
  });

  factory NotificationItem.fromJson(Map<String, dynamic> json) {
    return NotificationItem(
      id: _parseInt(json['id']),
      appName: (json['app_name'] as String?) ?? 'Unknown',
      bundleId: (json['bundle_id'] as String?) ?? '',
      title: (json['title'] as String?) ?? '',
      body: (json['body'] as String?) ?? '',
      timestamp: (json['timestamp'] as String?) ?? '',
      isRead: _parseBool(json['is_read']),
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'app_name': appName,
    'bundle_id': bundleId,
    'title': title,
    'body': body,
    'timestamp': timestamp,
    'is_read': isRead ? 1 : 0,
  };

  NotificationItem copyWith({
    int? id,
    String? appName,
    String? bundleId,
    String? title,
    String? body,
    String? timestamp,
    bool? isRead,
  }) {
    return NotificationItem(
      id: id ?? this.id,
      appName: appName ?? this.appName,
      bundleId: bundleId ?? this.bundleId,
      title: title ?? this.title,
      body: body ?? this.body,
      timestamp: timestamp ?? this.timestamp,
      isRead: isRead ?? this.isRead,
    );
  }

  DateTime? get parsedDate {
    try {
      return DateTime.parse(timestamp).toLocal();
    } catch (_) {
      return null;
    }
  }

  static int _parseInt(dynamic val) {
    if (val == null) return 0;
    if (val is int) return val;
    return int.tryParse(val.toString()) ?? 0;
  }

  static bool _parseBool(dynamic val) {
    if (val == null) return false;
    if (val is bool) return val;
    if (val is int) return val != 0;
    return false;
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is NotificationItem &&
          runtimeType == other.runtimeType &&
          id == other.id;

  @override
  int get hashCode => id.hashCode;

  @override
  String toString() =>
      'NotificationItem(id=$id, app=$appName, title=$title)';
}