import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/notification_item.dart';

/// Bridge between Flutter/Dart and the Swift native layer.
/// All communication goes through the MethodChannel.
class NotificationBridge {
  static const _channelName =
      'com.yourname.notificationreader/notifications';

  static const _channel = MethodChannel(_channelName);

  // Singleton
  static final NotificationBridge _instance = NotificationBridge._internal();
  factory NotificationBridge() => _instance;
  NotificationBridge._internal();

  // ── Listener for real-time updates pushed by Swift ──────────────────
  /// Register a callback that fires whenever a new notification arrives
  /// via the HTTP server while the app is open.
  void setNewNotificationListener(VoidCallback onNew) {
    _channel.setMethodCallHandler((call) async {
      if (call.method == 'onNewNotification') {
        onNew();
      }
    });
  }

  void removeNewNotificationListener() {
    _channel.setMethodCallHandler(null);
  }

  // ── Server ───────────────────────────────────────────────────────────
  /// Returns true if the GCDWebServer is currently listening.
  Future<bool> isServerRunning() async {
    try {
      final result = await _channel.invokeMethod<bool>('isServerRunning');
      return result ?? false;
    } on PlatformException catch (e) {
      _log('isServerRunning error: ${e.message}');
      return false;
    }
  }

  /// Stops then restarts the HTTP server. Returns new running state.
  Future<bool> restartServer() async {
    try {
      final result = await _channel.invokeMethod<bool>('restartServer');
      return result ?? false;
    } on PlatformException catch (e) {
      _log('restartServer error: ${e.message}');
      return false;
    }
  }

  Future<int> getServerPort() async {
    try {
      final result = await _channel.invokeMethod<int>('getServerPort');
      return result ?? 8765;
    } catch (_) {
      return 8765;
    }
  }

  Future<String> getDatabasePath() async {
    try {
      final result = await _channel.invokeMethod<String>('getDatabasePath');
      return result ?? 'unknown';
    } catch (_) {
      return 'unknown';
    }
  }

  // ── Fetch ────────────────────────────────────────────────────────────
  /// Fetches ALL notifications from the Swift-managed SQLite database.
  /// Returns them as a list of [NotificationItem].
  Future<List<NotificationItem>> getAllNotifications() async {
    try {
      final jsonString =
          await _channel.invokeMethod<String>('getAllNotifications');
      if (jsonString == null || jsonString.isEmpty || jsonString == '[]') {
        return [];
      }

      final List<dynamic> decoded = jsonDecode(jsonString) as List<dynamic>;
      return decoded
          .map((e) => NotificationItem.fromJson(e as Map<String, dynamic>))
          .toList();
    } on PlatformException catch (e) {
      _log('getAllNotifications error: ${e.message}');
      return [];
    } catch (e) {
      _log('getAllNotifications parse error: $e');
      return [];
    }
  }

  // ── Delete ───────────────────────────────────────────────────────────
  /// Deletes a single notification by its SQLite row id.
  Future<bool> deleteById(int id) async {
    try {
      final result = await _channel.invokeMethod<bool>(
        'deleteById',
        {'id': id},
      );
      return result ?? false;
    } on PlatformException catch (e) {
      _log('deleteById error: ${e.message}');
      return false;
    }
  }

  /// Deletes ALL notifications. Returns success flag.
  Future<bool> clearAll() async {
    try {
      final result = await _channel.invokeMethod<bool>('clearAll');
      return result ?? false;
    } on PlatformException catch (e) {
      _log('clearAll error: ${e.message}');
      return false;
    }
  }

  // ── Read status ───────────────────────────────────────────────────────
  Future<bool> markAsRead(int id) async {
    try {
      final result =
          await _channel.invokeMethod<bool>('markAsRead', {'id': id});
      return result ?? false;
    } on PlatformException catch (e) {
      _log('markAsRead error: ${e.message}');
      return false;
    }
  }

  Future<bool> markAllAsRead() async {
    try {
      final result = await _channel.invokeMethod<bool>('markAllAsRead');
      return result ?? false;
    } on PlatformException catch (e) {
      _log('markAllAsRead error: ${e.message}');
      return false;
    }
  }

  Future<int> getUnreadCount() async {
    try {
      final result = await _channel.invokeMethod<int>('getUnreadCount');
      return result ?? 0;
    } on PlatformException catch (e) {
      _log('getUnreadCount error: ${e.message}');
      return 0;
    }
  }

  // ── Utility ───────────────────────────────────────────────────────────
  void _log(String msg) {
    // ignore: avoid_print
    print('[NotificationBridge] $msg');
  }
}