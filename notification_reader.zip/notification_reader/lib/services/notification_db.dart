import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import '../models/notification_item.dart';

/// Pure Dart/sqflite storage layer.
/// This runs in parallel to the Swift SQLite — it's a Dart-side cache
/// that Flutter uses directly for UI rendering (avoids MethodChannel on
/// every scroll). Sync it from Swift with [syncFromBridge].
class NotificationDb {
  static const _dbName = 'notifications_flutter.db';
  static const _tableName = 'notifications';
  static const _version = 2;

  static final NotificationDb _instance = NotificationDb._internal();
  factory NotificationDb() => _instance;
  NotificationDb._internal();

  Database? _db;

  // ── Open ──────────────────────────────────────────────────────────────
  Future<Database> get database async {
    if (_db != null && _db!.isOpen) return _db!;
    _db = await _openDb();
    return _db!;
  }

  Future<Database> _openDb() async {
    final dbPath = await getDatabasesPath();
    final path = p.join(dbPath, _dbName);

    return openDatabase(
      path,
      version: _version,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
      onConfigure: (db) async {
        await db.execute('PRAGMA journal_mode=WAL');
        await db.execute('PRAGMA foreign_keys=ON');
      },
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS $_tableName (
        id          INTEGER PRIMARY KEY,
        app_name    TEXT    NOT NULL DEFAULT '',
        bundle_id   TEXT             DEFAULT '',
        title       TEXT    NOT NULL DEFAULT '',
        body        TEXT    NOT NULL DEFAULT '',
        timestamp   TEXT    NOT NULL DEFAULT '',
        is_read     INTEGER NOT NULL DEFAULT 0,
        created_at  INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
      )
    ''');

    await db.execute('''
      CREATE INDEX IF NOT EXISTS idx_app_name
      ON $_tableName(app_name)
    ''');

    await db.execute('''
      CREATE INDEX IF NOT EXISTS idx_timestamp
      ON $_tableName(timestamp DESC)
    ''');
  }

  Future<void> _onUpgrade(Database db, int oldV, int newV) async {
    if (oldV < 2) {
      // Add bundle_id column if upgrading from v1
      try {
        await db.execute(
          'ALTER TABLE $_tableName ADD COLUMN bundle_id TEXT DEFAULT ""',
        );
      } catch (_) {
        // column may already exist
      }
    }
  }

  // ── CRUD ──────────────────────────────────────────────────────────────

  /// Insert or replace a notification.
  Future<int> insertOrReplace(NotificationItem item) async {
    final db = await database;
    return db.insert(
      _tableName,
      item.toJson(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  /// Insert a batch of notifications efficiently.
  Future<void> insertAll(List<NotificationItem> items) async {
    if (items.isEmpty) return;
    final db = await database;
    final batch = db.batch();
    for (final item in items) {
      batch.insert(
        _tableName,
        item.toJson(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
    await batch.commit(noResult: true);
  }

  /// Returns ALL notifications ordered by timestamp descending.
  Future<List<NotificationItem>> getAll({String? appFilter}) async {
    final db = await database;
    List<Map<String, dynamic>> rows;

    if (appFilter != null && appFilter.isNotEmpty) {
      rows = await db.query(
        _tableName,
        where: 'app_name = ?',
        whereArgs: [appFilter],
        orderBy: 'timestamp DESC',
      );
    } else {
      rows = await db.query(
        _tableName,
        orderBy: 'timestamp DESC',
      );
    }

    return rows.map(NotificationItem.fromJson).toList();
  }

  /// Returns a map of appName → list of notifications (grouped).
  Future<Map<String, List<NotificationItem>>> getGroupedByApp({
    String? appFilter,
  }) async {
    final all = await getAll(appFilter: appFilter);
    final Map<String, List<NotificationItem>> grouped = {};
    for (final item in all) {
      grouped.putIfAbsent(item.appName, () => []).add(item);
    }
    return grouped;
  }

  /// Returns all unique app names.
  Future<List<String>> getDistinctApps() async {
    final db = await database;
    final rows = await db.rawQuery(
      'SELECT DISTINCT app_name FROM $_tableName ORDER BY app_name ASC',
    );
    return rows.map((r) => r['app_name'] as String).toList();
  }

  /// Returns count of unread notifications.
  Future<int> getUnreadCount() async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT COUNT(*) as cnt FROM $_tableName WHERE is_read = 0',
    );
    return Sqflite.firstIntValue(result) ?? 0;
  }

  /// Returns count per app for badge display.
  Future<Map<String, int>> getUnreadCountPerApp() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT app_name, COUNT(*) as cnt
      FROM $_tableName
      WHERE is_read = 0
      GROUP BY app_name
    ''');
    return {for (final r in rows) r['app_name'] as String: r['cnt'] as int};
  }

  Future<bool> deleteById(int id) async {
    final db = await database;
    final count = await db.delete(
      _tableName,
      where: 'id = ?',
      whereArgs: [id],
    );
    return count > 0;
  }

  Future<bool> deleteAll() async {
    final db = await database;
    await db.delete(_tableName);
    return true;
  }

  Future<bool> markAsRead(int id) async {
    final db = await database;
    final count = await db.update(
      _tableName,
      {'is_read': 1},
      where: 'id = ?',
      whereArgs: [id],
    );
    return count > 0;
  }

  Future<void> markAllAsRead() async {
    final db = await database;
    await db.update(_tableName, {'is_read': 1});
  }

  /// Replaces all local data with the given list (used for full sync from Swift).
  Future<void> replaceAll(List<NotificationItem> items) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete(_tableName);
      final batch = txn.batch();
      for (final item in items) {
        batch.insert(
          _tableName,
          item.toJson(),
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
      await batch.commit(noResult: true);
    });
  }

  Future<void> close() async {
    if (_db != null && _db!.isOpen) {
      await _db!.close();
      _db = null;
    }
  }
}