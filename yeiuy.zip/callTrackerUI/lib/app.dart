import 'package:calltrackerui/src/app/bindings/app_binding.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'src/app/modules/splash/views/screens/splash.dart';

class App extends StatelessWidget {
  App({super.key});

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;
    return GetMaterialApp(
      home: Splashscreen(),
      theme: ThemeData(
        textTheme: GoogleFonts.nunitoTextTheme().copyWith(
          // Display / Large titles
          displayLarge: GoogleFonts.nunito(
            fontSize: 48,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.5,
          ),
          displayMedium: GoogleFonts.nunito(
            fontSize: 40,
            fontWeight: FontWeight.w600,
            letterSpacing: -0.25,
          ),
          displaySmall: GoogleFonts.nunito(
            fontSize: 32,
            fontWeight: FontWeight.w600,
          ),

          // Headlines
          headlineLarge: GoogleFonts.nunito(
            fontSize: 28,
            fontWeight: FontWeight.w700,
          ),
          headlineMedium: GoogleFonts.nunito(
            fontSize: 24,
            fontWeight: FontWeight.w600,
          ),
          headlineSmall: GoogleFonts.nunito(
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),

          // Titles
          titleLarge: GoogleFonts.nunito(
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
          titleMedium: GoogleFonts.nunito(
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
          titleSmall: GoogleFonts.nunito(
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),

          // Body Text
          bodyLarge: GoogleFonts.nunito(
            fontSize: 16,
            fontWeight: FontWeight.w400,
            height: 1.4,
          ),
          bodyMedium: GoogleFonts.nunito(
            fontSize: 14,
            fontWeight: FontWeight.w400,
            height: 1.4,
          ),
          bodySmall: GoogleFonts.nunito(
            fontSize: 10,
            fontWeight: FontWeight.w400,
            // height: 1.4,
          ),

          // Labels (Buttons, captions)
          labelLarge: GoogleFonts.nunito(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
          labelMedium: GoogleFonts.nunito(
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
          labelSmall: GoogleFonts.nunito(
            fontSize: 10,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
      debugShowCheckedModeBanner: false,
      initialBinding: AppBinding(),
    );
  }
}
