import 'package:calltrackerui/src/core/app_colors.dart';
import 'package:flutter/material.dart';

class AppStyle {
  static const double iconSizelarge = 25;
  static const double iconSize = 20;
  static const double iconSize2 = 15;
  static const double iconSize3 = 10;

  static const double borderRadiusBox = 10;
  static const double borderRadiusClip = 5;
  static const double borderRadiusBottom = 50;
  static const BoxDecoration inputDecoration = BoxDecoration(
    borderRadius: BorderRadius.all(Radius.circular(borderRadiusBox)),
  );
  static BoxDecoration decoration = BoxDecoration(
    color: AppColors.card,
    borderRadius: BorderRadius.circular(12),
    boxShadow: [
      BoxShadow(
        color: Colors.black.withOpacity(0.03),
        blurRadius: 8,
        offset: const Offset(0, 4),
      ),
    ],
  );
  static const List<BoxShadow> boxShadow = [
    BoxShadow(
      color: Color.fromRGBO(0, 0, 0, 0.05),
      blurRadius: 2,
      spreadRadius: 0,
      offset: Offset(0, 1),
    ),
  ];
}
