import 'package:flutter/material.dart';

class AppText {
  static TextStyle heading(BuildContext context) => 
      TextStyle(fontSize: MediaQuery.of(context).size.width * 0.06, fontWeight: FontWeight.bold);

  static TextStyle body(BuildContext context) =>
      TextStyle(fontSize: MediaQuery.of(context).size.width * 0.04, color: Colors.black87);
}
