import 'package:calltrackerui/src/app/modules/bottom/controller/bottom_controller.dart';
import 'package:calltrackerui/src/app/modules/callLogs/controller/callLog_detailscontroller.dart';
import 'package:calltrackerui/src/app/modules/callLogs/controller/callLogcontroller.dart';
import 'package:calltrackerui/src/app/modules/dashboard/controller/dashboard_controller.dart';
import 'package:get/get.dart';

import '../controller/app_controller.dart';
import '../modules/bottombar/contoller/bottombar_contoller.dart';
import '../modules/onboading/onboarding_controller.dart';
import '../modules/payment_tracker/controller/customercontroller.dart';
import '../modules/payment_tracker/controller/paymentcontroller.dart';
import '../modules/payment_tracker/controller/schedulecontroller.dart';
import '../modules/splash/controller/splashcontroller.dart';
 

class AppBinding implements Bindings {
  @override
  void dependencies() {
    Get.put(AppDataController(), permanent: true);
    Get.lazyPut(() => SplashController(), fenix: true);
    Get.lazyPut(() => BottomNavController(), fenix: true);
    Get.lazyPut(() => DashboardController(), fenix: true);
    Get.lazyPut(() => CallLogsController(), fenix: true); 
    Get.lazyPut(() => OnboardingController(), fenix: true);
    Get.lazyPut(() => BottomBarContoller(), fenix: true);
    Get.lazyPut(() => CallDetailsController(), fenix: true);
    Get.lazyPut(() => CustomerController(), fenix: true);
    Get.lazyPut(() => CallDetailsController(), fenix: true);
    Get.lazyPut(() => SchedulesController(), fenix: true);
    Get.lazyPut(() => Paymentcontroller(), fenix: true);
  }
}
