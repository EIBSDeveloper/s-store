 
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import '../modules/note_model.dart';
import '../repository/note_repository.dart';
import 'notes_controller.dart';

class NoteDetailController extends GetxController {
  final NoteRepository repository =Get.find();
  final Rx<NoteModel?> existingNote =  Rx<NoteModel?> (null) ;


  final RxBool isLoading = false.obs;
  final RxBool isEditing = false.obs;
  final RxString title = ''.obs;
  final RxString content = ''.obs;
  final RxString label = 'Welcome'.obs;
  final RxString error = ''.obs;

  final titleController = TextEditingController();
  final contentController = TextEditingController();

  bool get isNewNote => existingNote.value == null;

  @override
  void onInit() {
    super.onInit();

   NoteModel? note =Get.arguments;
if(note != null){
  existingNote.value =note;
}
    
    if (existingNote.value != null) {
      titleController.text = existingNote.value!.title;
      contentController.text = existingNote.value!.content;
      title(existingNote.value!.title);
      content(existingNote.value!.content);
      label(existingNote.value!.label);
    }
  }

  void toggleEditMode() {
    isEditing.toggle();
  }

  void updateLabel(String newLabel) {
    label(newLabel);
  }

  Future<void> saveNote() async {
    if (!_validateForm()) return;

    try {
      isLoading(true);
      
      final note = NoteModel(
        id: existingNote.value?.id ?? '',
        title: titleController.text.trim(),
        content: contentController.text.trim(),
        label: label.value,
        createdAt: existingNote.value?.createdAt ?? DateTime.now(),
        updatedAt: DateTime.now(),
      );

      if (isNewNote) {
        await Get.find<NotesController>().createNote(note);
      } else {
        await Get.find<NotesController>().updateNote(note);
      }
    } catch (e) {
      showErrorToast('Failed to save note');
    } finally {
      isLoading(false);
    }
  }

  Future<void> deleteNote() async {
    if (existingNote.value != null) {
      await Get.find<NotesController>().deleteNote(existingNote.value!.id);
    }
  }

  bool _validateForm() {
    if (titleController.text.trim().isEmpty) {
      showErrorToast('Please enter a title');
      return false;
    }
    
    if (titleController.text.trim().length < 3) {
      showErrorToast('Title must be at least 3 characters');
      return false;
    }
    
    if (contentController.text.trim().isEmpty) {
      showErrorToast('Please enter note content');
      return false;
    }
    
    if (contentController.text.trim().length < 5) {
      showErrorToast('Content must be at least 5 characters');
      return false;
    }
    
    return true;
  }

  void showErrorToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.red,
      textColor: Colors.white,
    );
  }

  @override
  void onClose() {
    titleController.dispose();
    contentController.dispose();
    super.onClose();
  }
}