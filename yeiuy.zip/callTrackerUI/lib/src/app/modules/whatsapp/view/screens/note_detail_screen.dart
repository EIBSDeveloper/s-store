 
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../utils/routes/app_pages.dart';
import '../../../../widgets/custom_app_bar.dart';
import '../../../../widgets/input_card_style.dart';
import '../../../../widgets/title_text.dart';
import '../../controller/note_detail_controller.dart';
import '../widget/message_lable_sheet.dart';

class NoteDetailScreen extends GetView<NoteDetailController> {
  const NoteDetailScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: CustomAppBar(
        titleText: controller.isNewNote ? 'add_note'.tr : 'note_detail'.tr,
        actions: [
          if (controller.isNewNote)
            IconButton(
              color: Get.theme.primaryColor,
              icon: const Icon(Icons.save),
              onPressed: controller.saveNote,
            )
          else
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: controller.toggleEditMode,
                ),

                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () {
                    Get.dialog(
                      AlertDialog(
                        title: Text('delete_note'.tr),
                        content: Text('delete_confirmation'.tr),
                        actions: [
                          TextButton(
                            onPressed: Get.back,
                            child: Text('cancel'.tr),
                          ),
                          TextButton(
                            onPressed: () {
                              Get.back();
                              controller.deleteNote();
                            },
                            child: Text('delete'.tr),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Label and Date Header
            Obx(() => Row(
                children: [
                  const TitleText("Lable :"), const SizedBox(width: 10),
                  // Label Chip
                  InputChip(
                    label: Text(controller.label.value),
                    onPressed: () {
                      Get.bottomSheet(
                        MessageLableSheet(controller: controller),
                      );
                    },
                  ),
                ],
              )),
            const SizedBox(height: 16),

            // Title Field
            InputCardStyle(
              child: TextFormField(
                controller: controller.titleController,
                enabled: controller.isNewNote || controller.isEditing.value,
                decoration: InputDecoration(
                  labelText: 'title'.tr,
                  border: InputBorder.none,
                ),
                // style: Get.theme.textTheme.titleLarge?.copyWith(
                //   fontWeight: FontWeight.bold,
                // ),
                // maxLines: 2,
              ),
            ),
            const SizedBox(height: 16),

            InputCardStyle(
              child: TextFormField(
                controller: controller.contentController,
                enabled: controller.isNewNote || controller.isEditing.value,
                decoration: InputDecoration(
                  labelText: 'content'.tr,
                  border: InputBorder.none,
                  alignLabelWithHint: true,
                ),
                style: Get.theme.textTheme.bodyLarge,
                maxLines: 3,
                // expands: true,
                textAlignVertical: TextAlignVertical.top,
              ),
            ),
          ],
        ),
      ),

      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Get.toNamed(AppPages.bot);
        },
        child: const Icon(Icons.auto_awesome),
      ),
    );
}
