// lib/modules/dashboard/view/dashboard_screen.dart
import 'package:calltrackerui/src/app/modules/dashboard/controller/dashboard_controller.dart';
import 'package:calltrackerui/src/app/modules/dashboard/views/widgets/pie_chart.dart';
import 'package:calltrackerui/src/app/modules/dashboard/views/widgets/recent_activity.dart';
import 'package:calltrackerui/src/app/modules/dashboard/views/widgets/stat_card.dart';
import 'package:calltrackerui/src/app/modules/dashboard/views/widgets/weekly_graph.dart';
import 'package:calltrackerui/src/core/app_colors.dart';
import 'package:calltrackerui/src/core/app_style.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';
import 'package:lottie/lottie.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';
import '../../../bottombar/views/widgets/nav_bar_item.dart';
import '../../../lead/views/screens/leadProfilescreen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with SingleTickerProviderStateMixin {
  final DashboardController controller = Get.find();
  late AnimationController _controller;
  late Animation<double> _countAnimation;

  double _oldValue = 0;
  double _newValue = 0;
  String? _suffixPart;

  // Tilt effect variables
  double _rotateX = 0.0;
  double _rotateY = 0.0;
  double _scale = 1.0;

  @override
  void initState() {
    super.initState();
    _parseValue();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _countAnimation = Tween<double>(
      begin: 0,
      end: _newValue,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _controller.forward();
  }

  void _parseValue() {
    final parts = controller.calls.value.split('/');
    if (parts.length == 2) {
      _newValue = double.tryParse(parts[0].trim()) ?? 0;
      _suffixPart = '/ ${parts[1].trim()}';
    } else {
      _newValue =
          double.tryParse(
            controller.calls.value.replaceAll(RegExp('[^0-9.]'), ''),
          ) ??
          0;
      _suffixPart = null;
    }
  }

  @override
  void didUpdateWidget(covariant DashboardScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (controller.calls.value != 5) {
      _oldValue = _newValue;
      _parseValue();

      _countAnimation = Tween<double>(
        begin: _oldValue,
        end: _newValue,
      ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

      _controller
        ..reset()
        ..forward();
    }
  }

  void _onPanUpdate(DragUpdateDetails details, Size size) {
    setState(() {
      // Calculate tilt based on pointer position
      _rotateY = (details.localPosition.dx - size.width / 2) / size.width * 0.3;
      _rotateX =
          (details.localPosition.dy - size.height / 2) / size.height * -0.3;
      _scale = 1.05;
    });
  }

  void _onPanEnd(DragEndDetails details) {
    setState(() {
      _rotateX = 0.0;
      _rotateY = 0.0;
      _scale = 1.0;
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeTitle = Get.textTheme.titleLarge!;
    final bodyMedium = Get.textTheme.bodyMedium!;
    final bodySmall = Get.textTheme.bodySmall!;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            // header
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              height: 50,
              color: AppColors.background,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    onTap: () {
                      Get.to(LeadProfileScreen());
                    },
                    child: Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(999),
                        image: const DecorationImage(
                          fit: BoxFit.cover,
                          image: NetworkImage(
                            "https://lh3.googleusercontent.com/aida-public/AB6AXuC_QyOUmrO3QXMKlQyKGRC_8p3CKPTVcnuyqwzdmJP-F7LDqeNGgrB_lrYYoG9B31c4F0eUivl0_-aZCnHKsZzG0RL5yuK9X6h1QLaA2220oukmqBLIpGXpph5cNz69Ckl4HIHzgiHRerO0ML4w6wC1hwJVYvWbd9J9ChwdXhGcoVsV9T0AWc5r493Yc0re91gOIr_BqGDj9OzYdjfFZ2Is4lyXkp7TiaqonwH75bzmgGQnrH8KY-PFq-1vQcU3rOYvutBH9hCmBFqW",
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                   Text("Dashboard", style: themeTitle),
                  Spacer(),
                  IconButton(
                    onPressed: () {},
                    icon: HugeIcon(
                      icon: HugeIcons.strokeRoundedNotification01,
                      // color: widget.backgroundColor,
                      size: AppStyle.iconSizelarge,
                    ),
                    color: AppColors.textDark,
                  ),
                ],
              ),
            ),
            SizedBox(height: 5),
            // body
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                physics: const BouncingScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Hero banner + CTA
                    Container(
                      height: 150,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppColors.primary,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(left: 8),
                                  child: Text(
                                    "WelCome!",
                                    style: themeTitle.copyWith(
                                      color: AppColors.textLight,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8),
                                  child: Text(
                                    "Success is the sum of small efforts repeated day in and day out",
                                    style: bodyMedium.copyWith(
                                      height: 0.9,
                                      color: AppColors.textLight.withOpacity(
                                        0.8,
                                      ),
                                    ),
                                  ),
                                ),
                                const Spacer(),
                                Container(
                                  width: double.infinity,
                                  padding: EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color: const Color.fromARGB(
                                      47,
                                      255,
                                      254,
                                      254,
                                    ),
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      RichText(
                                        text: TextSpan(
                                          children: [
                                            TextSpan(
                                              text: "Total Talk ",
                                              style: Get
                                                  .theme
                                                  .textTheme
                                                  .bodyMedium
                                                  ?.copyWith(
                                                    color: Colors.white,
                                                  ),
                                            ),

                                            TextSpan(
                                              text: "16.9",
                                              style: Get
                                                  .theme
                                                  .textTheme
                                                  .titleLarge!
                                                  .copyWith(
                                                    color: Colors.white,
                                                    fontWeight: FontWeight.w900,

                                                    shadows: [
                                                      Shadow(
                                                        color: Colors.black
                                                            .withOpacity(0.3),
                                                        offset: const Offset(
                                                          0,
                                                          2,
                                                        ),
                                                        blurRadius: 4,
                                                      ),
                                                    ],
                                                  ),
                                            ),
                                            TextSpan(
                                              text: "hrs",
                                              style: Get
                                                  .theme
                                                  .textTheme
                                                  .bodySmall
                                                  ?.copyWith(
                                                    color: Colors.white,
                                                  ),
                                            ),
                                            TextSpan(
                                              text: " - ",
                                              style: Get
                                                  .theme
                                                  .textTheme
                                                  .titleLarge!
                                                  .copyWith(
                                                    color: Colors.white,
                                                    fontWeight: FontWeight.w900,

                                                    // shadows: [
                                                    //   Shadow(
                                                    //     color: Colors.black
                                                    //         .withOpacity(0.3),
                                                    //     offset: const Offset(
                                                    //       0,
                                                    //       2,
                                                    //     ),
                                                    //     blurRadius: 4,
                                                    //   ),
                                                    // ],
                                                  ),
                                            ),
                                            TextSpan(
                                              text: "140",
                                              style: Get
                                                  .theme
                                                  .textTheme
                                                  .titleLarge!
                                                  .copyWith(
                                                    color: Colors.white,
                                                    fontWeight: FontWeight.w900,

                                                    shadows: [
                                                      Shadow(
                                                        color: Colors.black
                                                            .withOpacity(0.3),
                                                        offset: const Offset(
                                                          0,
                                                          2,
                                                        ),
                                                        blurRadius: 4,
                                                      ),
                                                    ],
                                                  ),
                                            ),
                                            TextSpan(
                                              text: "Calls",
                                              style: Get
                                                  .theme
                                                  .textTheme
                                                  .bodySmall
                                                  ?.copyWith(
                                                    color: Colors.white,
                                                  ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      // Divider(),
                                      // RichText(
                                      //   text: TextSpan(
                                      //     children: [

                                      //     ],
                                      //   ),
                                      // ),
                                    ],
                                  ),

                                  // Text(,style: bodyMedium.copyWith(
                                  //   color: AppColors.textLight ,
                                  // ),),
                                ),
                              ],
                            ),
                          ),

                          Column(
                            children: [
                              //  Text(
                              //   "performance",
                              //   style: Get.theme.textTheme.bodySmall?.copyWith(
                              //     color: AppColors.textLight.withAlpha(220),
                              //   ),
                              // ),
                              Flexible(
                                child: SizedBox(
                                  width: 130,
                                  // height: 130,
                                  child: SfRadialGauge(
                                    axes: <RadialAxis>[
                                      RadialAxis(
                                        minimum: 0,
                                        maximum: 100,
                                        showLabels: false,
                                        showTicks: false,
                                        pointers: <GaugePointer>[
                                          RangePointer(
                                            value: 30,
                                            cornerStyle: CornerStyle.bothCurve,
                                            width: 0.2,
                                            color: Colors.green,
                                            sizeUnit: GaugeSizeUnit.factor,
                                          ),
                                          // RangePointer(
                                          //   value: 50,
                                          //   cornerStyle: CornerStyle.bothCurve,
                                          //   width: 0.2,
                                          //   sizeUnit: GaugeSizeUnit.factor,
                                          // ),
                                        ],
                                        annotations: <GaugeAnnotation>[
                                          GaugeAnnotation(
                                            positionFactor: 0.1,
                                            angle: 90,
                                            widget: Padding(
                                              padding: const EdgeInsets.all(30),
                                              child: Lottie.network(
                                                'https://raw.githubusercontent.com/EIBSDeveloper/animation/refs/heads/main/amazing-emoji.json',
                                              ),
                                            ),
                                          ),
                                        ],
                                        axisLineStyle: AxisLineStyle(
                                          thickness: 0.2,
                                          cornerStyle: CornerStyle.bothCurve,
                                          color: Color.fromARGB(
                                            255,
                                            255,
                                            255,
                                            255,
                                          ),
                                          thicknessUnit: GaugeSizeUnit.factor,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),

                              // const SizedBox(height: 4),

                              // Animated count with premium styling
                              RichText(
                                text: TextSpan(
                                  children: [
                                    TextSpan(
                                      text: "20",
                                      style: Get.theme.textTheme.titleLarge!
                                          .copyWith(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w900,

                                            shadows: [
                                              Shadow(
                                                color: Colors.black.withOpacity(
                                                  0.3,
                                                ),
                                                offset: const Offset(0, 2),
                                                blurRadius: 4,
                                              ),
                                            ],
                                          ),
                                    ),
                                    TextSpan(
                                      text: "/",
                                      style: Get.theme.textTheme.titleLarge!
                                          .copyWith(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w900,

                                            shadows: [
                                              Shadow(
                                                color: const Color.fromARGB(
                                                  255,
                                                  107,
                                                  107,
                                                  107,
                                                ),
                                                offset: const Offset(0, 2),
                                                blurRadius: 4,
                                              ),
                                            ],
                                          ),
                                    ),
                                    if (_suffixPart != null)
                                      TextSpan(
                                        text: '100',
                                        style: Get.theme.textTheme.titleMedium!
                                            .copyWith(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w600,
                                            ),
                                      ),
                                    TextSpan(
                                      text: 'calls',
                                      style: Get.theme.textTheme.bodySmall!
                                          .copyWith(
                                            color: Colors.white.withAlpha(220),
                                            fontWeight: FontWeight.w600,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          // Container(
                          //   width: 100,
                          //   height: 50,
                          //   child: CheckInOutSwitch(
                          //     initialValue: false,
                          //     onChanged: (value) {
                          //       if (value) {
                          //         ScaffoldMessenger.of(context).showSnackBar(
                          //           const SnackBar(
                          //             content: Text("You have checked in!"),
                          //           ),
                          //         );
                          //       } else {
                          //         ScaffoldMessenger.of(context).showSnackBar(
                          //           const SnackBar(
                          //             content: Text("You have checked out!"),
                          //           ),
                          //         );
                          //       }
                          //     },
                          //   ),
                          // ),
                          // ElevatedButton(
                          //   onPressed: () {},
                          //   style: ElevatedButton.styleFrom(
                          //     backgroundColor: AppColors.primary,
                          //     shape: RoundedRectangleBorder(
                          //       borderRadius: BorderRadius.circular(999),
                          //     ),
                          //     padding: const EdgeInsets.symmetric(
                          //       horizontal: 16,
                          //       vertical: 10,
                          //     ),
                          //   ),
                          //   child: Text(
                          //     "View Details",
                          //     style: bodyMedium.copyWith(color: Colors.white),
                          //   ),
                          // ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 8),

                    // Stats grid (2x2)
                    Row(
                      children: [
                        Expanded(
                          child: StatCard.animated(
                            title: "Outgoing",
                            icon: Icons.call_made,
                            color: AppColors.primary,
                            countRx: controller.outgoing,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: StatCard.animated(
                            title: "Incoming",
                            icon: Icons.call_received,
                            color: AppColors.secondary,
                            countRx: controller.incoming,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: StatCard.animated(
                            title: "Missed",
                            icon: Icons.call_missed,
                            color: AppColors.tertiary,
                            countRx: controller.missed,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: StatCard.animated(
                            title: "Rejected",
                            icon: Icons.call_missed_outlined,
                            color: AppColors.danger,
                            countRx: controller.rejected,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 8),

                    // // donut + legend
                    // Container(
                    //   padding: const EdgeInsets.all(16),
                    //   decoration: BoxDecoration(
                    //     color: AppColors.card,
                    //     borderRadius: BorderRadius.circular(12),
                    //     boxShadow: [
                    //       BoxShadow(
                    //         color: Colors.black.withOpacity(0.03),
                    //         blurRadius: 8,
                    //         offset: const Offset(0, 4),
                    //       ),
                    //     ],
                    //   ),
                    //   child: Column(
                    //     children: [
                    //       Row(
                    //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //         children: [
                    //           Column(
                    //             crossAxisAlignment: CrossAxisAlignment.start,
                    //             children: [
                    //               Text("Today's Summary", style: themeTitle),
                    //               const SizedBox(height: 4),
                    //               Text(
                    //                 "October 26",
                    //                 style: bodySmall.copyWith(
                    //                   color: AppColors.textSecondary,
                    //                 ),
                    //               ),
                    //             ],
                    //           ),
                    //         ],
                    //       ),
                    //       const SizedBox(height: 12),
                    //       Row(
                    //         crossAxisAlignment: CrossAxisAlignment.center,
                    //         children: [
                    //           // Pie/donut
                    //           SizedBox(
                    //             width: 130,
                    //             height: 130,
                    //             child: Stack(
                    //               alignment: Alignment.center,
                    //               children: [
                    //                 // ✅ Force the CustomPaint to fill full area
                    //                 SizedBox.expand(
                    //                   child: Obx(() {
                    //                     final totals = [
                    //                       controller.outgoing.value.toDouble(),
                    //                       controller.incoming.value.toDouble(),
                    //                       controller.missed.value.toDouble(),
                    //                       controller.rejected.value.toDouble(),
                    //                     ];
                    //                     return DonutPieChart(
                    //                       values: totals,
                    //                       colors: const [
                    //                         AppColors.primary,
                    //                         AppColors.secondary,
                    //                         AppColors.tertiary,
                    //                         AppColors.danger,
                    //                       ],
                    //                     );
                    //                   }),
                    //                 ),

                    //                 // ✅ Optional soft inner circle (for text contrast)
                    //                 Container(
                    //                   width: 65,
                    //                   height: 65,
                    //                   decoration: BoxDecoration(
                    //                     color: Colors.white.withOpacity(0.9),
                    //                     shape: BoxShape.circle,
                    //                   ),
                    //                 ),

                    //                 // ✅ Center total calls text
                    //                 Obx(() {
                    //                   return Column(
                    //                     mainAxisAlignment:
                    //                         MainAxisAlignment.center,
                    //                     children: [
                    //                       Text(
                    //                         "${controller.totalCalls.value}",
                    //                         style: themeTitle.copyWith(
                    //                           fontSize: 20,
                    //                           fontWeight: FontWeight.bold,
                    //                         ),
                    //                       ),
                    //                       Text(
                    //                         "Total Calls",
                    //                         style: bodySmall.copyWith(
                    //                           color: AppColors.textSecondary,
                    //                         ),
                    //                       ),
                    //                     ],
                    //                   );
                    //                 }),
                    //               ],
                    //             ),
                    //           ),

                    //           const SizedBox(width: 18),
                    //           // legend
                    //           Expanded(
                    //             child: Column(
                    //               crossAxisAlignment: CrossAxisAlignment.start,
                    //               children: [
                    //                 LegendItem(
                    //                   color: AppColors.primary,
                    //                   label: "Outgoing",
                    //                 ),
                    //                 LegendItem(
                    //                   color: AppColors.secondary,
                    //                   label: "Incoming",
                    //                 ),
                    //                 LegendItem(
                    //                   color: AppColors.tertiary,
                    //                   label: "Missed",
                    //                 ),
                    //                 LegendItem(
                    //                   color: AppColors.danger,
                    //                   label: "Rejected",
                    //                 ),
                    //               ],
                    //             ),
                    //           ),
                    //         ],
                    //       ),
                    //     ],
                    //   ),
                    // ),

                    // const SizedBox(height: 16),

                    // weekly activity (graph)
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.03),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Weekly Activity",
                                    style: Get.theme.textTheme.titleLarge
                                        ?.copyWith(fontWeight: FontWeight.bold),
                                  ),
                                  SizedBox(height: 4),
                                  RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: 'Total ',
                                          style: Get
                                              .theme
                                              .textTheme
                                              .titleMedium!
                                              .copyWith(
                                                color: Colors.black.withAlpha(
                                                  220,
                                                ),
                                                fontWeight: FontWeight.w600,
                                              ),
                                        ),
                                        TextSpan(
                                          text: "869",
                                          style: Get.theme.textTheme.titleLarge!
                                              .copyWith(
                                                color: AppColors.primary,
                                                fontWeight: FontWeight.w900,

                                                shadows: [
                                                  Shadow(
                                                    color: Colors.grey
                                                        .withOpacity(0.3),
                                                    offset: const Offset(0, 2),
                                                    blurRadius: 4,
                                                  ),
                                                ],
                                              ),
                                        ),

                                        TextSpan(
                                          text: ' calls',
                                          style: Get.theme.textTheme.bodySmall!
                                              .copyWith(
                                                color: Colors.black.withAlpha(
                                                  220,
                                                ),
                                                fontWeight: FontWeight.w600,
                                              ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 6,
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.danger.withAlpha(30),
                                  borderRadius: BorderRadius.circular(999),
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.arrow_downward,
                                      color: AppColors.danger,
                                      size: AppStyle.iconSize2,
                                    ),
                                    SizedBox(width: 4),
                                    Text(
                                      "-5.2%",
                                      style: Get.theme.textTheme.bodySmall
                                          ?.copyWith(
                                            color: AppColors.danger,
                                            fontWeight: FontWeight.bold,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          // const SizedBox(height: ),
                          SizedBox(
                            height: 160,
                            child: WeeklyGraph(
                              data: [0.5, 0.6, 0.4, 0.7, 0.5, 0.1],
                            ),
                          ),
                          // const SizedBox(height: 8),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 5),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Mon",
                                  style: Get.theme.textTheme.bodySmall,
                                ),
                                Text(
                                  "Tue",
                                  style: Get.theme.textTheme.bodySmall,
                                ),
                                Text(
                                  "Wed",
                                  style: Get.theme.textTheme.bodySmall,
                                ),
                                Text(
                                  "Thu",
                                  style: Get.theme.textTheme.bodySmall,
                                ),
                                Text(
                                  "Fri",
                                  style: Get.theme.textTheme.bodySmall,
                                ),
                                Text(
                                  "Sat",
                                  style: Get.theme.textTheme.bodySmall,
                                ),
                                // Text("Sun", style: Get.theme.textTheme.bodySmall),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 16),

                    // // recent activity
                    // Container(
                    //   padding: const EdgeInsets.all(16),
                    //   decoration: BoxDecoration(
                    //     color: AppColors.card,
                    //     borderRadius: BorderRadius.circular(12),
                    //     boxShadow: [
                    //       BoxShadow(
                    //         color: Colors.black.withOpacity(0.03),
                    //         blurRadius: 8,
                    //         offset: const Offset(0, 4),
                    //       ),
                    //     ],
                    //   ),
                    //   child: Column(
                    //     crossAxisAlignment: CrossAxisAlignment.start,
                    //     children: [
                    //       Text("Recent Activity", style: themeTitle),
                    //       const SizedBox(height: 12),
                    //       Obx(
                    //         () => Column(
                    //           children: controller.recent.map((r) {
                    //             return RecentActivityItem(
                    //               name: r['name'] ?? '',
                    //               subtitle: r['type'] ?? '',
                    //               time: r['time'] ?? '',
                    //               icon: r['icon'] ?? 'call_made',
                    //               colorName: r['color'] ?? 'primary',
                    //             );
                    //           }).toList(),
                    //         ),
                    //       ),
                    //     ],
                    //   ),
                    // ),
                    const SizedBox(height: 90),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class LegendItem extends StatelessWidget {
  final Color color;
  final String label;
  const LegendItem({super.key, required this.color, required this.label});
  @override
  Widget build(BuildContext context) {
    final bodySmall = Get.textTheme.bodySmall!;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 10),
      child: Row(
        children: [
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          const SizedBox(width: 8),
          Text(label, style: bodySmall.copyWith(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
