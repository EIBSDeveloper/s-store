import 'dart:ui';

import 'package:calltrackerui/src/core/app_colors.dart';
import 'package:flutter/material.dart';

class WeeklyGraph extends StatefulWidget {
  final List<double> data; // expected 7 points (Mon–Sun), values 0..1
  const WeeklyGraph({super.key, required this.data});

  @override
  State<WeeklyGraph> createState() => _WeeklyGraphState();
}

class _WeeklyGraphState extends State<WeeklyGraph>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..forward();

    _animation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, _) {
        return CustomPaint(
          painter: _SmoothWeeklyPainter(
            data: widget.data,
            progress: _animation.value,
          ),
          size: Size.infinite,
        );
      },
    );
  }
}

class _SmoothWeeklyPainter extends CustomPainter {
  final List<double> data;
  final double progress; // animation progress 0..1

  _SmoothWeeklyPainter({required this.data, required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    if (data.isEmpty) return;

    const double horizontalPadding = 14;
    final double availableWidth = size.width - (horizontalPadding * 2);
    final int n = data.length;
    final double step = availableWidth / (n - 1);

    final Offset startPoint = Offset(
      horizontalPadding,
      size.height - (data.first * size.height),
    );

    final path = Path()..moveTo(startPoint.dx, startPoint.dy);

    for (int i = 0; i < n - 1; i++) {
      final current = Offset(
        horizontalPadding + (i * step),
        size.height - (data[i] * size.height),
      );
      final next = Offset(
        horizontalPadding + ((i + 1) * step),
        size.height - (data[i + 1] * size.height),
      );

      final controlPoint1 = Offset((current.dx + next.dx) / 2, current.dy);
      final controlPoint2 = Offset((current.dx + next.dx) / 2, next.dy);

      path.cubicTo(
        controlPoint1.dx,
        controlPoint1.dy,
        controlPoint2.dx,
        controlPoint2.dy,
        next.dx,
        next.dy,
      );
    }

    // Animate the path drawing (clip based on animation progress)
    final PathMetrics metrics = path.computeMetrics();
    final Path animatedPath = Path();
    double currentLength = 0;
    for (final m in metrics) {
      final extractLength = m.length * progress;
      animatedPath.addPath(m.extractPath(0, extractLength), Offset.zero);
      currentLength += extractLength;
    }

    // Fill below the line (animated)
    final fillPath = Path.from(animatedPath)
      ..lineTo(horizontalPadding + availableWidth * progress, size.height)
      ..lineTo(horizontalPadding, size.height)
      ..close();

    final fillPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          AppColors.danger, // soft bluish gradient like image
          AppColors.background,
        ],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.fill;

    canvas.drawPath(fillPath, fillPaint);

    // Draw the line
    final linePaint = Paint()
      ..color = AppColors.danger
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    canvas.drawPath(animatedPath, linePaint);
  }

  @override
  bool shouldRepaint(covariant _SmoothWeeklyPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.data != data;
}
