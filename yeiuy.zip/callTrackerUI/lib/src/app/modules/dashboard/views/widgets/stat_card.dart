// lib/modules/dashboard/widgets/stat_card.dart
import 'package:calltrackerui/src/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class StatCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final RxInt? countRx;

  const StatCard({
    super.key,
    required this.title,
    required this.icon,
    required this.color,
    this.countRx,
  });

  /// helper constructor for animated number
  factory StatCard.animated({
    required String title,
    required IconData icon,
    required Color color,
    required RxInt countRx,
  }) => StatCard(title: title, icon: icon, color: color, countRx: countRx);

  @override
  Widget build(BuildContext context) {
    final titleStyle = Get.textTheme.titleLarge!;
    final bodyMedium = Get.textTheme.bodyMedium!;
    return Container(
      height: 100,
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      padding: const EdgeInsets.all(10),
      child: Row(
        children: [
          Container(
            height: 44,
            width: 44,
            decoration: BoxDecoration(
              color: color.withAlpha(30),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: color),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  title,
                  style: bodyMedium.copyWith(color: AppColors.textSecondary),
                ),
                const SizedBox(height: 3),
                if (countRx != null)
                  Obx(() {
                    final target = countRx!.value.toDouble();
                    return TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0, end: target),
                      duration: const Duration(milliseconds: 900),
                      builder: (context, value, _) => Text(
                        value.toInt().toString(),
                        style: titleStyle.copyWith(
                          fontSize: 24,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    );
                  })
                else
                  Text("0", style: titleStyle.copyWith(fontSize: 24)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
