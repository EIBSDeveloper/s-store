import 'package:get/get.dart';

import '../../onboading/screem/onboarding_wrapper.dart';

class SplashController extends GetxController {
  var progress = 0.0.obs;

  @override
  void onInit() {
    super.onInit();
    startLoading();
  }

  void startLoading() async {
    for (int i = 1; i <= 100; i++) {
      await Future.delayed(const Duration(milliseconds: 25));
      progress.value = i / 100;

      if (i == 100) {
        await Future.delayed(const Duration(milliseconds: 300));
        Get.to(OnboardingFlow());
      }
    }
  }
}
