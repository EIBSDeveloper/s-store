import 'package:flutter/material.dart';

import '../../../../../core/app_style.dart';
import '../../../../../core/image_view.dart';
import '../../model/bottom_nav_bar_item.dart';
import 'package:hugeicons/hugeicons.dart';

class NavBarItem extends StatefulWidget {
  final BottomNavBarItem item;
  final int index;
  final bool selected;
  final Function onTap;
  final Color? backgroundColor;
  const NavBarItem({
    super.key,
    required this.item,
    this.selected = false,
    required this.onTap,
    this.backgroundColor,
    required this.index,
  });

  @override
  State<NavBarItem> createState() => _NavBarItemState();
}

class _NavBarItemState extends State<NavBarItem> {
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: () {
      widget.onTap();
    },
    child: AnimatedContainer(
      margin: const EdgeInsets.all(8),
      padding: const EdgeInsets.all(8),
      duration: const Duration(milliseconds: 300),
      constraints: BoxConstraints(minWidth: widget.selected ? 70 : 50),
      height: 56,
      // width: Get.size.width *0.15,
      decoration: BoxDecoration(
        color: widget.selected
            ? widget.backgroundColor!.withAlpha(70) // 0.2 * 255 = 51
            : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          HugeIcon(
            icon: widget.item.icon,
            color: widget.backgroundColor,
            size: AppStyle.iconSize,
          ),
          //  Icon(widget.item.icon,color: widget.backgroundColor),
          // ImageView(
          //   widget.item.icon,
          //   width: AppStyle.iconSize,
          //   height: AppStyle.iconSize,
          // ),
          const SizedBox(width: 4),
          Offstage(
            offstage: !widget.selected,
            child: Text(
              widget.item.title,
              style: TextStyle(color: widget.backgroundColor),
            ),
          ),
        ],
      ),
    ),
  );
}

class CheckInOutSwitch extends StatefulWidget {
  final bool initialValue;
  final Function(bool)? onChanged;

  const CheckInOutSwitch({Key? key, this.initialValue = false, this.onChanged})
    : super(key: key);

  @override
  State<CheckInOutSwitch> createState() => _CheckInOutSwitchState();
}

class _CheckInOutSwitchState extends State<CheckInOutSwitch> {
  late bool isCheckedIn;

  @override
  void initState() {
    super.initState();
    isCheckedIn = widget.initialValue;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      // padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      // decoration: BoxDecoration(
      //   color: isCheckedIn ? Colors.green.shade50 : Colors.red.shade50,
      //   borderRadius: BorderRadius.circular(30),
      //   border: Border.all(
      //     color: isCheckedIn ? Colors.green : Colors.red,
      //     // width: 1.5
      //   ),
      // ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Text(
          //   isCheckedIn ? "Check-In" : "Check-Out",
          //   style: TextStyle(
          //     color: isCheckedIn ? Colors.green.shade700 : Colors.red.shade700,
          //     fontWeight: FontWeight.w600,
          //     // fontSize: 16,
          //   ),
          // ),
          // const SizedBox(height: 8),
          Switch(
            value: isCheckedIn,
            onChanged: (value) {
              setState(() => isCheckedIn = value);
              if (widget.onChanged != null) widget.onChanged!(value);
            },
            activeColor: Colors.white,
            activeTrackColor: Colors.green,
            inactiveThumbColor: Colors.white,
            inactiveTrackColor: Colors.red,
          ),
        ],
      ),
    );
  }
}
