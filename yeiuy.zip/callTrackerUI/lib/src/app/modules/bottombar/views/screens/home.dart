
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';

import '../../../../../core/app_colors.dart';
import '../../contoller/bottombar_contoller.dart';
import '../../model/bottom_nav_bar_item.dart';
import '../widgets/bottom_nav_bar.dart';

class Home extends GetView<BottomBarContoller> {
  const Home({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    key: controller.scaffoldKey,
    backgroundColor: AppColors.background,
    // drawer: const CustomAppDrawer(selectedItem: "messafe"),
    // drawer: Drawer(
    //   child: ListView(
    //     padding: EdgeInsets.zero,
    //     children: <Widget>[
    //       const DrawerHeader(
    //         decoration: BoxDecoration(color: Colors.blue),
    //         child: Text(
    //           'CallTracker App',
    //           style: TextStyle(color: Colors.white),
    //         ),
    //       ),
    //       ListTile(
    //         title: const Text('Whatsapp Message'),
    //         onTap: () {
    //           Get.toNamed(AppPages.whatsAppMessage);
    //         },
    //       ),
    //       ListTile(
    //         title: const Text('Assing to me'),
    //         onTap: () {
    //           // Get.toNamed(AppPages.whatsAppMessage);
    //         },
    //       ),
  
    //       // ListTile(title: Text('Item 2')),
    //     ],
    //   ),
    // ),
    // appBar: AppBar(
    //   title: const TitleText("Call Tracker"),
    //   toolbarHeight: 50,
    //   backgroundColor: Colors.white54,
    //   // leading: IconButton(
    //   //   onPressed: controller.openDrawer,
    //   //   icon: ImageView(
    //   //     AppIcons.menuicon,
    //   //     width: AppStyle.iconSize2,
    //   //     height: AppStyle.iconSize2,
    //   //   ),
    //   // ),
    //   actions: [
    //     IconButton(
    //       onPressed: () {
    //         // Get.toNamed(AppPages.callRecord);
    //       },
    //       icon: ImageView(
    //         AppIcons.callRing,
    //         width: AppStyle.iconSize,
    //         height: AppStyle.iconSize,
    //       ),
    //     ),
    //     IconButton(
    //       onPressed: () {
    //         // Get.toNamed(AppPages.notification);
    //       },
    //       icon: ImageView(
    //         AppIcons.notification,
    //         width: AppStyle.iconSizelarge,
    //         color: Get.theme.primaryColor,
    //         height: AppStyle.iconSizelarge,
    //       ),
    //     ),
    //     InkWell(
    //       onTap: () {
    //         // Get.toNamed(AppPages.profile);
    //       },
    //       child: Icon(
    //         Icons.account_circle
    //         ,color: Get.theme.primaryColor,
    //       ),
    //       // child: ImageView(
    //       //   AppIcons.user,
    //       //   width: AppStyle.iconSizelarge,
                 
    //       //   height: AppStyle.iconSizelarge,
    //       // ),
    //     ),
    //     const SizedBox(width: 18,)
    //   ],
    // ),
    body: SafeArea(
      child: PageView.builder(
        controller: controller.pageController,
        itemCount: controller.pages.length,
        itemBuilder: (context, index) => controller.pages[index],
        onPageChanged: (index) {
          controller.selectedIndex.value = index;
        },
      ),
    ),
  
    bottomNavigationBar: SafeArea(
      
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Obx(
          () => BottomNavBar(
            key: const ValueKey("ButtomBar"),
            curentIndex: controller.selectedIndex.value,
            backgroundColor: AppColors.card,
          
            selectColor: Get.theme.colorScheme.secondaryContainer,
            onTap: (index) {
              controller.selectedIndex.value = index;
              controller.pageController.jumpToPage(index);
            },
            children: [
              BottomNavBarItem(
                title: 'Dashboard',
                icon: HugeIcons.strokeRoundedDashboardSquare02,
                color: AppColors.primary,
              ),
              BottomNavBarItem(
                title: 'Call Log',
                icon: HugeIcons.strokeRoundedCall02,
                color: AppColors.secondary,
              ),
              // BottomNavBarItem(
              //   title: 'Message',
              //   icon: AppIcons.userlist,
              //   color: Colors.green,
              // ),
              // BottomNavBarItem(
              //   title: 'Leads',
              //   icon:HugeIcons.strokeRoundedUserMultiple02,
              //   color: Colors.pink,
              // ),
              // BottomNavBarItem(
              //   title: "Tracker",
              //   // icon: Icons.trending_down_sharp,
              //   icon: HugeIcons.strokeRoundedTaskEdit02,
              //   color: Colors.blue,
              // ),
            ],
          ),
        ),
      ),
    ),
  );
}
