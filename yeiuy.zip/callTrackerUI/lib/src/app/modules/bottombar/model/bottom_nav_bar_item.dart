import 'package:flutter/material.dart';

class BottomNavBarItem {
  final String title;
  final List<List<dynamic>> icon;
  final Color color;
  const BottomNavBarItem({
    required this.title,
    required this.icon,
    required this.color,
  });
}
