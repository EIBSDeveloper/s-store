import 'package:calltrackerui/src/app/modules/payment_tracker/view/screens/customerdetailscreen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../callLogs/views/screens/call_logscreen.dart';
import '../../dashboard/views/screens/dashboard_screen.dart';
import '../../lead/views/screens/leadProfilescreen.dart';
import '../../payment_tracker/view/screens/customerscreen.dart';
import '../../payment_tracker/view/screens/payment_dashboard.dart';
import '../../payment_tracker/view/screens/schedulescreen.dart';

class BottomBarContoller extends GetxController {
  final RxList<Widget> pages = <Widget>[
    DashboardScreen(),
    CallLogsScreen(),
    CustomerScreen(),

    SchedulesScreen(),
    PaymentScreen(),
    CustomerDetailsScreen(),
  ].obs;
  final RxInt selectedIndex = 0.obs;
  late final PageController pageController;
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  void onInit() {
    super.onInit();
    pageController = PageController(initialPage: selectedIndex.value);
  }

  @override
  void onClose() {
    pageController.dispose();
    super.onClose();
  }

  void openDrawer() {
    scaffoldKey.currentState?.openDrawer();
  }

  void closeDrawer() {
    scaffoldKey.currentState?.openEndDrawer();
  }
}
