// lib/modules/call_details/controller/call_details_controller.dart
import 'package:get/get.dart';

import '../model/followup_model.dart';

class CallDetailsController extends GetxController {
  final RxInt tab = 0.obs;
  final contact = {
    "name": "Eleanor Vance",
    "company": "Innovate Inc.",
    "phone": "+91 9876543210",
    "image":
        "https://lh3.googleusercontent.com/aida-public/AB6AXuBrdw_52nYPkOU_ctQ9MhL0T7jkaVm3gpwXCY_VM2Ae67Y8dJMDk0fBSopuLV6VdXgPVc8NqoViiX2-g4sVwQ2XqXp7RPV5bSulh8ORGhOd1qmEI1sN4UYzWVaKLRJXxj4EdBBpX6C31KjVItGFRymcDrK6i8XpRxQZ-CNG-HesN1x2G9V0NjaASBenIyFMuX4ctwoFrsWcp0eboG0OLbCcKdgbtx78C_LK2Vs18uMuDFi_sjOo7WOPNWgU3mXfkjST1d-ZR45i8_0V",
    "callType": "Outgoing",
    "iconColor": "green",
    "dateTime": "21/02/2025 10:32 am",
    "duration": "5m 32s",
    "notes":
        "Discussed the new product line and potential for a bulk order. Follow-up required next week to finalize the details and pricing.",
    "categories": ["Follow-up"],
  }.obs;

  List<FollowUpModel> followUps = [
    // Next week follow-up
    FollowUpModel(
      id: 'f4',
      leadId: '100',
      followUpDate: DateTime.now().add(const Duration(days: 7)),
      reason: 'Follow-up Call',
      status: 'Scheduled',
      notes: 'Check on client satisfaction and address any concerns',
      createdAt: DateTime.now().subtract(const Duration(days: 1)),
    ),
    // Overdue follow-up
    FollowUpModel(
      id: '102',
      leadId: '5',
      followUpDate: DateTime.now().subtract(const Duration(days: 1)),
      reason: 'Payment Follow-up',
      status: 'Overdue',
      notes: 'Client missed payment deadline, need to follow up urgently',
      createdAt: DateTime.now().subtract(const Duration(days: 10)),
    ),
  ];
}
