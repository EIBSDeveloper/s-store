// lib/modules/call_logs/controller/call_logs_controller.dart
import 'package:get/get.dart';

import '../../../../core/app_colors.dart';
 
class CallLogsController extends GetxController {
  var selectedFilter = CallType.all.obs;

  void changeFilter(CallType filter) {
    selectedFilter.value = filter;
  }

  // Example mock data
  final todayCalls = [
    {
      "name": "Jane Cooper",
      "number": "+1 (555) 123-4567",
      "type": CallType.incoming,
      "duration": "02:15",
      "time": "10:45 AM",
    },
    {
      "name": "Floyd Miles",
      "number": "+1 (555) 987-6543",
      "type": CallType.outgoing,
      "duration": "05:30",
      "time": "09:12 AM",
    },
    {
      "name": "Ronald Richards",
      "number": "+1 (555) 246-8135",
      "type": CallType.missed,
      "duration": "",
      "time": "08:30 AM",
    },
    {
      "name": "Jane Cooper",
      "number": "+1 (555) 123-4567",
      "type": CallType.incoming,
      "duration": "02:15",
      "time": "10:45 AM",
    },
    {
      "name": "Floyd Miles",
      "number": "+1 (555) 987-6543",
      "type": CallType.outgoing,
      "duration": "05:30",
      "time": "09:12 AM",
    },
    {
      "name": "Ronald Richards",
      "number": "+1 (555) 246-8135",
      "type": CallType.missed,
      "duration": "",
      "time": "08:30 AM",
    },
    {
      "name": "Jane Cooper",
      "number": "+1 (555) 123-4567",
      "type": CallType.incoming,
      "duration": "02:15",
      "time": "10:45 AM",
    },
    {
      "name": "Floyd Miles",
      "number": "+1 (555) 987-6543",
      "type": CallType.outgoing,
      "duration": "05:30",
      "time": "09:12 AM",
    },
    {
      "name": "Ronald Richards",
      "number": "+1 (555) 246-8135",
      "type": CallType.missed,
      "duration": "",
      "time": "08:30 AM",
    },
  ];

  final yesterdayCalls = [
    {
      "name": "Annette Black",
      "number": "+1 (555) 369-2580",
      "type": CallType.missed,
      "duration": "",
      "time": "5:21 PM",
    },
    {
      "name": "Savannah Nguyen",
      "number": "+1 (555) 159-7532",
      "type": CallType.outgoing,
      "duration": "12:45",
      "time": "2:03 PM",
    },
    {
      "name": "Annette Black",
      "number": "+1 (555) 369-2580",
      "type": CallType.missed,
      "duration": "",
      "time": "5:21 PM",
    },
    {
      "name": "Savannah Nguyen",
      "number": "+1 (555) 159-7532",
      "type": CallType.outgoing,
      "duration": "12:45",
      "time": "2:03 PM",
    },
  ];

  List<Map<String, dynamic>> get filteredToday {
    if (selectedFilter.value == CallType.all) return todayCalls;
    return todayCalls.where((e) => e["type"] == selectedFilter.value).toList();
  }

  List<Map<String, dynamic>> get filteredYesterday {
    if (selectedFilter.value == CallType.all) return yesterdayCalls;
    return yesterdayCalls
        .where((e) => e["type"] == selectedFilter.value)
        .toList();
  }
}
