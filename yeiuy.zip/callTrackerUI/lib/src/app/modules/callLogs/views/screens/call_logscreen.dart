import 'dart:math';

import 'package:calltrackerui/src/app/modules/callLogs/controller/callLogcontroller.dart';
import 'package:calltrackerui/src/app/modules/callLogs/views/screens/callLogdetailscreen.dart';
import 'package:calltrackerui/src/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';

import '../../../../../core/app_icons.dart';
import '../../../../../core/app_style.dart';
import '../../../../../core/image_view.dart';
import '../../../../utils/utils.dart';

class CallLogsScreen extends GetView<CallLogsController> {
  const CallLogsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Get.theme.textTheme;
    final isDark = Get.isDarkMode;
    return Scaffold(
      backgroundColor: AppColors.background,
      // floatingActionButton: FloatingActionButton(
      //   elevation: 0,
      //   backgroundColor: Get.theme.primaryColor.withAlpha(80),
      //   onPressed: () {
      //     Get.toNamed(AppPages.dialPad);
      //   },
      //   child: const Icon(Icons.dialpad),
      // ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        backgroundColor: AppColors.primary,
        child: const Icon(Icons.dialpad, color: Colors.white, size: 28),
      ),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _appBar(theme),

            _searchBar(),
            SizedBox(height: 8),
            _filterChips(controller),
            Expanded(
              child: Obx(
                () => ListView(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  physics: const BouncingScrollPhysics(),
                  children: [
                    _sectionHeader("Today"),
                    ...controller.filteredToday.map((e) => _callItem(e, theme)),
                    _sectionHeader("Yesterday"),
                    ...controller.filteredYesterday.map(
                      (e) => _callItem(e, theme),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _appBar(TextTheme theme) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Call Logs",
            style: theme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
              color: AppColors.textPrimary,
            ),
          ),
          Spacer(),
          IconButton(
            onPressed: () {},
            icon: HugeIcon(
              icon: HugeIcons.strokeRoundedNotification01,
              // color: widget.backgroundColor,
              size: AppStyle.iconSizelarge,
            ),
            color: AppColors.textDark,
          ),
          //  IconButton(
          //           onPressed: () {},
          //           icon: const Icon(Icons.notifications_outlined, size: 26),
          //           color: AppColors.textSecondary,
          //         ),
        ],
      ),
    );
  }

  Widget _searchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              decoration: InputDecoration(
                hintText: "Search by name or number...",
                prefixIcon: Padding(
                  padding: const EdgeInsets.all(15
                  ),
                  child:  HugeIcon(
                    icon: HugeIcons.strokeRoundedSearch01,
                    color: AppColors.textSecondary,
                    size:AppStyle.iconSize2,
                  ),
                ),
                filled: true,
                fillColor: AppColors.card,
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
                enabledBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: AppColors.border),
                  borderRadius: BorderRadius.circular(12),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: AppColors.primary),
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
          // SizedBox(width: 8),
          // Container(
          //   width: 46,
          //   height: 46,
          //   padding: EdgeInsets.all(15),
          //   decoration: BoxDecoration(
          //     color: AppColors.card,
          //     borderRadius: BorderRadius.circular(12),
          //     // shape: BoxShape.circle,
          //     boxShadow: [
          //       BoxShadow(
          //         color: AppColors.textSecondary.withOpacity(0.1),
          //         blurRadius: 4,
          //       ),
          //     ],
          //   ),
          //   child: const HugeIcon(
          //     icon: HugeIcons.strokeRoundedPreferenceHorizontal,
          //     color: AppColors.textPrimary,
          //     size: AppStyle.iconSize2,
          //   ),
          // ),
        ],
      ),
    );
  }

  Widget _filterChips(CallLogsController controller) {
    return Obx(
      () => SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(
          children: [
            _chip(controller, "All", CallType.all, AppColors.primary, 20),
            _chip(
              controller,
              "Incoming",
              CallType.incoming,
              AppColors.secondary,
              10,
              Icons.south_west,
            ),
            _chip(
              controller,
              "Outgoing",
              CallType.outgoing,
              AppColors.primary,
              3,
              Icons.north_east,
            ),
            _chip(
              controller,
              "Missed",
              CallType.missed,
              AppColors.danger,
              4,
              Icons.call_missed,
            ),
            _chip(
              controller,
              "Not Answer",
              CallType.missed,
              AppColors.danger,
              3,
              Icons.call_missed,
            ),
          ],
        ),
      ),
    );
  }

  Widget _chip(
    CallLogsController controller,
    String label,
    CallType type,
    Color color,
    int count, [
    IconData? icon,
  ]) {
    final bool active = controller.selectedFilter.value == type;
    return GestureDetector(
      onTap: () => controller.changeFilter(type),
      child: Container(
        margin: const EdgeInsets.only(right: 10),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: active ? color : AppColors.card,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            if (icon != null)
              Icon(icon, color: active ? Colors.white : color, size: 18),
            if (icon != null) const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: active ? Colors.white : AppColors.textPrimary,
              ),
            ),
            SizedBox(width: 2),
            Text(
              "($count)",
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: active ? Colors.white : AppColors.textPrimary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 5, 16, 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: AppColors.textPrimary,
        ),
      ),
    );
  }

  Widget _callItem(Map<String, dynamic> call, TextTheme theme) {
    final CallType type = call["type"];
    final icon = switch (type) {
      CallType.incoming => Icons.south_west,
      CallType.outgoing => Icons.north_east,
      CallType.missed => Icons.call_missed,
      _ => Icons.call,
    };
    final color = switch (type) {
      CallType.incoming => AppColors.secondary,
      CallType.outgoing => AppColors.primary,
      CallType.missed => AppColors.danger,
      _ => AppColors.textSecondary,
    };
    return Column(
      children: [
        InkWell(
          // onTap: ontop,
          onTap: () {
            Get.to(CallDetailsScreen());
          },
          // onTap: ontop,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 4),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
            // decoration: AppStyle.decoration,
            color: Colors.white,
            child: Column(
              children: [
                Row(
                  children: [
                    Column(
                      children: [
                        SizedBox(height: 5),
                        InkWell(
                          onTap: () {
                            // Get.toNamed(AppPages.logDetails);
                          },
                          child: Stack(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                  bottom: 10,
                                  right: 10,
                                ),
                                child: CircleAvatar(
                                  // backgroundColor: Get.theme.primaryColor.withAlpha(20),
                                  backgroundColor: Color.fromARGB(
                                    50,
                                    Random().nextInt(256),
                                    Random().nextInt(256),
                                    Random().nextInt(256),
                                  ),
                                  child: Text(call["name"][0].toUpperCase()),
                                ),
                              ),
                              Positioned(
                                bottom: 0,
                                right: 0,
                                child: AppColors.getCallTypeIcon(type),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      flex: 3,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  call["name"],
                                  style: Get.theme.textTheme.bodyMedium
                                      ?.copyWith(
                                        color: type == CallType.missed
                                            ? AppColors.danger
                                            : null,
                                        fontWeight: FontWeight.w600,
                                      ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                          // const SizedBox(height: 5),
                          InkWell(
                            onTap: () {
                              // Get.toNamed(AppPages.logDetails);
                            },
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 3),
                              child: Row(
                                children: [
                                  // Icon(
                                  //   Icons.access_time,
                                  //   color: Get.theme.primaryColor,
                                  // ),
                                  // ImageView(AppIcons.time2,width: AppStyle.iconsize2,height: AppStyle.iconsize2,),
                                  Row(
                                    children: [
                                      Text(
                                        call["time"],
                                        style: Get.theme.textTheme.bodySmall!
                                            .copyWith(
                                              color: Get.isDarkMode
                                                  ? Colors.grey[400]
                                                  : AppColors.textSecondary,
                                            ),
                                      ),
                                      const SizedBox(width: 5),
                                      Text(
                                        type == CallType.missed
                                            ? "00:00"
                                            : Utils.formatDuration(
                                                int.tryParse("333") ?? 0,
                                              ),
                                        style: Get.theme.textTheme.bodySmall!
                                            .copyWith(
                                              color: Get.isDarkMode
                                                  ? Colors.grey[400]
                                                  : AppColors.textSecondary,
                                            ),
                                      ),
                                      // if (call["time"] != null)
                                      if (type == CallType.incoming ||
                                          type == CallType.outgoing) ...[
                                        Container(
                                          decoration: AppStyle.decoration
                                              .copyWith(
                                                color: Colors.red.withAlpha(50),
                                                boxShadow: [],
                                              ),
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 4,
                                            vertical: 2,
                                          ),
                                          margin: const EdgeInsets.symmetric(
                                            horizontal: 4,
                                          ),
                                          child: Row(
                                            children: [
                                              const Icon(
                                                Icons.circle,
                                                color: Colors.red,
                                                size: 8,
                                              ),
                                              Text(
                                                "RCE",
                                                style: Get
                                                    .theme
                                                    .textTheme
                                                    .bodySmall
                                                    ?.copyWith(
                                                      color: Colors.black,
                                                      fontSize: 9,
                                                    ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        // LocalAudioPlayer(audioPath: audioPath!),
                                      ],
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),

                          // const SizedBox(height: 5),
                          // SingleChildScrollView(
                          //   scrollDirection: Axis.horizontal,
                          //   child: Row(
                          //     children: [
                          //       TagCard(
                          //         onTap: () {
                          //           // showTagBottomSheet();
                          //         },
                          //         color: Colors.orange,
                          //         lable: "VIP",
                          //       ),
                          //       TagCard(
                          //         onTap: () {},
                          //         color: Colors.blueGrey,
                          //         lable: "Call Back",
                          //         // icon: Icons.add,
                          //       ),
                          //       TagCard(
                          //         onTap: () {
                          //           // showTagBottomSheet();
                          //         },
                          //         color: Colors.blue,
                          //         lable: "",
                          //         icon: Icons.add,
                          //         // icon: Icons.add,
                          //       ),

                          //       // Spacer(),
                          //       // Flexible(
                          //       //   child: ,
                          //       // ),
                          //       // Row(
                          //       //   children: [
                          //       //     IconButton(onPressed: (){}, icon: Icon(Icons.mic)),
                          //       //   ],
                          //       // )
                          //     ],
                          //   ),
                          // ),
                        ],
                      ),
                    ),

                    CircleAvatar(
                      backgroundColor: Get.theme.primaryColor.withAlpha(20),
                      child: InkWell(
                        onTap: () {
                          // FlutterPhoneDirectCaller.callNumber(number.toString());
                        },
                        child: Icon(
                          Icons.call,
                          color: Get.theme.primaryColor,
                          size: AppStyle.iconSize,
                          // height: AppStyle.iconSize,
                        ),
                      ),
                    ),
                  ],
                ),
                // if (false)
                //   Container(
                //     margin: const EdgeInsets.symmetric(
                //       vertical: 4,
                //       horizontal: 4,
                //     ),
                //     padding: const EdgeInsets.all(5),
                //     decoration: AppStyle.decoration.copyWith(boxShadow: []),
                //     child: Row(
                //       mainAxisAlignment: MainAxisAlignment.spaceAround,
                //       children: [
                //         Expanded(
                //           child: ActionButton(
                //             icon: AppIcons.time2,
                //             label: 'Add Follow Up',
                //             color: Get.theme.primaryColor,
                //             onTap: () {
                //               // openAddFollowUpBottomSheet
                //             },
                //           ),
                //         ),
                //         Expanded(
                //           child: ActionButton(
                //             icon: AppIcons.whatsapp,
                //             label: 'Whatsapp',
                //             color: Colors.green,
                //             onTap: () {
                //               //  openTemplateBottomSheet
                //             },
                //           ),
                //         ),
                //         Expanded(
                //           child: ActionButton(
                //             icon: AppIcons.sms,
                //             label: 'SMS',
                //             color: Colors.blue,
                //             onTap: () {
                //               // openSMS(number);
                //             },
                //           ),
                //         ),
                //         Expanded(
                //           child: ActionButton(
                //             icon: AppIcons.useredit,
                //             label: 'Assigned to',
                //             color: Colors.indigo,
                //             onTap: () {
                //               // ClientBinding().dependencies();

                //               // // loadAvailableAgents();
                //               // Get.bottomSheet(
                //               //   AgentSelectionBottomSheet(),
                //               //   isScrollControlled: true,
                //               // );
                //             },
                //           ),
                //         ),
                //       ],
                //     ),
                //   ),

                // if (audioPath != null) LocalAudioPlayer(audioPath: audioPath!),
              ],
            ),
          ),
        ),
        Divider(height: 1, color: Get.theme.primaryColor.withAlpha(10)),
      ],
    );
    // return GestureDetector(
    //   onTap: () {
    //     Get.to(CallDetailsScreen());
    //   },
    //   child: Container(
    //     color: AppColors.card,
    //     padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
    //     child: Row(
    //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
    //       children: [
    //         Row(
    //           children: [
    //             Container(
    //               width: 48,
    //               height: 48,
    //               decoration: BoxDecoration(
    //                 color: color.withOpacity(0.1),
    //                 shape: BoxShape.circle,
    //               ),
    //               child: Icon(icon, color: color, size: 22),
    //             ),
    //             const SizedBox(width: 12),
    //             Column(
    //               crossAxisAlignment: CrossAxisAlignment.start,
    //               children: [
    //                 Text(
    //                   call["name"],
    //                   style: theme.bodyMedium?.copyWith(
    //                     fontWeight: FontWeight.w600,
    //                     color: type == CallType.missed
    //                         ? AppColors.danger
    //                         : AppColors.textPrimary,
    //                   ),
    //                 ),
    //                 Text(
    //                   "${call["number"]}${call["duration"].isNotEmpty ? " • ${call["duration"]}" : ""}",
    //                   style: theme.bodySmall?.copyWith(
    //                     color: AppColors.textSecondary,
    //                   ),
    //                 ),
    //               ],
    //             ),
    //           ],
    //         ),
    //         Text(
    //           call["time"],
    //           style: theme.bodySmall?.copyWith(color: AppColors.textSecondary),
    //         ),
    //       ],
    //     ),
    //   ),
    // );
  }
}

class TagCard extends StatelessWidget {
  const TagCard({
    super.key,
    required this.color,
    required this.lable,
    this.onTap,
    this.icon,
  });
  final void Function()? onTap;
  final MaterialColor color;
  final String lable;
  final IconData? icon;
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    child: Container(
      decoration: AppStyle.decoration.copyWith(
        color: (lable.isNotEmpty) ? color.withAlpha(30) : Colors.transparent,
        borderRadius: const BorderRadius.all(
          Radius.circular(AppStyle.borderRadiusClip),
        ),
        border: (lable.isNotEmpty)
            ? null
            : Border.all(color: Colors.grey.withAlpha(50)),
        boxShadow: [],
      ),

      margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
      padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 2),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) Icon(icon, color: color, size: AppStyle.iconSize2),

          if (lable.isNotEmpty) ...[
            const SizedBox(width: 3),
            Flexible(
              child: Text(
                lable,
                style: Get.theme.textTheme.bodySmall!.copyWith(
                  color: color,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          ],
        ],
      ),
    ),
  );
}
