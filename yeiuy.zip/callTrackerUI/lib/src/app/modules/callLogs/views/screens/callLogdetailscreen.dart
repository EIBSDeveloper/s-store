// lib/modules/call_details/view/call_details_screen.dart
import 'package:calltrackerui/src/app/modules/callLogs/controller/callLog_detailscontroller.dart';
import 'package:calltrackerui/src/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../../../core/app_style.dart';
import '../../../../controller/app_controller.dart';
import '../../../../widgets/toggle_bar.dart';

class CallDetailsScreen extends GetView<CallDetailsController> {
  CallDetailsScreen({super.key});
  final AppDataController appDeta = Get.find();
  @override
  Widget build(BuildContext context) {
    final data = controller.contact;
    final theme = Theme.of(context).textTheme;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15),
          child: Column(
            children: [
              _topAppBar(theme),
              Column(
                children: [
                  _contactCard(data, theme),
                  const SizedBox(height: 8),
                  _callMetaCard(data, theme),
                  const SizedBox(height: 8),
                  _notesCard(data, theme),
                  // const SizedBox(height: 16),
                  // _categoriesCard(data, theme),
                ],
              ),

              // _actionBar(),
              Flexible(
                child: Obx(() {
                  return Container(
                    height: 600,

                    margin: const EdgeInsets.only(top: 0),

                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        const SizedBox(height: 10),
                        // Padding(
                        //   padding: const EdgeInsets.symmetric(horizontal: 0),
                        //   child: ToggleBar(
                        //     onTap: (index) {
                        //       controller.tab.value = index;
                        //     },
                        //     activePageIndex: controller.tab.value,
                        //     buttonsList: ["Call logs", 'Follows'],
                        //   ),
                        // ),
                        // const SizedBox(height: 10),
                        if (controller.tab.value == 1)
                          Expanded(
                            child: ListView.builder(
                              physics: NeverScrollableScrollPhysics(),
                              // physics: A,
                              padding: const EdgeInsets.only(
                                bottom: 16,
                                // right: 10,
                                // left: 10,
                              ),
                              itemCount: controller.followUps.length,
                              itemBuilder: (context, index) {
                                final followUp = controller.followUps[index];

                                return FeedbackMessageCard(
                                  title: followUp.reason,
                                  dateTime: DateFormat(
                                    "dd/MM/yyyy - h:mm a",
                                  ).format(followUp.followUpDate),
                                  message: followUp.notes,
                                );

                                // return FollowUpCard(
                                //   followUp: followUp,
                                //   noCall: false,
                                //   onTap:
                                //       () => Get.to(
                                //         () => FollowUpDetailPage(
                                //           followUp: followUp,
                                //         ),
                                //       ),
                                // );
                              },
                            ),
                          ),
                        if (controller.tab.value == 0)
                          const Column(
                            children: [
                              VoiceMessageCard(),
                              VoiceMessageCard(),
                              // VoiceMessageCard(),
                              // VoiceMessageCard(),
                            ],
                          ),
                        //  _buildCallLogList(client),
                      ],
                    ),
                  );
                }),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // 🔹 App Bar
  Widget _topAppBar(TextTheme theme) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: Colors.transparent,
        // border: Border(
        //   bottom: BorderSide(color: AppColors.border.withOpacity(0.5)),
        // ),
      ),
      child: Row(
        children: [
          InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => Get.back(),
            child: const Padding(
              padding: EdgeInsets.all(6.0),
              child: Icon(
                Icons.arrow_back_ios_new,
                color: AppColors.textPrimary,
                size: 22,
              ),
            ),
          ),
          const Spacer(),
          Text(
            "Call Details",
            style: theme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: AppColors.textPrimary,
            ),
          ),
          const Spacer(),
          Text(
            "Edit",
            style: theme.bodyMedium?.copyWith(
              color: AppColors.primary,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  // 🔹 Contact Information Card
  Widget _contactCard(RxMap<String, dynamic> data, TextTheme theme) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 28,
                backgroundImage: NetworkImage(data['image']),
              ),
              const SizedBox(width: 14),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    data['name'],
                    style: theme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: AppColors.textPrimary,
                    ),
                  ),const SizedBox(height: 5),
                  Text(
                    data['phone'],
                    style: theme.bodySmall?.copyWith(
                      color: AppColors.textSecondary,
                    ),
                  ),const SizedBox(height: 5),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: (data['categories'] as List<String>)
                        .map(
                          (e) => Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: _chipColor(e),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              e,
                              style: theme.bodySmall?.copyWith(
                                fontWeight: FontWeight.w600,
                                color: _chipTextColor(e),
                              ),
                            ),
                          ),
                        )
                        .toList(),
                  ),
                ],
              ),

              Spacer(),
              CircleAvatar(
                backgroundColor: Get.theme.primaryColor.withAlpha(20),
                child: InkWell(
                  onTap: () {
                    // FlutterPhoneDirectCaller.callNumber(number.toString());
                  },
                  child: Icon(
                    Icons.call,
                    color: Get.theme.primaryColor,
                    size: AppStyle.iconSize,
                    // height: AppStyle.iconSize,
                  ),
                ),
              ),
            ],
          ),
          // const SizedBox(height: 12),
          // Text(
          //   data['phone'],
          //   style: theme.bodyMedium?.copyWith(
          //     color: AppColors.textSecondary,
          //     fontSize: 16,
          //   ),
          // ),
        ],
      ),
    );
  }

  // 🔹 Call Metadata
  Widget _callMetaCard(RxMap<String, dynamic> data, TextTheme theme) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          // _metaItem(
          //   Icons.call_made,
          //   "Call Type",
          //   data['callType'],
          //   color: Colors.green,
          //   theme: theme,
          // ),
          // const Divider(color: AppColors.border, height: 1),
          _metaItem(
            Icons.call_made,
            "Last Call",
            color: Colors.green,
            data['dateTime'],
            theme: theme,
          ),
          const Divider(color: AppColors.border, height: 1),
          _metaItem(
            Icons.hourglass_top,
            "Duration",
            data['duration'],
            theme: theme,
          ),
        ],
      ),
    );
  }

  Widget _metaItem(
    IconData icon,
    String label,
    String value, {
    Color? color,
    required TextTheme theme,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Icon(icon, color: color ?? AppColors.textSecondary, size: 22),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: theme.bodySmall?.copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
                Text(
                  value,
                  style: theme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                    color: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // 🔹 Notes
  Widget _notesCard(RxMap<String, dynamic> data, TextTheme theme) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Notes",
            style: theme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height:3),
          Text(
            data['notes'],
            style: theme.bodySmall?.copyWith(
              color: AppColors.textPrimary,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  // 🔹 Categories
  Widget _categoriesCard(RxMap<String, dynamic> data, TextTheme theme) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Categories",
                style: theme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                ),
              ),
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.15),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.add,
                  color: AppColors.primary,
                  size: 20,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: (data['categories'] as List<String>)
                .map(
                  (e) => Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: _chipColor(e),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      e,
                      style: theme.bodySmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: _chipTextColor(e),
                      ),
                    ),
                  ),
                )
                .toList(),
          ),
        ],
      ),
    );
  }

  Color _chipColor(String label) {
    switch (label) {
      case "Lead":
        return Colors.blue.shade100;
      case "Follow-up":
        return Colors.orange.shade100;
      case "Q4-Pipeline":
        return Colors.green.shade100;
      default:
        return AppColors.card;
    }
  }

  Color _chipTextColor(String label) {
    switch (label) {
      case "Lead":
        return Colors.blue.shade800;
      case "Follow-up":
        return Colors.orange.shade800;
      case "Q4-Pipeline":
        return Colors.green.shade800;
      default:
        return AppColors.textPrimary;
    }
  }

  // 🔹 Bottom Action Bar
  Widget _actionBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        border: Border(
          top: BorderSide(color: AppColors.border.withOpacity(0.5)),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                shape: const StadiumBorder(),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: () {},
              icon: const Icon(Icons.call, color: Colors.white),
              label: const Text(
                "Call Back",
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                backgroundColor: AppColors.primary.withOpacity(0.1),
                shape: const StadiumBorder(),
                side: BorderSide.none,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: () {},
              icon: const Icon(Icons.message, color: AppColors.primary),
              label: const Text(
                "Message",
                style: TextStyle(
                  color: AppColors.primary,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class VoiceMessageCard extends StatelessWidget {
  const VoiceMessageCard({super.key});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.symmetric(vertical: 3),
    decoration: AppStyle.decoration,
    child: Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      padding: const EdgeInsets.all(10),
      child: Row(
        children: [
          // Left section: date & message
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    AppColors.getCallTypeIcon(CallType.incoming),
                    Text(
                      "21/02/2025 10:32am",
                      style: Get.theme.textTheme.bodyMedium?.copyWith(
                        color: Get.theme.primaryColor,
                      ),
                    ),

                    // Container(
                    //   decoration: AppStyle.decoration.copyWith(
                    //     color: Colors.red.withAlpha(50),
                    //     boxShadow: [],
                    //   ),
                    //   padding: const EdgeInsets.symmetric(
                    //     horizontal: 4,
                    //     vertical: 2,
                    //   ),
                    //   margin: const EdgeInsets.symmetric(horizontal: 4),
                    //   child: const Row(
                    //     children: [
                    //       Icon(Icons.circle, color: Colors.red, size: 8),
                    //       Text(
                    //         "RCE",
                    //         style: TextStyle(color: Colors.black, fontSize: 9),
                    //       ),
                    //     ],
                    //   ),
                    // ),

                    // LocalAudioPlayer(audioPath: audioPath!),
                  ],
                ),

                const SizedBox(height: 3),
                Text(
                  "Just wanted to confirm if you received my previous email regarding ...",
                  style: Get.theme.textTheme.bodySmall,
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),

          // Right section: play icon and red rec dot
          Column(
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  // Play button circle
                  Container(
                    decoration: BoxDecoration(
                      color: Get.theme.primaryColor.withAlpha(30),
                      shape: BoxShape.circle,
                    ),
                    padding: const EdgeInsets.all(5),
                    child: Icon(
                      Icons.play_arrow,
                      color: Get.theme.primaryColor,
                      size: AppStyle.iconSize,
                    ),
                  ),

                  // Red dot positioned bottom right
                  Positioned(
                    bottom: 2,
                    right: 2,
                    child: Container(
                      width: 5,
                      height: 5,
                      decoration: const BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 8),
              Text("10:00", style: Get.theme.textTheme.bodySmall),
            ],
          ),
        ],
      ),
    ),
  );
}

class FeedbackMessageCard extends StatelessWidget {
  final String title;
  final String dateTime;
  final String message;

  const FeedbackMessageCard({
    super.key,
    required this.title,
    required this.dateTime,
    required this.message,
  });

  @override
  Widget build(BuildContext context) => Container(
    decoration: AppStyle.decoration,
    padding: const EdgeInsets.all(10),
    margin: const EdgeInsets.only(bottom: 10),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Vertical black bar
        Container(
          width: 6,
          height: 60,
          decoration: BoxDecoration(
            color: Colors.black87,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        const SizedBox(width: 12),

        // Text content
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Title
              Text(
                title,
                style: Get.theme.textTheme.bodyMedium?.copyWith(
                  color: Get.theme.primaryColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 5),
              // Date and time
              Text(
                dateTime,
                style: Get.theme.textTheme.bodySmall?.copyWith(
                  color: Colors.grey[700],
                ),
              ),
              const SizedBox(height: 5),
              // Message text
              Text(message, style: Get.theme.textTheme.bodySmall),
            ],
          ),
        ),
      ],
    ),
  );
}
