import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../walkthrough/views/screens/firstscreen.dart';
import '../../walkthrough/views/screens/secondscreen.dart';
import '../../walkthrough/views/screens/thirdscreen.dart';
import '../onboarding_controller.dart';
 
// import 'onboarding_screen3.dart';

class OnboardingFlow extends StatelessWidget {
  final controller = Get.put(OnboardingController());

  OnboardingFlow({super.key});

  final screens = [
      OnboardingScreen(),
      PermissionScreen(),
      AppSettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => screens[controller.pageIndex.value],
    );
  }
}