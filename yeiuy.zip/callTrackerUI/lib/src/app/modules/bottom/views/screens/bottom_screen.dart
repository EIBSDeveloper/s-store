// lib/modules/dashboard/view/main_dashboard.dart
import 'package:calltrackerui/src/app/modules/bottom/controller/bottom_controller.dart';
import 'package:calltrackerui/src/app/modules/callLogs/views/screens/call_logscreen.dart';
import 'package:calltrackerui/src/app/modules/dashboard/views/screens/dashboard_screen.dart';
import 'package:calltrackerui/src/app/modules/lead/views/screens/leadProfilescreen.dart';
import 'package:calltrackerui/src/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class BottomScreen extends GetView<BottomNavController> {
  const BottomScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Widget> screens = const [
      DashboardScreen(),
      CallLogsScreen(),
      LeadProfileScreen(),
    ];

    return Obx(
      () => Scaffold(
        backgroundColor: AppColors.background,
        body: screens[controller.currentIndex.value],
        bottomNavigationBar: Container(
          height: 80,
          decoration: BoxDecoration(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _navButton(controller, Icons.home_rounded, 'Home', 0),
                _navButton(controller, Icons.leaderboard_rounded, 'Calls', 1),
                _navButton(controller, Icons.person_rounded, 'Profile', 2),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _navButton(
    BottomNavController controller,
    IconData icon,
    String label,
    int index,
  ) {
    final bool active = controller.currentIndex.value == index;

    return GestureDetector(
      onTap: () => controller.changeTab(index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(12)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 26,
              color: active ? AppColors.primary : AppColors.textSecondary,
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: Get.textTheme.bodySmall?.copyWith(
                color: active ? AppColors.primary : AppColors.textSecondary,
                fontWeight: active ? FontWeight.w600 : FontWeight.w400,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
