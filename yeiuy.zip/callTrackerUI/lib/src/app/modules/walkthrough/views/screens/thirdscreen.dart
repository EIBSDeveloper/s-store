/*
import 'package:flutter/material.dart';

class AppSettingsScreen extends StatefulWidget {
  const AppSettingsScreen({super.key});

  @override
  State<AppSettingsScreen> createState() => _AppSettingsScreenState();
}

class _AppSettingsScreenState extends State<AppSettingsScreen> {
  bool is12Hour = true;
  double fontSize = 50;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDark
          ? const Color(0xFF101922)
          : const Color(0xFFF6F7F8),
      body: SafeArea(
        child: Column(
          children: [
            // Top header
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Left progress bars
                  Row(
                    children: [
                      _progressDot(isDark, active: false),
                      const SizedBox(width: 6),
                      _progressDot(isDark, active: false),
                      const SizedBox(width: 6),
                      _progressBar(),
                    ],
                  ),

                  // Skip
                  TextButton(
                    onPressed: () {},
                    child: const Text(
                      "Skip",
                      style: TextStyle(
                        color: Color(0xFF16A34A),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Title
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "App Settings",
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF0D141B),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "Customize your experience. These settings can be changed later.",
                      style: TextStyle(
                        fontSize: 15,
                        color: isDark
                            ? Colors.grey[300]
                            : const Color(0xFF516374),
                      ),
                    ),
                    const SizedBox(height: 20),

                    /// Time Format card
                    _buildTimeFormatCard(isDark),

                    const SizedBox(height: 16),

                    /// Timezone Card
                    _buildSimpleCard(
                      isDark,
                      icon: Icons.public,
                      title: "Timezone",
                      subtitle: "Select your local timezone.",
                      trailing: Row(
                        children: [
                          Text(
                            "GMT-5:00",
                            style: TextStyle(
                              color: isDark
                                  ? Colors.grey[300]
                                  : Colors.grey[700],
                              fontSize: 14,
                            ),
                          ),
                          const SizedBox(width: 4),
                          Icon(
                            Icons.arrow_forward_ios,
                            size: 16,
                            color: Colors.grey[500],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 16),

                    /// Language Card
                    _buildSimpleCard(
                      isDark,
                      icon: Icons.translate,
                      title: "Language",
                      subtitle: "Choose your preferred language.",
                      trailing: Row(
                        children: [
                          Text(
                            "English (US)",
                            style: TextStyle(
                              color: isDark
                                  ? Colors.grey[300]
                                  : Colors.grey[700],
                            ),
                          ),
                          const SizedBox(width: 4),
                          Icon(
                            Icons.arrow_forward_ios,
                            size: 16,
                            color: Colors.grey[500],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 16),

                    /// Font Size Card
                    _buildFontSizeCard(isDark),
                  ],
                ),
              ),
            ),

            // Bottom Button
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 15),
              child: SizedBox(
                height: 56,
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF16A34A),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(50),
                    ),
                    shadowColor: const Color(0xFF16A34A).withOpacity(0.3),
                    elevation: 8,
                  ),
                  onPressed: () {},
                  child: const Text(
                    "Finish Setup",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // UI Helpers ----------------------------------------------------

  Widget _progressDot(bool isDark, {required bool active}) {
    return Container(
      height: 8,
      width: 8,
      decoration: BoxDecoration(
        color: active
            ? const Color(0xFF16A34A)
            : const Color(0xFF16A34A).withOpacity(0.3),
        borderRadius: BorderRadius.circular(20),
      ),
    );
  }

  Widget _progressBar() {
    return Container(
      height: 8,
      width: 30,
      decoration: BoxDecoration(
        color: const Color(0xFF16A34A),
        borderRadius: BorderRadius.circular(20),
      ),
    );
  }

  Widget _buildTimeFormatCard(bool isDark) {
    return _settingsCard(
      isDark,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _iconTitle(
            isDark,
            icon: Icons.schedule,
            title: "Time Format",
            subtitle: "Choose 12-hour or 24-hour format.",
          ),
          const SizedBox(height: 12),

          /// Buttons
          Row(
            children: [
              Expanded(
                child: _optionButton(
                  isSelected: is12Hour,
                  text: "12-hour",
                  onTap: () => setState(() => is12Hour = true),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _optionButton(
                  isSelected: !is12Hour,
                  text: "24-hour",
                  onTap: () => setState(() => is12Hour = false),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSimpleCard(
    bool isDark, {
    required IconData icon,
    required String title,
    required String subtitle,
    required Widget trailing,
  }) {
    return _settingsCard(
      isDark,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _iconTitle(isDark, icon: icon, title: title, subtitle: subtitle),
          trailing,
        ],
      ),
    );
  }

  Widget _buildFontSizeCard(bool isDark) {
    return _settingsCard(
      isDark,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _iconTitle(
            isDark,
            icon: Icons.format_size,
            title: "Font Size",
            subtitle: "Adjust text size for better readability.",
          ),
          const SizedBox(height: 16),

          Slider(
            value: fontSize,
            min: 0,
            max: 100,
            activeColor: const Color(0xFF16A34A),
            inactiveColor: const Color(0xFFDCFCE7),
            onChanged: (value) => setState(() => fontSize = value),
          ),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _label("Small", isDark),
              _label("Default", isDark),
              _label("Large", isDark),
            ],
          ),
        ],
      ),
    );
  }

  Widget _settingsCard(bool isDark, {required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E293B) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFDDE2E9),
        ),
      ),
      child: child,
    );
  }

  Widget _iconTitle(
    bool isDark, {
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Row(
      children: [
        Container(
          height: 48,
          width: 48,
          decoration: BoxDecoration(
            color: isDark
                ? Colors.green.shade900.withOpacity(0.4)
                : Colors.green.shade100,
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: const Color(0xFF16A34A), size: 26),
        ),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(
                color: isDark ? Colors.white : const Color(0xFF0D141B),
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            Text(
              subtitle,
              style: TextStyle(
                color: isDark ? Colors.grey[300] : const Color(0xFF516374),
                fontSize: 13,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _optionButton({
    required bool isSelected,
    required String text,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 48,
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF16A34A) : Colors.white,
          borderRadius: BorderRadius.circular(50),
          border: Border.all(
            color: isSelected
                ? const Color(0xFF16A34A)
                : const Color(0xFFDDE2E9),
          ),
        ),
        child: Center(
          child: Text(
            text,
            style: TextStyle(
              color: isSelected ? Colors.white : Colors.grey[700],
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget _label(String text, bool isDark) {
    return Text(
      text,
      style: TextStyle(
        color: isDark ? Colors.grey[300] : Colors.grey[600],
        fontSize: 12,
      ),
    );
  }
}
*/
import 'package:calltrackerui/src/app/modules/walkthrough/controller/onboardingcontroller.dart';
import 'package:calltrackerui/src/core/app_colors.dart';
import 'package:calltrackerui/src/core/app_style.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../bottombar/views/screens/home.dart';
import '../../../onboading/onboarding_controller.dart';

class AppSettingsScreen extends GetView<OnboardingController> {
  AppSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Get.theme.textTheme;
    final isDark = Get.isDarkMode;

    return Scaffold(
      backgroundColor: isDark
          ? AppColors.backgroundDark
          : AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _header(),

            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("App Settings", style: theme.titleLarge),
                    const SizedBox(height: 8),
                    Text(
                      "Customize your experience. These settings can be changed later.",
                      style: theme.bodyMedium?.copyWith(
                        color: isDark
                            ? AppColors.textLight
                            : AppColors.textSecondary,
                      ),
                    ),

                    const SizedBox(height: 8),

                    _card(
                      isDark,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _iconTitle(
                            isDark,
                            icon: Icons.schedule,
                            title: "Time Format",
                            subtitle: "Choose 12-hour or 24-hour format.",
                          ),
                          const SizedBox(height: 8),

                          Obx(
                            () => Row(
                              children: [
                                Expanded(
                                  child: _optionButton(
                                    text: "12-hour",
                                    isSelected: controller.is12Hour.value,
                                    onTap: () =>
                                        controller.changeTimeFormat(true),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: _optionButton(
                                    text: "24-hour",
                                    isSelected: !controller.is12Hour.value,
                                    onTap: () =>
                                        controller.changeTimeFormat(false),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 8),

                    _card(
                      isDark,
                      child: Row(
                        children: [
                          Expanded(
                            child: _iconTitle(
                              isDark,
                              icon: Icons.public,
                              title: "Timezone",
                              subtitle: "Select your local timezone.",
                            ),
                          ),
                          Row(
                            children: [
                              Text(
                                "GMT-5:00",
                                style: theme.bodyMedium?.copyWith(
                                  color: isDark
                                      ? AppColors.textLight
                                      : AppColors.textSecondary,
                                ),
                              ),
                              const SizedBox(width: 4),
                              Icon(
                                Icons.arrow_forward_ios,
                                size: 16,
                                color: isDark
                                    ? AppColors.textLight
                                    : Colors.grey,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 8),

                    _card(
                      isDark,
                      child: Row(
                        children: [
                          Expanded(
                            child: _iconTitle(
                              isDark,
                              icon: Icons.translate,
                              title: "Language",
                              subtitle: "Choose your preferred language.",
                            ),
                          ),
                          Row(
                            children: [
                              Text(
                                "English (US)",
                                style: theme.bodyMedium?.copyWith(
                                  color: isDark
                                      ? AppColors.textLight
                                      : AppColors.textSecondary,
                                ),
                              ),
                              const SizedBox(width: 4),
                              Icon(
                                Icons.arrow_forward_ios,
                                size: 16,
                                color: Colors.grey,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 8),

                    _card(
                      isDark,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _iconTitle(
                            isDark,
                            icon: Icons.format_size,
                            title: "Font Size",
                            subtitle:
                                "Adjust text size for better readability.",
                          ),
                          // const SizedBox(height: 8),

                          Obx(
                            () => Slider(
                              value: controller.fontSize.value,
                              min: 0,
                              max: 100,
                              activeColor: AppColors.primary,
                              inactiveColor: AppColors.primary10(0.4),
                              onChanged: controller.changeFontSize,
                            ),
                          ),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("Small", style: theme.bodySmall),
                              Text("Default", style: theme.bodySmall),
                              Text("Large", style: theme.bodySmall),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            _finishButton(),
          ],
        ),
      ),
    );
  }

  // ----------------- UI COMPONENTS ----------------------

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              _dot(false),
              const SizedBox(width: 6),
              _dot(false),
              const SizedBox(width: 6),
              _bar(),
            ],
          ),
         TextButton(
                    onPressed: controller.skip,
                    child: Text(
                      "Skip",
                      style: Get.theme.textTheme.bodyMedium?.copyWith(
                        color: AppColors.primary,
                        fontWeight: FontWeight.bold
                      ),
                    ),
                  ),
        ],
      ),
    );
  }

  Widget _dot(bool active) {
    return Container(
      height: 8,
      width: 8,
      decoration: BoxDecoration(
        color: active ? AppColors.primary : AppColors.primary10(0.3),
        borderRadius: BorderRadius.circular(50),
      ),
    );
  }

  Widget _bar() {
    return Container(
      height: 8,
      width: 32,
      decoration: BoxDecoration(
        color: AppColors.primary,
        borderRadius: BorderRadius.circular(50),
      ),
    );
  }

  Widget _finishButton() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      child: SizedBox(
        height: 56,
        width: double.infinity,
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primary,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(50),
            ),
            shadowColor: AppColors.primary.withOpacity(0.3),
            elevation: 8,
          ),
          onPressed: () {
            Get.offAll(Home());
          },
          child: Text(
            "Finish Setup",
            style: Get.theme.textTheme.bodyMedium?.copyWith(
              color: AppColors.card,
            ),
          ),
        ),
      ),
    );
  }

  Widget _card(bool isDark, {required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.backgroundDark : AppColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: child,
    );
  }

  Widget _iconTitle(
    bool isDark, {
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    final theme = Get.theme.textTheme;

    return Row(
      children: [
        Container(
          height: 48,
          width: 48,
          decoration: BoxDecoration(
            color: AppColors.primary.withAlpha(20),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: AppColors.primary, size: AppStyle.iconSize),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: theme.bodyMedium?.copyWith(
                fontWeight: FontWeight.bold
              )),
              Text(subtitle, style: theme.bodySmall),
            ],
          ),
        ),
      ],
    );
  }

  Widget _optionButton({
    required bool isSelected,
    required String text,
    required VoidCallback onTap,
  }) {
    final theme = Get.theme.textTheme;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 30,
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primary : AppColors.card,
          borderRadius: BorderRadius.circular(50),
          border: Border.all(color: AppColors.primary),
        ),
        alignment: Alignment.center,
        child: Text(
          text,
          style: theme.bodyMedium?.copyWith(
            color: isSelected ? Colors.white : AppColors.textPrimary,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
