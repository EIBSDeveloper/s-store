// lib/modules/permissions/permission_screen.dart

import 'package:calltrackerui/src/app/modules/walkthrough/controller/onboardingcontroller.dart';
import 'package:calltrackerui/src/core/app_colors.dart';
import 'package:calltrackerui/src/core/app_style.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';

import '../../../onboading/onboarding_controller.dart';

class PermissionScreen extends GetView<OnboardingController> {
  PermissionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final textTheme = Get.textTheme;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            //----------------------------------------------------------
            // TOP SECTION (Dots + Skip)
            //----------------------------------------------------------
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      _dot(false),
                      const SizedBox(width: 6),
                      _dot(true), // Active dot
                      const SizedBox(width: 6),
                      _dot(false),
                    ],
                  ),
                  TextButton(
                    onPressed: controller.skip,
                    child: Text(
                      "Skip",
                      style: Get.theme.textTheme.bodyMedium?.copyWith(
                        color: AppColors.primary,
                        fontWeight: FontWeight.bold
                      ),
                    ),
                  ),
                ],
              ),
            ),

            //----------------------------------------------------------
            // MIDDLE CONTENT
            //----------------------------------------------------------
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    //------------------------------------------------
                    // TITLE
                    //------------------------------------------------
                    Text(
                      "App Permissions",
                      style: textTheme.titleLarge?.copyWith(
                        color: AppColors.textPrimary,
                      
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),

                    //------------------------------------------------
                    // SUBTEXT
                    //------------------------------------------------
                    Text(
                      "To work correctly, CallTrack needs a few permissions. Your data is always secure and private.",
                      style: textTheme.bodyMedium?.copyWith(
                        color: AppColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 28),

                    //------------------------------------------------
                    // PERMISSION CARDS
                    //------------------------------------------------
                    _permissionTile(
                      icon: HugeIcons.strokeRoundedCall02,
                      title: "Call Logs",
                      subtitle: "To track and analyze calls.",
                      toggle: controller.callLogs,
                      onToggle: controller.toggleCallLogs,
                    ),
                    const SizedBox(height: 14),

                    _permissionTile(
                      icon:HugeIcons.strokeRoundedAlbum01,
                      title: "App Overlay",
                      subtitle: "For caller ID popups.",
                      toggle: controller.overlay,
                      onToggle: controller.toggleOverlay,
                    ),
                    const SizedBox(height: 14),

                    _permissionTile(
                      icon: HugeIcons.strokeRoundedFolderSync,
                      title: "Storage",
                      subtitle: "To save call recordings.",
                      toggle: controller.storage,
                      onToggle: controller.toggleStorage,
                    ),
                    const SizedBox(height: 14),

                    _permissionTile(
                      icon: HugeIcons.strokeRoundedNotification01,
                      title: "Notifications",
                      subtitle: "For call reminders.",
                      toggle: controller.notifications,
                      onToggle: controller.toggleNotifications,
                    ),

                    const SizedBox(height: 24),

                    //------------------------------------------------
                    // Allow All Button
                    //------------------------------------------------
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: ElevatedButton(
                        onPressed: controller.allowAll,
                        
                        style: ElevatedButton.styleFrom(
                          elevation: 0,
                          backgroundColor: AppColors.primary.withAlpha(30),
                          foregroundColor: AppColors.primary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(40),
                          ),
                        ),
                        child: Text(
                          "Allow All",
                          style: textTheme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: AppColors.primary,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            //----------------------------------------------------------
            // BOTTOM CONTINUE BUTTON
            //----------------------------------------------------------
            Padding(
              padding: const EdgeInsets.only(
                left: 20,
                right: 20,
                bottom: 20,
                top: 10,
              ),
              child: SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: controller.next,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(40),
                    ),
                    shadowColor: AppColors.primary.withOpacity(0.3),
                    elevation: 8,
                  ),
                  child: Text(
                    "Continue",
                    style: textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: AppColors.card,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  //----------------------------------------------------------
  // DOT WIDGET
  //----------------------------------------------------------
  Widget _dot(bool active) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      width: active ? 32 : 8,
      height: 8,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: active ? AppColors.primary : AppColors.primary.withOpacity(0.3),
      ),
    );
  }

  //----------------------------------------------------------
  // PERMISSION TILE
  //----------------------------------------------------------
  Widget _permissionTile({
    required List<List<dynamic>>  icon,
    required String title,
    required String subtitle,
    required RxBool toggle,
    required VoidCallback onToggle,
  }) {
    final textTheme = Get.textTheme;

    return Obx(
      () => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            //------------------------------------------
            // Icon + Title + Subtitle
            //------------------------------------------
            Row(
              children: [
                Container(
                  height: 48,
                  width: 48,
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withAlpha(30),
                    borderRadius: BorderRadius.circular(40),
                  ),
                  child: HugeIcon(
  icon:icon,
  color:AppColors.primary,
  size:AppStyle.iconSize
),
                  
                  //  Icon(icon, color: , size: AppStyle.iconSize),
                ),
                const SizedBox(width: 14),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: textTheme.bodySmall?.copyWith(
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ],
            ),

            //------------------------------------------
            // Toggle Switch
            //------------------------------------------
            GestureDetector(
              onTap: onToggle,
              child: Container(
                width: 50,
                height: 26,
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  color: toggle.value
                      ? AppColors.primary
                      : Colors.grey.shade400,
                  borderRadius: BorderRadius.circular(40),
                ),
                child: AnimatedAlign(
                  duration: const Duration(milliseconds: 200),
                  alignment: toggle.value
                      ? Alignment.centerRight
                      : Alignment.centerLeft,
                  child: Container(
                    width: 18,
                    height: 18,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(40),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
