import 'package:calltrackerui/src/app/modules/payment_tracker/controller/customercontroller.dart';
import 'package:calltrackerui/src/app/modules/payment_tracker/view/screens/customerdetailscreen.dart';
import 'package:calltrackerui/src/app/modules/payment_tracker/view/screens/schedulescreen.dart';
import 'package:calltrackerui/src/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hugeicons/hugeicons.dart';

import '../../../../../core/app_style.dart';

class CustomerScreen extends GetView<CustomerController> {
  CustomerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Get.isDarkMode;
    final theme = Get.theme.textTheme;

    return Scaffold(
      backgroundColor: isDark ? AppColors.backgroundDark : AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            // HEADER
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
              decoration: BoxDecoration(
                color: isDark ? AppColors.backgroundDark : AppColors.background,
                border: Border(
                  // bottom: BorderSide(
                  //   color: isDark ? Colors.grey[700]! : Colors.grey[300]!,
                  // ),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      "Customers",
                      style: theme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: isDark
                            ? AppColors.textLight
                            : AppColors.textDark,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: HugeIcon(
                      icon: HugeIcons.strokeRoundedNotification01,
                      // color: widget.backgroundColor,
                      size: AppStyle.iconSize,
                    ),
                    color: AppColors.textSecondary,
                  ),
                ],
              ),
            ),

            // // SEARCH BAR
            // Container(
            //   padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            //   color: isDark
            //       ? AppColors.backgroundDark
            //       : AppColors.backgroundLight,
            //   child: TextField(
            //     style: theme.bodyMedium?.copyWith(
            //       color: isDark ? Colors.white : AppColors.textDark,
            //     ),
            //     decoration: InputDecoration(
            //       prefixIcon: Padding(
            //       padding: const EdgeInsets.all(10.0),
            //       child: const HugeIcon(
            //                  icon:    HugeIcons.strokeRoundedSearch01,
            //         color: AppColors.textSecondary,
            //       ),
            //     ),
            //       hintText: "Search by name or ID...",
            //       hintStyle: theme.bodyMedium?.copyWith(
            //         color: isDark ? Colors.grey[400] : Colors.grey[600],
            //       ),
            //       filled: true,
            //       fillColor: isDark ? Colors.grey[800] : Colors.white,
            //       border: OutlineInputBorder(
            //         borderRadius: BorderRadius.circular(12),
            //         borderSide: BorderSide.none,
            //       ),
            //     ),
            //   ),
            // ),
            _searchBar(),
            SizedBox(height: 8),
            // FILTER CHIPS
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
              child: SizedBox(
                height: 35,
                child: ListView(
                
                  scrollDirection: Axis.horizontal,
                  children: [
                    _filterChip("All POS", selected: true, isDark: isDark),
                    const SizedBox(width: 10),
                    _filterChip("Proposal Status", isDark: isDark),
                    const SizedBox(width: 10),
                    _filterChip("Reminder Status", isDark: isDark),
                  ],
                ),
              ),
            ),
            // Container(
            //   margin: EdgeInsets.only(left: 20, top: 20),
            //   child: Row(children: [_statusRow()]),
            // ),
            // CUSTOMER LIST
            Expanded(
              child: Obx(
                () => ListView.separated(
                  padding: const EdgeInsets.all(10),
                  itemCount: controller.customers.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 5),
                  itemBuilder: (context, index) {
                    final customer = controller.customers[index];
                    return CustomerCard(customer: customer);
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _searchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              decoration: InputDecoration(
                hintText: "Search by name or number...",
                prefixIcon: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: const HugeIcon(
                    icon: HugeIcons.strokeRoundedSearch01,
                    color: AppColors.textSecondary,
                  ),
                ),
                filled: true,
                fillColor: AppColors.card,
                contentPadding: const EdgeInsets.symmetric(vertical: 8),
                enabledBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: AppColors.border),
                  borderRadius: BorderRadius.circular(12),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: AppColors.primary),
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),

          // SizedBox(width: 10),
          // Container(
          //   width: 42,
          //   height: 42,
          //   padding: EdgeInsets.all(10),
          //   decoration: BoxDecoration(
          //     color: AppColors.card,
          //     shape: BoxShape.circle,
          //     boxShadow: [
          //       BoxShadow(
          //         color: AppColors.textSecondary.withOpacity(0.1),
          //         blurRadius: 4,
          //       ),
          //     ],
          //   ),
          //   child: const HugeIcon(icon:HugeIcons.strokeRoundedPreferenceHorizontal, color: AppColors.textPrimary),
          // ),
        ],
      ),
    );
  }

  // Filter Chip Widget
  Widget _filterChip(
    String label, {
    bool selected = false,
    bool isDark = false,
  }) {
    final theme = Get.theme.textTheme;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: selected
            ? AppColors.primary.withOpacity(0.25)
            : (isDark ? Colors.grey[800] : Colors.white),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        children: [
          Text(
            label,
            style: theme.bodyMedium?.copyWith(
              color: selected
                  ? AppColors.primary
                  : (isDark ? Colors.white : AppColors.textDark),
            ),
          ),
          const SizedBox(width: 4),
          Icon(
            Icons.expand_more,
            color: selected
                ? AppColors.primary
                : (isDark ? Colors.white : AppColors.textDark),
            size: 20,
          ),
        ],
      ),
    );
  }
}

Widget _statusRow() {
  final theme = Get.theme.textTheme;

  return Row(
    children: [
      _dot(Colors.teal[800]!),
      const SizedBox(width: 6),
      Text("Proposal", style: theme.bodySmall),

      const SizedBox(width: 14),

      _dot(Colors.red[800]!),
      const SizedBox(width: 6),
      Text("Sent", style: theme.bodySmall),

      const SizedBox(width: 14),

      _dot(Colors.grey[800]!),
      const SizedBox(width: 6),
      Text("Draft", style: theme.bodySmall),

      const SizedBox(width: 14),

      _dot(Colors.yellow[800]!),
      const SizedBox(width: 6),
      Text("Scheduled", style: theme.bodySmall),
    ],
  );
}

Widget _dot(Color color) {
  return Container(
    height: 10,
    width: 10,
    decoration: BoxDecoration(color: color, shape: BoxShape.circle),
  );
}

class CustomerCard extends StatelessWidget {
  final Customer customer;

  const CustomerCard({required this.customer, super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Get.isDarkMode;
    final theme = Get.theme.textTheme;

    return GestureDetector(
      onTap: () {
        Get.to(CustomerDetailsScreen());
      },
      child: Container(
        decoration: BoxDecoration(
          color: isDark ? Colors.grey[800] : Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: isDark ? Colors.black26 : Colors.grey.withOpacity(0.15),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        padding: const EdgeInsets.all(10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Profile Image
            Container(
              height: 40,
              width: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                image: DecorationImage(
                  image: NetworkImage(customer.profileImage),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(width: 8),

            // Customer Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    customer.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: isDark ? Colors.white : AppColors.textDark,
                    ),
                  ),
                  Text(
                    " ID: ${customer.id}",
                    style: theme.bodySmall?.copyWith(
                      color: isDark
                          ? Colors.grey[400]
                          : AppColors.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 6),

                  Wrap(
                    spacing: 6,
                    runSpacing: 4,
                    children: [
                      _proposalChip(customer.proposalStatus, isDark),

                      if (customer.reminderStatus != null)
                        _reminderChip(customer.reminderStatus!, isDark),
                    ],
                  ),
                ],
              ),
            ),

            // Right Side Amount + Arrow
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  customer.dueAmount,
                  style: theme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: isDark ? Colors.white : AppColors.danger,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "Due",
                  style: theme.bodyMedium?.copyWith(
                    // fontWeight: FontWeight.bold,
                    color: isDark ? Colors.white : AppColors.textDark,
                  ),
                ),
                // GestureDetector(
                //   onTap: () {
                //     Get.to(SchedulesScreen());
                //   },
                //   child: Icon(
                //     Icons.chevron_right,
                //     color: isDark ? Colors.grey[400] : Colors.grey[600],
                //   ),
                // ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _proposalChip(String status, bool isDark) {
    final theme = Get.theme.textTheme;

    Color textColor;
    Color bgColor;

    switch (status.toLowerCase()) {
      case "accepted":
        textColor = const Color(0xFF0A6F5A);
        bgColor = const Color(0xFFD7F3EC);
        break;

      case "sent":
        textColor = const Color(0xFF0D47A1);
        bgColor = const Color(0xFFDCE8FF);
        break;

      case "draft":
        textColor = Colors.grey[800]!;
        bgColor = const Color(0xFFE8E8E8);
        break;

      default:
        textColor = Colors.grey[700]!;
        bgColor = Colors.grey[300]!;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bgColor.withAlpha(140),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        "Proposal: $status",
        style: theme.bodySmall?.copyWith(
          fontWeight: FontWeight.w600,
          color: textColor,
        ),
      ),
    );
  }

  Widget _reminderChip(String status, bool isDark) {
    final theme = Get.theme.textTheme;

    Color textColor;
    Color bgColor;

    switch (status.toLowerCase()) {
      case "sent":
        textColor = const Color(0xFFB71C1C);
        bgColor = const Color(0xFFFFDAD6);
        break;

      case "scheduled":
        textColor = const Color(0xFF8C5300);
        bgColor = const Color(0xFFFFE8C7);
        break;

      default:
        textColor = Colors.grey[700]!;
        bgColor = Colors.grey[300]!;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bgColor.withAlpha(140),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        "Reminder: $status",
        style: theme.bodySmall?.copyWith(
          fontWeight: FontWeight.w600,
          color: textColor,
        ),
      ),
    );
  }
}
