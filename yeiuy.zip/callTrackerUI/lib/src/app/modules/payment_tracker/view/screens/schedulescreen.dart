import 'package:calltrackerui/src/app/modules/payment_tracker/controller/schedulecontroller.dart';
import 'package:calltrackerui/src/app/modules/payment_tracker/view/screens/addSchedule.dart';
import 'package:calltrackerui/src/core/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SchedulesScreen extends GetView<SchedulesController> {
  const SchedulesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // ensure controller is created
    final controller = Get.put(SchedulesController());
    final theme = Get.theme.textTheme;
    final isDark = Get.isDarkMode;

    return Scaffold(
      backgroundColor: isDark ? AppColors.backgroundDark : AppColors.background,
      body: SafeArea(
        child: Center(
          child: Column(
            children: [
              // Top App Bar
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 12,
                ),
                color: isDark
                    ? AppColors.backgroundDark
                    : AppColors.background,
                child: Row(
                  children: [
                    // Icon(
                    //   Icons.arrow_back,
                    //   color: isDark
                    //       ? AppColors.textLight
                    //       : AppColors.textPrimary,
                    // ),
                    // const SizedBox(width: 8),
                    Text(
                      'Payment Schedules',
                      textAlign: TextAlign.center,
                      style: theme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: isDark
                            ? AppColors.textLight
                            : AppColors.textPrimary,
                      ),
                    ),
                  ],
                ),
              ),
          
              // Search bar
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 10,
                ),
                color: isDark
                    ? AppColors.backgroundDark
                    : AppColors.background,
                child: TextField(
                  style: theme.bodyMedium?.copyWith(
                    color: isDark ? Colors.white : AppColors.textDark,
                  ),
                  decoration: InputDecoration(
                    prefixIcon: Icon(
                      Icons.search,
                      color: isDark ? Colors.grey[400] : Colors.grey[600],
                    ),
                    hintText: "Search by name or ID...",
                    hintStyle: theme.bodyMedium?.copyWith(
                      color: isDark ? Colors.grey[400] : Colors.grey[600],
                    ),
                    filled: true,
                    fillColor: isDark ? Colors.grey[800] : Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
          
              // chips
              Padding(
                padding: const EdgeInsets.only(
                  left: 12,
                  right: 12,
                  bottom: 6,
                ),
                child: SizedBox(
                  height: 44,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      const SizedBox(width: 4),
                      _filterChip(
                        'Sort by Due Date',
                        selected: true,
                        isDark: isDark,
                      ),
                      const SizedBox(width: 8),
                      _filterChip('Upcoming', isDark: isDark),
                      const SizedBox(width: 8),
                      _filterChip('Overdue', isDark: isDark),
                      const SizedBox(width: 8),
                      _filterChip('Paid', isDark: isDark),
                      const SizedBox(width: 8),
                    ],
                  ),
                ),
              ),
          
              // list
              Expanded(
                child: Obx(() {
                  final items = controller.schedules;
                  if (items.isEmpty) {
                    return SingleChildScrollView(
                      padding: const EdgeInsets.all(16),
                      child: _emptyState(theme, isDark),
                    );
                  }
          
                  return ListView.separated(
                    padding: const EdgeInsets.all(12),
                    itemCount:
                        items.length + 1, // +1 for empty spacer at bottom
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, index) {
                      if (index >= items.length) {
                        return const SizedBox(height: 24);
                      }
                      final s = items[index];
                      return _scheduleCard(s, theme, isDark);
                    },
                  );
                }),
              ),
            ],
          ),
        ),
      ),

      // floating add button (bottom-right)
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Get.to(NewSchedulePage());
        },
        backgroundColor: AppColors.primary,
        child: const Icon(Icons.add, color: AppColors.card),
      ),
    );
  }

  Widget _filterChip(
    String label, {
    bool selected = false,
    bool isDark = false,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: selected
            ? AppColors.primary.withOpacity(0.15)
            : (isDark ? Colors.grey[850] : Colors.grey[100]),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isDark ? Colors.grey[800]! : AppColors.border,
        ),
      ),
      child: Row(
        children: [
          Text(
            label,
            style: Get.theme.textTheme.bodyMedium?.copyWith(
              color: selected
                  ? AppColors.primary
                  : (isDark ? AppColors.textLight : AppColors.textPrimary),
            ),
          ),
          const SizedBox(width: 6),
          Icon(
            Icons.expand_more,
            size: 18,
            color: selected
                ? AppColors.primary
                : (isDark ? AppColors.textLight : AppColors.textPrimary),
          ),
        ],
      ),
    );
  }

  Widget _scheduleCard(PaymentSchedule s, TextTheme theme, bool isDark) {
    Color statusColor;
    Color statusBg;
    switch (s.statusLabel.toLowerCase()) {
      case 'overdue':
        statusColor = AppColors.danger;
        statusBg = AppColors.danger.withOpacity(0.12);
        break;
      case 'upcoming':
        statusColor = Colors.orange.shade700;
        statusBg = Colors.orange.shade100;
        break;
      case 'paid':
        statusColor = Colors.green.shade700;
        statusBg = Colors.green.shade100;
        break;
      default:
        statusColor = AppColors.textSecondary;
        statusBg = Colors.grey.shade200;
        break;
    }

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: isDark ? Colors.grey[850] : AppColors.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isDark ? Colors.grey[800]! : AppColors.border,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // title + status
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                s.title,
                style: Get.theme.textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: isDark ? AppColors.textLight : AppColors.textPrimary,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: statusBg,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  s.statusLabel,
                  style: Get.theme.textTheme.bodySmall?.copyWith(
                    color: statusColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
  //  const SizedBox(height: 8),
          Text(
            s.note,
            style: Get.theme.textTheme.bodySmall?.copyWith(
              color: AppColors.textSecondary,
            ),
          ),
          const SizedBox(height: 5),

          // progress + percent
          Row(
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    value: s.progress,
                    minHeight: 8,
                    backgroundColor: isDark
                        ? Colors.grey[800]
                        : Colors.grey[200],
                    valueColor: AlwaysStoppedAnimation<Color>(
                      AppColors.primary,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Text(
                '${(s.progress * 100).toStringAsFixed(0)}%',
                style: Get.theme.textTheme.bodyMedium?.copyWith(
                  color: isDark ? AppColors.textLight : AppColors.textPrimary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),

          const SizedBox(height: 8),

          // Paid / Remaining / Total
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Paid',
                      style: Get.theme.textTheme.bodySmall?.copyWith(
                        color: AppColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '₹${s.paid.toStringAsFixed(0)}',
                      style: Get.theme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      'Remaining',
                      style: Get.theme.textTheme.bodySmall?.copyWith(
                        color: AppColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '₹${s.remaining.toStringAsFixed(0)}',
                      style: Get.theme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'Total',
                      style: Get.theme.textTheme.bodySmall?.copyWith(
                        color: AppColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '₹${s.total.toStringAsFixed(0)}',
                      style: Get.theme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

       
        ],
      ),
    );
  }

  Widget _emptyState(TextTheme theme, bool isDark) {
    return Column(
      children: [
        Container(
          height: 120,
          decoration: BoxDecoration(
            color: isDark ? Colors.grey[850] : Colors.grey[50],
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.all(18),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 56,
                width: 56,
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Icon(
                  Icons.receipt_long,
                  size: 32,
                  color: AppColors.primary,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'No Payment Schedules Yet',
                style: theme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: isDark ? AppColors.textLight : AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Tap the \'+\' button to add your first payment schedule and start tracking.',
                style: theme.bodySmall?.copyWith(
                  color: AppColors.textSecondary,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 18,
                    vertical: 12,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.add, color: Colors.white),
                    const SizedBox(width: 8),
                    Text(
                      'Add New Schedule',
                      style: Get.theme.textTheme.bodyMedium?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
