// app_pages.dart

// import 'package:get/get.dart';

// import '../../modules/whatsapp/bindings/notes_binding.dart';
// import '../../modules/whatsapp/view/screens/note_detail_screen.dart';
// import '../../modules/whatsapp/view/screens/notes_screen.dart';
// import 'app_pages.dart';
// class Routes {
//   static final pages = [
//     GetPage(name: AppPages.splash, page: () => const SplashScreen()),
//     GetPage(name: AppPages.login, page: () => LoginPage()),
//     GetPage(name: AppPages.otp, page: () => OtpPage()),
//     GetPage(name: AppPages.home, page: () => const Home()),
//     GetPage(name: AppPages.leads, page: () => const LeadsPage()),
//     GetPage(name: AppPages.addLead, page: () => const AddLeadPage()),

//     GetPage(name: AppPages.dialPad, page: () => const DialPad()),

//     GetPage(
//       name: AppPages.todayFollowups,
//       page: () => const TodayFollowUpsPage(),
//     ),
//     GetPage(name: AppPages.followups, page: () => const FollowUpsPage()),
//     GetPage(name: AppPages.notification, page: () => const Notifications()),
//     GetPage(name: AppPages.addFollowup, page: () => const AddFollowUpPage()),
//     GetPage(name: AppPages.callRecord, page: () => CallRecordingScreen()),
//     // GetPage(name: Routes.test, page: () => const DetailPage()),
//     GetPage(
//       name: AppPages.logDetails,
//       page: () => const ClientDetailsScreen(),
//       binding: ClientBinding(),
//     ),

//     GetPage(
//       name: AppPages.whatsAppMessage,
//       page: () => const NotesScreen(),
//       binding: NotesBinding(),
//     ),
//     GetPage(
//       name: '/add-note',
//       page: () => const NoteDetailScreen(),
//       binding: NoteDetailBinding(),
//     ),
//     GetPage(
//       name: '/note-detail',
//       page: () => const NoteDetailScreen(),
//       binding: NoteDetailBinding(),
//     ),
//     GetPage(
//       name: AppPages.bot,
//       page: () => const SmartFarmView(),
//       binding: SmartFarmBinding(),
//     ),
//     GetPage(
//       name: AppPages.notes,
//       page: () => const MyNotesScreen(),
//       binding: MessageBinding(),
//     ),
//     GetPage(
//       name: AppPages.notesDetails,
//       page: () => const NoteDetailScreen(),
//       binding: BindingsBuilder(() {
//         MessageDetailBinding().dependencies();
//       }),
//     ),

//     GetPage(
//       name: AppPages.profile,
//       page: () => const Profilescreen(),
//       binding: ProfileBinding(),
//     ),
//   ];
// }
