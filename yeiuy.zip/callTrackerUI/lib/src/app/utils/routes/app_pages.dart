class AppPages {
  static const splash = '/';
  static const login = '/login';
  static const otp = '/otp';
  static const home = '/home';
  static const leads = '/leads';
  static const addLead = '/add-lead';
  static const dialPad = '/dialPad';
  static const leadDetails = '/lead-detail';
  static const todayFollowups = '/today-followups';
  static const followups = '/followups';
  static const addFollowup = '/add-followup';
  static const notification = '/notification';
  static const callRecord = '/call-record';
  static const test = '/test';
  static const logDetails = '/log-details';
  static const whatsAppMessage = '/whatsapp-message';
  static const bot = '/smart_farm';
  static const notes = '/notes-list';
  static const notesDetails = '/note-detail';
  static const profile = '/profile';
}
