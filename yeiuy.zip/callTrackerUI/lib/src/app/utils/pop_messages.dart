import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';





void showError(final String message) {
  // Skip showing toast for these error codes or generic error keywords
  if (message.contains('404') ||
   
      message.toLowerCase().contains('load') ||
      message.toLowerCase().contains('error')) {
    return;
  }

  // Show custom message if 502 found
  if (message.contains('502')) {
    Fluttertoast.showToast(
      msg: 'There is a problem with the server.',
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.red,
      textColor: Colors.white,
    );
    return;
  }

  // Remove "Exception" substring anywhere in the message if present
  String displayMessage = message.contains("Exception")
      ? message.replaceAll("Exception:", "").trim()
      : message;

  Fluttertoast.showToast(
    msg: displayMessage,
    toastLength: Toast.LENGTH_LONG,
    gravity: ToastGravity.BOTTOM,
    backgroundColor: Colors.red,
    textColor: Colors.white,
  );
}



void showSuccess(final String message) {
  Fluttertoast.showToast(
    msg: message,
    toastLength: Toast.LENGTH_LONG,
    gravity: ToastGravity.BOTTOM,
    backgroundColor: Colors.green,
    textColor: Colors.white,
  );
}

void showWarning(final String message) {
  Fluttertoast.showToast(
    msg: message,
    toastLength: Toast.LENGTH_LONG,
    gravity: ToastGravity.BOTTOM,
    backgroundColor: Colors.orangeAccent,
    textColor: Colors.white,
  );
}

void showDefaultGetXDialog(final String message) {
  Get.defaultDialog(
    title: 'Package Limit Reached',
    middleText: "You've reached your limit for adding new $message .",
    textConfirm: "Upgrade",
    textCancel: 'Close',
    radius: 10,
    onConfirm: () {
      Get.back();
      // Get.toNamed(Routes.subscriptionUsage);
    },
    onCancel: Get.back,
  );
}
