package com.example.calltrackerui

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
